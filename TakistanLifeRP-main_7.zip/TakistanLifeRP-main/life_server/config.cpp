class DefaultEventhandlers;
class CfgPatches {
	class life_server {
		units[] = { "C_man_1" };
		weapons[] = {};
		requiredAddons[] = { "A3_Data_F", "A3_Soft_F", "A3_Soft_F_Offroad_01", "A3_Characters_F" };
		fileName = "life_server.pbo";
		author = "Tonic";
	};
};

class CfgFunctions {
	class Life_System {
		tag = "SG";
		class warrants {
			file = "\life_server\Functions\warrants";
			class addWarrantsServ {};
			class delWarrantsServ {};
		};

		class MySQL {
			file = "\life_server\Functions\MySQL";
			class numberSafe {};
			class mresArray {};
			class asyncCall {};
			class mresToArray {};
			class insertVehicle {};
			class bool{};
			class mresString {};
		};

		class Jail_Sys {
			file = "\life_server\Functions\Jail";
			class jailPlayer {};
			class jailSaveTime {};
		};

		class Client_Code {
			file = "\life_server\Functions\Client";
		};
	};

	class TON_System {
		tag = "TON";
		class Systems {
			file = "\life_server\Functions\Systems";
			class cleanup {};
			class entityRespawned {};
			class getVehicles {};
			class vehicleDelete {};
			class transferOwnership {};
			class clientDisconnect {};
			class cleanupRequest {};
			class keyManagement {};
			class vehicleUpdate {};
			class recupkeyforHC {};
			class serverVehicleStore {};
			class insureVehicle {};
		};

		class Housing {
			file = "\life_server\Functions\Housing";
			class fetchPlayerHouses {};
			class initHouses {};
			class houseCleanup {};
			class houseGarage {};
		};

		class Gangs {
			file = "\life_server\Functions\Gangs";
			class queryPlayerGang {};
			class removeGang {};
		};

		class Actions {
			file = "\life_server\Functions\Actions";
			class pickupAction {};
		};
	};
};