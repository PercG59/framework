class DefaultEventhandlers;
class CfgPatches {
	class SG_HC {
		units[] = { "C_man_1" };
		weapons[] = {};
		requiredAddons[] = { "A3_Data_F", "A3_Soft_F", "A3_Soft_F_Offroad_01", "A3_Characters_F" };
		fileName = "SG_HC.pbo";
		author = "Tonic";
	};
};

class CfgFunctions {
	class Headless_System {
		tag = "SG";

		class MySQL {
			file = "\SG_HC\Functions\MySQL";
			class numberSafe {};
			class mresArray {};
			class asyncCall {};
			class mresToArray {};
			class insertVehicle {};
			class bool{};
			class mresString {};
		};
	};
};