/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


CREATE DATABASE IF NOT EXISTS `takistanrp` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `takistanrp`;

CREATE TABLE IF NOT EXISTS `apartmentcontainers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(17) NOT NULL,
  `name` varchar(64) NOT NULL,
  `class` varchar(64) NOT NULL,
  `pos` varchar(64) NOT NULL,
  `gear` text NOT NULL,
  `inventory` text NOT NULL,
  `owned` tinyint(1) NOT NULL DEFAULT '0',
  `insert_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `apartments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(17) NOT NULL,
  `pos` varchar(64) NOT NULL,
  `class` varchar(64) NOT NULL,
  `number` varchar(64) NOT NULL,
  `owned` tinyint(1) NOT NULL DEFAULT '1',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rented_till` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `arrests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cop` varchar(17) NOT NULL,
  `civ` varchar(17) NOT NULL,
  `time` int(11) NOT NULL,
  `insert_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `auctions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `owner` varchar(17) NOT NULL,
  `type` enum('V-Item','Weapon','Item') NOT NULL,
  `class` text NOT NULL,
  `price` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `containers` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `pid` varchar(17) NOT NULL,
  `classname` varchar(32) NOT NULL,
  `pos` varchar(64) DEFAULT NULL,
  `inventory` text NOT NULL,
  `gear` text NOT NULL,
  `dir` varchar(128) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `owned` tinyint(1) DEFAULT '0',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `event` text NOT NULL,
  `data` text NOT NULL,
  `player_name` varchar(64) NOT NULL,
  `player_uid` varchar(17) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6522 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `gambling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(17) NOT NULL DEFAULT '',
  `opponent` varchar(17) NOT NULL DEFAULT '',
  `loss` tinyint(1) NOT NULL DEFAULT '0',
  `amount` int(100) NOT NULL DEFAULT '0',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=589 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `gangmoney` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL DEFAULT '',
  `money` int(100) NOT NULL DEFAULT '0',
  `gangid` int(32) NOT NULL DEFAULT '0',
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `gangs` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `owner` varchar(32) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `members` text,
  `maxmembers` int(3) DEFAULT '20',
  `bank` int(100) DEFAULT '0',
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tasks` text,
  `color` varchar(50) NOT NULL DEFAULT '[0.713726,0.713726,0.713726]',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name_UNIQUE` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

CREATE TABLE IF NOT EXISTS `gangshedcontainers` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `gang_id` int(6) NOT NULL,
  `pos` varchar(64) DEFAULT NULL,
  `inventory` text NOT NULL,
  `gear` text NOT NULL,
  `dir` varchar(128) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `owned` tinyint(1) DEFAULT '0',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

CREATE TABLE IF NOT EXISTS `gangsheds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gang_id` int(11) NOT NULL,
  `gang_name` varchar(64) NOT NULL,
  `pos` varchar(64) NOT NULL,
  `class` varchar(64) NOT NULL,
  `owned` tinyint(1) NOT NULL DEFAULT '1',
  `pay_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `gangwars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gang_1` int(11) NOT NULL,
  `gang_2` int(11) NOT NULL,
  `gang_1_pid` varchar(17) NOT NULL DEFAULT '',
  `gang_2_pid` varchar(17) NOT NULL DEFAULT '',
  `war_cancel` varchar(17) DEFAULT '',
  `start_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`start_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `houses` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `pid` varchar(17) NOT NULL,
  `pos` varchar(64) DEFAULT NULL,
  `class` varchar(100) NOT NULL,
  `owned` tinyint(1) DEFAULT '0',
  `garage` tinyint(1) NOT NULL DEFAULT '0',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tax_paydate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`,`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

CREATE TABLE IF NOT EXISTS `kills` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `killer` varchar(17) NOT NULL,
  `victim` varchar(17) NOT NULL,
  `killer_side` enum('1','2','3','4') NOT NULL,
  `victim_side` enum('1','2','3','4') NOT NULL,
  `killer_group` int(7) NOT NULL,
  `victim_group` int(7) NOT NULL,
  `weapon` varchar(50) NOT NULL,
  `warzone` tinyint(1) NOT NULL DEFAULT '0',
  `gangwar` tinyint(1) NOT NULL DEFAULT '0',
  `distance` int(11) NOT NULL,
  `insert_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1575 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `loadouts` (
  `uid` int(6) NOT NULL AUTO_INCREMENT,
  `pid` varchar(17) NOT NULL,
  `name` varchar(64) NOT NULL,
  `data` text NOT NULL,
  `side` enum('1','2','3','4') NOT NULL DEFAULT '1',
  `insert_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`uid`),
  KEY `name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `messages` (
  `uid` int(12) NOT NULL AUTO_INCREMENT,
  `fromID` varchar(50) NOT NULL,
  `toID` varchar(50) NOT NULL,
  `message` text,
  `fromName` varchar(32) NOT NULL,
  `toName` varchar(32) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`uid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

CREATE TABLE IF NOT EXISTS `players` (
  `uid` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `aliases` text NOT NULL,
  `pid` varchar(17) NOT NULL,
  `exp_total` int(11) NOT NULL DEFAULT '0',
  `exp_level` int(11) NOT NULL DEFAULT '0',
  `cash` int(100) NOT NULL DEFAULT '20',
  `bankacc` int(100) NOT NULL DEFAULT '0',
  `warpoints` int(100) NOT NULL DEFAULT '0',
  `wealth_tax` int(11) NOT NULL DEFAULT '0',
  `last_wealth` int(100) NOT NULL DEFAULT '0',
  `taxamount` int(100) NOT NULL DEFAULT '0',
  `adminlevel` enum('0','1','2') NOT NULL DEFAULT '0',
  `coplevel` enum('0','1','2','3','4','5','6','7','8') NOT NULL DEFAULT '0',
  `copdept` enum('0','1','2','3','4') NOT NULL DEFAULT '0',
  `opflevel` enum('0','1','2','3','4','5','6','7','8') NOT NULL DEFAULT '0',
  `opfdept` enum('0','1','2','3','4') NOT NULL DEFAULT '0',
  `mediclevel` enum('0','1','2','3','4') NOT NULL DEFAULT '0',
  `medicdept` enum('0','1') NOT NULL DEFAULT '0',
  `donorlevel` enum('0','1','2','3') NOT NULL DEFAULT '0',
  `civ_licenses` text NOT NULL,
  `cop_licenses` text NOT NULL,
  `med_licenses` text NOT NULL,
  `opf_licenses` text NOT NULL,
  `civ_gear` text NOT NULL,
  `cop_gear` text NOT NULL,
  `med_gear` text NOT NULL,
  `opf_gear` text NOT NULL,
  `civ_stats` varchar(32) NOT NULL DEFAULT '[100,100,0]',
  `cop_stats` varchar(32) NOT NULL DEFAULT '[100,100,0]',
  `med_stats` varchar(32) NOT NULL DEFAULT '[100,100,0]',
  `opf_stats` varchar(32) NOT NULL DEFAULT '[100,100,0]',
  `arrested` tinyint(1) NOT NULL DEFAULT '0',
  `blacklist` tinyint(1) NOT NULL DEFAULT '0',
  `civ_alive` tinyint(1) NOT NULL DEFAULT '0',
  `civ_position` varchar(64) NOT NULL DEFAULT '[]',
  `playtime` varchar(64) NOT NULL DEFAULT '[0,0,0,0]',
  `playtime_week` varchar(64) NOT NULL DEFAULT '[0,0,0,0]',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_seen` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `exp_perkPoints` int(11) NOT NULL DEFAULT '0',
  `exp_perks` text,
  `achievements` text,
  `jail_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `pid` (`pid`),
  FULLTEXT KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

CREATE TABLE IF NOT EXISTS `revival` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reviver` varchar(17) NOT NULL,
  `revivee` varchar(17) NOT NULL,
  `pos` varchar(64) NOT NULL,
  `map_grid` varchar(16) NOT NULL,
  `side` enum('1','2','3','4') NOT NULL DEFAULT '1',
  `type` enum('1','2') NOT NULL,
  `insert_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `rewards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(17) NOT NULL DEFAULT '0',
  `last_login` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reward_amount` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `PID` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(17) NOT NULL,
  `combat_logs` int(11) NOT NULL DEFAULT '0' COMMENT 'Times disconneted while dead',
  `bloodbag` int(11) NOT NULL DEFAULT '0' COMMENT 'Stable someone',
  `arrests` int(11) NOT NULL DEFAULT '0' COMMENT 'People arrested',
  `arrested` int(11) NOT NULL DEFAULT '0' COMMENT 'Times arrested',
  `arrested_time` int(11) NOT NULL DEFAULT '0' COMMENT 'Time spent arrested',
  `arrested_escapes` int(11) NOT NULL DEFAULT '0' COMMENT 'Broken out',
  `arrested_served` int(11) NOT NULL DEFAULT '0' COMMENT 'Waited time',
  `arrested_bails` int(11) NOT NULL DEFAULT '0' COMMENT 'Times paid bail',
  `gambling_won` int(11) NOT NULL DEFAULT '0' COMMENT 'Winnings',
  `gambling_lost` int(11) NOT NULL DEFAULT '0' COMMENT 'Losing',
  `gambling_bet` int(11) NOT NULL DEFAULT '0' COMMENT 'Amount Bets',
  PRIMARY KEY (`id`),
  UNIQUE KEY `pid` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(20) NOT NULL,
  `officer` varchar(50) NOT NULL,
  `officer_pid` varchar(17) NOT NULL,
  `price` int(11) NOT NULL,
  `reason` text NOT NULL,
  `issuedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `paid` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `vehicles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `side` varchar(16) NOT NULL,
  `classname` varchar(64) NOT NULL,
  `type` varchar(16) NOT NULL,
  `pid` varchar(17) NOT NULL,
  `alive` tinyint NOT NULL DEFAULT '1',
  `blacklist` tinyint NOT NULL DEFAULT '0',
  `active` tinyint NOT NULL DEFAULT '0',
  `plate` varchar(10) NOT NULL,
  `color` text NOT NULL,
  `parts` text NOT NULL,
  `tuning` int NOT NULL DEFAULT '0',
  `inventory` text NOT NULL,
  `gear` text NOT NULL,
  `fuel` double NOT NULL DEFAULT '1',
  `damage` varchar(256) NOT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `impound` int NOT NULL DEFAULT '0',
  `insured` int NOT NULL DEFAULT '0',
  `stolen` tinyint NOT NULL,
  `original_owner` varchar(64) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `side` (`side`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=505 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

CREATE TABLE IF NOT EXISTS `vitems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` varchar(17) NOT NULL,
  `item` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL,
  `price` int(100) NOT NULL DEFAULT '0',
  `insert_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=934 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `warrants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(17) NOT NULL,
  `crime_id` int(11) NOT NULL,
  `insert_datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

DELIMITER //
CREATE EVENT `wealth tax` ON SCHEDULE EVERY 24 HOUR STARTS '2022-02-01 03:00:00' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
UPDATE `players` SET `wealth_tax`=round((bankacc+cash)-round((bankacc+cash)/100 * 98)) WHERE (bankacc+cash) > 1000000;

UPDATE `players` SET `bankacc`=round(((bankacc+cash)/100 * 98) - cash) WHERE (bankacc+cash) > 1000000;

UPDATE `players` SET `taxamount`=taxamount+GREATEST(((bankacc+cash)-last_wealth),0);
UPDATE `players` SET `last_wealth`=(bankacc+cash);
END//
DELIMITER ;

DELIMITER //
CREATE EVENT `property_tax` ON SCHEDULE EVERY 24 HOUR STARTS '2022-02-01 03:00:00' ON COMPLETION NOT PRESERVE ENABLE DO UPDATE houses SET property_tax = property_tax - 1//
DELIMITER ;

DELIMITER //
CREATE EVENT `playtimeWeekly` ON SCHEDULE EVERY 1 WEEK STARTS '2022-02-01 03:00:00' ON COMPLETION PRESERVE ENABLE DO BEGIN
	UPDATE players SET playtime_week = playtime;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `resetLifeVehicles`()
BEGIN
  UPDATE `vehicles` SET `active`= 0;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `deleteDeadVehicles`()
BEGIN
  DELETE FROM `vehicles` WHERE `alive` = 0;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `deleteOldContainers`()
BEGIN
  DELETE FROM `containers` WHERE `owned` = 0;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `deleteOldGangs`()
BEGIN
  DELETE FROM `gangs` WHERE `active` = 0;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `deleteOldHouses`()
BEGIN
  DELETE FROM `houses` WHERE `owned` = 0;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `deleteUnpaidHouses`()
BEGIN
  DELETE FROM `houses` WHERE `property_tax` = 0;
END//
DELIMITER ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
