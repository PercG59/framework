class RscButtonInvisible : RscButton {
	idc = -1;
	text = "";
	colorBackground[] = { 0, 0, 0, 0 };
	colorBackgroundActive[] = { 0, 0, 0, 0 };
	colorBackgroundDisabled[] = { 0, 0, 0, 0 };
	colorBorder[] = { 0, 0, 0, 0 };
	colorFocused[] = { 0, 0, 0, 0 };
};

class RscInteractionText : RscText {
	font = "RobotoCondensedLight";
	SizeEx = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) * 0.75)";
	Style = 0x02;
	Shadow = 0;
};

class SG_InteractionMenu {
	idd = 1000;
	movingenable = 0;
	enableSimulation = 0;
	onUnload = "SG_Int_Open = false;";
	class controlsBackground {
		class RscPicture_1208 : RscPicture {
			idc = 1200;
			//text = "\SG_Core\images\interaction\field_1.paa";
			colorText[]={0, 0, 0, 0.8};
		};

		class RscPicture_1207 : RscPicture {
			idc = 1201;
			//text = "\SG_Core\images\interaction\field_2.paa";
			colorText[]={0, 0, 0, 0.8};
		};

		class RscPicture_1200 : RscPicture {
			idc = 1202;
			//text = "\SG_Core\images\interaction\field_3.paa";
			colorText[]={0, 0, 0, 0.8};
		};

		class RscPicture_1201 : RscPicture {
			idc = 1203;
			//text = "\SG_Core\images\interaction\field_4.paa";
			colorText[]={0, 0, 0, 0.8};
		};

		class RscPicture_1203 : RscPicture {
			idc = 1204;
			//text = "\SG_Core\images\interaction\field_5.paa";
			colorText[]={0, 0, 0, 0.8};
		};

		class RscPicture_1204 : RscPicture {
			idc = 1205;
			//text = "\SG_Core\images\interaction\field_6.paa";
			colorText[]={0, 0, 0, 0.8};
		};

		class RscPicture_1205 : RscPicture {
			idc = 1206;
			//text = "\SG_Core\images\interaction\field_7.paa";
			colorText[]={0, 0, 0, 0.8};
		};

		class RscPicture_1206 : RscPicture {
			idc = 1207;
			//text = "\SG_Core\images\interaction\field_8.paa";
			colorText[]={0, 0, 0, 0.8};
		};

		class RscPictureActive_1208 : RscPicture {
			idc = 1100;
			text = "\SG_Core\images\interaction\field_1.paa";
			colorText[]={"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.3843])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.7019])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.8862])", "1"};
			onLoad = "(_this select 0) ctrlShow false;";
		};

		class RscPictureActive_1207 : RscPicture {
			idc = 1101;
			text = "\SG_Core\images\interaction\field_2.paa";
			colorText[]={"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.3843])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.7019])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.8862])", "1"};
			onLoad = "(_this select 0) ctrlShow false;";
		};

		class RscPictureActive_1200 : RscPicture {
			idc = 1102;
			text = "\SG_Core\images\interaction\field_3.paa";
			colorText[]={"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.3843])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.7019])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.8862])", "1"};
			onLoad = "(_this select 0) ctrlShow false;";
		};

		class RscPictureActive_1201 : RscPicture {
			idc = 1103;
			text = "\SG_Core\images\interaction\field_4.paa";
			colorText[]={"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.3843])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.7019])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.8862])", "1"};
			onLoad = "(_this select 0) ctrlShow false;";
		};

		class RscPictureActive_1203 : RscPicture {
			idc = 1104;
			text = "\SG_Core\images\interaction\field_5.paa";
			colorText[]={"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.3843])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.7019])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.8862])", "1"};
			onLoad = "(_this select 0) ctrlShow false;";
		};

		class RscPictureActive_1204 : RscPicture {
			idc = 1105;
			text = "\SG_Core\images\interaction\field_6.paa";
			colorText[]={"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.3843])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.7019])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.8862])", "1"};
			onLoad = "(_this select 0) ctrlShow false;";
		};

		class RscPictureActive_1205 : RscPicture {
			idc = 1106;
			text = "\SG_Core\images\interaction\field_7.paa";
			colorText[]={"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.3843])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.7019])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.8862])", "1"};
			onLoad = "(_this select 0) ctrlShow false;";
		};

		class RscPictureActive_1206 : RscPicture {
			idc = 1107;
			text = "\SG_Core\images\interaction\field_8.paa";
			colorText[]={"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.3843])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.7019])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.8862])", "1"};
			onLoad = "(_this select 0) ctrlShow false;";
		};

		class RscPicture_12022 : RscPicture {
			idc = 1208;
			//text = "\SG_Core\images\interaction\Middle.paa";
			x = ((getResolution select 2) * 0.5 * pixelW) - (52 * 0.5) * (pixelW * pixelGrid * 1);
			y = 0.5 - (125 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = 100 * (pixelW * pixelGrid * 0.5);
			h = 100 * (pixelH * pixelGrid * 0.5);
		};
	};

	class controls {
		class RscInteractionText_1003 : RscInteractionText {
			idc = 1001;
			//text = "Button1";
			x = ((getResolution select 2) * 0.5 * pixelW) - (210 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (160 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (5 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscCenterLeft : RscButtonInvisible {
			action = "[0] call SG_InteractionButton;";
			onMouseEnter = "(ctrlParent (_this # 0)) displayCtrl 1001 ctrlSetFont 'RobotoCondensedBold'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1200)) then {(ctrlParent (_this # 0)) displayCtrl 1100 ctrlShow true;};";
			onMouseExit = "(ctrlParent (_this # 0)) displayCtrl 1001 ctrlSetFont 'RobotoCondensedLight'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1200)) then {(ctrlParent (_this # 0)) displayCtrl 1100 ctrlShow false;};";
		};

		class RscButtonInvisible_1613 : RscCenterLeft {
			idc = 1613;
			x = ((getResolution select 2) * 0.5 * pixelW) - (100 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 + (0 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (0.6 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (0.5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscInteractionText_1000 : RscInteractionText {
			idc = 1002;
			//text = "Button2";
			x = ((getResolution select 2) * 0.5 * pixelW) - (190 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (210 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (5 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscTopLeft : RscButtonInvisible {
			action = "[1] call SG_InteractionButton;";
			onMouseEnter = "(ctrlParent (_this # 0)) displayCtrl 1002 ctrlSetFont 'RobotoCondensedBold'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1201)) then {(ctrlParent (_this # 0)) displayCtrl 1101 ctrlShow true;};";
			onMouseExit = "(ctrlParent (_this # 0)) displayCtrl 1002 ctrlSetFont 'RobotoCondensedLight'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1201)) then {(ctrlParent (_this # 0)) displayCtrl 1101 ctrlShow false;};";
		};

		class RscButtonInvisible_1609 : RscTopLeft {
			idc = 1609;
			x = ((getResolution select 2) * 0.5 * pixelW) - (80 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (100 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (0.6 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (0.5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscInteractionText_1001 : RscInteractionText {
			idc = 1003;
			//text = "Button3";
			x = ((getResolution select 2) * 0.5 * pixelW) - (138 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (235 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (5 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscTop : RscButtonInvisible {
			action = "[2] call SG_InteractionButton;";
			onMouseEnter = "(ctrlParent (_this # 0)) displayCtrl 1003 ctrlSetFont 'RobotoCondensedBold'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1202)) then {(ctrlParent (_this # 0)) displayCtrl 1102 ctrlShow true;};";
			onMouseExit = "(ctrlParent (_this # 0)) displayCtrl 1003 ctrlSetFont 'RobotoCondensedLight'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1202)) then {(ctrlParent (_this # 0)) displayCtrl 1102 ctrlShow false;};";
		};

		class RscButtonInvisible_1600 : RscTop {
			idc = 1600;
			x = ((getResolution select 2) * 0.5 * pixelW) - (27.5 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (120 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (0.6 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (0.5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscInteractionText_1002 : RscInteractionText {
			idc = 1004;
			//text = "Button4";
			x = ((getResolution select 2) * 0.5 * pixelW) - (85 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (210 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (5 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscTopRight : RscButtonInvisible {
			action = "[3] call SG_InteractionButton;";
			onMouseEnter = "(ctrlParent (_this # 0)) displayCtrl 1004 ctrlSetFont 'RobotoCondensedBold'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1203)) then {(ctrlParent (_this # 0)) displayCtrl 1103 ctrlShow true;};";
			onMouseExit = "(ctrlParent (_this # 0)) displayCtrl 1004 ctrlSetFont 'RobotoCondensedLight'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1203)) then {(ctrlParent (_this # 0)) displayCtrl 1103 ctrlShow false;};";
		};

		class RscButtonInvisible_1605 : RscTopRight {
			idc = 1605;
			x = ((getResolution select 2) * 0.5 * pixelW) + (25 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (100 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (0.6 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (0.5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscInteractionText_1005 : RscInteractionText {
			idc = 1005;
			//text = "Button5";
			x = ((getResolution select 2) * 0.5 * pixelW) - (65 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (160 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (5 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscCenterRight : RscButtonInvisible {
			action = "[4] call SG_InteractionButton;";
			onMouseEnter = "(ctrlParent (_this # 0)) displayCtrl 1005 ctrlSetFont 'RobotoCondensedBold'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1204)) then {(ctrlParent (_this # 0)) displayCtrl 1104 ctrlShow true;};";
			onMouseExit = "(ctrlParent (_this # 0)) displayCtrl 1005 ctrlSetFont 'RobotoCondensedLight'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1204)) then {(ctrlParent (_this # 0)) displayCtrl 1104 ctrlShow false;};";
		};

		class RscButtonInvisible_1618 : RscCenterRight {
			idc = 1618;
			x = ((getResolution select 2) * 0.5 * pixelW) + (45 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 + (0 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (0.6 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (0.5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscInteractionText_1007 : RscInteractionText {
			idc = 1006;
			//text = "Button6";
			x = ((getResolution select 2) * 0.5 * pixelW) - (85 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (110 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (5 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscBottomRight : RscButtonInvisible {
			action = "[5] call SG_InteractionButton;";
			onMouseEnter = "(ctrlParent (_this # 0)) displayCtrl 1006 ctrlSetFont 'RobotoCondensedBold'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1205)) then {(ctrlParent (_this # 0)) displayCtrl 1105 ctrlShow true;};";
			onMouseExit = "(ctrlParent (_this # 0)) displayCtrl 1006 ctrlSetFont 'RobotoCondensedLight'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1205)) then {(ctrlParent (_this # 0)) displayCtrl 1105 ctrlShow false;};";
		};

		class RscButtonInvisible_1633 : RscBottomRight {
			idc = 1633;
			x = ((getResolution select 2) * 0.5 * pixelW) + (25 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 + (52.5 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (0.6 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (0.5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscInteractionText_1006 : RscInteractionText {
			idc = 1007;
			//text = "Button7";
			x = ((getResolution select 2) * 0.5 * pixelW) - (138 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (85 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (5 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscBottom : RscButtonInvisible {
			action = "[6] call SG_InteractionButton;";
			onMouseEnter = "(ctrlParent (_this # 0)) displayCtrl 1007 ctrlSetFont 'RobotoCondensedBold'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1206)) then {(ctrlParent (_this # 0)) displayCtrl 1106 ctrlShow true;};";
			onMouseExit = "(ctrlParent (_this # 0)) displayCtrl 1007 ctrlSetFont 'RobotoCondensedLight'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1206)) then {(ctrlParent (_this # 0)) displayCtrl 1106 ctrlShow false;};";
		};

		class RscButtonInvisible_1623 : RscBottom {
			idc = 1623;
			x = ((getResolution select 2) * 0.5 * pixelW) - (27.5 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 + (72.5 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (0.6 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (0.5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscInteractionText_1004 : RscInteractionText {
			idc = 1008;
			//text = "Button8";
			x = ((getResolution select 2) * 0.5 * pixelW) - (190 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (110 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (5 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class RscBottomLeft : RscButtonInvisible {
			action = "[7] call SG_InteractionButton;";
			onMouseEnter = "(ctrlParent (_this # 0)) displayCtrl 1008 ctrlSetFont 'RobotoCondensedBold'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1207)) then {(ctrlParent (_this # 0)) displayCtrl 1107 ctrlShow true;};";
			onMouseExit = "(ctrlParent (_this # 0)) displayCtrl 1008 ctrlSetFont 'RobotoCondensedLight'; if (ctrlShown ((ctrlParent (_this # 0)) displayCtrl 1207)) then {(ctrlParent (_this # 0)) displayCtrl 1107 ctrlShow false;};";
		};

		class RscButtonInvisible_1628 : RscBottomLeft {
			idc = 1628;
			x = ((getResolution select 2) * 0.5 * pixelW) - (80 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 + (52.5 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (0.6 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (0.5 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};

		class MiddleButton : RscButtonInvisible {
			action = "closeDialog 0;";
		};

		class RscButtonInvisible_1636 : MiddleButton {
			idc = 1636;
			x = ((getResolution select 2) * 0.5 * pixelW) - (45 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (60 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = (1.3 * 25 + 4 * 2) * (pixelW * pixelGrid * 0.50);
			h = (1 * 25 + 5 * 2) * (pixelH * pixelGrid * 0.50);
		};
	};
};