class SG_Tickets {
	idd = 16162;
	name = "SG_Tickets";
	movingEnable = 1;
	enableSimulation = 0;
	enableDisplay = 1;

	class ControlsBackground {
		class Header : SG_ctrlStaticHeader {
			text = "Tickets Database";
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (100 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50)) - ((5 + 2) * (pixelH * pixelGrid * 0.50));
		};
		class FilterBackground : SG_ctrlStatic {
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50));
			w = (160 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = 5 * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 1 };
		};
		class ListBackground : SG_ctrlStaticContent {
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 2) + (1.5 * (pixelH * pixelGrid * 0.50));
			w = (160 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = (100 * 0.73) * (pixelH * pixelGrid * 0.50);
		};
	};
	class Controls {
		class Search : SG_ctrlEditNoRect {
			idc = 22;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50)));
			w = (100 / 2.5) * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};

		class ButtonSearch : SG_ctrlButtonSearch {
			idc = 32;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50))) + ((100 / 2.5) * (pixelW * pixelGrid * 0.50)) + (0.85 * (pixelW * pixelGrid * 0.50));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50)));
		};

		class Filter : SG_ctrlListNBox {
			idc = 40;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50));
			w = (160 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = 5 * (pixelH * pixelGrid * 0.50);
			disableOverflow = 1;
			columns[] = { 0, 0.15, 0.38, 0.6 };
			class Items {
				class TicketID {
					text = "Ticket ID";
					value = 0;
				};
				class Name : TicketID {
					text = "Officers Name";
				};
				class Price : TicketID {
					text = "Price";
				};
				class Date : TicketID {
					text = "Issuing Date and Time";
				};
			};
		};

		class List : Filter {
			idc = 60;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 2) + (1.5 * (pixelH * pixelGrid * 0.50));
			w = (160 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = (100 * 0.73) * (pixelH * pixelGrid * 0.50);
			class Items {};
		};

		class GroupFooter : SG_ctrlControlsGroupNoScrollbars {
			idc = 43;
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (100 * (pixelH * pixelGrid * 0.50)) - ((5 + 2) * (pixelH * pixelGrid * 0.50));
			h = (5 + 2) * (pixelH * pixelGrid * 0.50);
			w = 160 * (pixelW * pixelGrid * 0.50);
			class Controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					h = (5 + 2) * (pixelH * pixelGrid * 0.50);
					w = 160 * (pixelW * pixelGrid * 0.50);
				};
				class ButtonPayTicket : SG_ctrlDefaultButton {
					idc = 25;
					text = "PAY TICKET";
					x = (pixelW * pixelGrid * 0.50);
					y = (pixelH * pixelGrid * 0.50);
					w = (160 / 4) * (pixelW * pixelGrid * 0.50);
					h = 5 * (pixelH * pixelGrid * 0.50);
				};
				class ButtonViewTicket : SG_ctrlDefaultButton {
					idc = 26;
					text = "VIEW TICKET";
					x = ((pixelW * pixelGrid * 0.50) * 2) + ((160 / 4) * (pixelW * pixelGrid * 0.50));
					y = (pixelH * pixelGrid * 0.50);
					w = (160 / 4) * (pixelW * pixelGrid * 0.50);
					h = 5 * (pixelH * pixelGrid * 0.50);
				};
			};
		};

		class GroupViewTicketBackground : SG_ctrlControlsGroupNoScrollbars {
			idc = 54;
			x = safezoneX;
			y = safezoneY;
			w = safezoneW;
			h = safezoneH;
			class Controls {
				class Background : SG_ctrlStaticBackgroundDisableTiles {
					x = 0;
					y = 0;
					w = safezoneW;
					h = safezoneH;
				};
			};
		};
		class GroupViewTicket : SG_ctrlControlsGroupNoScrollbars {
			idc = 66;
			x = (((getResolution select 2) * 0.5 * pixelW) - (120 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (80 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 120 * (pixelW * pixelGrid * 0.50);
			h = 80 * (pixelH * pixelGrid * 0.50);
			class Controls {
				class Header : SG_ctrlStaticHeader {
					text = "Ticket Info";
					x = 0;
					y = 0;
					w = 120 * (pixelW * pixelGrid * 0.50);
					h = 5 * (pixelH * pixelGrid * 0.50);
				};
				class Background : SG_ctrlStaticBackground {
					x = 0;
					y = 5 * (pixelH * pixelGrid * 0.50);
					w = 120 * (pixelW * pixelGrid * 0.50);
					h = (80 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50)) - ((5 + 2) * (pixelH * pixelGrid * 0.50));
				};
				class FooterBackground : SG_ctrlStaticFooter {
					x = 0;
					y = (80 * (pixelH * pixelGrid * 0.50)) - ((5 + 2) * (pixelH * pixelGrid * 0.50));
					w = 120 * (pixelW * pixelGrid * 0.50);
					h = (5 + 2) * (pixelH * pixelGrid * 0.50);
				};
				class ButtonAddWarrant : SG_ctrlDefaultButton {
					idc = 21;
					text = "PAY TICKET";
					x = (pixelW * pixelGrid * 0.50);
					y = (80 * (pixelH * pixelGrid * 0.50)) - ((5 + 2) * (pixelH * pixelGrid * 0.50)) + (pixelH * pixelGrid * 0.50);
					w = (120 * (pixelW * pixelGrid * 0.50)) / 3;
					h = 5 * (pixelH * pixelGrid * 0.50);
				};
				class ButtonClose : SG_ctrlDefaultButton {
					idc = 20;
					text = "CLOSE";
					x = ((pixelW * pixelGrid * 0.50) * 2) + ((120 * (pixelW * pixelGrid * 0.50)) / 3);
					y = (80 * (pixelH * pixelGrid * 0.50)) - ((5 + 2) * (pixelH * pixelGrid * 0.50)) + (pixelH * pixelGrid * 0.50);
					w = (120 * (pixelW * pixelGrid * 0.50)) / 3;
					h = 5 * (pixelH * pixelGrid * 0.50);
				};

				class BackgroundTicketNumText : SG_ctrlStatic {
					idc = -1;
					x = (1.5 * (pixelW * pixelGrid * 0.50));
					y = 8 * (pixelH * pixelGrid * 0.50);
					w = (50 * (pixelW * pixelGrid * 0.50)) * 0.46;
					h = (7 * (pixelH * pixelGrid * 0.50)) * 0.72;
					colorBackground[] = { 0, 0, 0, 0.60000001 };
				};

				class BackgroundTicketNum : SG_ctrlStatic {
					idc = -1;
					x = (25 * (pixelW * pixelGrid * 0.50));
					y = 8 * (pixelH * pixelGrid * 0.50);
					w = (202 * (pixelW * pixelGrid * 0.50)) * 0.46;
					h = (7 * (pixelH * pixelGrid * 0.50)) * 0.72;
					colorBackground[] = { 0, 0, 0, 0.40000001 };
				};

				class BackgroundOfficerText : SG_ctrlStatic {
					idc = -1;
					x = (1.5 * (pixelW * pixelGrid * 0.50));
					y = 14 * (pixelH * pixelGrid * 0.50);
					w = (50 * (pixelW * pixelGrid * 0.50)) * 0.46;
					h = (7 * (pixelH * pixelGrid * 0.50)) * 0.72;
					colorBackground[] = { 0, 0, 0, 0.60000001 };
				};

				class BackgroundOfficer : SG_ctrlStatic {
					idc = -1;
					x = (25 * (pixelW * pixelGrid * 0.50));
					y = 14 * (pixelH * pixelGrid * 0.50);
					w = (202 * (pixelW * pixelGrid * 0.50)) * 0.46;
					h = (7 * (pixelH * pixelGrid * 0.50)) * 0.72;
					colorBackground[] = { 0, 0, 0, 0.40000001 };
				};

				class BackgroundPriceText : SG_ctrlStatic {
					idc = -1;
					x = (1.5 * (pixelW * pixelGrid * 0.50));
					y = 20 * (pixelH * pixelGrid * 0.50);
					w = (50 * (pixelW * pixelGrid * 0.50)) * 0.46;
					h = (7 * (pixelH * pixelGrid * 0.50)) * 0.72;
					colorBackground[] = { 0, 0, 0, 0.60000001 };
				};

				class BackgroundPrice : SG_ctrlStatic {
					idc = -1;
					x = (25 * (pixelW * pixelGrid * 0.50));
					y = 20 * (pixelH * pixelGrid * 0.50);
					w = (202 * (pixelW * pixelGrid * 0.50)) * 0.46;
					h = (7 * (pixelH * pixelGrid * 0.50)) * 0.72;
					colorBackground[] = { 0, 0, 0, 0.40000001 };
				};

				class BackgroundTimeText : SG_ctrlStatic {
					idc = -1;
					x = (1.5 * (pixelW * pixelGrid * 0.50));
					y = 26 * (pixelH * pixelGrid * 0.50);
					w = (50 * (pixelW * pixelGrid * 0.50)) * 0.46;
					h = (7 * (pixelH * pixelGrid * 0.50)) * 0.72;
					colorBackground[] = { 0, 0, 0, 0.60000001 };
				};

				class BackgroundTime : SG_ctrlStatic {
					idc = -1;
					x = (25 * (pixelW * pixelGrid * 0.50));
					y = 26 * (pixelH * pixelGrid * 0.50);
					w = (202 * (pixelW * pixelGrid * 0.50)) * 0.46;
					h = (7 * (pixelH * pixelGrid * 0.50)) * 0.72;
					colorBackground[] = { 0, 0, 0, 0.40000001 };
				};

				class BackgroundReasonText : SG_ctrlStatic {
					idc = -1;
					x = (1.5 * (pixelW * pixelGrid * 0.50));
					y = 34 * (pixelH * pixelGrid * 0.50);
					w = (50 * (pixelW * pixelGrid * 0.50)) * 0.46;
					h = (50 * (pixelH * pixelGrid * 0.50)) * 0.72;
					colorBackground[] = { 0, 0, 0, 0.60000001 };
				};

				class BackgroundReason : SG_ctrlStatic {
					idc = -1;
					x = (25 * (pixelW * pixelGrid * 0.50));
					y = 34 * (pixelH * pixelGrid * 0.50);
					w = (202 * (pixelW * pixelGrid * 0.50)) * 0.46;
					h = (50 * (pixelH * pixelGrid * 0.50)) * 0.72;
					colorBackground[] = { 0, 0, 0, 0.40000001 };
				};

				class TicketNumberText : SG_ctrlStatic {
					idc = -1;
					text = "Ticket Number";
					x = 61 * (pixelW * pixelGrid * 0.50) - ((120 * (pixelW * pixelGrid * 0.50)) * 0.48) - (1.5 * (pixelW * pixelGrid * 0.50));
					y = 8 * (pixelH * pixelGrid * 0.50);
					w = (120 * (pixelW * pixelGrid * 0.50)) * 0.48;
					h = 5 * (pixelH * pixelGrid * 0.50);
				};

				class TicketNumber : SG_ctrlStatic {
					idc = 68;
					text = "";
					x = 85 * (pixelW * pixelGrid * 0.50) - ((120 * (pixelW * pixelGrid * 0.50)) * 0.48) - (1.5 * (pixelW * pixelGrid * 0.50));
					y = 8 * (pixelH * pixelGrid * 0.50);
					w = (120 * (pixelW * pixelGrid * 0.50)) * 0.48;
					h = 5 * (pixelH * pixelGrid * 0.50);
				};

				class OfficerText : SG_ctrlStatic {
					idc = -1;
					text = "Officer Name";
					x = 61 * (pixelW * pixelGrid * 0.50) - ((120 * (pixelW * pixelGrid * 0.50)) * 0.48) - (1.5 * (pixelW * pixelGrid * 0.50));
					y = 14 * (pixelH * pixelGrid * 0.50);
					w = (120 * (pixelW * pixelGrid * 0.50)) * 0.48;
					h = 5 * (pixelH * pixelGrid * 0.50);
				};

				class Officer : SG_ctrlStatic {
					idc = 69;
					text = "";
					x = 85 * (pixelW * pixelGrid * 0.50) - ((120 * (pixelW * pixelGrid * 0.50)) * 0.48) - (1.5 * (pixelW * pixelGrid * 0.50));
					y = 14 * (pixelH * pixelGrid * 0.50);
					w = (120 * (pixelW * pixelGrid * 0.50)) * 0.48;
					h = 5 * (pixelH * pixelGrid * 0.50);
				};

				class TicketValueText : SG_ctrlStatic {
					idc = -1;
					text = "Ticket Price";
					x = 61 * (pixelW * pixelGrid * 0.50) - ((120 * (pixelW * pixelGrid * 0.50)) * 0.48) - (1.5 * (pixelW * pixelGrid * 0.50));
					y = 20 * (pixelH * pixelGrid * 0.50);
					w = (120 * (pixelW * pixelGrid * 0.50)) * 0.48;
					h = 5 * (pixelH * pixelGrid * 0.50);
				};

				class TicketValue : SG_ctrlStatic {
					idc = 70;
					text = "";
					x = 85 * (pixelW * pixelGrid * 0.50) - ((120 * (pixelW * pixelGrid * 0.50)) * 0.48) - (1.5 * (pixelW * pixelGrid * 0.50));
					y = 20 * (pixelH * pixelGrid * 0.50);
					w = (120 * (pixelW * pixelGrid * 0.50)) * 0.48;
					h = 5 * (pixelH * pixelGrid * 0.50);
				};

				class TicketIssuedText : SG_ctrlStatic {
					idc = -1;
					text = "Ticket Issued";
					x = 61 * (pixelW * pixelGrid * 0.50) - ((120 * (pixelW * pixelGrid * 0.50)) * 0.48) - (1.5 * (pixelW * pixelGrid * 0.50));
					y = 26 * (pixelH * pixelGrid * 0.50);
					w = (120 * (pixelW * pixelGrid * 0.50)) * 0.48;
					h = 5 * (pixelH * pixelGrid * 0.50);
				};

				class TicketIssued : SG_ctrlStatic {
					idc = 71;
					text = "";
					x = 85 * (pixelW * pixelGrid * 0.50) - ((120 * (pixelW * pixelGrid * 0.50)) * 0.48) - (1.5 * (pixelW * pixelGrid * 0.50));
					y = 26 * (pixelH * pixelGrid * 0.50);
					w = (120 * (pixelW * pixelGrid * 0.50)) * 0.48;
					h = 5 * (pixelH * pixelGrid * 0.50);
				};

				class TicketReasonText : SG_ctrlStatic {
					idc = -1;
					text = "Ticket Reason";
					x = 61 * (pixelW * pixelGrid * 0.50) - ((120 * (pixelW * pixelGrid * 0.50)) * 0.48) - (1.5 * (pixelW * pixelGrid * 0.50));
					y = 50 * (pixelH * pixelGrid * 0.50);
					w = (120 * (pixelW * pixelGrid * 0.50)) * 0.48;
					h = 5 * (pixelH * pixelGrid * 0.50);
				};

				class TicketReason : SG_ctrlStaticContent {
					idc = 72;
					text = "";
					style = ST_MULTI + ST_NO_RECT;
					x = 85 * (pixelW * pixelGrid * 0.50) - ((120 * (pixelW * pixelGrid * 0.50)) * 0.48) - (1.5 * (pixelW * pixelGrid * 0.50));
					y = 35 * (pixelH * pixelGrid * 0.50);
					w = (189 * (pixelW * pixelGrid * 0.50)) * 0.48;
					h = 34 * (pixelH * pixelGrid * 0.50);
					colorBackground[] = { 0, 0, 0, 0 };
				};
			};
		};
		class ButtonClose : SG_ctrlButtonClose {
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (160 * (pixelW * pixelGrid * 0.50)) - (5 * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 5 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
	};
};