class SG_ModShop {
	idd = 34653;
	name = "SG_ModShop";
	onUnload = "SG_VehicleCam cameraEffect ['TERMINATE','FRONT']; camDestroy SG_VehicleCam; [(objectParent player)] call SG_ModShop_Revert;";

	class controlsBackground {
		class SG_TitleBackground : Life_RscText {
			idc = 1000;
			x = 0.00891873 * safezoneW + safezoneX;
			y = 0.07562 * safezoneH + safezoneY;
			w = 0.175313 * safezoneW;
			h = 0.737 * safezoneH;
			colorBackground[] = { 0, 0, 0, 0.7 };
		};
		class SG_TitleText : Life_RscText {
			idc = 1001;
			text = "Vehicle Paint:";
			x = 0.00882088 * safezoneW + safezoneX;
			y = 0.04394 * safezoneH + safezoneY;
			w = 0.175627 * safezoneW;
			h = 0.0326103 * safezoneH;
			colorBackground[] = { 0, 0, 0, 0.8 };
		};
		class SG_ModificationsBar : Life_RscText {
			idc = 1251;
			text = "Modifications:";
			x = 0.00912499 * safezoneW + safezoneX;
			y = 0.5484 * safezoneH + safezoneY;
			w = 0.175627 * safezoneW;
			h = 0.0316844 * safezoneH;
			colorBackground[] = { 0, 0, 0, 0.8 };
		};
	};

	class Controls {
		class SG_RedSlider : life_RscXSliderH {
			idc = 1900;
			x = 0.0456312 * safezoneW + safezoneX;
			y = 0.11742 * safezoneH + safezoneY;
			w = 0.120799 * safezoneW;
			h = 0.0276445 * safezoneH;
		};
		class SG_RedSliderText : Life_RscText {
			idc = 1002;

			text = "Red:"; //--- ToDo: Localize;
			x = 0.0145906 * safezoneW + safezoneX;
			y = 0.11522 * safezoneH + safezoneY;
			w = 0.025877 * safezoneW;
			h = 0.0219906 * safezoneH;
		};
		class SG_GreenSliderText : Life_RscText {
			idc = 1007;

			text = "Green:"; //--- ToDo: Localize;
			x = 0.0135594 * safezoneW + safezoneX;
			y = 0.16362 * safezoneH + safezoneY;
			w = 0.025877 * safezoneW;
			h = 0.0219906 * safezoneH;
		};
		class SG_BlueSliderText : Life_RscText {
			idc = 1008;

			text = "Blue:"; //--- ToDo: Localize;
			x = 0.0135594 * safezoneW + safezoneX;
			y = 0.21642 * safezoneH + safezoneY;
			w = 0.025877 * safezoneW;
			h = 0.0219906 * safezoneH;
		};
		class SG_OpacityText : Life_RscText {
			idc = 1008;

			text = "Opacity:"; //--- ToDo: Localize;
			x = 0.0142812 * safezoneW + safezoneX;
			y = 0.2668 * safezoneH + safezoneY;
			w = 0.0316061 * safezoneW;
			h = 0.0219906 * safezoneH;
		};
		class SG_GreenSlider : life_RscXSliderH {
			idc = 1901;
			x = 0.0456312 * safezoneW + safezoneX;
			y = 0.16802 * safezoneH + safezoneY;
			w = 0.120799 * safezoneW;
			h = 0.0276445 * safezoneH;
		};
		class SG_BlueSlider : life_RscXSliderH {
			idc = 1902;
			x = 0.0446 * safezoneW + safezoneX;
			y = 0.22082 * safezoneH + safezoneY;
			w = 0.120799 * safezoneW;
			h = 0.0276445 * safezoneH;
		};
		class SG_OpacitySlider : life_RscXSliderH {
			idc = 1906;
			x = 0.0524374 * safezoneW + safezoneX;
			y = 0.2668 * safezoneH + safezoneY;
			w = 0.120799 * safezoneW;
			h = 0.0276445 * safezoneH;
		};
		class SG_RimColorText : Life_RscText {
			idc = 1009;

			text = "Rim Color:";
			x = 0.0704844 * safezoneW + safezoneX;
			y = 0.3042 * safezoneH + safezoneY;
			w = 0.0414031 * safezoneW;
			h = 0.0219906 * safezoneH;
		};
		class SG_ColorText : Life_RscText {
			idc = 1010;

			text = "Color:";
			x = 0.0704844 * safezoneW + safezoneX;
			y = 0.0864 * safezoneH + safezoneY;
			w = 0.0414031 * safezoneW;
			h = 0.0219906 * safezoneH;
		};
		class SG_RimColorRed : Life_RscText {
			idc = 1012;

			text = "Red:"; //--- ToDo: Localize;
			x = 0.0156219 * safezoneW + safezoneX;
			y = 0.3394 * safezoneH + safezoneY;
			w = 0.025877 * safezoneW;
			h = 0.0219906 * safezoneH;
		};
		class SG_RimColorGreen : Life_RscText {
			idc = 1013;

			text = "Green:"; //--- ToDo: Localize;
			x = 0.0135594 * safezoneW + safezoneX;
			y = 0.3922 * safezoneH + safezoneY;
			w = 0.025877 * safezoneW;
			h = 0.0219906 * safezoneH;
		};
		class SG_RimColorBlue : Life_RscText {
			idc = 1014;

			text = "Blue:"; //--- ToDo: Localize;
			x = 0.0156219 * safezoneW + safezoneX;
			y = 0.445 * safezoneH + safezoneY;
			w = 0.025877 * safezoneW;
			h = 0.0219906 * safezoneH;
		};
		class SG_RimOpacityText : Life_RscText {
			idc = 1014;

			text = "Opacity:"; //--- ToDo: Localize;
			x = 0.0153125 * safezoneW + safezoneX;
			y = 0.4978 * safezoneH + safezoneY;
			w = 0.0310853 * safezoneW;
			h = 0.0229165 * safezoneH;
		};
		class SG_RimColorRedSlide : life_RscXSliderH {
			idc = 1903;

			x = 0.0446 * safezoneW + safezoneX;
			y = 0.3394 * safezoneH + safezoneY;
			w = 0.120799 * safezoneW;
			h = 0.0276445 * safezoneH;
		};

		class SG_RimColorGreenSlider : life_RscXSliderH {
			idc = 1904;

			x = 0.0446 * safezoneW + safezoneX;
			y = 0.3922 * safezoneH + safezoneY;
			w = 0.120799 * safezoneW;
			h = 0.0276445 * safezoneH;
		};
		class SG_RimColorBlueSlider : life_RscXSliderH {
			idc = 1905;

			x = 0.0446 * safezoneW + safezoneX;
			y = 0.445 * safezoneH + safezoneY;
			w = 0.120799 * safezoneW;
			h = 0.0276445 * safezoneH;
		};
		class SG_RimColorOpacitySlider : life_RscXSliderH {
			idc = 1907;
			x = 0.0534687 * safezoneW + safezoneX;
			y = 0.4978 * safezoneH + safezoneY;
			w = 0.120799 * safezoneW;
			h = 0.0276445 * safezoneH;
		};

		class SG_WindowTint : Life_RscText {
			idc = 1016;

			text = "Window Tint:";
			x = 0.0617187 * safezoneW + safezoneX;
			y = 0.5968 * safezoneH + safezoneY;
			w = 0.0517539 * safezoneW;
			h = 0.0219906 * safezoneH;
		};
		class SG_WindowTintList : Life_RscListBox {
			idc = 1501;

			x = 0.0184062 * safezoneW + safezoneX;
			y = 0.6386 * safezoneH + safezoneY;
			w = 0.156086 * safezoneW;
			h = 0.133069 * safezoneH;
		};
		class SG_BuyButton : Life_RscButtonMenu {
			idc = 1600;

			text = "Mod My Car";
			x = 0.00860935 * safezoneW + safezoneX;
			y = 0.81284 * safezoneH + safezoneY;
			w = 0.175414 * safezoneW;
			h = 0.0320993 * safezoneH;
			colorText[] = { 1, 1, 1, 1 };
			colorBackground[] = { 0, 0, 0, 0.8 };
		};
	};
};