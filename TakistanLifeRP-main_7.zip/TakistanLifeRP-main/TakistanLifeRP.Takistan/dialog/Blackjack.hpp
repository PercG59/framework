class SG_BlackjackBet {
	idd = 8999216;
	name = "SG_BlackjackBet";
	movingEnable = 0;
	enableSimulation = 1;

	class ControlsBackground {
		class Header : SG_ctrlStaticHeader {
			text = "Blackjack Bet";
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (40 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 130 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (40 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50));
			w = 130 * (pixelW * pixelGrid * 0.50);
			h = (40 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50)) - ((5 + 2) * (pixelH * pixelGrid * 0.50));
		};
		class TitleBank : SG_ctrlStatic {
			text = "Welcome to Blackjack, your goal is to get as close to 21 as you can. If the dealer ends with a closer number, he wins. Good luck, and just remember no refunds are allowed. Min $5,000 - Max - $50,000";
			x = ((((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.43 - (40 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50)));
			w = 130 * (pixelW * pixelGrid * 0.50);
			h = (5 * (pixelH * pixelGrid * 0.50)) * 2;
			sizeEx = "0.015 * safezoneH";
			style = ST_MULTI + ST_NO_RECT;
		};
		class AmmountToBetText : TitleBank {
			text = "Amount to Bet:";
			y = ((0.46 - (40 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + (5 * (pixelH * pixelGrid * 0.50)) + (pixelH * pixelGrid * 0.50);
			w = 25 * (pixelW * pixelGrid * 0.50);
		};
	};

	class Controls {
		class AmmountToBet : SG_ctrlEditNoRect {
			idc = 123;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (40 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + (((5 * (pixelH * pixelGrid * 0.50)) + (pixelH * pixelGrid * 0.50)) * 2) + (5 * (pixelH * pixelGrid * 0.50)) + (pixelH * pixelGrid * 0.50);
			w = (130 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = 5 * (pixelH * pixelGrid * 0.50);
			text = "1";
		};
		class FooterGroup : SG_ctrlControlsGroupNoScrollbars {
			idc = 124;
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (40 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (40 * (pixelH * pixelGrid * 0.50)) - ((5 + 2) * (pixelH * pixelGrid * 0.50));
			w = 130 * (pixelW * pixelGrid * 0.50);
			h = (5 + 2) * (pixelH * pixelGrid * 0.50);
			class Controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					w = 130 * (pixelW * pixelGrid * 0.50);
					h = (5 + 2) * (pixelH * pixelGrid * 0.50);
				};
				class ButtonStart : SG_ctrlDefaultButton {
					idc = 125;
					text = "START GAME";
					x = (pixelW * pixelGrid * 0.50);
					y = (pixelH * pixelGrid * 0.50);
					w = (130 * (pixelW * pixelGrid * 0.50)) * 0.2;
					h = 5 * (pixelH * pixelGrid * 0.50);
					onButtonClick = "";
				};
			};
		};
		class ButtonCancel : SG_ctrlButtonClose {
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50)) + (130 * (pixelW * pixelGrid * 0.50)) - (5 * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (40 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 5 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
			onButtonClick = "closeDialog 0;";
		};
	};
};

class SG_Blackjack {
	idd = 158513;
	name = "SG_Blackjack";
	movingEnable = 0;
	enableSimulation = 1;

	class controlsBackground {
		class Header : SG_ctrlStaticHeader {
			idc = 32;
			text = "Blackjack";
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.440 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.440 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (100 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50));
		};
		class MyHandTopBackground : SG_ctrlStatic {
			x = ((((getResolution select 2) * 0.5 * pixelW) - (155 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + (5 * (pixelH * pixelGrid * 0.50)) + (2 * (pixelH * pixelGrid * 0.50 / 2));
			w = ((160 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = 5 * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 1 };
		};
		class MyHandLabel : SG_ctrlStatic {
			idc = 232321 + 1;
			text = "My Hand";
			x = ((((getResolution select 2) * 0.5 * pixelW) - (155 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.456 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50)));
			w = ((160 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class MyHandAmm : SG_ctrlStatic {
			idc = 13;
			text = "0";
			x = ((((getResolution select 2) * 0.5 * pixelW) - (20 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.456 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50)));
			w = ((160 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = 5 * (pixelH * pixelGrid * 0.50);
		};

		class MyHandBackground : SG_ctrlStatic {
			idc = 25;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (155 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.376 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
			w = ((160 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = (100 / 1.34) * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 0.5 };
		};

		class DealerHandTopBackground : SG_ctrlStatic {
			x = ((((getResolution select 2) * 0.5 * pixelW) - (0 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + (5 * (pixelH * pixelGrid * 0.50)) + (2 * (pixelH * pixelGrid * 0.50 / 2));
			w = ((160 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = 5 * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 1 };
		};
		class DealerHandLabel : SG_ctrlStatic {
			idc = 232324 + 1;
			text = "Dealer Hand";
			x = ((((getResolution select 2) * 0.5 * pixelW) - (0 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.456 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50)));
			w = ((160 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = 5 * (pixelH * pixelGrid * 0.50);
		};

		class DealerHandAmm : SG_ctrlStatic {
			idc = 14;
			text = "0";
			x = ((((getResolution select 2) * 0.5 * pixelW) - (-135 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.456 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50)));
			w = ((160 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = 5 * (pixelH * pixelGrid * 0.50);
		};

		class DealerHandBackground : SG_ctrlStatic {
			idc = 26;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (0 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.376 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
			w = ((160 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = (100 / 1.34) * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 0.5 };
		};
	};
	class controls {
		class MyHandCard1 : SG_ctrlStaticPictureKeepAspect {
			idc = 1;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (158.5 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.36 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
			w = ((60 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = (60 / 1.34) * (pixelH * pixelGrid * 0.50);
			text = "";
		};

		class MyHandCard2 : MyHandCard1 {
			idc = 2;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (109 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
		};

		class MyHandCard3 : MyHandCard2 {
			idc = 3;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (60 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
		};

		class MyHandCard4 : MyHandCard1 {
			idc = 4;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (158.5 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.58 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
		};

		class MyHandCard5 : MyHandCard4 {
			idc = 5;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (109 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
		};

		class MyHandCard6 : MyHandCard5 {
			idc = 6;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (60 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
		};

		class DealerHandCard1 : SG_ctrlStaticPictureKeepAspect {
			idc = 7;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (3.5 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.36 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
			w = ((60 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = (60 / 1.34) * (pixelH * pixelGrid * 0.50);
			text = "";
		};

		class DealerHandCard2 : DealerHandCard1 {
			idc = 8;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (-46 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
		};

		class DealerHandCard3 : DealerHandCard2 {
			idc = 9;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (-95 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
		};

		class DealerHandCard4 : DealerHandCard1 {
			idc = 10;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (3.5 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.58 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
		};

		class DealerHandCard5 : DealerHandCard4 {
			idc = 11;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (-46 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
		};

		class DealerHandCard6 : DealerHandCard5 {
			idc = 12;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (-95 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
		};

		class Footer : SG_ctrlControlsGroupNoScrollbars {
			idc = 46;
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.4 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + ((100 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50))) + (5 * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (5 + 2) * (pixelH * pixelGrid * 0.50);
			class controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					w = 160 * (pixelW * pixelGrid * 0.50);
					h = (5 + 2) * (pixelH * pixelGrid * 0.50);
				};
				class ButtonHit : SG_ctrlDefaultButton {
					idc = 125;
					text = "HIT";
					x = (pixelW * pixelGrid * 0.50);
					y = (pixelH * pixelGrid * 0.50);
					w = (130 * (pixelW * pixelGrid * 0.50)) * 0.2;
					h = 5 * (pixelH * pixelGrid * 0.50);
					onButtonClick = "";
				};
				class ButtonStand : SG_ctrlDefaultButton {
					idc = 126;
					text = "STAND";
					x = (pixelW * pixelGrid * 0.50) + ((((130 * (pixelW * pixelGrid * 0.50)) * 0.2) + (pixelW * pixelGrid * 0.50)) * 1);
					y = (pixelH * pixelGrid * 0.50);
					w = (130 * (pixelW * pixelGrid * 0.50)) * 0.2;
					h = 5 * (pixelH * pixelGrid * 0.50);
					onButtonClick = "";
				};
				class Button2xDown : SG_ctrlDefaultButton {
					idc = 127;
					text = "2X DOWN";
					x = (pixelW * pixelGrid * 0.50) + ((((130 * (pixelW * pixelGrid * 0.50)) * 0.2) + (pixelW * pixelGrid * 0.50)) * 2);
					y = (pixelH * pixelGrid * 0.50);
					w = (130 * (pixelW * pixelGrid * 0.50)) * 0.2;
					h = 5 * (pixelH * pixelGrid * 0.50);
					onButtonClick = "";
				};
			};
		};
	};
};