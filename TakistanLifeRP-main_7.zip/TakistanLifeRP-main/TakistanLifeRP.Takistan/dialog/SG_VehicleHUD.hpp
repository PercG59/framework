class SG_VehicleHud {
	name = "SG_VehicleHud";
	idd = 100;
	duration = 1e+1000;
	movingEnable = 0;
	fadein = 0.5;
	fadeout = 0;
	onLoad = "uiNamespace setVariable ['SG_VehicleHud', _this select 0];";
	class controls {
		class MainMeter : SG_RscControlsGroupNoScrollbars {
			idc = 2900;
			x = 0.768125 * safezoneW + safezoneX;
			y = 0.467 * safezoneH + safezoneY;
			w = 0.221719 * safezoneW;
			h = 0.319 * safezoneH;
			class Controls {
				class SpeedoMeterImg : SG_RscPictureKeepAspect {
					idc = 1200;

					text = "\SG_Core\images\vehicle\speedometer_2.paa";
					x = 0.0103119 * safezoneW;
					y = 0.022 * safezoneH;
					w = 0.20625 * safezoneW;
					h = 0.275 * safezoneH;
				};
				class NeedleImg : SG_RscPictureKeepAspect {
					idc = 2201;

					text = "\SG_Core\images\vehicle\needle2.paa";
					x = 0.036093 * safezoneW;
					y = 0.055 * safezoneH;
					w = 0.154687 * safezoneW;
					h = 0.209 * safezoneH;
				};
				class SpeedText : SG_RscText {
					idc = 2200;
					style = "0x02";
					font = "PuristaSemiBold";

					text = "0 KM/H";
					x = 0.0824999 * safezoneW;
					y = 0.11 * safezoneH;
					w = 0.061875 * safezoneW;
					h = 0.044 * safezoneH;
				};
			};
		};

		class FuelImg : SG_RscPictureKeepAspect {
			idc = 1209;
			text = "\SG_Core\images\vehicle\fuel.paa";
			x = 0.78875 * safezoneW + safezoneX;
			y = 0.61 * safezoneH + safezoneY;
			w = 0.020625 * safezoneW;
			h = 0.033 * safezoneH;
		};
		class EngineImg : SG_RscPictureKeepAspect {
			idc = 1201;
			text = "\SG_Core\images\vehicle\engine.paa";
			x = 0.793906 * safezoneW + safezoneX;
			y = 0.566 * safezoneH + safezoneY;
			w = 0.020625 * safezoneW;
			h = 0.033 * safezoneH;
		};
		class HullImg : SG_RscPictureKeepAspect {
			idc = 1202;
			text = "\SG_Core\images\vehicle\hull.paa";
			x = 0.804219 * safezoneW + safezoneX;
			y = 0.522 * safezoneH + safezoneY;
			w = 0.020625 * safezoneW;
			h = 0.033 * safezoneH;
		};
		class WheelImg : SG_RscPictureKeepAspect {
			idc = 1203;
			text = "\SG_Core\images\vehicle\wheel.paa";
			x = 0.824844 * safezoneW + safezoneX;
			y = 0.489 * safezoneH + safezoneY;
			w = 0.020625 * safezoneW;
			h = 0.033 * safezoneH;
		};
	};
};