
class IGUIBack_2200 : IGUIBack {
	idc = 2200;
	x = 0.222353 * safezoneW + safezoneX;
	y = 0.180267 * safezoneH + safezoneY;
	w = 0.339346 * safezoneW;
	h = 0.677083 * safezoneH;
};
class IGUIBack_2201 : IGUIBack {
	idc = 2201;
	x = 0.222353 * safezoneW + safezoneX;
	y = 0.180267 * safezoneH + safezoneY;
	w = 0.339346 * safezoneW;
	h = 0.0188079 * safezoneH;
};
class classBackground : IGUIBack {
	idc = 2205;
	x = 0.22676 * safezoneW + safezoneX;
	y = 0.208478 * safezoneH + safezoneY;
	w = 0.127806 * safezoneW;
	h = 0.639467 * safezoneH;
};
class Class1Btn : IGUIBack {
	idc = 2202;
	x = 0.231167 * safezoneW + safezoneX;
	y = 0.217882 * safezoneH + safezoneY;
	w = 0.118992 * safezoneW;
	h = 0.197482 * safezoneH;
};
class Class2Btn : IGUIBack {
	idc = 2203;
	x = 0.231167 * safezoneW + safezoneX;
	y = 0.424769 * safezoneH + safezoneY;
	w = 0.118992 * safezoneW;
	h = 0.197482 * safezoneH;
};
class Class3Btn : IGUIBack {
	idc = 2204;
	x = 0.231167 * safezoneW + safezoneX;
	y = 0.631655 * safezoneH + safezoneY;
	w = 0.118992 * safezoneW;
	h = 0.197482 * safezoneH;
};
class DEscriptionBackground : IGUIBack {
	idc = 2206;
	x = 0.358973 * safezoneW + safezoneX;
	y = 0.208478 * safezoneH + safezoneY;
	w = 0.193912 * safezoneW;
	h = 0.253906 * safezoneH;
};
class DescriptionTitle : IGUIBack {
	idc = 2207;
	x = 0.358973 * safezoneW + safezoneX;
	y = 0.208478 * safezoneH + safezoneY;
	w = 0.193912 * safezoneW;
	h = 0.0188079 * safezoneH;
};
class SelectBtn : RscButton {
	idc = 1601;
	x = 0.358973 * safezoneW + safezoneX;
	y = 0.462384 * safezoneH + safezoneY;
	w = 0.193912 * safezoneW;
	h = 0.0282118 * safezoneH;
};
class NoteTxt : IGUIBack {
	idc = 2208;
	x = 0.358973 * safezoneW + safezoneX;
	y = 0.800926 * safezoneH + safezoneY;
	w = 0.198319 * safezoneW;
	h = 0.0470196 * safezoneH;
};