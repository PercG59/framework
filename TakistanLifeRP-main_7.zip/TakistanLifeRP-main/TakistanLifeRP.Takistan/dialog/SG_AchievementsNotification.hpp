class SG_achievements_notification_control_group : ctrlControlsGroupNoScrollbars {
	idc = 2500;
	x = "0.375 * safezoneW + safezoneX";
	y = "0.77 * safezoneH + safezoneY";
	w = "0.25 * safezoneW";
	h = "0.02 * safezoneH";
	class controls {
		class title_bar : ctrlStaticTitle {
			idc = 5000;
			style = 2;
			x = "0 * safezoneW";
			y = "0 * safezoneH";
			w = "0.255 * safezoneW";
			h = "0.02 * safezoneH";
			font = "PuristaBold";
			shadow = 0;
			colorBackground[] = { 0.1, 0.1, 0.1, 1 };
		};
		class background : ctrlStaticBackground {
			x = "0 * safezoneW";
			y = "0.02 * safezoneH";
			w = "0.255 * safezoneW";
			h = "1 * safezoneH";
		};
		class picture : ctrlStaticPicture {
			idc = 500;
			x = "0.005 * safezoneW";
			y = "0.03 * safezoneH";
			w = "0.045 * safezoneW";
			h = "0.08 * safezoneH";
		};
		class title : ctrlStatic {
			idc = 1000;
			x = "0.05 * safezoneW";
			y = "0.025 * safezoneH";
			w = "0.19 * safezoneW";
			h = "0.03 * safezoneH";
			sizeEx = "0.028 / (getResolution#5)";
			font = "RobotoCondensedBold";
			shadow = 0;
		};
		class description : ctrlStructuredText {
			idc = 1500;
			x = "0.05 * safezoneW";
			y = "0.0525 * safezoneH";
			w = "0.19 * safezoneW";
			h = "0.04 * safezoneH";
			size = "0.019 / (getResolution#5)";
			shadow = 0;
			onload = "(_this#0) ctrlEnable false;";
			class Attributes {
				align = "left";
				color = "#919191";
				colorLink = "#919191";
				size = 1;
				shadow = 0;
				font = "RobotoCondensedLight";
			};
		};
		class progess_background : ctrlStaticBackground {
			idc = 2400;
			show = 0;
			x = "0.055 * safezoneW";
			y = "0.0925 * safezoneH";
			w = "0.19 * safezoneW";
			h = "0.018 * safezoneH";
			colorBackground[] = { 0.15, 0.15, 0.15, 1 };
		};
		class progess_foreground : progess_background {
			idc = 2500;
			show = 0;
			w = "0 * safezoneW";
			colorBackground[] = { 0.13, 0.54, 0.21, 1 };
		};
		class progess_text : ctrlStatic {
			idc = 3000;
			show = 0;
			style = 2;
			x = "0.055 * safezoneW";
			y = "0.0925 * safezoneH";
			w = "0.19 * safezoneW";
			h = "0.018 * safezoneH";
			font = "PuristaBold";
			shadow = 0;
			text = "";
		};
	};
};
