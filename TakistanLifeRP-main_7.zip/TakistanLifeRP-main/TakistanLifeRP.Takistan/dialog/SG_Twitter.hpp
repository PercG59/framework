

class twitter_RscButton {
	deletable = 0;
	fade = 0;
	access = 0;
	type = 1;
	text = "";
	colorText[] = { 1, 1, 1, 1 };
	colorDisabled[] = { 1, 1, 1, 0.25 };
	colorBackground[] = { 0, 0, 0, 0.5 };
	colorBackgroundDisabled[] = { 0, 0, 0, 0.5 };
	colorBackgroundActive[] = { 0, 0, 0, 1 };
	colorFocused[] = { 0, 0, 0, 1 };
	colorShadow[] = { 0, 0, 0, 0 };
	colorBorder[] = { 0, 0, 0, 1 };
	soundEnter[] = { "\A3\ui_f\data\sound\RscButton\soundEnter", 0.09, 1 };
	soundPush[] = { "\A3\ui_f\data\sound\RscButton\soundPush", 0.09, 1 };
	soundClick[] = { "\A3\ui_f\data\sound\RscButton\soundClick", 0.09, 1 };
	soundEscape[] = { "\A3\ui_f\data\sound\RscButton\soundEscape", 0.09, 1 };
	idc = -1;
	style = 2;
	x = 0;
	y = 0;
	w = 0.095589;
	h = 0.039216;
	shadow = 2;
	font = "RobotoCondensed";
	sizeEx = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) * 1)";
	url = "";
	offsetX = 0;
	offsetY = 0;
	offsetPressedX = 0;
	offsetPressedY = 0;
	borderSize = 0;
};
class twitter_RscEdit {
	deletable = 0;
	fade = 0;
	access = 0;
	type = 2;
	x = 0;
	y = 0;
	h = 0.04;
	w = 0.2;
	colorBackground[] = { 0, 0, 0, 0 };
	colorText[] = { 0.95, 0.95, 0.95, 1 };
	colorDisabled[] = { 1, 1, 1, 0.25 };
	colorSelection[] = { "(profilenamespace getvariable ['GUI_BCG_RGB_R',0.13])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.54])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.21])", 1 };
	autocomplete = "";
	text = "";
	size = 0.2;
	style = "0x00 + 0x40";
	font = "RobotoCondensed";
	shadow = 2;
	sizeEx = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) * 1)";
	canModify = 1;
	tooltipColorText[] = { 1, 1, 1, 1 };
	tooltipColorBox[] = { 1, 1, 1, 1 };
	tooltipColorShade[] = { 0, 0, 0, 0.65 };
};
class twitter_RscText {
	deletable = 0;
	fade = 0;
	access = 0;
	type = 0;
	idc = -1;
	colorBackground[] = { 0, 0, 0, 0 };
	colorText[] = { 1, 1, 1, 1 };
	text = "";
	fixedWidth = 0;
	x = 0;
	y = 0;
	h = 0.037;
	w = 0.3;
	style = 0;
	shadow = 1;
	colorShadow[] = { 0, 0, 0, 0.5 };
	font = "RobotoCondensed";
	SizeEx = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) * 1)";
	linespacing = 1;
	tooltipColorText[] = { 1, 1, 1, 1 };
	tooltipColorBox[] = { 1, 1, 1, 1 };
	tooltipColorShade[] = { 0, 0, 0, 0.65 };
};
class twitter_RscStructuredText {
	deletable = 0;
	fade = 0;
	access = 0;
	type = 13;
	idc = -1;
	style = 0;
	colorText[] = { 1, 1, 1, 1 };
	class Attributes {
		font = "RobotoCondensed";
		color = "#ffffff";
		colorLink = "#D09B43";
		align = "left";
		shadow = 1;
	};
	x = 0;
	y = 0;
	h = 0.035;
	w = 0.1;
	text = "";
	size = "4.32 * (1 / (getResolution select 3)) * pixelGrid * 0.6";
	// size = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) * 1)";
	shadow = 1;
};
class twitter_RscControlsGroup {
	deletable = 0;
	fade = 0;
	class VScrollbar {
		color[] = { 1, 1, 1, 0 };
		width = 0;
		autoScrollEnabled = 1;
	};
	class HScrollbar {
		color[] = { 1, 1, 1, 0 };
		height = 0;
	};
	class Controls {
	};
	type = 15;
	idc = -1;
	x = 0;
	y = 0;
	w = 1;
	h = 1;
	shadow = 0;
	style = 16;
};

class twitterDisplay {
	idd = 963258;
	name = "twitterDisplay";
	movingEnable = 0;
	enableSimulation = 1;
	onLoad = "uiNamespace setVariable ['twitterDisplay', _this select 0]";
	// onUnload = "uiNamespace setVariable ['twitterDisplay', objNull]";
	// onDestroy = "uiNamespace setVariable ['twitterDisplay', objNull]";
	fadein = 0;
	fadeout = 0;
	duration = 10e10;
	class controlsBackground {};
	class controls {
		class twitterfeedname : twitter_RscText {
			idc = 1100;
			// colorBackground[] = {0,0,0,1};
			text = "Takistan Twitter Feed";
			shadow = 0;
			sizeEx = "4.32 * (1 / (getResolution select 3)) * pixelGrid * 0.9";
			font = "PuristaSemiBold";
			// x = 0.005 * safezoneW + safezoneX;
			// y = 0.423 * safezoneH + safezoneY;
			// w = 0.221719 * safezoneW;
			// h = 0.033 * safezoneH;

			// x = 0.00499997 * safezoneW + safezoneX;
			// y = 0.093 * safezoneH + safezoneY;
			// w = 0.221719 * safezoneW;
			// h = 0.033 * safezoneH;

			x = 0.00499997 * safezoneW + safezoneX;
			y = 0.027 * safezoneH + safezoneY;
			w = 0.221719 * safezoneW;
			h = 0.033 * safezoneH;
		};
		class ContolsGrp : twitter_RscControlsGroup {
			idc = 1101;
			// x = 0.00499997 * safezoneW + safezoneX;
			// y = 0.456 * safezoneH + safezoneY;
			// w = 0.221719 * safezoneW;
			// h = 0.286 * safezoneH;

			// x = 0.00499997 * safezoneW + safezoneX;
			// y = 0.126 * safezoneH + safezoneY;
			// w = 0.221719 * safezoneW;
			// h = 0.286 * safezoneH;

			x = 0.00499997 * safezoneW + safezoneX;
			y = 0.06 * safezoneH + safezoneY;
			w = 0.221719 * safezoneW;
			h = 0.286 * safezoneH;
		};
	};
};

class errorDialog : twitter_RscText {
	idc = 1402;
	text = "Error";
	shadow = 0;
	font = "PuristaMedium";
	colorBackground[] = { 1, 0.239, 0.239, 1 };
	x = 0.00499997 * safezoneW + safezoneX;
	y = 0.390 * safezoneH + safezoneY;
	// y = 0.786 * safezoneH + safezoneY;
	w = 0.221719 * safezoneW;
	h = 0.022 * safezoneH;
};

class twitterDialog {
	idd = 963258;
	name = "twitterDialog";
	movingEnable = 0;
	enableSimulation = 1;
	// onLoad = "uiNamespace setVariable ['twitterDisplay', _this select 0]";
	// onUnload = "uiNamespace setVariable ['twitterDisplay', objNull]";
	// onDestroy = "uiNamespace setVariable ['twitterDisplay', objNull]";
	fadein = 0;
	fadeout = 0;
	duration = 10e10;
	class controlsBackground {};
	class controls {
		class RscEdit_1400 : twitter_RscEdit {
			idc = 1400;
			text = "";
			font = "PuristaMedium";
			colorText[] = { 0.012, 0.631, 0.988, 1 };
			colorBackground[] = { 1, 1, 1, 1 };
			shadow = 0;
			// x = 0.00499997 * safezoneW + safezoneX;
			// y = 0.742 * safezoneH + safezoneY;
			// w = 0.175313 * safezoneW;
			// h = 0.022 * safezoneH;

			// x = 0.00499997 * safezoneW + safezoneX;
			// y = 0.412 * safezoneH + safezoneY;
			// w = 0.175313 * safezoneW;
			// h = 0.022 * safezoneH;

			x = 0.00499997 * safezoneW + safezoneX;
			y = 0.346 * safezoneH + safezoneY;
			w = 0.175313 * safezoneW;
			h = 0.022 * safezoneH;
		};
		class charcounter : twitter_RscText {
			idc = 1401;
			text = "Characters: 0";
			colorText[] = { 0.341, 0.341, 0.341, 1 };
			shadow = 0;
			// colorBackground[] = {0,0,0,1};
			x = 0.00499997 * safezoneW + safezoneX;
			y = 0.364 * safezoneH + safezoneY;
			// y = 0.760 * safezoneH + safezoneY;
			w = 0.175313 * safezoneW;
			h = 0.022 * safezoneH;
			SizeEx = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) * 0.85)";
		};
		class RscButton_1600 : twitter_RscButton {
			idc = 1600;
			text = "Tweet";
			colorText[] = { 1, 1, 1, 1 };
			colorBackground[] = { 0.012, 0.631, 0.988, 1 };
			shadow = 0;
			// x = 0.180313 * safezoneW + safezoneX;
			// y = 0.742 * safezoneH + safezoneY;
			// w = 0.0464063 * safezoneW;
			// h = 0.022 * safezoneH;

			// x = 0.180312 * safezoneW + safezoneX;
			// y = 0.412 * safezoneH + safezoneY;
			// w = 0.0464063 * safezoneW;
			// h = 0.022 * safezoneH;

			x = 0.180312 * safezoneW + safezoneX;
			y = 0.346 * safezoneH + safezoneY;
			w = 0.0464063 * safezoneW;
			h = 0.022 * safezoneH;
		};
	};
};