class SG_VehicleShop {
	idd = 8000240;
	name = "SG_VehicleShop";
	movingEnable = 0;
	enableSimulation = 1;

	class ControlsBackground {
		class BACKGROUND : SG_ctrlStatic {
			idc = -1;
			x = "0.01 * safezoneW + safezoneX";
			y = "0.1625 * safezoneH + safezoneY";
			w = "0.152 * safezoneW";
			h = "0.65 * safezoneH";
			colorBackground[] = { 0.2, 0.2, 0.2, 1 };
		};
		class BACKGROUND_SPEC : SG_ctrlStatic {
			idc = -1;
			x = "0.73090 * safezoneW + safezoneX";
			y = "0.398148 * safezoneH + safezoneY";
			w = "0.265 * safezoneW";
			h = "0.215 * safezoneH";
			colorBackground[] = { 0.2, 0.2, 0.2, 1 };
		};
		class HEADER : SG_ctrlStatic {
			idc = 8000241;
			text = "Vehicle Purchases"; // ToDo: Localize;
			x = "0.01 * safezoneW + safezoneX";
			y = "0.14 * safezoneH + safezoneY";
			w = "0.152 * safezoneW";
			h = "0.022 * safezoneH";
			colorBackground[] = { "(profilenamespace getvariable ['GUI_BCG_RGB_R',0.3843])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.7019])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.8862])", "1" };
		};
		class TREE_TITLE : SG_ctrlStatic {
			idc = -1;
			text = "Available Vehicles"; // ToDo: Localize;
			x = "0.015 * safezoneW + safezoneX";
			y = "0.17 * safezoneH + safezoneY";
			w = "0.140245 * safezoneW";
			h = "0.022 * safezoneH";
			colorBackground[] = { 0.05, 0.05, 0.05, 1 };
		};
		class TITLE_NAME : SG_ctrlStatic {
			idc = -1;
			text = "Name:"; // ToDo: Localize;
			x = "0.730542 * safezoneW + safezoneX";
			y = "0.400385 * safezoneH + safezoneY";
			w = "0.0773833 * safezoneW";
			h = "0.022 * safezoneH";
			colorBackground[] = { 0, 0, 0, 0.5 };
			style = 0x01;
		};
		class TITLE_PRICE : TITLE_NAME {
			text = "Price:"; // ToDo: Localize;
			y = "0.422726 * safezoneH + safezoneY";
		};
		class TITLE_MAXSPEED : TITLE_NAME {
			text = "Max Speed:"; // ToDo: Localize;
			y = "0.446341 * safezoneH + safezoneY";
		};
		class TITLE_HORSEPOWER : TITLE_NAME {
			text = "Horse Power:"; // ToDo: Localize;
			y = "0.469023 * safezoneH + safezoneY";
		};
		class TITLE_PASSENGERSEATS : TITLE_NAME {
			text = "Passenger Seats:"; // ToDo: Localize;
			y = "0.4924 * safezoneH + safezoneY";
		};
		class TITLE_TRUNKSPACE : TITLE_NAME {
			text = "Trunk Space:"; // ToDo: Localize;
			y = "0.516126 * safezoneH + safezoneY";
		};
		class TITLE_FUEL : TITLE_NAME {
			text = "Fuel Space:"; // ToDo: Localize;
			y = "0.538696 * safezoneH + safezoneY";
		};
		class TITLE_ARMOR : TITLE_NAME {
			text = "Armor:"; // ToDo: Localize;
			y = "0.562422 * safezoneH + safezoneY";
		};
		class TITLE_VEHICLESPECIFICATIONS : TITLE_NAME {
			text = "Vehicle Specifications"; // ToDo: Localize;
			y = "0.376533 * safezoneH + safezoneY";
			w = "0.265031 * safezoneW";
			colorBackground[] = { 0.05, 0.05, 0.05, 1 };
			style = 0x00;
		};
	};
	class controls {
		class TREE_VEHICLES : SG_ctrlTree {
			idc = 8000243;
			y = "0.2 * safezoneH + safezoneY";
			x = "0.015 * safezoneW + safezoneX";
			w = "0.140245 * safezoneW";
			h = "0.6 * safezoneH";
			colorBackground[] = { 0, 0, 0, 0.5 };
		};
		class TEXT_NAME : SG_ctrlStatic {
			idc = 8000245;
			text = "";
			x = "0.8086 * safezoneW + safezoneX";
			y = "0.400385 * safezoneH + safezoneY";
			w = "0.187196 * safezoneW";
			h = "0.022 * safezoneH";
			colorBackground[] = { 0, 0, 0, 0.4 };
		};
		class TEXT_PRICE : TEXT_NAME {
			idc = 8000246;
			text = "$0"; // ToDo: Localize;
			y = "0.422725 * safezoneH + safezoneY";
		};
		class TEXT_MAXSPEED : TEXT_NAME {
			idc = 8000247;
			text = "320 km/h"; // ToDo: Localize;
			y = "0.446333 * safezoneH + safezoneY";
		};
		class TEXT_HORSEPOWER : TEXT_NAME {
			idc = 8000248;
			text = "220hp"; // ToDo: Localize;
			y = "0.469482 * safezoneH + safezoneY";
		};
		class TEXT_PASSENGERSEATS : TEXT_NAME {
			idc = 8000249;
			text = "3"; // ToDo: Localize;
			y = "0.492519 * safezoneH + safezoneY";
		};
		class TEXT_TRUNKSPACE : TEXT_NAME {
			idc = 8000250;
			text = "30"; // ToDo: Localize;
			y = "0.516016 * safezoneH + safezoneY";
		};
		class TEXT_FUEL : TEXT_NAME {
			idc = 8000251;
			text = "50l"; // ToDo: Localize;
			y = "0.539163 * safezoneH + safezoneY";
		};
		class TEXT_ARMOR : TEXT_NAME {
			idc = 8000252;
			text = "220"; // ToDo: Localize;
			y = "0.562311 * safezoneH + safezoneY";
		};
		class BUTTON_RENT_VEHICLE : SG_ctrlDefaultButton {
			idc = 8000253;
			text = "RENT VEHICLE"; // ToDo: Localize;
			x = "0.737645 * safezoneW + safezoneX";
			y = "0.589 * safezoneH + safezoneY";
			w = "0.070 * safezoneW";
			h = "0.0198 * safezoneH";
			colorBackground[] = { 0, 0, 0, 1 };
		};
		class BUTTON_PURCHASE_VEHICLE : BUTTON_RENT_VEHICLE {
			idc = 8000254;
			text = "PURCHASE VEHICLE";
			w = "0.110341 * safezoneW";
			x = "0.879645 * safezoneW + safezoneX";
		};
		class INSURANCE_CHECKBOX : SG_RscCheckbox {
			idc = 8000255;
			x = "0.867645 * safezoneW + safezoneX";
			y = "0.589 * safezoneH + safezoneY";
			w = "0.0103125 * safezoneW";
			h = "0.0198 * safezoneH";
			colorBackground[] = { 0, 0, 0, 1 };
			tooltip = "Mark checkbox to add insurance to your vehicle"; // ToDo: Localize;
		};
	};
};