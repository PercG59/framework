class SG_PolicePC {
	idd = 61312;
	name = "SG_PolicePC";
	movingEnable = 0;
	enableSimulation = 1;

	class ControlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = -1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class Header : SG_ctrlStaticHeader {
			text = "Police Computer";
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (80 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 130 * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (80 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE));
			w = 130 * (pixelW * SG_GRID_SIZE);
			h = (73 * (pixelH * SG_GRID_SIZE)) - (5 * (pixelH * SG_GRID_SIZE)) - ((5 + 2) * (pixelH * SG_GRID_SIZE));
		};
	};

	class Controls {
		class ButtonPlayer : SG_ctrlDefaultButton {
			idc = 125;
			text = "NAME LOOKUP";
			x = (((getResolution select 2) * 0.5 * pixelW) - (120 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (50 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 120 * (pixelW * SG_GRID_SIZE);
			h = 10 * (pixelH * SG_GRID_SIZE);
			onButtonClick = "";
		};

		class ButtonPlate : SG_ctrlDefaultButton {
			idc = 126;
			text = "PLATE LOOKUP";
			x = (((getResolution select 2) * 0.5 * pixelW) - (120 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (20 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 120 * (pixelW * SG_GRID_SIZE);
			h = 10 * (pixelH * SG_GRID_SIZE);
			onButtonClick = "";
		};

		class ButtonWarrant : SG_ctrlDefaultButton {
			idc = 127;
			text = "WARRANT DATABASE";
			x = (((getResolution select 2) * 0.5 * pixelW) - (120 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (-10 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 120 * (pixelW * SG_GRID_SIZE);
			h = 10 * (pixelH * SG_GRID_SIZE);
			onButtonClick = "";
		};

		class FooterGroup : SG_ctrlControlsGroupNoScrollbars {
			idc = 124;
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (15 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (40 * (pixelH * SG_GRID_SIZE)) - ((5 + 2) * (pixelH * SG_GRID_SIZE));
			w = 130 * (pixelW * SG_GRID_SIZE);
			h = (5 + 2) * (pixelH * SG_GRID_SIZE);
			class Controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					w = 130 * (pixelW * SG_GRID_SIZE);
					h = (5 + 2) * (pixelH * SG_GRID_SIZE);
				};
			};
		};

		class ButtonCancel : SG_ctrlButtonClose {
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * SG_GRID_SIZE)) + (130 * (pixelW * SG_GRID_SIZE)) - (5 * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (80 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 5 * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
			onButtonClick = "closeDialog 0;";
		};
	};
};

class SG_PolicePCPlateLookup {
	idd = 61313;
	name = "SG_PolicePCPlateLookup";
	movingEnable = 0;
	enableSimulation = 1;

	class ControlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = -1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class Header : SG_ctrlStaticHeader {
			text = "Police Computer | Plate Lookup";
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (80 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 130 * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (80 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE));
			w = 130 * (pixelW * SG_GRID_SIZE);
			h = (80 * (pixelH * SG_GRID_SIZE)) - (5 * (pixelH * SG_GRID_SIZE)) - ((5 + 2) * (pixelH * SG_GRID_SIZE));
		};
	};

	class Controls {
		class BackgroundSearchPlateText : SG_ctrlStatic {
			idc = -1;
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (62 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 7 * (pixelH * SG_GRID_SIZE);
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};
		class SearchPlateText : SG_ctrlStatic {
			idc = -1;
			text = "Plate:";
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (62 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class Search : SG_ctrlEditNoRect {
			idc = 80;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (77 * 0.5) * (pixelW * SG_GRID_SIZE)) + (1.5 * (pixelW * SG_GRID_SIZE)));
			y = ((0.415 - (75 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE)));
			w = (245 / 2.5) * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
			maxChars = 7;
		};

		class ButtonSearch : SG_ctrlDefaultButton {
			idc = 125;
			text = "SEARCH PLATE";
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (50 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 123 * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
			onButtonClick = "";
		};

		class CarsFilterBackground : SG_ctrlStatic {
			idc = 232321 + 105;
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = ((0.415 - (60 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE))) + ((5 * (pixelH * SG_GRID_SIZE)) * 1) + (2 * (pixelH * SG_GRID_SIZE));
			w = (126 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = 5 * (pixelH * SG_GRID_SIZE);
			colorBackground[] = { 0, 0, 0, 1 };
		};

		class CarsFilter : SG_ctrlListNBox {
			idc = 82;
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = ((0.415 - (60 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE))) + ((5 * (pixelH * SG_GRID_SIZE)) * 1) + (2 * (pixelH * SG_GRID_SIZE));
			w = (126 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = 5 * (pixelH * SG_GRID_SIZE);
			disableOverflow = 1;
			columns[] = { 0, 0.4, 0.8 };
			class Items {
				class Vehicle {
					text = "Vehicle";
					value = 0;
				};
				class Owner : Vehicle {
					text = "Owner";
				};
				class Plate : Vehicle {
					text = "Plate";
				};
			};
		};
		class CarsListBackground : SG_ctrlStaticContent {
			idc = 232321 + 108;
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = ((0.415 - (60 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE))) + ((5 * (pixelH * SG_GRID_SIZE)) * 2) + (2 * (pixelH * SG_GRID_SIZE));
			w = (126 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = (50 / 1.4) * (pixelH * SG_GRID_SIZE);
		};
		class CarsList : CarsFilter {
			idc = 83;
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = ((0.415 - (60 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE))) + ((5 * (pixelH * SG_GRID_SIZE)) * 2) + (2 * (pixelH * SG_GRID_SIZE));
			w = (126 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = (50 / 1.4) * (pixelH * SG_GRID_SIZE);
			class Items {};
		};

		class FooterGroup : SG_ctrlControlsGroupNoScrollbars {
			idc = 124;
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (10 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (40 * (pixelH * SG_GRID_SIZE)) - ((5 + 2) * (pixelH * SG_GRID_SIZE));
			w = 130 * (pixelW * SG_GRID_SIZE);
			h = (5 + 2) * (pixelH * SG_GRID_SIZE);
			class Controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					w = 130 * (pixelW * SG_GRID_SIZE);
					h = (5 + 2) * (pixelH * SG_GRID_SIZE);
				};

				class ButtonOpenOwener : SG_ctrlDefaultButton {
					idc = 25;
					text = "OWNER PROFILE";
					x = (pixelW * SG_GRID_SIZE);
					y = (pixelH * SG_GRID_SIZE);
					w = (160 / 4) * (pixelW * SG_GRID_SIZE);
					h = 5 * (pixelH * SG_GRID_SIZE);
				};
				class ButtonDestroyWarrant : SG_ctrlDefaultButton {
					idc = 26;
					text = "VEHICLE PROFILE";
					x = ((pixelW * SG_GRID_SIZE) * 2) + ((160 / 4) * (pixelW * SG_GRID_SIZE));
					y = (pixelH * SG_GRID_SIZE);
					w = (160 / 4) * (pixelW * SG_GRID_SIZE);
					h = 5 * (pixelH * SG_GRID_SIZE);
				};
			};
		};

		class ButtonCancel : SG_ctrlButtonClose {
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * SG_GRID_SIZE)) + (130 * (pixelW * SG_GRID_SIZE)) - (5 * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (80 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 5 * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
			onButtonClick = "closeDialog 0;";
		};
	};
};

class SG_PolicePCPlateResult {
	idd = 61314;
	name = "SG_PolicePCPlateResult";
	movingEnable = 1;
	enableSimulation = 0;
	enableDisplay = 1;

	class ControlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = -1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class Header : SG_ctrlStaticHeader {
			text = "Police PC | Vehicle Info";
			x = (((getResolution select 2) * 0.5 * pixelW) - (100 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 100 * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (100 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE));
			w = 100 * (pixelW * SG_GRID_SIZE);
			h = (80 * (pixelH * SG_GRID_SIZE)) - (5 * (pixelH * SG_GRID_SIZE)) - ((5 + 2) * (pixelH * SG_GRID_SIZE));
		};
	};
	class Controls {
		class BackgroundVehicleNameText : SG_ctrlStatic {
			idc = -1;
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 25 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundVehicleName : SG_ctrlStatic {
			idc = -1;
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 25 * (pixelH * SG_GRID_SIZE);
			w = (157 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.40000001 };
		};

		class VehicleNameText : SG_ctrlStatic {
			idc = -1;
			text = "Vehicle Name";
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 25 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class VehicleName : SG_ctrlStatic {
			idc = 68;
			text = "2008 Ford Fiesta (SRT)";
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 25 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class BackgroundVehiclePlateText : SG_ctrlStatic {
			idc = -1;
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 33 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundVehiclePlate : SG_ctrlStatic {
			idc = -1;
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 33 * (pixelH * SG_GRID_SIZE);
			w = (157 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.40000001 };
		};

		class VehiclePlateText : SG_ctrlStatic {
			idc = -1;
			text = "Vehicle Plate";
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 33 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class VehiclePlate : SG_ctrlStatic {
			idc = 69;
			text = "K1LL3RS";
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 33 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class BackgroundVehicleInsuredText : SG_ctrlStatic {
			idc = -1;
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 41 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundVehicleInsured : SG_ctrlStatic {
			idc = -1;
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 41 * (pixelH * SG_GRID_SIZE);
			w = (157 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.40000001 };
		};

		class VehicleInsuredText : SG_ctrlStatic {
			idc = -1;
			text = "Vehicle Insured";
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 41 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class VehicleInsured : SG_ctrlStatic {
			idc = 70;
			text = "Yes";
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 41 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class BackgroundVehicleTintText : SG_ctrlStatic {
			idc = -1;
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 49 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundVehicleTint : SG_ctrlStatic {
			idc = -1;
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 49 * (pixelH * SG_GRID_SIZE);
			w = (157 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.40000001 };
		};

		class VehicleTintText : SG_ctrlStatic {
			idc = -1;
			text = "Vehicle Tint";
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 49 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class VehicleTint : SG_ctrlStatic {
			idc = 71;
			text = "0.7";
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 49 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class BackgroundVehicleOwnerText : SG_ctrlStatic {
			idc = -1;
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 57 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundVehicleOwner : SG_ctrlStatic {
			idc = -1;
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 57 * (pixelH * SG_GRID_SIZE);
			w = (157 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.40000001 };
		};

		class VehicleOwnerText : SG_ctrlStatic {
			idc = -1;
			text = "Vehicle Owner";
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 57 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class VehicleOwner : SG_ctrlStatic {
			idc = 72;
			text = "Travis Butts";
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 57 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class BackgroundVehicleKeysText : SG_ctrlStatic {
			idc = -1;
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 65 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (15 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundVehicleKeys : SG_ctrlStatic {
			idc = -1;
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 65 * (pixelH * SG_GRID_SIZE);
			w = (157 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (15 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.40000001 };
		};

		class VehicleKeysText : SG_ctrlStatic {
			idc = -1;
			text = "Vehicle Keys";
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 68 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class VehicleKeys : SG_ctrlStatic {
			idc = 73;
			text = "Travis Butts";
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 65 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class BackgroundReportStolenText : SG_ctrlStatic {
			idc = -1;
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 79 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundReportStolen : SG_ctrlStatic {
			idc = -1;
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 79 * (pixelH * SG_GRID_SIZE);
			w = (157 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.40000001 };
		};

		class ReportStolenText : SG_ctrlStatic {
			idc = -1;
			text = "Reported Stolen";
			x = (51 * (pixelW * SG_GRID_SIZE));
			y = 79 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class ReportStolen : SG_ctrlStatic {
			idc = 74;
			text = "Yes";
			x = (75 * (pixelW * SG_GRID_SIZE));
			y = 79 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class GroupFooter : SG_ctrlControlsGroupNoScrollbars {
			idc = 43;
			x = (((getResolution select 2) * 0.5 * pixelW) - (100 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (140 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (100 * (pixelH * SG_GRID_SIZE)) - ((5 + 2) * (pixelH * SG_GRID_SIZE));
			h = (5 + 2) * (pixelH * SG_GRID_SIZE);
			w = 100 * (pixelW * SG_GRID_SIZE);
			class Controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					h = (5 + 2) * (pixelH * SG_GRID_SIZE);
					w = 160 * (pixelW * SG_GRID_SIZE);
				};
				class ButtonPayTicket : SG_ctrlDefaultButton {
					idc = 25;
					text = "OWNER PROFILE";
					x = (pixelW * SG_GRID_SIZE);
					y = (pixelH * SG_GRID_SIZE);
					w = (160 / 4) * (pixelW * SG_GRID_SIZE);
					h = 5 * (pixelH * SG_GRID_SIZE);
				};
			};
		};

		class ButtonClose : SG_ctrlButtonClose {
			x = (((getResolution select 2) * 0.5 * pixelW) - (220 * 0.5) * (pixelW * SG_GRID_SIZE)) + (160 * (pixelW * SG_GRID_SIZE)) - (5 * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 5 * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
		};
	};
};

class SG_PolicePCNameLookup {
	idd = 61315;
	name = "SG_PolicePCNameLookup";
	movingEnable = 0;
	enableSimulation = 1;

	class ControlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = -1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class Header : SG_ctrlStaticHeader {
			text = "Police Computer | Name Lookup";
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (80 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 130 * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (80 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE));
			w = 130 * (pixelW * SG_GRID_SIZE);
			h = (80 * (pixelH * SG_GRID_SIZE)) - (5 * (pixelH * SG_GRID_SIZE)) - ((5 + 2) * (pixelH * SG_GRID_SIZE));
		};
	};

	class Controls {
		class BackgroundSearchPlateText : SG_ctrlStatic {
			idc = -1;
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (62 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 7 * (pixelH * SG_GRID_SIZE);
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};
		class SearchPlateText : SG_ctrlStatic {
			idc = -1;
			text = "Name:";
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (62 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class Search : SG_ctrlEditNoRect {
			idc = 80;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (77 * 0.5) * (pixelW * SG_GRID_SIZE)) + (1.5 * (pixelW * SG_GRID_SIZE)));
			y = ((0.415 - (75 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE)));
			w = (245 / 2.5) * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class ButtonSearch : SG_ctrlDefaultButton {
			idc = 125;
			text = "SEARCH NAME";
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (50 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 123 * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
			onButtonClick = "";
		};

		class PlayersFilterBackground : SG_ctrlStatic {
			idc = 232321 + 105;
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = ((0.415 - (60 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE))) + ((5 * (pixelH * SG_GRID_SIZE)) * 1) + (2 * (pixelH * SG_GRID_SIZE));
			w = (126 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = 5 * (pixelH * SG_GRID_SIZE);
			colorBackground[] = { 0, 0, 0, 1 };
		};

		class PlayersFilter : SG_ctrlListNBox {
			idc = 82;
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = ((0.415 - (60 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE))) + ((5 * (pixelH * SG_GRID_SIZE)) * 1) + (2 * (pixelH * SG_GRID_SIZE));
			w = (126 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = 5 * (pixelH * SG_GRID_SIZE);
			disableOverflow = 1;
			columns[] = { 0, 0.4, 0.8 };
			class Items {
				class Name {
					text = "Name";
					value = 0;
				};
				class Jailed : Name {
					text = "Jailed";
				};
				class Active : Name {
					text = "Active";
				};
			};
		};

		class PlayersListBackground : SG_ctrlStaticContent {
			idc = 232321 + 108;
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = ((0.415 - (60 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE))) + ((5 * (pixelH * SG_GRID_SIZE)) * 2) + (2 * (pixelH * SG_GRID_SIZE));
			w = (126 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = (50 / 1.4) * (pixelH * SG_GRID_SIZE);
		};

		class PlayersList : PlayersFilter {
			idc = 83;
			x = (37 * (pixelW * SG_GRID_SIZE));
			y = ((0.415 - (60 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE))) + ((5 * (pixelH * SG_GRID_SIZE)) * 2) + (2 * (pixelH * SG_GRID_SIZE));
			w = (126 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = (50 / 1.4) * (pixelH * SG_GRID_SIZE);
			class Items {};
		};

		class FooterGroup : SG_ctrlControlsGroupNoScrollbars {
			idc = 124;
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (10 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (40 * (pixelH * SG_GRID_SIZE)) - ((5 + 2) * (pixelH * SG_GRID_SIZE));
			w = 130 * (pixelW * SG_GRID_SIZE);
			h = (5 + 2) * (pixelH * SG_GRID_SIZE);
			class Controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					w = 130 * (pixelW * SG_GRID_SIZE);
					h = (5 + 2) * (pixelH * SG_GRID_SIZE);
				};

				class ButtonOpenProfile : SG_ctrlDefaultButton {
					idc = 25;
					text = "VIEW PROFILE";
					x = (pixelW * SG_GRID_SIZE);
					y = (pixelH * SG_GRID_SIZE);
					w = (160 / 4) * (pixelW * SG_GRID_SIZE);
					h = 5 * (pixelH * SG_GRID_SIZE);
				};
			};
		};

		class ButtonCancel : SG_ctrlButtonClose {
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * SG_GRID_SIZE)) + (130 * (pixelW * SG_GRID_SIZE)) - (5 * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (80 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 5 * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
			onButtonClick = "closeDialog 0;";
		};
	};
};

class SG_PolicePCPlayerResult {
	idd = 61316;
	name = "SG_PolicePCPlayerResult";
	movingEnable = 1;
	enableSimulation = 0;
	enableDisplay = 1;

	class ControlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = -1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class Header : SG_ctrlStaticHeader {
			idc = -1;
			text = "Police PC | Player Result";
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 160 * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE));
			w = 160 * (pixelW * SG_GRID_SIZE);
			h = (100 * (pixelH * SG_GRID_SIZE)) - (5 * (pixelH * SG_GRID_SIZE)) - ((5 + 2) * (pixelH * SG_GRID_SIZE));
		};
	};
	class Controls {
		class NotWorking : SG_ctrlStatic {
			idc = -1;
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 25 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundPlayerNameText : SG_ctrlStatic {
			idc = -1;
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 25 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundPlayerName : SG_ctrlStatic {
			idc = -1;
			x = (47 * (pixelW * SG_GRID_SIZE));
			y = 25 * (pixelH * SG_GRID_SIZE);
			w = (130 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.40000001 };
		};

		class PlayerNameText : SG_ctrlStatic {
			idc = -1;
			text = "Player Name";
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 25 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class PlayerName : SG_ctrlStatic {
			idc = 68;
			text = "Travis Butts";
			x = (47 * (pixelW * SG_GRID_SIZE));
			y = 25 * (pixelH * SG_GRID_SIZE);
			w = (130 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class BackgroundWarrantsText : SG_ctrlStatic {
			idc = -1;
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 32 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundWarrants : SG_ctrlStatic {
			idc = -1;
			x = (47 * (pixelW * SG_GRID_SIZE));
			y = 32 * (pixelH * SG_GRID_SIZE);
			w = (130 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.40000001 };
		};

		class WarrantsText : SG_ctrlStatic {
			idc = -1;
			text = "Warrants";
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 32 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class Warrants : SG_ctrlStatic {
			idc = 69;
			text = "6";
			x = (47 * (pixelW * SG_GRID_SIZE));
			y = 32 * (pixelH * SG_GRID_SIZE);
			w = (130 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class BackgroundTicketsText : SG_ctrlStatic {
			idc = -1;
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 39 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundTickets : SG_ctrlStatic {
			idc = -1;
			x = (47 * (pixelW * SG_GRID_SIZE));
			y = 39 * (pixelH * SG_GRID_SIZE);
			w = (130 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.40000001 };
		};

		class TicketsText : SG_ctrlStatic {
			idc = -1;
			text = "Unpaid Tickets";
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 39 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class Tickets : SG_ctrlStatic {
			idc = 70;
			text = "6";
			x = (47 * (pixelW * SG_GRID_SIZE));
			y = 39 * (pixelH * SG_GRID_SIZE);
			w = (130 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class BackgroundArrestsText : SG_ctrlStatic {
			idc = -1;
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 46 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundArrests : SG_ctrlStatic {
			idc = -1;
			x = (47 * (pixelW * SG_GRID_SIZE));
			y = 46 * (pixelH * SG_GRID_SIZE);
			w = (130 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.40000001 };
		};

		class ArrestsText : SG_ctrlStatic {
			idc = -1;
			text = "Arrests";
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 46 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class Arrests : SG_ctrlStatic {
			idc = 71;
			text = "6";
			x = (47 * (pixelW * SG_GRID_SIZE));
			y = 46 * (pixelH * SG_GRID_SIZE);
			w = (130 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class BackgroundHousesText : SG_ctrlStatic {
			idc = -1;
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 53 * (pixelH * SG_GRID_SIZE);
			w = (50 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class BackgroundHouses : SG_ctrlStatic {
			idc = -1;
			x = (47 * (pixelW * SG_GRID_SIZE));
			y = 53 * (pixelH * SG_GRID_SIZE);
			w = (130 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.40000001 };
		};

		class HousesText : SG_ctrlStatic {
			idc = -1;
			text = "Houses";
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 53 * (pixelH * SG_GRID_SIZE);
			w = (120 * (pixelW * SG_GRID_SIZE)) * 0.48;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class Houses : SG_ctrlStatic {
			idc = 72;
			text = "6";
			x = (47 * (pixelW * SG_GRID_SIZE));
			y = 53 * (pixelH * SG_GRID_SIZE);
			w = (130 * (pixelW * SG_GRID_SIZE)) * 0.46;
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class BackgroundTicketsUIText : SG_ctrlStatic {
			idc = -1;
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 60 * (pixelH * SG_GRID_SIZE);
			w = (155 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = (7 * (pixelH * SG_GRID_SIZE)) * 0.72;
			colorBackground[] = { 0, 0, 0, 0.60000001 };
		};

		class TicketsUIText : SG_ctrlStatic {
			idc = -1;
			text = "All Tickets";
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = 60 * (pixelH * SG_GRID_SIZE);
			w = (155 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = 5 * (pixelH * SG_GRID_SIZE);
		};

		class TicketsFilterBackground : SG_ctrlStatic {
			idc = 232321 + 105;
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = ((0.415 - (30 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE))) + ((5 * (pixelH * SG_GRID_SIZE)) * 1) + (2 * (pixelH * SG_GRID_SIZE));
			w = (155 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = 5 * (pixelH * SG_GRID_SIZE);
			colorBackground[] = { 0, 0, 0, 1 };
		};

		class TicketsFilter : SG_ctrlListNBox {
			idc = 82;
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = ((0.415 - (30 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE))) + ((5 * (pixelH * SG_GRID_SIZE)) * 1) + (2 * (pixelH * SG_GRID_SIZE));
			w = (155 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = 5 * (pixelH * SG_GRID_SIZE);
			disableOverflow = 1;
			columns[] = { 0, 0.4, 0.8 };
			class Items {
				class Issued {
					text = "Issued";
					value = 0;
				};
				class Reason : Issued {
					text = "Reason";
				};
				class Officer : Issued {
					text = "Officer";
				};
			};
		};

		class TicketsListBackground : SG_ctrlStaticContent {
			idc = 232321 + 108;
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = ((0.415 - (30 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE))) + ((5 * (pixelH * SG_GRID_SIZE)) * 2) + (2 * (pixelH * SG_GRID_SIZE));
			w = (155 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = (50 / 1.4) * (pixelH * SG_GRID_SIZE);
		};

		class TicketsList : TicketsFilter {
			idc = 83;
			x = (23 * (pixelW * SG_GRID_SIZE));
			y = ((0.415 - (30 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (5 * (pixelH * SG_GRID_SIZE)) + (1.5 * (pixelH * SG_GRID_SIZE))) + ((5 * (pixelH * SG_GRID_SIZE)) * 2) + (2 * (pixelH * SG_GRID_SIZE));
			w = (155 * (pixelW * SG_GRID_SIZE)) - ((1.5 * (pixelW * SG_GRID_SIZE)) * 2);
			h = (50 / 1.4) * (pixelH * SG_GRID_SIZE);
			class Items {};
		};

		class GroupFooter : SG_ctrlControlsGroupNoScrollbars {
			idc = 43;
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * SG_GRID_SIZE)) + (100 * (pixelH * SG_GRID_SIZE)) - ((5 + 2) * (pixelH * SG_GRID_SIZE));
			h = (5 + 2) * (pixelH * SG_GRID_SIZE);
			w = 160 * (pixelW * SG_GRID_SIZE);
			class Controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					h = (5 + 2) * (pixelH * SG_GRID_SIZE);
					w = 160 * (pixelW * SG_GRID_SIZE);
				};
				class ButtonPayTicket : SG_ctrlDefaultButton {
					idc = 25;
					text = "BACK TO MAIN";
					x = (pixelW * SG_GRID_SIZE);
					y = (pixelH * SG_GRID_SIZE);
					w = (160 / 4) * (pixelW * SG_GRID_SIZE);
					h = 5 * (pixelH * SG_GRID_SIZE);
				};
			};
		};

		class ButtonClose : SG_ctrlButtonClose {
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * SG_GRID_SIZE)) + (160 * (pixelW * SG_GRID_SIZE)) - (5 * (pixelW * SG_GRID_SIZE));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * SG_GRID_SIZE));
			w = 5 * (pixelW * SG_GRID_SIZE);
			h = 5 * (pixelH * SG_GRID_SIZE);
		};
	};
};