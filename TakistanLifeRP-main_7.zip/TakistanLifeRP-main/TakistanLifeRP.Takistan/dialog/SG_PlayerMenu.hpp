#define PM_W 175
#define PM_H 100
#define PM_BAR_H 15
#define PM_GAP_W (2 * GRID_W)
#define PM_GAP_H (2 * GRID_H)
#define PM_BACKGROUND {0.1, 0.1, 0.1, 0.9}

#define PM_BUTTON_W (PM_W * 0.2 * GRID_W) - (PM_GAP_W * 0.8)
#define PM_BUTTON_H (PM_H * 0.333 * GRID_H) - (PM_GAP_H * 0.666)


#define PM_COLOR {"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.77])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.51])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.08])", 1 }

#define PM_STARTPOS_X CENTER_X - (PM_W * 0.5) * GRID_W
#define PM_STARTPOS_Y CENTER_Y - (PM_H * 0.5) * GRID_H

class SG_PlayerMenu {
	idd          = 0;
	scriptName   = "SG_PlayerMenu";
	onLoad = "[ 'onLoad', _this ] call SG_PlayerMenu";
	onUnload = "[ 'onUnload', _this ] call SG_PlayerMenu";

	class controlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = 1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
	};
	class controls {

		class HeaderBar: SG_ctrlControlsGroupNoScrollbars {
			idc = 2;
			x   = PM_STARTPOS_X;
			y   = PM_STARTPOS_Y - PM_GAP_H - (PM_BAR_H * GRID_H);
			w   = PM_W * GRID_W;
			h   = PM_BAR_H * GRID_H;
			class Controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					w   = PM_W * GRID_W;
					h   = PM_BAR_H * GRID_H;
					colorBackground[] = PM_COLOR;
				};

				class Header : SG_RscText {
					idc  = 3;
					text = "Takistan RP";
					w    = PM_W * GRID_W;
					h    = PM_BAR_H * GRID_H;
					colorBackground[] = {0,0,0,0};
					colorText[] = { 1, 1, 1, 1 };
					shadow = 0;
					size = 2;
					style = ST_CENTER;
				};
			};
		};

		class ButtonGroup: SG_ctrlControlsGroupNoScrollbars {
			idc = 4;
			x   = PM_STARTPOS_X;
			y   = PM_STARTPOS_Y;
			w   = PM_W * GRID_W;
			h   = PM_H * GRID_H;
			class Controls {
				// class Background : SG_ctrlStaticFooter {
				// 	w = PM_W * GRID_W;
				// 	h = PM_H * GRID_H;
				// 	colorBackground[] = {0.15, 0.15, 0.15, 0.45};
				// };


				class ContentGroup : SG_RscControlsGroupNoScrollbars {
					idc = 5;
					w   = PM_BUTTON_W + PM_BUTTON_W + PM_GAP_W;
					h   = PM_BUTTON_H + PM_BUTTON_H + PM_BUTTON_H + PM_GAP_H + PM_GAP_H;
					class Controls {
						class Content : SG_ctrlStructuredText {
							idc = 6;

							w   = PM_BUTTON_W + PM_BUTTON_W + PM_GAP_W;
							h   = PM_BUTTON_H + PM_BUTTON_H + PM_BUTTON_H + PM_GAP_H + PM_GAP_H;
							colorBackground[] = { 0.2, 0.2, 0.2, 1 };
						};
					}
				};

				class Settings : SG_ctrlShortcutButton {
					idc = 7;
					x   = PM_BUTTON_W + PM_BUTTON_W + PM_GAP_W + PM_GAP_W;
					w   = PM_BUTTON_W;
					h   = PM_BUTTON_H;

					tooltip = "Settings";
					textureNoShortcut = "\SG_Hud\images\displays\PlayerMenu\settings_ca.paa";
					text = "Settings";

					colorBackground[] = { 0.2, 0.2, 0.2, 1 };
					colorBackground2[] = PM_COLOR;
					colorBackgroundFocused[] = PM_COLOR;
					colorBackgroundActive[] = PM_COLOR;
					class TextPos : TextPos {
						top = PM_BUTTON_H - PM_GAP_W - PM_GAP_W - PM_GAP_W - PM_GAP_W;
					};

					class ShortcutPos {
						left = (PM_W * 0.045 * GRID_W);
        				top = (PM_W * 0.035 * GRID_H);
						w = (PM_W * 0.1 * GRID_W);
						h = (PM_W * 0.1 * GRID_H);
					};
					shortcuts[] = {};
					class Attributes {
						align = "center";
						color = "#ffffff";
						font = "RobotoCondensedLight";
						shadow = 0;
					};
				};

				class VirtualInventory : Settings {
					idc = 8;
					x   = PM_BUTTON_W + PM_BUTTON_W + PM_BUTTON_W + PM_GAP_W + PM_GAP_W + PM_GAP_W;
					w   = PM_BUTTON_W;
					h   = PM_BUTTON_H;

					tooltip = "Inventory";
					textureNoShortcut = "\SG_Hud\images\displays\PlayerMenu\inventory_ca.paa";
					text = "Items";
				};
				class Market : Settings {
					idc = 9;
					x   = PM_BUTTON_W + PM_BUTTON_W + PM_BUTTON_W + PM_BUTTON_W + PM_GAP_W + PM_GAP_W + PM_GAP_W + PM_GAP_W;
					w   = PM_BUTTON_W;
					h   = PM_BUTTON_H;

					tooltip = "Market";
					textureNoShortcut = "\SG_Hud\images\displays\PlayerMenu\market_ca.paa";
					text = "Market";
				};

				class Gang : Settings {
					idc = 10;
					x   = PM_BUTTON_W + PM_BUTTON_W + PM_GAP_W + PM_GAP_W;
					y   = PM_BUTTON_H + PM_GAP_H;
					w   = PM_BUTTON_W;
					h   = PM_BUTTON_H;

					tooltip = "Gang";
					textureNoShortcut = "\SG_Hud\images\displays\PlayerMenu\gang_ca.paa";
					text = "Gang";
				};
				class Police : Settings {
					idc = 16;
					x   = PM_BUTTON_W + PM_BUTTON_W + PM_GAP_W + PM_GAP_W;
					y   = PM_BUTTON_H + PM_GAP_H;
					w   = PM_BUTTON_W;
					h   = PM_BUTTON_H;

					tooltip = "Police Computer";
					textureNoShortcut = "\SG_Hud\images\displays\PlayerMenu\police_ca.paa";
					text = "Database";
				};
				class Wiki : Settings {
					idc = 11;
					x   = PM_BUTTON_W + PM_BUTTON_W + PM_BUTTON_W + PM_GAP_W + PM_GAP_W + PM_GAP_W;
					y   = PM_BUTTON_H + PM_GAP_H;
					w   = PM_BUTTON_W;
					h   = PM_BUTTON_H;

					tooltip = "Wiki";
					textureNoShortcut = "\SG_Hud\images\displays\PlayerMenu\wiki_ca.paa";
					text = "Wiki";
				};
				
				class Keys : Settings {
					idc = 12;
					x   = PM_BUTTON_W + PM_BUTTON_W + PM_BUTTON_W + PM_BUTTON_W + PM_GAP_W + PM_GAP_W + PM_GAP_W + PM_GAP_W;
					y   = PM_BUTTON_H + PM_GAP_H;
					w   = PM_BUTTON_W;
					h   = PM_BUTTON_H;

					tooltip = "Keys";
					textureNoShortcut = "\SG_Hud\images\displays\PlayerMenu\keys_ca.paa";
					text = "Keys";
				};

				class Perks : Settings {
					idc = 13;
					x   = PM_BUTTON_W + PM_BUTTON_W + PM_GAP_W + PM_GAP_W;
					y   = PM_BUTTON_H + PM_BUTTON_H + PM_GAP_H + PM_GAP_H;
					w   = PM_BUTTON_W;
					h   = PM_BUTTON_H;

					tooltip = "Perks";
					textureNoShortcut = "\SG_Hud\images\displays\PlayerMenu\perks_ca.paa";
					text = "Perks";
				};

				class Msg : Settings {
					idc = 14;
					x   = PM_BUTTON_W + PM_BUTTON_W + PM_BUTTON_W + PM_GAP_W + PM_GAP_W + PM_GAP_W;
					y   = PM_BUTTON_H + PM_BUTTON_H + PM_GAP_H + PM_GAP_H;
					w   = PM_BUTTON_W;
					h   = PM_BUTTON_H;

					tooltip = "Messages";
					textureNoShortcut = "\SG_Hud\images\displays\PlayerMenu\messenger_ca.paa";
					text = "Messages";
				};

				class Profile : Settings {
					idc = 15;
					x   = PM_BUTTON_W + PM_BUTTON_W + PM_BUTTON_W + PM_BUTTON_W + PM_GAP_W + PM_GAP_W + PM_GAP_W + PM_GAP_W;
					y   = PM_BUTTON_H + PM_BUTTON_H + PM_GAP_H + PM_GAP_H;
					w   = PM_BUTTON_W;
					h   = PM_BUTTON_H;

					tooltip = "Profile";
					textureNoShortcut = "\SG_Hud\images\displays\PlayerMenu\profile_ca.paa";
					text = "Profile";
				};
			};
		};
	};
};