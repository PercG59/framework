class SG_TicketGive {
	idd = 99921;
	name = "SG_TicketGive";
	movingEnable = 1;
	enableSimulation = 0;
	enableDisplay = 1;

	class ControlsBackground {
		class Tiles : SG_RscTiles {};

		class Header : SG_ctrlStaticHeader {
			text = "Issue a ticket";
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (38 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 130 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (38 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50));
			w = 130 * (pixelW * pixelGrid * 0.50);
			h = (38 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50)) - ((5 + 2) * (pixelH * pixelGrid * 0.50));
		};
		class TicketPriceText : SG_ctrlStatic {
			text = "Please enter the price of the ticket, min is $200 and max is $100,000";
			x = ((((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (38 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50)));
			w = (130 * (pixelW * pixelGrid * 0.50)) - (1.5 * (pixelW * pixelGrid * 0.50));
			h = (5 * (pixelH * pixelGrid * 0.50)) * 3;
			style = ST_MULTI + ST_NO_RECT;
		};

		class TicketReasonText : SG_ctrlStatic {
			text = "Please enter the reason of the ticket, list the crimes commited!";
			x = ((((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.500 - (38 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50)));
			w = (130 * (pixelW * pixelGrid * 0.50)) - (1.5 * (pixelW * pixelGrid * 0.50));
			h = (5 * (pixelH * pixelGrid * 0.50)) * 3;
			style = ST_MULTI + ST_NO_RECT;
		};
	};

	class Controls {
		class TicketPrice : SG_ctrlEditNoRect {
			idc = 22;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.340 - (38 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (1.5 * (pixelH * pixelGrid * 0.50));
			w = (130 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};

		class TicketReason : SG_ctrlEditNoRect {
			idc = 23;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.425 - (38 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (1.5 * (pixelH * pixelGrid * 0.50));
			w = (130 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class FooterGroup : SG_ctrlControlsGroupNoScrollbars {
			idc = 24;
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (38 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (38 * (pixelH * pixelGrid * 0.50)) - ((5 + 2) * (pixelH * pixelGrid * 0.50));
			w = 130 * (pixelW * pixelGrid * 0.50);
			h = (5 + 2) * (pixelH * pixelGrid * 0.50);
			class Controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					w = 130 * (pixelW * pixelGrid * 0.50);
					h = (5 + 2) * (pixelH * pixelGrid * 0.50);
				};
				class ButtonIssueTicket : SG_ctrlDefaultButton {
					idc = 25;
					text = "ISSUE TICKET";
					x = (pixelW * pixelGrid * 0.50);
					y = (pixelH * pixelGrid * 0.50);
					w = (130 * (pixelW * pixelGrid * 0.50)) * 0.3;
					h = 5 * (pixelH * pixelGrid * 0.50);
				};
			};
		};
		class ButtonCancel : SG_ctrlButtonClose {
			x = (((getResolution select 2) * 0.5 * pixelW) - (130 * 0.5) * (pixelW * pixelGrid * 0.50)) + (130 * (pixelW * pixelGrid * 0.50)) - (5 * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (38 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 5 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
	};
};
