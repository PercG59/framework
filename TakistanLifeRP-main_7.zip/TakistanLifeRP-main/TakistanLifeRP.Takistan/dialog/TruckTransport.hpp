class SG_TruckTransport {
	idd = 95233;
	name = "SG_TruckTransport";
	movingEnable = 0;
	enableSimulation = 1;

	class controlsBackground {
		class TruckHeader : SG_ctrlStaticHeader {
			text = "Transport Jobs";
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (100 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50));
		};
		class FilterBackground : SG_ctrlStatic {
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50));
			w = (160 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = 5 * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 1 };
		};
		class ListBackground : SG_ctrlStaticContent {
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 2) + (1.5 * (pixelH * pixelGrid * 0.50));
			w = (160 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = (100 * (pixelH * pixelGrid * 0.50)) * 0.8;
		};
	};
	class controls {
		class Search : SG_ctrlEditNoRect {
			idc = 23;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50)));
			w = (160 / 3) * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class ButtonSearch : SG_ctrlButtonSearch {
			idc = 24;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50))) + ((160 / 3) * (pixelW * pixelGrid * 0.50)) + (0.85 * (pixelW * pixelGrid * 0.50));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50)));
		};
		class Filter : SG_ctrlListNBox {
			idc = 25;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50));
			w = (160 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = 5 * (pixelH * pixelGrid * 0.50);
			disableOverflow = 1;
			columns[] = { 0, 0.18, 0.36, 0.56, 0.85 };
			class Items {
				class PickupLoaction {
					text = "Pickup Location";
					value = 0;
				};
				class DropOffLocation : PickupLoaction {
					text = "Drop-Off Location";
				};
				class DistanceToPickup : PickupLoaction {
					text = "Distance to Pickup";
				};
				class DistanceFromPicktoDrop : PickupLoaction {
					text = "Distance from Pickup to Drop";
				};
				class JobPayout : PickupLoaction {
					text = "Job Payout";
				};
			};
		};
		class List : Filter {
			idc = 26;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 2) + (1.5 * (pixelH * pixelGrid * 0.50));
			w = (160 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = (100 * (pixelH * pixelGrid * 0.50)) * 0.8;
			class Items {};
		};
		class Footer : SG_ctrlControlsGroupNoScrollbars {
			idc = 27;
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + ((100 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50))) + (5 * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (5 + 2) * (pixelH * pixelGrid * 0.50);
			class controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					w = "safezoneW";
					h = "safezoneH";
				};
				class ButtonTakeJob : SG_ctrlDefaultButton {
					idc = 1;
					text = "TAKE JOB";
					x = (pixelW * pixelGrid * 0.50);
					y = (pixelH * pixelGrid * 0.50);
					w = (160 / 6.8) * (pixelW * pixelGrid * 0.50);
					h = 5 * (pixelH * pixelGrid * 0.50);
				};
				class ButtonQuitJob : SG_ctrlDefaultButton {
					idc = 2;
					text = "QUIT JOB";
					x = ((pixelW * pixelGrid * 0.50) * 2) + (160 / 6.8) * (pixelW * pixelGrid * 0.50);
					y = (pixelH * pixelGrid * 0.50);
					w = (160 / 6.8) * (pixelW * pixelGrid * 0.50);
					h = 5 * (pixelH * pixelGrid * 0.50);
				};
			};
		};
		class ButtonClose : SG_ctrlButtonClose {
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + ((160 * (pixelW * pixelGrid * 0.50)) - (5 * (pixelW * pixelGrid * 0.50)));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			h = 5 * (pixelH * pixelGrid * 0.50);
			w = 5 * (pixelW * pixelGrid * 0.50);
		};
	};
};