class SG_Slots {
	idd = 51862;
	name = "SG_Slots";
	movingEnable = 0;
	enableSimulation = 1;

	class controlsBackground {
		class Header : SG_ctrlStaticHeader {
			idc = 32;
			text = "Slots";
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.440 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.440 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (85 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50));
		};
		class SlotsTopBackground : SG_ctrlStatic {
			x = ((((getResolution select 2) * 0.5 * pixelW) - (155 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + (5 * (pixelH * pixelGrid * 0.50)) + (2 * (pixelH * pixelGrid * 0.50 / 2));
			w = ((330 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = 5 * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 1 };
		};

		class SlotsLabel : SG_ctrlStatic {
			idc = 232321 + 1;
			text = "Spin Result";
			x = ((((getResolution select 2) * 0.5 * pixelW) - (155 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.456 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50)));
			w = ((330 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = 5 * (pixelH * pixelGrid * 0.50);
		};

		class SlotsBackground : SG_ctrlStatic {
			idc = 25;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (155 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.376 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
			w = ((330 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = (85 / 1.34) * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0.08, 0.08, 0.08, 1 };
		};

		class FirstSpinnerBack : SG_ctrlStatic {
			idc = -1;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (145 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.45 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
			w = ((80 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = (50 / 1.34) * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 1 };
		};

		class SecondSpinnerBack : SG_ctrlStatic {
			idc = -1;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (40 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.45 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
			w = ((80 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = (50 / 1.34) * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 1 };
		};

		class ThirdSpinnerBack : SG_ctrlStatic {
			idc = -1;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (-64 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.45 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
			w = ((80 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = (50 / 1.34) * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 1 };
		};
	};
	class controls {
		class FirstSpinner : SG_ctrlStaticPictureKeepAspect {
			idc = 26;
			text = "";
			x = ((((getResolution select 2) * 0.5 * pixelW) - (145 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.45 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
			w = ((80 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = (50 / 1.34) * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 0 };
		};

		class SecondSpinner : SG_ctrlStaticPictureKeepAspect {
			idc = 27;
			text = "";
			x = ((((getResolution select 2) * 0.5 * pixelW) - (40 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.45 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
			w = ((80 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = (50 / 1.34) * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 0 };
		};

		class ThirdSpinner : SG_ctrlStaticPictureKeepAspect {
			idc = 28;
			text = "";
			x = ((((getResolution select 2) * 0.5 * pixelW) - (-64 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.45 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (2 * (pixelH * pixelGrid * 0.50));
			w = ((80 / 2.18) * (pixelW * pixelGrid * 0.50));
			h = (50 / 1.34) * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 0 };
		};

		class Footer : SG_ctrlControlsGroupNoScrollbars {
			idc = 46;
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.33 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + ((100 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50))) + (5 * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (5 + 2) * (pixelH * pixelGrid * 0.50);
			class controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					w = 160 * (pixelW * pixelGrid * 0.50);
					h = (5 + 2) * (pixelH * pixelGrid * 0.50);
				};
				class OneThousandSpin : SG_ctrlDefaultButton {
					idc = 125;
					text = "$1,000 SPIN";
					x = (pixelW * pixelGrid * 0.50);
					y = (pixelH * pixelGrid * 0.50);
					w = (130 * (pixelW * pixelGrid * 0.50)) * 0.2;
					h = 5 * (pixelH * pixelGrid * 0.50);
					onButtonClick = "";
				};
				class FiveThousandSpin : SG_ctrlDefaultButton {
					idc = 126;
					text = "$5,000 SPIN";
					x = (pixelW * pixelGrid * 0.50) + ((((130 * (pixelW * pixelGrid * 0.50)) * 0.2) + (pixelW * pixelGrid * 0.50)) * 1);
					y = (pixelH * pixelGrid * 0.50);
					w = (130 * (pixelW * pixelGrid * 0.50)) * 0.2;
					h = 5 * (pixelH * pixelGrid * 0.50);
					onButtonClick = "";
				};
				class FifteenThousandSpin : SG_ctrlDefaultButton {
					idc = 127;
					text = "$15,000 SPIN";
					x = (pixelW * pixelGrid * 0.50) + ((((130 * (pixelW * pixelGrid * 0.50)) * 0.2) + (pixelW * pixelGrid * 0.50)) * 2);
					y = (pixelH * pixelGrid * 0.50);
					w = (130 * (pixelW * pixelGrid * 0.50)) * 0.2;
					h = 5 * (pixelH * pixelGrid * 0.50);
					onButtonClick = "";
				};
				class TwentyFiveThousandSpin : SG_ctrlDefaultButton {
					idc = 128;
					text = "$25,000 SPIN";
					x = (pixelW * pixelGrid * 0.50) + ((((130 * (pixelW * pixelGrid * 0.50)) * 0.2) + (pixelW * pixelGrid * 0.50)) * 3);
					y = (pixelH * pixelGrid * 0.50);
					w = (130 * (pixelW * pixelGrid * 0.50)) * 0.2;
					h = 5 * (pixelH * pixelGrid * 0.50);
					onButtonClick = "";
				};
			};
		};

		class ButtonClose : SG_ctrlButtonClose {
			idc = 999;
			x = (((getResolution select 2) * 0.5 * pixelW) - (0 * 0.5) * (pixelW * pixelGrid * 0.50)) + (80 * (pixelW * pixelGrid * 0.50)) - (5 * (pixelW * pixelGrid * 0.50));
			y = (0.44 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 5 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
	};
};