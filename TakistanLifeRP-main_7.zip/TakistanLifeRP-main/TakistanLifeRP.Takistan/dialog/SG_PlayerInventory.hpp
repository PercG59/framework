class SG_PlayerInventory {
	idd = 61234;
	scriptName = "SG_PlayerInventory";
	onLoad = [ 'onLoad', _this ] spawn SG_PlayerInventory;
	class ControlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = 0x1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class Background : SG_ctrlStaticBackground {
			idc = 1001;
			x = 0.33335 * safezoneW + safezoneX;
			y = 0.37042 * safezoneH + safezoneY;
			w = 0.333333 * safezoneW;
			h = 0.277779 * safezoneH;
		};
		class BackgroundFilter : SG_ctrlStatic {
			idc = 1002;
			x = 0.335412 * safezoneW + safezoneX;
			y = 0.39638 * safezoneH + safezoneY;
			w = 0.329167 * safezoneW;
			h = 0.0185185 * safezoneH;
			colorBackground[] = { 0, 0, 0, 1 };
		};
		class BackgroundList : SG_ctrlStaticOverlay {
			idc = 1003;
			x = 0.335412 * safezoneW + safezoneX;
			y = 0.41486 * safezoneH + safezoneY;
			w = 0.329167 * safezoneW;
			h = 0.203704 * safezoneH;
		};
		class BackgroundButtons : SG_ctrlStaticFooter {
			idc = 1004;
			x = 0.33335 * safezoneW + safezoneX;
			y = 0.62232 * safezoneH + safezoneY;
			w = 0.333333 * safezoneW;
			h = 0.0259259 * safezoneH;
		};
		class BackgroundInventoryLoad : SG_ctrlStatic {
			idc = 1005;
			x = 0.335412 * safezoneW + safezoneX;
			y = 0.6001 * safezoneH + safezoneY;
			w = 0.329167 * safezoneW;
			h = 0.0185185 * safezoneH;
			colorBackground[] = { 0.7, 0.7, 0.7, 0.5 };
		};
	};
	class controls {
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT START (by Kaiden Smith, v1.063, #Pawico)
		////////////////////////////////////////////////////////
		class Dummy : SG_ctrlStatic {};
		class Title : SG_ctrlStaticTitle {
			idc = 1007;
			text = "Inventory"; //--- ToDo: Localize;
			x = 0.33335 * safezoneW + safezoneX;
			y = 0.35194 * safezoneH + safezoneY;
			w = 0.333333 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
		class ButtonClose : SG_ctrlButtonClose {
			idc = 1008;
			x = 0.656234 * safezoneW + safezoneX;
			y = 0.35194 * safezoneH + safezoneY;
			w = 0.0104167 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
		class Search : SG_ctrlEditNoRect {
			idc = 80;

			x = 0.335412 * safezoneW + safezoneX;
			y = 0.37416 * safezoneH + safezoneY;
			w = 0.0833334 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
		class ButtonSearch : SG_ctrlButtonSearch {
			idc = 81;

			x = 0.418738 * safezoneW + safezoneX;
			y = 0.37416 * safezoneH + safezoneY;
			w = 0.0104167 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
		class ItemsFilter : SG_ctrlListNBox {
			idc = 82;

			x = 0.335412 * safezoneW + safezoneX;
			y = 0.39638 * safezoneH + safezoneY;
			w = 0.329167 * safezoneW;
			h = 0.0185185 * safezoneH;
			disableOverflow = 1;
			columns[] = { 0, 0.5, 0.8 };
			class Items {
				class Item {
					text = "Item";
					value = 0;
				};
				class Weight {
					text = "Weight";
					value = 0;
				};
				class Qty {
					text = "Qty";
					value = 0;
				};
			};
		};
		class ItemsList : SG_ctrlListNBox {
			idc = 83;
			columns[] = { 0, 0.5, 0.8 };
			disableOverflow = 1;

			x = 0.335412 * safezoneW + safezoneX;
			y = 0.41486 * safezoneH + safezoneY;
			w = 0.329167 * safezoneW;
			h = 0.203704 * safezoneH;
		};
		class InventoryLoad : SG_ctrlProgress {
			idc = 84;

			x = 0.335412 * safezoneW + safezoneX;
			y = 0.6001 * safezoneH + safezoneY;
			w = 0.329167 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
		class TextInventoryLoad : SG_ctrlStatic {
			idc = 85;
			shadow = 0;
			style = 2;

			text = "0/100";
			x = 0.335412 * safezoneW + safezoneX;
			y = 0.6001 * safezoneH + safezoneY;
			w = 0.329167 * safezoneW;
			h = 0.0185185 * safezoneH;
			colorText[] = { 1, 1, 1, 1 };
		};
		class Footer : SG_ctrlControlsGroupNoScrollbars {
			idc = 89;

			x = 0.33335 * safezoneW + safezoneX;
			y = 0.62232 * safezoneH + safezoneY;
			w = 0.208333 * safezoneW;
			h = 0.0259259 * safezoneH;
		};
		class ButtonUse : SG_ctrlButton {
			idc = 90;

			text = "Use"; //--- ToDo: Localize;
			x = 0.336444 * safezoneW + safezoneX;
			y = 0.62518 * safezoneH + safezoneY;
			w = 0.0520833 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
		class ButtonDrop : ButtonUse {
			idc = 91;

			text = "Drop"; //--- ToDo: Localize;
			x = 0.395833 * safezoneW + safezoneX;
		};
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT END
		////////////////////////////////////////////////////////
	};
};