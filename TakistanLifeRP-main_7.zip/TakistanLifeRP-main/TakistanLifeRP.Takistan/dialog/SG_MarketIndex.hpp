class SG_MarketIndex {
	idd = 0x0;
	scriptName = "SG_MarketIndex";
	onLoad = [ 'onLoad', _this ] call SG_MarketIndex;
	class ControlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = 0x1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class Background : SG_ctrlStaticBackground {
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) * 0.5 + 10 * (pixelH * pixelGrid * 0.50);
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) - (10 + 5) * (pixelH * pixelGrid * 0.50);
		};
		class BackgroundFilter : SG_ctrlStatic {
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5 - 1) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) * 0.5 + (12 + 5) * (pixelH * pixelGrid * 0.50);
			w = (160 - 2) * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 1 };
		};
		class BackgroundList : SG_ctrlStaticOverlay {
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5 - 1) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) * 0.5 + (12 + 5 + 5) * (pixelH * pixelGrid * 0.50);
			w = (160 - 2) * (pixelW * pixelGrid * 0.50);
			h = (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) - (23 + 5 * 2 + 2) * (pixelH * pixelGrid * 0.50);
		};
		class BackgroundButtons : SG_ctrlStaticFooter {
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 + (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) * 0.5 - 2 * (5 + 1) * (pixelH * pixelGrid * 0.50);
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (5 + 2) * (pixelH * pixelGrid * 0.50);
		};
	};
	class Controls {
		class Dummy : SG_ctrlStatic {};
		class Title : SG_ctrlStaticTitle {
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) * 0.5 + 5 * (pixelH * pixelGrid * 0.50);
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
			text = "Market Index";
		};
		class ButtonClose : SG_ctrlButtonClose {
			x = ((getResolution select 2) * 0.5 * pixelW) - (-150 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) * 0.5 + 5 * (pixelH * pixelGrid * 0.50);
			w = 5 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class Search : SG_ctrlEditNoRect {
			idc = 0x1;
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5 - 1) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) * 0.5 + (11) * (pixelH * pixelGrid * 0.50);
			w = (160 / 4) * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class SearchButton : SG_ctrlButtonSearch {
			idc = 81;
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5 - 1 - 160 / 4) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) * 0.5 + (11) * (pixelH * pixelGrid * 0.50);
			w = 5 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class Filter : SG_ctrlListNBox {
			idc = 0x3;
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5 - 1) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) * 0.5 + (12 + 5) * (pixelH * pixelGrid * 0.50);
			w = (160 - 2) * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
			columns[] = { 0, 0.4, 0.5, 0.7 };
			disableOverflow = 1;
			class Items {
				class Name {
					text = "Name";
					value = 0;
				};
				class Weight {
					text = "Weight";
					value = -1;
					data = "data";
				};
				class Illegal {
					text = "Illegal";
					value = -1;
					data = "data";
				};
				class Sell_Price {
					text = "Sell Price";
					value = -1;
					data = "data";
				};
			};
		};
		class List : SG_ctrlListNBox {
			idc = 0x4;
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5 - 1) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) * 0.5 + (12 + 5 + 5) * (pixelH * pixelGrid * 0.50);
			w = (160 - 2) * (pixelW * pixelGrid * 0.50);
			h = (safezoneH min(90 * (pixelH * pixelGrid * 0.50))) - (23 + 5 * 2 + 2) * (pixelH * pixelGrid * 0.50);
			columns[] = { 0, 0.4, 0.5, 0.7 };
			disableOverflow = 1;
		};
	};
};