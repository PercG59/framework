class SS_Button {
	type = 1;
	sizeEx = "4.32 * (1 / (getResolution select 3)) * pixelGrid * 0.5";
	shadow = 1;
	soundClick[] = { "\A3\ui_f\data\sound\RscButton\soundClick", 0.090000004, 1 };
	soundEnter[] = { "\A3\ui_f\data\sound\RscButton\soundEnter", 0.090000004, 1 };
	soundPush[] = { "\A3\ui_f\data\sound\RscButton\soundPush", 0.090000004, 1 };
	soundEscape[] = { "\A3\ui_f\data\sound\RscButton\soundEscape", 0.090000004, 1 };
	style = "0x02 + 0xC0";
	colorBackground[] = { 0, 0, 0, 1 };
	colorBackgroundDisabled[] = { 0, 0, 0, 0.5 };
	colorBackgroundActive[] = { "(profilenamespace getvariable ['GUI_BCG_RGB_R',0.77])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.51])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.08])", 1 };
	colorFocused[] = { "(profilenamespace getvariable ['GUI_BCG_RGB_R',0.77])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.51])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.08])", 1 };
	font = "PuristaLight";
	text = "";
	colorText[] = { 1, 1, 1, 1 };
	colorDisabled[] = { 1, 1, 1, 0.25 };
	borderSize = 0;
	colorBorder[] = { 0, 0, 0, 0 };
	colorShadow[] = { 0, 0, 0, 0 };
	offsetX = 0;
	offsetY = 0;
	offsetPressedX = "pixelW";
	offsetPressedY = "pixelH";
	period = 0;
	periodFocus = 2;
	periodOver = 0.5;
	class KeyHints {
		class A {
			key = "0x00050000 + 0";
			hint = "KEY_XBOX_A";
		};
	};
	onCanDestroy = "";
	onDestroy = "";
	onMouseEnter = "";
	onMouseExit = "";
	onSetFocus = "";
	onKillFocus = "";
	onKeyDown = "";
	onKeyUp = "";
	onMouseButtonDown = "";
	onMouseButtonUp = "";
	onMouseButtonClick = "";
	onMouseButtonDblClick = "";
	onMouseZChanged = "";
	onMouseMoving = "";
	onMouseHolding = "";
	onButtonClick = "";
	onButtonDown = "";
	onButtonUp = "";
};
class SS_RscStructuredText {
	deletable = 0;
	fade = 0;
	access = 0;
	type = 13;
	idc = -1;
	style = 0;
	colorText[] = { 1, 1, 1, 1 };
	class Attributes {
		font = "RobotoCondensedLight";
		color = "#ffffff";
		colorLink = "#D09B43";
		align = "left";
		shadow = 0;
	};
	x = 0;
	y = 0;
	h = 0.035;
	w = 0.1;
	text = "";
	size = "4.32 * (1 / (getResolution select 3)) * pixelGrid * 0.55";
	shadow = 0;
};
class SS_RscControlsGroup {
	deletable = 0;
	fade = 0;
	class VScrollbar {
		color[] = { 0.5, 0.5, 0.5, 1 };
		colorActive[] = { 1, 1, 1, 1 };
		colorDisabled[] = { 1, 1, 1, 0.3 };
		colorBackground[] = { 0, 0, 0, 0 };
		thumb = "\A3\ui_f\data\gui\cfg\scrollbar\thumb_ca.paa";
		arrowEmpty = "\A3\ui_f\data\gui\cfg\scrollbar\arrowEmpty_ca.paa";
		arrowFull = "\A3\ui_f\data\gui\cfg\scrollbar\arrowFull_ca.paa";
		border = "\A3\ui_f\data\gui\cfg\scrollbar\border_ca.paa";
		shadow = 0;
		scrollSpeed = 0.06;
		width = 0.021;
		height = 0;
		autoScrollEnabled = 1;
		autoScrollSpeed = -1;
		autoScrollDelay = 5;
		autoScrollRewind = 0;
	};
	class HScrollbar : VScrollbar {
		height = 0.023;
	};
	class Controls {
	};
	type = 15;
	idc = -1;
	x = 0;
	y = 0;
	w = 1;
	h = 1;
	shadow = 0;
	style = 16;
};

class SS_RscText {
	deletable = 0;
	fade = 0;
	access = 0;
	type = 0;
	idc = -1;
	colorBackground[] = { 0, 0, 0, 0 };
	colorText[] = { 1, 1, 1, 1 };
	text = "";
	fixedWidth = 0;
	x = 0;
	y = 0;
	h = 0.037;
	w = 0.3;
	style = 2;
	shadow = 0;
	colorShadow[] = { 0, 0, 0, 0 };
	font = "PuristaLight";
	sizeEx = "4.32 * (1 / (getResolution select 3)) * pixelGrid * 0.55";
	linespacing = 1;
	tooltipColorText[] = { 1, 1, 1, 1 };
	tooltipColorBox[] = { 1, 1, 1, 1 };
	tooltipColorShade[] = { 0, 0, 0, 0.65 };
};

class SkillSystem_Tree {
	idd = 8356969;
	name = "SkillSystem_Tree";
	class ControlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = 0x1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
	};
	class controls {
		class BackgroundMain : SS_RscText {
			idc = 2201;
			colorBackground[] = { 0.2, 0.2, 0.2, 1 };
			x = 0.2525 * safezoneW + safezoneX;
			y = 0.17 * safezoneH + safezoneY;
			w = 0.495 * safezoneW;
			h = 0.605 * safezoneH;
		};
		class TopBarBack : SG_ctrlStaticTitle {
			idc = 2200;
			x = 0.2525 * safezoneW + safezoneX;
			y = 0.17 * safezoneH + safezoneY;
			w = 0.495 * safezoneW;
			text = "Skill Tree";
		};
		class background : Life_RscText {
			idc = -1;
			colorBackground[] = { 0, 0, 0, 0.3 };
			x = 0.257656 * safezoneW + safezoneX;
			y = 0.258 * safezoneH + safezoneY;
			w = 0.335156 * safezoneW;
			h = 0.506 * safezoneH;
		};
		class RscControlsGroup_2300 : SS_RscControlsGroup {
			idc = 2300;
			x = 0.257656 * safezoneW + safezoneX;
			y = 0.258 * safezoneH + safezoneY;
			w = 0.335156 * safezoneW;
			h = 0.506 * safezoneH;
			class Controls {};
		};
		class DescriptonBackground : SS_RscText {
			idc = 2202;
			text = "Descripton";
			colorBackground[] = { "(profilenamespace getvariable ['GUI_BCG_RGB_R',0.13])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.54])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.21])", 1 };
			x = 0.597969 * safezoneW + safezoneX;
			y = 0.236 * safezoneH + safezoneY;
			w = 0.144375 * safezoneW;
			h = 0.022 * safezoneH;
		};
		class DescContent : SS_RscStructuredText {
			idc = 22203;
			text = "ERRORddd";
			colorBackground[] = { 0, 0, 0, 0.3 };
			colorText[] = { 1, 1, 1, 1 };
			x = 0.597969 * safezoneW + safezoneX;
			y = 0.2602 * safezoneH + safezoneY;
			w = 0.144375 * safezoneW;
			h = 0.396 * safezoneH;
		};
		class levelinfo : SS_RscStructuredText {
			idc = 2208;
			colorBackground[] = { 0, 0, 0, 0.3 };
			x = 0.597969 * safezoneW + safezoneX;
			y = 0.6606 * safezoneH + safezoneY;
			w = 0.144375 * safezoneW;
			h = 0.077 * safezoneH;
		};
		class Life_RscText_2204 : SS_RscText {
			idc = 2204;
			colorBackground[] = { 0, 0, 0, 0.3 };
			text = "Professional";
			x = 0.267512 * safezoneW + safezoneX; //3-8
			y = 0.23 * safezoneH + safezoneY;
			w = 0.0928125 * safezoneW;
			h = 0.022 * safezoneH;
		};
		class Life_RscText_2205 : SS_RscText {
			idc = 2205;
			colorBackground[] = { 0, 0, 0, 0.3 };
			text = "Working Man";
			x = 0.3749 * safezoneW + safezoneX;
			y = 0.23 * safezoneH + safezoneY;
			w = 0.0928125 * safezoneW;
			h = 0.022 * safezoneH;
		};
		class Life_RscText_2206 : SS_RscText {
			idc = 2206;
			text = "The Hustler";
			colorBackground[] = { 0, 0, 0, 0.3 };
			x = 0.483 * safezoneW + safezoneX;
			y = 0.23 * safezoneH + safezoneY;
			w = 0.0928125 * safezoneW;
			h = 0.022 * safezoneH;
		};
		class Btn : SS_Button {
			idc = 2207;
			text = "UNLOCK";
			x = 0.597969 * safezoneW + safezoneX;
			y = 0.742 * safezoneH + safezoneY;
			w = 0.144375 * safezoneW;
			h = 0.022 * safezoneH;
		};
		class exitBtn : SG_ctrlButtonClose {
			idc = -1;
			x = 0.725844 * safezoneW + safezoneX;
			y = 0.17 * safezoneH + safezoneY;
			w = 0.0122185 * safezoneW;
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
	};
};

class skillBox : Life_RscControlsGroup {
	idc = 2300;
	x = 0.29375 * safezoneW + safezoneX;
	y = 0.225 * safezoneH + safezoneY;
	w = 0.0928125 * safezoneW;
	h = 0.154 * safezoneH;
	class Controls {
		class Background : Life_RscText {
			idc = 2200;
			colorBackground[] = { 0.1, 0.1, 0.1, 1 };
			x = 0.00103204 * safezoneW;
			y = 0.0022 * safezoneH;
			w = 0.0907499 * safezoneW;
			h = 0.1496 * safezoneH;
		};
		class pictureHolder : life_RscPicture {
			idc = 1200;
			text = "#(argb,8,8,3)color(1,1,1,1)";
			x = 0.0257812 * safezoneW;
			y = 0.011 * safezoneH;
			w = 0.04125 * safezoneW;
			h = 0.066 * safezoneH;
		};
		class skillName : SS_RscText {
			idc = 1100;
			style = 2 + 16 + 512;
			font = "PuristaMedium";
			text = "Endurnace Level 1";
			x = 0.00515625 * safezoneW;
			y = 0.0814 * safezoneH;
			w = 0.0825 * safezoneW;
			h = 0.0396 * safezoneH;
		};
		class RequiredLevel : SS_RscText {
			idc = 1101;
			text = "Error";
			sizeEx = "4.32 * (1 / (getResolution select 3)) * pixelGrid * 0.5";
			x = 0.00515626 * safezoneW;
			y = 0.1232 * safezoneH;
			w = 0.0825 * safezoneW;
			h = 0.022 * safezoneH;
		};
	};
};

class LockedSkillbackground : SS_RscText {
	idc = 2203;
	colorBackground[] = { 0, 0, 0, 0.6 };
	x = 0.00103204 * safezoneW;
	y = 0.0022 * safezoneH;
	w = 0.0907499 * safezoneW;
	h = 0.1496 * safezoneH;
};
class LockedSkillPicture : life_RscPicture {
	idc = 2201;
	style = 48 + 2048;
	text = "a3\ui_f\data\GUI\Rsc\RscDisplayDynamicGroups\Lock.paa";
	colorBackground[] = { 0, 0, 0, 0.5 };
	x = 0.0257812 * safezoneW;
	y = 0.020 * safezoneH;
	w = 0.04125 * safezoneW;
	h = 0.066 * safezoneH;
};
