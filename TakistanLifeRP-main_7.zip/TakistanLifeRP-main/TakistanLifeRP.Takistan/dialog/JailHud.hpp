class SG_JailHud {
	idd = 102012;
	duration = 10e10;
	name = "SG_JailHud";
	movingEnable = 0;
	onLoad = "uiNamespace setVariable ['SG_JailHud',_this select 0]";

	class controlsBackground {
		class Background : SG_ctrlStatic {
			x = 0.395844 * safezoneW + safezoneX;
			y = 0.03792 * safezoneH + safezoneY;
			w = 0.208333 * safezoneW;
			h = 0.0722223 * safezoneH;
			colorBackground[] = { 0.1, 0.1, 0.1, 0.5 };
		};
	};
	class controls {
		class Title : SG_ctrlStatic {
			idc = 20;
			text = "";
			x = 0.395844 * safezoneW + safezoneX;
			y = 0.01944001 * safezoneH + safezoneY;
			w = 0.208333 * safezoneW;
			h = 0.074074 * safezoneH;
			font = "RobotoCondensedBold";
			style = 0x02;
			colorText[] = { 0.8, 0.01, 0, 1 };
		};
		class Reason : SG_ctrlStatic {
			idc = 21;
			text = "";
			x = 0.395844 * safezoneW + safezoneX;
			y = 0.05838 * safezoneH + safezoneY;
			w = 0.208333 * safezoneW;
			h = 0.037037 * safezoneH;
			style = 0x02;
		};
		class TimeLeft : SG_ctrlStatic {
			idc = 22;
			text = "";
			x = 0.395844 * safezoneW + safezoneX;
			y = 0.07862 * safezoneH + safezoneY;
			w = 0.208333 * safezoneW;
			h = 0.037037 * safezoneH;
			style = 0x02;
		};
	};
};