class SG_achievements_insert : ctrlControlsGroupNoScrollbars {
	idc = 2500;
	x = "0 * safezoneW";
	y = "0 * safezoneH";
	w = "0.4025 * safezoneW";
	h = "0.076 * safezoneH";
	class controls {
		class background : ctrlStaticBackground {
			idc = 400;
			x = "0 * safezoneW";
			y = "0 * safezoneH";
			w = "0.4025 * safezoneW";
			h = "0.075 * safezoneH";
			colorBackground[] = { 0.13, 0.13, 0.13, 1 };
		};
		class picture : ctrlStaticPicture {
			idc = 500;
			x = "0.00375 * safezoneW";
			y = "0.00525 * safezoneH";
			w = "0.0375 * safezoneW";
			h = "0.0625 * safezoneH";
		};
		class title : ctrlStatic {
			idc = 1000;
			x = "0.041 * safezoneW";
			y = "0.00525 * safezoneH";
			w = "0.350 * safezoneW";
			h = "0.022 * safezoneH";
			sizeEx = "0.0215 / (getResolution#5)";
			font = "RobotoCondensedBold";
			shadow = 0;
		};
		class description : ctrlStructuredText {
			idc = 1500;
			x = "0.04 * safezoneW";
			y = "0.02675 * safezoneH";
			w = "0.350 * safezoneW";
			h = "0.02 * safezoneH";
			size = "0.018 / (getResolution#5)";
			shadow = 0;
			onload = "(_this#0) ctrlEnable false;";
			class Attributes {
				align = "left";
				color = "#757575";
				colorLink = "#757575";
				size = 1;
				shadow = 0;
				font = "RobotoCondensedLight";
			};
		};
		class progess_background : ctrlStaticBackground {
			idc = 2400;
			show = 0;
			x = "0.045 * safezoneW";
			y = "0.0475 * safezoneH";
			w = "0.350 * safezoneW";
			h = "0.0175 * safezoneH";
		};
		class progess_foreground : progess_background {
			idc = 2500;
			show = 0;
			w = "0 * safezoneW";
			colorBackground[] = { 0.13, 0.54, 0.21, 1 };
		};
		class progess_text : ctrlStatic {
			idc = 3000;
			show = 0;
			style = 2;
			x = "0.045 * safezoneW";
			y = "0.0475 * safezoneH";
			w = "0.350 * safezoneW";
			h = "0.0175 * safezoneH";
			font = "PuristaBold";
			shadow = 0;
			text = "";
		};
		class hidden_image : ctrlStaticPicture {
			idc = 3500;
			show = 0;
			x = "0 * safezoneW";
			y = "0 * safezoneH";
			w = "0.70 * safezoneW";
			h = "0.075 * safezoneH";
			text = "data\blur_ca.paa";
			tooltip = "This achievement is hidden until you unlock it during gameplay.";
		};
	};
};

class SG_achievements_display {
	idd = 280000;
	onLoad = "['onload',_this] call SG_AchievementsSystem";
	onUnload = "['onunload',_this] call SG_AchievementsSystem";
	class controlsbackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = 0x1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class title_background : ctrlStaticTitle {
			idc = 250;
			style = 2;
			x = "0.29375 * safezoneW + safezoneX";
			y = "0.225 * safezoneH + safezoneY";
			w = "0.4125 * safezoneW";
			h = "0.022 * safezoneH";
			text = "Achievements";
			font = "PuristaBold";
			shadow = 0;
		};
		class main_background : title_background {
			moving = 0;
			y = "0.247 * safezoneH + safezoneY";
			h = "0.528 * safezoneH";
			text = "";
			colorBackground[] = { 0.2, 0.2, 0.2, 1 };
		};
	};
	class controls {
		class exit_button : SG_ctrlButtonClose {
			idc = 2;
			x = "0.695937 * safezoneW + safezoneX";
			y = "0.225 * safezoneH + safezoneY";
			w = "0.0103125 * safezoneW";
			h = "0.022 * safezoneH";
		};
		class control_group_master : ctrlControlsGroup {
			idc = 1500;
			x = "0.29375 * safezoneW + safezoneX";
			y = "0.247 * safezoneH + safezoneY";
			w = "0.4125 * safezoneW";
			h = "0.528 * safezoneH";
			class VScrollbar : VScrollBar {
				width = "0.0075 * safezoneW";
			};
		};
	};
};