/**
*    Copyright (c) 2017 SimZor, SimZor Studios
*    All Rights Reserved
*
*    Filename: displayLicenses.hpp
*/
#define SIZE_BLOCK_HEADER2 0.022 * safezoneH
#define SIZE_BLOCK_CONTENTBUTTON "0.0198 * safezoneH"

class SG_Coinflip {
    idd        = 456346;
    scriptName = "SG_Coinflip";
    onLoad     = "";
    class controlsBackground {
        class TILES: SG_RscTiles {};
        class Background: SG_ctrlStaticBackground
        {
            idc = -1;
            x = 0.395854 * safezoneW + safezoneX;
            y = 0.324352 * safezoneH + safezoneY;
            w = 0.208333 * safezoneW;
            h = 0.297 * safezoneH;
        };
        class Title: SG_ctrlStaticHeader
        {
            idc = -1;

            text = "Coinflip";
            x = 0.395833 * safezoneW + safezoneX;
            y = 0.305833 * safezoneH + safezoneY;
            w = 0.208333 * safezoneW;
            h = 0.0185185 * safezoneH;
        };
        class ButtonClose: SG_ctrlButtonClose
        {
            idc = 1008;
            text = "\a3\3DEN\Data\Displays\Display3DEN\search_end_ca.paa";
            x = 0.591667 * safezoneW + safezoneX;
            y = 0.305833 * safezoneH + safezoneY;
            w = 0.0104167 * safezoneW;
            h = 0.0185185 * safezoneH;
            colorText[] = {1,1,1,1};
            colorBackground[] = {0,0,0,0};
            tooltip = "Close Display";
            sizeEx = 0.018 * safezoneH * GUI_GRID_H;
        };
    };
    class controls {
        class IMAGE_COIN: SG_ctrlStaticPicture {
        	idc                = 20;
        	x = 0.438125 * safezoneW + safezoneX;
            y = 0.346 * safezoneH + safezoneY;
            w = 0.12375 * safezoneW;
            h = 0.209 * safezoneH;
        	colorBackground[]  = {0, 0, 0, 0};
        };
        class TEXT_NAME: SG_ctrlStatic {
        	idc                = 25;
        	text               = "N/A";
        	x = 0.453593 * safezoneW + safezoneX;
            y = 0.573519 * safezoneH + safezoneY;
            w = 0.144375 * safezoneW;
            h = 0.0185185 * safezoneH;
        	colorBackground[]  = {0, 0, 0, 0.4};
        };
        class TEXT_AMOUNT: TEXT_NAME {
        	idc                = 26;
        	x = 0.453594 * safezoneW + safezoneX;
            y = 0.5946 * safezoneH + safezoneY;
            w = 0.144375 * safezoneW;
            h = 0.0185185 * safezoneH;
        };
        class TEXT_NAME1: SG_ctrlStatic {
        	idc                = -1;
        	text               = "Bet Opponent: ";
        	x = 0.401 * safezoneW + safezoneX;
            y = 0.573519 * safezoneH + safezoneY;
            w = 0.0515625 * safezoneW;
            h = 0.0185185 * safezoneH;
        	colorBackground[]  = {0, 0, 0, 0.4};
        };
        class TEXT_AMOUNT1: SG_ctrlStatic {
        	idc                = -1;
        	text               = "Bet Amount: ";
        	x = 0.401 * safezoneW + safezoneX;
            y = 0.5946 * safezoneH + safezoneY;
            w = 0.0515625 * safezoneW;
            h = 0.0185185 * safezoneH;
        	colorBackground[]  = {0, 0, 0, 0.4};
        };
    };
};
