class SG_CheckpointBuilder {
	idd = 5125;
	name = "SG_CheckpointBuilder";
	movingEnable = 0;
	enableSimulation = 1;

	class controlsBackground {
		class Title : SG_ctrlStaticHeader {
			idc = 92;
			text = "Checkpoint Builder";
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50));
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (88 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50));
		};
	};
	class controls {
		class SG_Close : SG_ctrlDefaultButton {
			idc = 2409;
			onButtonClick = "closeDialog 0;";
			text = "Close";
			x = (((getResolution select 2) * 0.5 * pixelW) - (-13 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (-60 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = (75 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = 0.022 * safezoneH;
		};
		class SG_BuyObject : SG_ctrlDefaultButton {
			idc = 2410;
			text = "Buy Object";
			x = (((getResolution select 2) * 0.5 * pixelW) - (157 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (-60 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = (75 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = 0.022 * safezoneH;
		};
		class SG_ItemList : SG_ctrlListNBox {
			idc = 1500;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (123 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 2) + (2 * (pixelH * pixelGrid * 0.50));
			w = (160 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = (100 / 1.4) * (pixelH * pixelGrid * 0.50);
		};
		class ItemsListBackground : SG_ctrlStaticContent {
			idc = 232321 + 108;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.415 - (123 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 2) + (2 * (pixelH * pixelGrid * 0.50));
			w = (160 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = (100 / 1.4) * (pixelH * pixelGrid * 0.50);
		};
		class ButtonClose : SG_ctrlButtonClose {
			x = (((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50)) + (160 * (pixelW * pixelGrid * 0.50)) - (5 * (pixelW * pixelGrid * 0.50));
			y = (0.415 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 5 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
	};
};