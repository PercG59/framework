class SG_Bleedout {
	idd = 1010;
	name = "SG_Bleedout";
	movingEnable = 0;
	duration = 10e10;
	onLoad = "uiNamespace setVariable ['SG_Bleedout',_this select 0]";

	class controlsBackground {
		class PROGRESS_BACKGROUND : SG_ctrlStatic {
			idc = -1;
			x = "0.314375 * safezoneW + safezoneX";
			y = "0.8498 * safezoneH + safezoneY";
			w = "0.371242 * safezoneW";
			h = "0.0308 * safezoneH";
			colorBackground[] = { "(profilenamespace getvariable ['IGUI_BCG_RGB_R',0])", "(profilenamespace getvariable ['IGUI_BCG_RGB_G',1])", "(profilenamespace getvariable ['IGUI_BCG_RGB_B',1])", "(profilenamespace getvariable ['IGUI_BCG_RGB_A',0.8])" };
		};
	};

	class controls {
		class PROGRESS : SG_ctrlProgress {
			idc = 1011;
			x = "0.314375 * safezoneW + safezoneX";
			y = "0.8498 * safezoneH + safezoneY";
			w = "0.371242 * safezoneW";
			h = "0.0308 * safezoneH";
			colorBar[] = { 0.59, 0, 0, 1 };
		};
		class PROGRESS_TEXT : SG_ctrlStatic {
			idc = 1012;
			text = "";
			x = "0.314375 * safezoneW + safezoneX";
			y = "0.8498 * safezoneH + safezoneY";
			w = "0.371242 * safezoneW";
			h = "0.0286 * safezoneH";
			style = 0x02;
			font = "RobotoCondensedLight";
			sizeEx = "0.02 * safezoneH";
		};
		class NEAREST_MEDIC : SG_ctrlStatic {
			idc = 1013;
			text = "";
			x = "0.314375 * safezoneW + safezoneX";
			y = "0.8168 * safezoneH + safezoneY";
			w = "0.371184 * safezoneW";
			h = "0.033 * safezoneH";
			style = 0x02;
			font = "RobotoCondensed";
			sizeEx = "0.02 * safezoneH";
		};
	};
};