
class chopshop {
	idd = 12233;
	name = "chopshop";
	class controls {

		class IGUIBack_2200 : SG_ctrlStaticBackground {
			idc = 2200;
			x = 0.0823432 * safezoneW + safezoneX;
			y = 0.225 * safezoneH + safezoneY;
			w = 0.154687 * safezoneW;
			h = 0.462 * safezoneH;
		};
		class IGUIBack_2201 : SG_ctrlStaticTitle {
			idc = 2201;
			text = "Chop Shop";
			x = 0.0823437 * safezoneW + safezoneX;
			y = 0.225 * safezoneH + safezoneY;
			w = 0.154687 * safezoneW;
			h = 0.022 * safezoneH;
		};
		class IGUIBack_2202 : SG_ctrlStaticContent {
			idc = 2202;
			colorBackground[] = { 0, 0, 0, 0.6 };
			text = "Vehicles Nearby";
			x = 0.0875 * safezoneW + safezoneX;
			y = 0.258 * safezoneH + safezoneY;
			w = 0.144375 * safezoneW;
			h = 0.022 * safezoneH;
		};
		class RscListbox_1500 : SG_ctrlListbox {
			idc = 1500;
			colorBackground[] = { 0, 0, 0, 0.3 };
			x = 0.0875 * safezoneW + safezoneX;
			y = 0.28 * safezoneH + safezoneY;
			w = 0.144375 * safezoneW;
			h = 0.319 * safezoneH;
		};
		class RscButton_1600 : SG_CtrlButton {
			idc = 1600;
			text = "Claim Vehicle";
			x = 0.0875 * safezoneW + safezoneX;
			y = 0.654 * safezoneH + safezoneY;
			w = 0.0711562 * safezoneW;
			h = 0.022 * safezoneH;
			onButtonClick = "[] spawn SG_ClaimVehicle;";
		};
		class RscButton_1601 : SG_CtrlButton {
			idc = 1601;
			text = "Scrap Vehicle";
			x = 0.160719 * safezoneW + safezoneX;
			y = 0.654 * safezoneH + safezoneY;
			w = 0.0711562 * safezoneW;
			h = 0.022 * safezoneH;
			onButtonClick = "[] spawn SG_ScrapVehicle;";
		};
		class IGUIBack_2203 : SG_ctrlStructuredText {
			idc = 2203;
			size = "4.32 * (1 / (getResolution select 3)) * pixelGrid * 0.55";
			text = "Scrapping Vehicle Price:";
			colorBackground[] = { 0, 0, 0, 0.3 };
			x = 0.0875 * safezoneW + safezoneX;
			y = 0.6034 * safezoneH + safezoneY;
			w = 0.144375 * safezoneW;
			h = 0.022 * safezoneH;
		};
		class IGUIBack_2204 : SG_ctrlStructuredText {
			idc = 2204;
			size = "4.32 * (1 / (getResolution select 3)) * pixelGrid * 0.55";
			text = "Claiming Vehicle Cost:";
			colorBackground[] = { 0, 0, 0, 0.3 };
			x = 0.0875 * safezoneW + safezoneX;
			y = 0.6276 * safezoneH + safezoneY;
			w = 0.144375 * safezoneW;
			h = 0.022 * safezoneH;
		};
	};
};