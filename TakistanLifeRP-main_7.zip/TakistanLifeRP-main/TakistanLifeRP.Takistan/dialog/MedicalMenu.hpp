class SG_MedicalMenu {
	idd = 9300;
	name = "SG_MedicalMenu";
	movingEnable = 0;
	enableSimulation = 1;

	class controlsBackground {
		//Background
		class SG_Background : Life_RscPicture {
			idc = 1200;
			text = "\SG_Core\images\bodyparts\medicBG.paa";
			x = 0.387849 * safezoneW + safezoneX;
			y = 0.236 * safezoneH + safezoneY;
			w = 0.299682 * safezoneW;
			h = 0.526621 * safezoneH;
		};
	};

	class controls {
		//Body Parts
		class HeadButton : Life_RscButtonInvisible {
			idc = 93021;
			x = 0.525365 * safezoneW + safezoneX;
			y = 0.357 * safezoneH + safezoneY;
			w = 0.0266667 * safezoneW;
			h = 0.0411111 * safezoneH;
		};
		class ChestButton : Life_RscButtonInvisible {
			idc = 93022;
			x = 0.527187 * safezoneW + safezoneX;
			y = 0.398452 * safezoneH + safezoneY;
			w = 0.0236979 * safezoneW;
			h = 0.078037 * safezoneH;
		};
		class Leg1Button : Life_RscButtonInvisible {
			idc = 93023;
			x = 0.527333 * safezoneW + safezoneX;
			y = 0.476837 * safezoneH + safezoneY;
			w = 0.0264063 * safezoneW;
			h = 0.128852 * safezoneH;
		};
		class Arm1 : Life_RscButtonInvisible {
			idc = 93024;
			x = 0.517072 * safezoneW + safezoneX;
			y = 0.3988 * safezoneH + safezoneY;
			w = 0.00973961 * safezoneW;
			h = 0.10663 * safezoneH;
		};
		class Arm2 : Life_RscButtonInvisible {
			idc = 93025;
			x = 0.550531 * safezoneW + safezoneX;
			y = 0.3988 * safezoneH + safezoneY;
			w = 0.00973961 * safezoneW;
			h = 0.10663 * safezoneH;
		};
		class RscPicture_1201 : Life_RscPicture {
			idc = 9301;
			text = "\SG_Core\images\bodyparts\torso_grey.paa";
			x = 0.448338 * safezoneW + safezoneX;
			y = 0.29386 * safezoneH + safezoneY;
			w = 0.178992 * safezoneW;
			h = 0.407 * safezoneH;
		};
		class RscPicture_1202 : Life_RscPicture {
			idc = 9302;
			text = "\SG_Core\images\bodyparts\head_grey.paa";
			x = 0.448338 * safezoneW + safezoneX;
			y = 0.29386 * safezoneH + safezoneY;
			w = 0.178992 * safezoneW;
			h = 0.407 * safezoneH;
		};
		class RscPicture_1203 : Life_RscPicture {
			idc = 9303;
			text = "\SG_Core\images\bodyparts\arms_grey.paa";
			x = 0.448338 * safezoneW + safezoneX;
			y = 0.29386 * safezoneH + safezoneY;
			w = 0.178992 * safezoneW;
			h = 0.407 * safezoneH;
		};
		class RscPicture_1204 : Life_RscPicture {
			idc = 9304;
			text = "\SG_Core\images\bodyparts\legs_grey.paa";
			x = 0.448338 * safezoneW + safezoneX;
			y = 0.29386 * safezoneH + safezoneY;
			w = 0.178992 * safezoneW;
			h = 0.407 * safezoneH;
		};

		//Medical Buttons
		class RscButton_1600 : RscButton {
			idc = 1600;
			x = 0.368845 * safezoneW + safezoneX;
			y = 0.337312 * safezoneH + safezoneY;
			w = 0.0881419 * safezoneW;
			h = 0.0282118 * safezoneH;
			text = "Diagnose";
		};
		class RscButton_1601 : RscButton {
			idc = 1601;
			x = 0.368845 * safezoneW + safezoneX;
			y = 0.377749 * safezoneH + safezoneY;
			w = 0.0881419 * safezoneW;
			h = 0.0282118 * safezoneH;
			text = "Defibrillate Patient";
		};
		class RscButton_1602 : RscButton {
			idc = 1602;
			x = 0.368845 * safezoneW + safezoneX;
			y = 0.415365 * safezoneH + safezoneY;
			w = 0.0881419 * safezoneW;
			h = 0.0282118 * safezoneH;
			text = "Apply Bandage";
		};
		class RscButton_1603 : RscButton {
			idc = 1603;
			x = 0.368845 * safezoneW + safezoneX;
			y = 0.45298 * safezoneH + safezoneY;
			w = 0.0881419 * safezoneW;
			h = 0.0282118 * safezoneH;
			text = "Inject Morphine";
		};
		class RscButton_1604 : RscButton {
			idc = 1604;
			x = 0.368845 * safezoneW + safezoneX;
			y = 0.490596 * safezoneH + safezoneY;
			w = 0.0881419 * safezoneW;
			h = 0.0282118 * safezoneH;
			text = "Give Blood";
		};
		class RscButton_1605 : RscButton {
			idc = 1605;
			x = 0.368845 * safezoneW + safezoneX;
			y = 0.528212 * safezoneH + safezoneY;
			w = 0.0881419 * safezoneW;
			h = 0.0282118 * safezoneH;
			text = "Apply Splint";
		};
		class RscButton_1606 : RscButton {
			idc = 1606;
			x = 0.368845 * safezoneW + safezoneX;
			y = 0.565828 * safezoneH + safezoneY;
			w = 0.0881419 * safezoneW;
			h = 0.0282118 * safezoneH;
			text = "Clean Wounds";
		};
		class RscButton_1607 : RscButton {
			idc = 1607;
			x = 0.368845 * safezoneW + safezoneX;
			y = 0.603443 * safezoneH + safezoneY;
			w = 0.0881419 * safezoneW;
			h = 0.0282118 * safezoneH;
		};
		class RscButton_1608 : RscButton {
			idc = 1608;
			x = 0.368845 * safezoneW + safezoneX;
			y = 0.641059 * safezoneH + safezoneY;
			w = 0.0881419 * safezoneW;
			h = 0.0282118 * safezoneH;
		};
	};
};