class SG_PlayerSettings {
	idd = 2900;
	name = "SG_PlayerSettings";
	onLoad = "_this call SG_PlayerSettings;";
	onUnload = "saveProfileNamespace;";
	class controlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = 0x1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class Header : SG_ctrlStaticHeaderMoving {
			idc = -1;
			text = "Player Settings"; // ToDo: Localize;
			x = "0.38657 * safezoneW + safezoneX";
			y = "0.379 * safezoneH + safezoneY";
			w = "0.227875 * safezoneW";
		};
		class Background : SG_ctrlStaticBackground {
			idc = -1;
			x = "0.386562 * safezoneW + safezoneX";
			y = "0.397407 * safezoneH + safezoneY";
			w = "0.227917 * safezoneW";
			h = "0.223704 * safezoneH";
		};
		class TitleViewSettings : SG_ctrlStaticContent {
			idc = -1;
			text = "View Settings"; // ToDo: Localize;
			x = "0.388624 * safezoneW + safezoneX";
			y = "0.401 * safezoneH + safezoneY";
			w = "0.223751 * safezoneW";
			h = "5 * (pixelH * pixelGrid * 0.50)";
		};
		class TitleHUD : TitleViewSettings {
			text = "General Settings"; // ToDo: Localize;
			y = "0.5268 * safezoneH + safezoneY";
		};
		/*
        class SomeTitle: TitleViewSettings {
            text               = "Some Settings"; // ToDo: Localize;
            y                  = "0.571556 * safezoneH + safezoneY";
        };
        */
		class TitleViewDistance : SG_ctrlStatic {
			idc = -1;
			text = "On Foot"; // ToDo: Localize;
			x = "0.388624 * safezoneW + safezoneX";
			y = "0.4208 * safezoneH + safezoneY";
			w = "0.0804375 * safezoneW";
			h = "5 * (pixelH * pixelGrid * 0.50)";
			colorBackground[] = { 0, 0, 0, 0 };
			style = 0x01;
		};
		class TitleCarDistance : TitleViewDistance {
			text = "In Car"; // ToDo: Localize;
			y = "0.439815 * safezoneH + safezoneY";
		};
		class TitleAirDistance : TitleViewDistance {
			text = "In Air"; // ToDo: Localize;
			y = "0.459259 * safezoneH + safezoneY";
		};
		class TitleShowPlayerTags : TitleViewDistance {
			text = "Name Tags"; // ToDo: Localize;
			y = "0.556481 * safezoneH + safezoneY";
			w = "0.07425 * safezoneW";
		};
		class TitleEnableTwitter : TitleViewDistance {
			text = "Twitter"; // ToDo: Localize;
			x = "0.388542 * safezoneW + safezoneX";
			y = "0.575926 * safezoneH + safezoneY";
			w = "0.07425 * safezoneW";
		};
		class TitleRevealObjects : TitleViewDistance {
			text = "Reveal Objects"; // ToDo: Localize;
			x = "0.388645 * safezoneW + safezoneX";
			y = "0.595037 * safezoneH + safezoneY";
			w = "0.07425 * safezoneW";
		};
		class TitleHudPercentage : TitleViewDistance {
			text = "Hud (%)"; // ToDo: Localize;
			x = "0.476552 * safezoneW + safezoneX";
			y = "0.556482 * safezoneH + safezoneY";
			w = "0.0680626 * safezoneW";
		};
		class TitelSpeedometer : TitleViewDistance {
			text = "Disable Speedometer"; // ToDo: Localize;
			x = "0.476595 * safezoneW + safezoneX";
			y = "0.575926 * safezoneH + safezoneY";
			w = "0.0680626 * safezoneW";
		};
		/*
        class SomethingElse: TitleViewDistance {
        	text               = "Something else"; // ToDo: Localize;
        	x                  = "0.476595 * safezoneW + safezoneX";
        	y                  = "0.54537 * safezoneH + safezoneY";
        	w                  = "0.0680626 * safezoneW";
        };
        class SomethingElse: TitleViewDistance {
        	text               = "Something else"; // ToDo: Localize;
        	x                  = "0.558282 * safezoneW + safezoneX";
        	y                  = "0.50637 * safezoneH + safezoneY";
        	w                  = "0.0418545 * safezoneW";
        };
        class SomethingElse: TitleViewDistance {
        	text               = "Something else"; // ToDo: Localize;
        	x                  = "0.388698 * safezoneW + safezoneX";
        	y                  = "0.590304 * safezoneH + safezoneY";
        	w                  = "0.0742498 * safezoneW";
        };
        */
		class TitleTerrainGrid : SG_ctrlStatic {
			idc = -1;
			text = "Terrain Quality"; // ToDo: Localize;
			x = "0.372624 * safezoneW + safezoneX";
			y = "0.495 * safezoneH + safezoneY";
			w = "0.0804375 * safezoneW";
			h = "5 * (pixelH * pixelGrid * 0.50)";
			colorBackground[] = { 0, 0, 0, 0 };
			style = 0x01;
		};
	};
	class Controls {
		class BUTTON_EXIT : SG_ctrlButtonClose {
			x = "0.602593 * safezoneW + safezoneX";
			y = "0.379 * safezoneH + safezoneY";
			w = "0.0122185 * safezoneW";
			h = "5 * (pixelH * pixelGrid * 0.50)";
		};
		class FootDistanceSlider : SG_ctrlXSliderH {
			idc = 2901;
			onSliderPosChanged = "[0,_this select 1] call SG_OnSliderChange;";
			tooltip = "$STR_SM_ToolTip1";

			x = "0.469345 * safezoneW + safezoneX";
			y = "0.42037 * safezoneH + safezoneY";
			w = "0.104155 * safezoneW";
			h = "5 * (pixelH * pixelGrid * 0.50)";
			colorBackground[] = { 0, 0, 0, 0.5 };
		};
		class CarDistanceSlider : FootDistanceSlider {
			idc = 2911;
			onSliderPosChanged = "[1,_this select 1] call SG_OnSliderChange;";
			tooltip = "$STR_SM_ToolTip2";

			y = "0.439815 * safezoneH + safezoneY";
		};
		class AirViewCheckbox : FootDistanceSlider {
			idc = 2921;
			onSliderPosChanged = "[2,_this select 1] call SG_OnSliderChange;";
			tooltip = "$STR_SM_ToolTip3";

			y = "0.45926 * safezoneH + safezoneY";
		};
		class RscButton_1600: SG_RscButton
		{
			idc = 1600;
			text = "Low"; //--- ToDo: Localize;
			onButtonClick = "[0] call SG_OnTerrainGridChange;";
			x = "0.469062 * safezoneW + safezoneX";
			y = "0.495 * safezoneH + safezoneY";
			w = "0.04125 * safezoneW";
			h = "0.022 * safezoneH";
		};
		class RscButton_1601: SG_RscButton
		{
			idc = 1601;
			text = "Medium"; //--- ToDo: Localize;
			onButtonClick = "[1] call SG_OnTerrainGridChange;";
			x = "0.510312 * safezoneW + safezoneX";
			y = "0.495 * safezoneH + safezoneY";
			w = "0.04125 * safezoneW";
			h = "0.022 * safezoneH";
		};
		class RscButton_1602: SG_RscButton
		{
			idc = 1602;
			text = "High"; //--- ToDo: Localize;
			onButtonClick = "[2] call SG_OnTerrainGridChange;";
			x = "0.551562 * safezoneW + safezoneX";
			y = "0.495 * safezoneH + safezoneY";
			w = "0.04125 * safezoneW";
			h = "0.022 * safezoneH";
		};
		class ShowPlayerTagsCheckbox : SG_RscCheckBox {
			idc = 2970;
			onCheckedChanged = "['tags',_this select 1] call SG_OnCheckedChange;";
			tooltip = "$STR_GUI_PlayTags";

			x = "0.463606 * safezoneW + safezoneX";
			y = "0.556482 * safezoneH + safezoneY";
			w = "5 * (pixelW * pixelGrid * 0.50)";
			h = "5 * (pixelH * pixelGrid * 0.50)";
		};
		class EnableTwitterCheckbox : SG_RscCheckBox {
			idc = 2971;
			tooltip = "$STR_GUI_TwitterSwitch";
			onCheckedChanged = "['twitter',_this select 1] call SG_OnCheckedChange;";

			x = "0.463542 * safezoneW + safezoneX";
			y = "0.575926 * safezoneH + safezoneY";
			w = "5 * (pixelW * pixelGrid * 0.50)";
			h = "5 * (pixelH * pixelGrid * 0.50)";
		};
		class RevealObjCheckbox : SG_RscCheckBox {
			idc = 2972;
			tooltip = "$STR_GUI_PlayerReveal";
			onCheckedChanged = "['objects',_this select 1] call SG_OnCheckedChange;";

			x = "0.463542 * safezoneW + safezoneX";
			y = "0.59537 * safezoneH + safezoneY";
			w = "5 * (pixelW * pixelGrid * 0.50)";
			h = "5 * (pixelH * pixelGrid * 0.50)";
		};
		class HudPercentCheckbox : SG_RscCheckBox {
			idc = 2973;
			tooltip = "$STR_GUI_HudPercent";
			onCheckedChanged = "['hudPercent',_this select 1] call SG_OnCheckedChange;";

			x = "0.545473 * safezoneW + safezoneX";
			y = "0.556482 * safezoneH + safezoneY";
			w = "5 * (pixelW * pixelGrid * 0.50)";
			h = "5 * (pixelH * pixelGrid * 0.50)";
		};

		class SpeedometerCheckbox : SG_RscCheckBox {
			idc = 2974;
			tooltip = "$STR_GUI_Speedometer";
			onCheckedChanged = "['speedometer',_this select 1] call SG_OnCheckedChange;";

			x = "0.545417 * safezoneW + safezoneX";
			y = "0.575593 * safezoneH + safezoneY";
			w = "5 * (pixelW * pixelGrid * 0.50)";
			h = "5 * (pixelH * pixelGrid * 0.50)";
		};

		/*
        class SomethingElse: SG_RscCheckBox {
            idc                 = -1;
            x                   = "0.545558 * safezoneW + safezoneX";
            y                   = "0.54537 * safezoneH + safezoneY";
            w                   = "5 * (pixelW * pixelGrid * 0.50)";
	        h                   = "5 * (pixelH * pixelGrid * 0.50)";
        };
        class SomethingElse: SG_RscCheckBox {
            idc                 = -1;
            x                   = "0.600542 * safezoneW + safezoneX";
            y                   = "0.506133 * safezoneH + safezoneY";
            w                   = "5 * (pixelW * pixelGrid * 0.50)";
	        h                   = "5 * (pixelH * pixelGrid * 0.50)";
        };
        class SomethingElse: SG_RscCheckBox {
            idc                 = -1;
            x                   = "0.463385 * safezoneW + safezoneX";
            y                   = "0.590778 * safezoneH + safezoneY";
            w                   = "5 * (pixelW * pixelGrid * 0.50)";
	        h                   = "5 * (pixelH * pixelGrid * 0.50)";
        };
        */
	};
};