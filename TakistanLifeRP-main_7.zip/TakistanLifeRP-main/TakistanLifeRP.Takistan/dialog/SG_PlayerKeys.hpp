class SG_PlayerKeys {
	idd = 57128;
	name = "SG_PlayerKeys";
	scriptName = "SG_PlayerKeys";
	onLoad = [ 'onLoad', _this ] call SG_PlayerKeys;
	movingEnable = 0;
	enableSimulation = 1;
	class controlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = 0x1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class Background : SG_ctrlStaticBackground {
			x = (((getResolution select 2) * 0.5 * pixelW) - (100 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.450 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50));
			w = 100 * (pixelW * pixelGrid * 0.50);
			h = (90 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50));
		};
	};
	class controls {
		class Dummy : SG_ctrlStatic {};
		class Title : SG_ctrlStaticTitle {
			x = (((getResolution select 2) * 0.5 * pixelW) - (100 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.450 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 100 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
			text = "Keychain";
		};
		class ButtonClose : SG_ctrlButtonClose {
			x = ((getResolution select 2) * 0.5 * pixelW) + (100 * 0.5 - 5) * (pixelW * pixelGrid * 0.50);
			y = (0.450 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50));
			w = 5 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class KeysFilterBackground : SG_ctrlStatic {
			idc = 232321 + 105;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (100 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.400 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 1) + (2 * (pixelH * pixelGrid * 0.50));
			w = (100 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = 5 * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 1 };
		};
		class KeysFilter : SG_ctrlListNBox {
			idc = 82;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (100 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.400 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 1) + (2 * (pixelH * pixelGrid * 0.50));
			w = (100 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = 5 * (pixelH * pixelGrid * 0.50);
			disableOverflow = 1;
			columns[] = { 0, 0.8 };
			class Items {
				class KeyOwner {
					text = "Key's Object";
					value = 0;
				};
				class Distance : KeyOwner {
					text = "Distance";
				};
			};
		};
		class KeysListBackground : SG_ctrlStaticContent {
			idc = 232321 + 108;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (100 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.400 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 2) + (2 * (pixelH * pixelGrid * 0.50));
			w = (100 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = (95 / 1.4) * (pixelH * pixelGrid * 0.50);
		};
		class KeysList : KeysFilter {
			idc = 83;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (100 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.400 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 2) + (2 * (pixelH * pixelGrid * 0.50));
			w = (100 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = (95 / 1.4) * (pixelH * pixelGrid * 0.50);
			class Items {};
		};
		class KeysPerson : SG_ctrlCombo {
			idc = 22;
			x = ((((getResolution select 2) * 0.5 * pixelW) - (100 * 0.5) * (pixelW * pixelGrid * 0.50)) + (1.5 * (pixelW * pixelGrid * 0.50)));
			y = ((0.830 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + (5 * (pixelH * pixelGrid * 0.50)) + (1.5 * (pixelH * pixelGrid * 0.50))) + ((5 * (pixelH * pixelGrid * 0.50)) * 3) + (1.5 * (pixelH * pixelGrid * 0.50));
			w = (100 * (pixelW * pixelGrid * 0.50)) - ((1.5 * (pixelW * pixelGrid * 0.50)) * 2);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class Footer : SG_ctrlControlsGroupNoScrollbars {
			idc = 89;
			x = (((getResolution select 2) * 0.5 * pixelW) - (100 * 0.5) * (pixelW * pixelGrid * 0.50));
			y = (0.350 - (100 * 0.5 - 5) * (pixelH * pixelGrid * 0.50)) + ((100 * (pixelH * pixelGrid * 0.50)) - (5 * (pixelH * pixelGrid * 0.50))) + (5 * (pixelH * pixelGrid * 0.50));
			w = 100 * (pixelW * pixelGrid * 0.50);
			h = (5 + 2) * (pixelH * pixelGrid * 0.50);
			class controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					w = "safezoneW";
					h = "safezoneH";
				};
				class ButtonGive : SG_ctrlDefaultButton {
					idc = 90;
					text = "GIVE KEY";
					x = ((pixelW * pixelGrid * 0.50) * 2) + 0 * (pixelW * pixelGrid * 0.50);
					y = (pixelH * pixelGrid * 0.50);
					w = (160 / 6.8) * (pixelW * pixelGrid * 0.50);
					h = 5 * (pixelH * pixelGrid * 0.50);
				};
				class ButtonDrop : SG_ctrlDefaultButton {
					idc = 91;
					text = "DROP KEY";
					x = ((pixelW * pixelGrid * 0.50) * 2) + (175 / 6.8) * (pixelW * pixelGrid * 0.50);
					y = (pixelH * pixelGrid * 0.50);
					w = (160 / 6.8) * (pixelW * pixelGrid * 0.50);
					h = 5 * (pixelH * pixelGrid * 0.50);
				};
				class ButtonStolen : SG_ctrlDefaultButton {
					idc = 92;
					text = "SELECT VEHICLE";
					x = ((pixelW * pixelGrid * 0.50) * 2) + (326 / 5) * (pixelW * pixelGrid * 0.50);
					y = (pixelH * pixelGrid * 0.50);
					w = (170 / 5.5) * (pixelW * pixelGrid * 0.50);
					h = 5 * (pixelH * pixelGrid * 0.50);
				};
			};
		};
	};
};