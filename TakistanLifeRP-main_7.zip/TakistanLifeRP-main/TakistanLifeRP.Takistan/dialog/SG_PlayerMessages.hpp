class SG_PlayerMessages {
	idd = 8000030;
	scriptName = "SG_PlayerMessages";
	onLoad = [ 'onLoad', _this ] call SG_PlayerMessages;
	class controlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = 0x1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class HEADER : SG_ctrlStaticTitle {
			idc = -1;
			text = "Messaging";
			x = "0.29375 * safezoneW + safezoneX";
			y = "0.225 * safezoneH + safezoneY";
			w = "0.4125 * safezoneW";
			h = "0.022 * safezoneH";
		};
		class BACKGROUND : SG_ctrlStatic {
			idc = -1;
			x = "0.29375 * safezoneW + safezoneX";
			y = "0.248148 * safezoneH + safezoneY";
			w = "0.4125 * safezoneW";
			h = "0.528 * safezoneH";
			colorBackground[] = { 0.2, 0.2, 0.2, 1 };
		};
		class TITLE_RECEIVEDMESSAGES : SG_ctrlStatic {
			idc = -1;
			text = "Received Messages";
			x = "0.295813 * safezoneW + safezoneX";
			y = "0.2514 * safezoneH + safezoneY";
			w = "0.127871 * safezoneW";
			h = "0.022 * safezoneH";
			colorBackground[] = { 0.05, 0.05, 0.05, 1 };
		};
		class TITLE_FROM : SG_ctrlStatic {
			idc = -1;
			text = "From:";
			x = "0.425 * safezoneW + safezoneX";
			y = "0.2514 * safezoneH + safezoneY";
			w = "0.0804375 * safezoneW";
			h = "0.022 * safezoneH";
			colorBackground[] = { 0, 0, 0, 0.5 };
		};
		class TITLE_TO : TITLE_FROM {
			text = "To:";
			y = "0.275 * safezoneH + safezoneY";
		};
		class TITLE_DATE : TITLE_FROM {
			text = "Date:";
			y = "0.298148 * safezoneH + safezoneY";
		};
		class TITLE_LOCATION : TITLE_FROM {
			text = "Location:";
			y = "0.321296 * safezoneH + safezoneY";
		};
	};
	class controls {
		class LIST_MESSAGES : SG_ctrlListbox {
			idc = 8000031;
			x = "0.295813 * safezoneW + safezoneX";
			y = "0.275 * safezoneH + safezoneY";
			w = "0.127871 * safezoneW";
			h = "0.477052 * safezoneH";
			colorBackground[] = { 0, 0, 0, 0.5 };
		};
		class BUTTON_REPLY : SG_ctrlContentAreaButton {
			idc = 8000032;
			text = "REPLY";
			x = "0.295813 * safezoneW + safezoneX";
			y = "0.753 * safezoneH + safezoneY";
			w = "0.0635 * safezoneW";
			h = "0.0198 * safezoneH";
			colorBackground[] = { 0, 0, 0, 1 };
		};
		class BUTTON_DELETE : BUTTON_REPLY {
			idc = 8000034;
			text = "DELETE";
			x = "0.359896 * safezoneW + safezoneX";
			y = "0.752778 * safezoneH + safezoneY";
			w = "0.0639 * safezoneW";
		};
		class BUTTON_CLOSE : SG_ctrlButtonClose {
			idc = 8000035;
			x = "0.692843 * safezoneW + safezoneX";
			y = "0.225 * safezoneH + safezoneY";
			w = "0.0134063 * safezoneW";
		};
		class SENDER_NAME : SG_ctrlStatic {
			idc = 8000036;
			text = "N/A";
			x = "0.505729 * safezoneW + safezoneX";
			y = "0.251852 * safezoneH + safezoneY";
			w = "0.197976 * safezoneW";
			h = "0.022 * safezoneH";
			colorBackground[] = { 0, 0, 0, 0.4 };
		};
		class TO_NAME : SENDER_NAME {
			idc = 8000037;
			text = "N/A";
			y = "0.275 * safezoneH + safezoneY";
		};
		class DATE_SENT : SENDER_NAME {
			idc = 8000038;
			text = "N/A";
			y = "0.298148 * safezoneH + safezoneY";
		};
		class LOCATION : SENDER_NAME {
			idc = 8000039;
			text = "N/A";
			y = "0.321296 * safezoneH + safezoneY";
		};
		class MESSAGE_TEXT : SG_ctrlStatic {
			idc = 8000040;
			x = "0.425 * safezoneW + safezoneX";
			y = "0.344792 * safezoneH + safezoneY";
			w = "0.278437 * safezoneW";
			h = "0.407 * safezoneH";
			style = ST_LEFT + ST_MULTI + ST_NO_RECT;
			colorBackground[] = { 0, 0, 0, 0.5 };
		};
		class BUTTON_NEWMESSAGE : SG_ctrlContentAreaButton {
			idc = 8000041;
			text = "COMPOSE";
			x = "0.639818 * safezoneW + safezoneX";
			y = "0.752778 * safezoneH + safezoneY";
			w = "0.0639 * safezoneW";
			h = "0.0198 * safezoneH";
			colorBackground[] = { 0, 0, 0, 1 };
		};
	};
};

class SG_MessagesTargets {
	idd = 8000011;
	scriptName = "SG_MessagesTargets";
	onLoad = [ 'onLoad', _this ] call SG_MessagesTargets;
	class controlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = 0x1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class HEADER : SG_ctrlStaticTitle {
			idc = -1;
			text = "Select a contact";
			x = "0.427802 * safezoneW + safezoneX";
			y = "0.225 * safezoneH + safezoneY";
			w = "0.145426 * safezoneW";
		};
		class BACKGROUND : SG_ctrlStaticBackground {
			x = "0.427698 * safezoneW + safezoneX";
			y = "0.248148 * safezoneH + safezoneY";
			w = "0.145426 * safezoneW";
			h = "0.528 * safezoneH";
		};
	};
	class controls {
		class BUTTON_CLOSE : SG_ctrlButtonClose {
			idc = 1;
			x = "0.559822 * safezoneW + safezoneX";
			y = "0.225 * safezoneH + safezoneY";
			w = "0.0123751 * safezoneW";
		};
		class TARGETS_SEARCH_INPUT : SG_ctrlEditNoRect {
			idc = 2;
			x = "0.429372 * safezoneW + safezoneX";
			y = "0.25117 * safezoneH + safezoneY";
			w = "0.130249 * safezoneW";
			h = "0.0198 * safezoneH";
			colorBackground[] = { 0, 0, 0, 0.4 };
		};
		class TARGETS_SEARCH_BUTTON_REFRESH : SG_ctrlButtonPictureKeepAspect {
			idc = 3;
			text = "\a3\3DEN\Data\Displays\Display3DEN\search_start_ca.paa";
			x = "0.55981 * safezoneW + safezoneX";
			y = "0.251052 * safezoneH + safezoneY";
			w = "0.0115501 * safezoneW";
			h = "0.0198 * safezoneH";
		};
		class TARGETS_TREE : SG_ctrlTree {
			idc = 4;
			idcSearch = 2;
			x = "0.429261 * safezoneW + safezoneX";
			y = "0.272444 * safezoneH + safezoneY";
			w = "0.142051 * safezoneW";
			h = "0.479252 * safezoneH";
			colorBackground[] = { 0, 0, 0, 0.5 };
		};
		class BUTTON_MESSAGE : SG_ctrlDefaultButton {
			idc = 6;
			text = "NEW MESSAGE";
			x = "0.429366 * safezoneW + safezoneX";
			y = "0.753926 * safezoneH + safezoneY";
			w = "0.1425 * safezoneW";
			colorBackground[] = { 0, 0, 0, 0 };
		};
	};
};

class SG_MessagesSendMessage {
	idd = 8000021;
	scriptName = "SG_MessagesSendMessage";
	onLoad = [ 'onLoad', _this ] call SG_MessagesSendMessage;
	onUnload = [ 'onUnload', _this ] call SG_MessagesSendMessage;
	class controlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = -1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class HEADER : SG_ctrlStatic {
			idc = -1;
			text = "Compose a message";
			x = "0.29375 * safezoneW + safezoneX";
			y = "0.225 * safezoneH + safezoneY";
			w = "0.4125 * safezoneW";
			h = "0.022 * safezoneH";
			colorBackground[] = { "(profilenamespace getvariable ['GUI_BCG_RGB_R',0.3843])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.7019])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.8862])", "1" };
			font = "RobotoCondensed";
			sizeEx = "0.020 * safezoneH";
		};
		class BACKGROUND : SG_ctrlStatic {
			idc = -1;
			x = "0.29375 * safezoneW + safezoneX";
			y = "0.2481 * safezoneH + safezoneY";
			w = "0.4125 * safezoneW";
			h = "0.528 * safezoneH";
			colorBackground[] = { 0.2, 0.2, 0.2, 1 };
		};
		class TITLE_TO : SG_ctrlStatic {
			idc = -1;
			text = "To:";
			x = "0.295812 * safezoneW + safezoneX";
			y = "0.2514 * safezoneH + safezoneY";
			w = "0.0690937 * safezoneW";
			h = "0.022 * safezoneH";
			colorBackground[] = { 0, 0, 0, 0.5 };
			font = "PuristaMedium";
			sizeEx = "0.018 * safezoneH";
		};
		class TITLE_LOCATION : TITLE_TO {
			text = "Location:";
			y = "0.275 * safezoneH + safezoneY";
		};
	};
	class controls {
		class TEXT_TO : SG_ctrlStatic {
			idc = 1;
			text = "N/A";
			x = "0.365628 * safezoneW + safezoneX";
			y = "0.25184 * safezoneH + safezoneY";
			w = "0.33825 * safezoneW";
			h = "0.022 * safezoneH";
			colorBackground[] = { 0, 0, 0, 0.4 };
			sizeEx = "0.018 * safezoneH";
		};
		class TEXT_LOCATION : TEXT_TO {
			idc = 2;
			text = "N/A";
			y = "0.275 * safezoneH + safezoneY";
			w = "0.33 * safezoneW";
			colorBackground[] = { 0, 0, 0, 0.4 };
		};
		class CHECKBOX_SENDLOCATION : SG_RscCheckBox {
			idc = 3;
			tooltip = "Attach your location with the message";
			x = "0.695 * safezoneW + safezoneX";
			y = "0.275 * safezoneH + safezoneY";
			w = "0.01 * safezoneW";
			h = "0.022 * safezoneH";
			colorBackground[] = { 0, 0, 0, 1 };
		};
		class INPUT_MESSAGE : SG_ctrlEditNoRect {
			idc = 4;
			x = "0.295813 * safezoneW + safezoneX";
			y = "0.298 * safezoneH + safezoneY";
			w = "0.4078 * safezoneW";
			h = "0.4532 * safezoneH";
			colorBackground[] = { 0, 0, 0, 0.5 };
			style = ST_MULTI + ST_NO_RECT;
			sizeEx = "0.018 * safezoneH";
		};
		class BUTTON_SENDMESSAGE : SG_ctrlContentAreaButton {
			idc = 5;
			text = "SEND MESSAGE";
			x = "0.295813 * safezoneW + safezoneX";
			y = "0.753 * safezoneH + safezoneY";
			w = "0.0773437 * safezoneW";
			h = "0.0198 * safezoneH";
			colorBackground[] = { 0, 0, 0, 1 };
		};
		class BUTTON_GOBACK : BUTTON_SENDMESSAGE {
			idc = 6;
			text = "GO BACK";
			x = "0.62631 * safezoneW + safezoneX";
		};
		class BUTTON_CLOSE : SG_ctrlButtonClose {
			idc = 7;
			x = "0.693147 * safezoneW + safezoneX";
			y = "0.225 * safezoneH + safezoneY";
			w = "0.0123751 * safezoneW";
		};
	};
};
