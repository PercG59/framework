class SG_PlayerProfile {
	idd = 36069;
	scriptName = "SG_PlayerProfile";
	onLoad = [ 'onLoad', _this ] call SG_PlayerProfile;
	onUnload = [ 'onUnload', _this ] call SG_PlayerProfile;
	class ControlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = 0x1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
		class Background : SG_ctrlStaticBackground {
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (140 * 0.5 - 5) * (pixelH * pixelGrid * 0.50);
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (140 - 10) * (pixelH * pixelGrid * 0.50);
		};
		class BackgroundTop : SG_ctrlStatic {
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (140 * 0.5 - 2 * 5) * (pixelH * pixelGrid * 0.50);
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (5 + 1) * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0.1, 0.1, 0.1, 1 };
		};
		class BackgroundButtons : SG_ctrlStaticFooter {
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 + (140 * 0.5 - 2 * 5 - 2) * (pixelH * pixelGrid * 0.50);
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (5 + 2) * (pixelH * pixelGrid * 0.50);
		};
	};
	class Controls {
		class Dummy : SG_ctrlStatic {};
		class Title : SG_ctrlStaticTitle {
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (140 * 0.5 - 5) * (pixelH * pixelGrid * 0.50);
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
			text = "Profile";
		};
		class ButtonClose : SG_ctrlButtonClose {
			x = ((getResolution select 2) * 0.5 * pixelW) + (160 * 0.5 - 5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (140 * 0.5 - 5) * (pixelH * pixelGrid * 0.50);
			w = 5 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
		};
		class Tabs : SG_ctrlToolbox {
			idc = 0x9;
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (140 * 0.5 - 2 * 5 - 1) * (pixelH * pixelGrid * 0.50);
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = 5 * (pixelH * pixelGrid * 0.50);
			colorBackground[] = { 0, 0, 0, 0 };
			colorSelectedBg[] = { 0.2, 0.2, 0.2, 1 };
			columns = 3;
			font = "RobotoCondensedLight";
			strings[] = {
				"Wallet",
				"Licenses"
			};
		};
		class TabMoney : SG_ctrlControlsGroupNoScrollbars {
			idc = 0x10;
			x = ((getResolution select 2) * 0.5 * pixelW) - (160 * 0.5) * (pixelW * pixelGrid * 0.50);
			y = 0.5 - (140 * 0.5 - 3 * 5 - 1) * (pixelH * pixelGrid * 0.50);
			w = 160 * (pixelW * pixelGrid * 0.50);
			h = (140 - 5 * 5 - 3) * (pixelH * pixelGrid * 0.50);
			class Controls {
				class TextBalance : SG_ctrlStatic {
					idc = 0x3;
					x = 1 * (pixelW * pixelGrid * 0.50);
					y = 1 * (pixelH * pixelGrid * 0.50);
					w = (160 - 2) * (pixelW * pixelGrid * 0.50);
					h = (5 + 2) * (pixelH * pixelGrid * 0.50);
					colorBackground[] = { 0.12549, 0.505882, 0.313726, 0.9 };
					font = "RobotoCondensed";
					style = 0x02;
				};
				class BackgroundFilter : SG_ctrlStatic {
					x = 1 * (pixelW * pixelGrid * 0.50);
					y = ((5 + 2) + 2) * (pixelH * pixelGrid * 0.50);
					w = (160 - 2) * (pixelW * pixelGrid * 0.50);
					h = 5 * (pixelH * pixelGrid * 0.50);
					colorBackground[] = { 0, 0, 0, 1 };
				};
				class Filter : SG_ctrlListNBox {
					idc = 0x4;
					x = 1 * (pixelW * pixelGrid * 0.50);
					y = ((5 + 2) + 2) * (pixelH * pixelGrid * 0.50);
					w = (160 - 2) * (pixelW * pixelGrid * 0.50);
					h = 5 * (pixelH * pixelGrid * 0.50);
					columns[] = { 0, 0.7, 0.85 };
					disableOverflow = 1;
					class Items {
						class Description {
							text = "Description";
							value = 1;
							data = "data";
						};
						class In {
							text = "In";
							value = -1;
							data = "data";
						};
						class Out {
							text = "Out";
							value = -1;
							data = "data";
						};
					};
				};
				class BackgroundTransactions : SG_ctrlStaticOverlay {
					x = 1 * (pixelW * pixelGrid * 0.50);
					y = ((5 + 2) + 5 + 2) * (pixelH * pixelGrid * 0.50);
					w = (160 - 2) * (pixelW * pixelGrid * 0.50);
					h = ((140 - 5 * 5 - 3) - (5 + 2) - 2 * 5 - 4) * (pixelH * pixelGrid * 0.50);
				};
				class ListTransactions : SG_ctrlListNBox {
					idc = 0x5;
					x = 1 * (pixelW * pixelGrid * 0.50);
					y = ((5 + 2) + 5 + 2) * (pixelH * pixelGrid * 0.50);
					w = (160 - 2) * (pixelW * pixelGrid * 0.50);
					h = ((140 - 5 * 5 - 3) - (5 + 2) - 2 * 5 - 4) * (pixelH * pixelGrid * 0.50);
					columns[] = { 0, 0.7, 0.85 };
					disableOverflow = 1;
				};
			};
		};
		class TabLicenses : TabMoney {
			idc = 0x11;
			show = 0;
			class Controls {
				class List : SG_ctrlListBox {
					idc = 0x7;
					x = 1 * (pixelW * pixelGrid * 0.50);
					y = 1 * (pixelH * pixelGrid * 0.50);
					w = (160 - 2) * (pixelW * pixelGrid * 0.50);
					h = ((140 - 5 * 5 - 3) - 2) * (pixelH * pixelGrid * 0.50);
					rowHeight = 8 * (pixelH * pixelGrid * 0.50);
					shadow = 0;
				};
			};
		};
	};
};