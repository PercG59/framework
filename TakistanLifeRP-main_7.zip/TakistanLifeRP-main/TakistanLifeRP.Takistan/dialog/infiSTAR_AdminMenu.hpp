/*
Antihack & AdminTools - Christian Lorenzen - www.infiSTAR.de
#19615
*/
class RscListBox_infiSTAR {
    access = 0;
    type = 5;
    style = 0;
    font = "PuristaLight";
    sizeEx = 0.03;
    rowHeight = 0;
    colorText[] = {
        1,
        1,
        1,
        1
    };
    colorScrollbar[] = {
        1,
        1,
        1,
        1
    };
    colorSelect[] = {
        0,
        0,
        0,
        1
    };
    colorSelect2[] = {
        1,
        0.5,
        0,
        1
    };
    colorSelectBackground[] = {
        0.6,
        0.6,
        0.6,
        1
    };
    colorSelectBackground2[] = {
        0.2,
        0.2,
        0.2,
        1
    };
    colorBackground[] = {
        0,
        0,
        0,
        0.8
    };
    maxHistoryDelay = 1.0;
    soundSelect[] = {
        "",
        0.1,
        1
    };
    period = 1;
    autoScrollSpeed = -1;
    autoScrollDelay = 5;
    autoScrollRewind = 0;
    arrowEmpty = "#(argb,8,8,3)color(1,1,1,1)";
    arrowFull = "#(argb,8,8,3)color(1,1,1,1)";
    shadow = 0;
    colorDisabled[] = {
        1,
        1,
        1,
        0.25
    };
    border = false;
    borderSize = 0;
    class ScrollBar {
        arrowEmpty = "#(argb,8,8,3)color(1,1,1,1)";
        arrowFull = "#(argb,8,8,3)color(1,1,1,1)";
        border = "#(argb,8,8,3)color(1,1,1,1)";
        color[] = {
            1,
            1,
            1,
            0.6
        };
        colorActive[] = {
            1,
            1,
            1,
            1
        };
        colorDisabled[] = {
            1,
            1,
            1,
            0.3
        };
        thumb = "#(argb,8,8,3)color(1,1,1,1)";
    };
    class ListScrollBar: ScrollBar {
        color[] = {
            1,
            1,
            1,
            0.6
        };
        colorActive[] = {
            1,
            1,
            1,
            1
        };
        colorDisabled[] = {
            1,
            1,
            1,
            0.3
        };
        thumb = "#(argb,8,8,3)color(1,1,1,1)";
        arrowEmpty = "#(argb,8,8,3)color(1,1,1,1)";
        arrowFull = "#(argb,8,8,3)color(1,1,1,1)";
        border = "#(argb,8,8,3)color(1,1,1,1)";
        shadow = 0;
    };
};
class RscText_infiSTAR {
    access = 0;
    idc = -1;
    type = 0;
    style = 0;
    linespacing = 1;
    colorBackground[] = {
        0,
        0,
        0,
        0
    };
    colorText[] = {
        0.84,
        0.07,
        0,
        1
    };
    shadow = 1;
    font = "PuristaBold";
    sizeex = 0.0400;
    fixedWidth = 0;
};
class RscEdit_infiSTAR {
    access = 0;
    type = 2;
    style = 0;
    colorBackground[] = {
        0,
        0,
        0,
        0.6
    };
    colorText[] = {
        1,
        1,
        1,
        1
    };
    colorSelection[] = {
        1,
        1,
        1,
        0.25
    };
    colorDisabled[] = {
        1,
        1,
        1,
        0
    };
    font = "PuristaBold";
    sizeEx = 0.04;
    autocomplete = "";
    text = "";
    size = 0.2;
    shadow = 0;
};
class RscButton_infiSTAR {
    access = 0;
    idc = -1;
    type = 1;
    style = 0;
    text = "";
    action = "";
    colorText[] = {
        1,
        1,
        1,
        0.9
    };
    colorDisabled[] = {
        0.6,
        0.1,
        0.3,
        0
    };
    colorBackground[] = {
        0,
        0,
        0,
        0.8
    };
    colorBackgroundDisabled[] = {
        0,
        0.0,
        0
    };
    colorBackgroundActive[] = {
        0.15,
        0.35,
        0.55,
        0.7
    };
    colorFocused[] = {
        0.58,
        0.05,
        0,
        0.7
    };
    colorShadow[] = {
        0.023529,
        0,
        0.0313725,
        1
    };
    colorBorder[] = {
        0.023529,
        0,
        0.0313725,
        1
    };
    soundEnter[] = {
        "\A3\ui_f\data\sound\RscButtonMenu\soundEnter",
        0.09,
        1
    };
    soundPush[] = {
        "\A3\ui_f\data\sound\RscButtonMenu\soundPush",
        0.09,
        1
    };
    soundClick[] = {
        "\A3\ui_f\data\sound\RscButtonMenu\soundClick",
        0.09,
        1
    };
    soundEscape[] = {
        "\A3\ui_f\data\sound\RscButtonMenu\soundEscape",
        0.09,
        1
    };
    shadow = 0;
    font = "PuristaMedium";
    sizeEx = 0.02921;
    offsetX = 0.003;
    offsetY = 0.003;
    offsetPressedX = 0.002;
    offsetPressedY = 0.002;
    borderSize = 0;
};
class RscHTML_infiSTAR {
    colorText[] = {
        1,
        1,
        1,
        1
    };
    colorBold[] = {
        1,
        1,
        1,
        0.75
    };
    colorLink[] = {
        "63/255",
        "212/255",
        "252/255",
        1
    };
    colorLinkActive[] = {
        "63/255",
        "212/255",
        "252/255",
        0.75
    };
    colorBackground[] = {
        0,
        0,
        0,
        0
    };
    colorPicture[] = {
        1,
        1,
        1,
        1
    };
    colorPictureBorder[] = {
        0,
        0,
        0,
        0
    };
    colorPictureLink[] = {
        1,
        1,
        1,
        1
    };
    colorPictureSelected[] = {
        1,
        1,
        1,
        1
    };
    hppversion = 3;
    filename = "";
    sizeEx = 0.03921;
    type = 9;
    style = 0;
    prevPage = "\ca\ui\data\arrow_left_ca.paa";
    nextPage = "\ca\ui\data\arrow_right_ca.paa";
    shadow = 2;
    class def {
        font = "PuristaMedium";
        fontBold = "PuristaBold";
        align = "left";
    };
    class H1: def {
        sizeEx = "38 * pixelH";
    };
    class H2: def {
        sizeEx = "32 * pixelH";
    };
    class H3: def {
        sizeEx = "26 * pixelH";
    };
    class H4: def {
        sizeEx = "20 * pixelH";
    };
    class H5: def {
        sizeEx = "17 * pixelH";
    };
    class H6: def {
        sizeEx = "15 * pixelH";
    };
    class P: def {
        sizeEx = "18 * pixelH";
    };
};
class RscEdit_infiSTAR_multi: RscEdit_infiSTAR {
    idc = 1339;
    x = 0.1 * safezoneW + safezoneX;
    y = 0.038 * safezoneH + safezoneY;
    w = 0.658333 * safezoneW;
    h = (0.143 * safezoneH) * 3;
    font = "EtelkaMonospacePro";
    colorText[] = {
        0.95,
        0.95,
        0.95,
        1
    };
    style = 16;
    sizeEx = "0.65 * ((((safezoneW / safezoneH) min 1.2) / 1.2) / 25)";
    show = 1;
};
class RscEdit_infiSTAR_ss: RscEdit_infiSTAR {
    x = 0;
    y = (safeZoneY + 0.01) + 1;
    w = 1;
    h = 0.05;
    idc = 1380;
    font = "EtelkaMonospacePro";
    colorText[] = {
        0.95,
        0.95,
        0.95,
        1
    };
    sizeEx = "0.65 * ((((safezoneW / safezoneH) min 1.2) / 1.2) / 25)";
    show = 1;
    autocomplete = "scripting";
};
class infiSTAR_EDITBOX {
    idd = -1341;
    movingenable = true;
    class controls {
        class RscEditMultiSTAR: RscEdit_infiSTAR_multi {
            idc = 1336;
            x = 0.25;
            y = 0.25;
            w = 0.5;
            h = 0.5;
        };
    };
};
class infiSTAR_EDITBOX2 {
    idd = -1341;
    movingenable = true;
    class controls {
        class RscEditMultiSTAR: RscEdit_infiSTAR_multi {
            autocomplete = "scripting";
        };
        class RscEditSingle1STAR: RscEdit_infiSTAR_ss {
            idc = 1380;
        };
        class RscEditSingle2STAR: RscEdit_infiSTAR_ss {
            idc = 1381;
        };
        class RscEditSingle3STAR: RscEdit_infiSTAR_ss {
            idc = 1382;
        };
        class RscEditSingle4STAR: RscEdit_infiSTAR_ss {
            idc = 1383;
        };
        class infi_LIST1384: RscListBox_infiSTAR {
            idc = 1384;
            x = -0.25;
            y = 0.2;
            w = 0.25;
            h = 0.9;
            sizeEx = 0.027;
        };
    };
};
class infiSTAR_AdminMenu {
    idd = 6971;
    movingenable = false;
    onLoad = "((_this select 0) displayCtrl 1502) ctrlShow false; ((_this select 0) displayCtrl 1501) ctrlShow true;";
    class controlsBackground {
        class thingy1: RscText_infiSTAR {
			idc = 2401;
			text = "sdr is cute";
			x = safezoneX;
			y = safezoneY;
			w = safezoneW;
			h = 0.0341667 * safezoneH;
			colorText[] = {
				1,
				1,
				1,
				0.9
			};
			colorBackground[] = {
				0.56,
				0.04,
				0.04,
				1
			};
		};
        class Background1: RscListBox_infiSTAR {
			idc = -1;
			x = safezoneX;
			y = 0.0617197 * safezoneH + safezoneY;
			w = 0.189063 * safezoneW;
			h = 0.938333 * safezoneH;
            colorBackground[] = {
                0,
                0,
                0,
                0.4
            };
		};
		class Background2: RscListBox_infiSTAR {
			idc = -1;
			x = 0.188975 * safezoneW + safezoneX;
			y = 0.0617197 * safezoneH + safezoneY;
			w = 0.344271 * safezoneW;
			h = 0.945999 * safezoneH;
            colorBackground[] = {
                0,
                0,
                0,
                0.4
            };
		};
    };
    class controls {
        class ExecuteBtn: RscButton_infiSTAR {
			idc = 1805;
			text = "Execute";
			x = 0.57 * safezoneW + safezoneX;
		    y = 0.81 * safezoneH + safezoneY;
			w = 0.1 * safezoneW;
			h = 0.0329999 * safezoneH;
		};
        class MsgEveryBtn: RscButton_infiSTAR {
			idc = 1804;
			text = "Message Everyone";
			x = (0.57 * safezoneW + safezoneX) + (1 * 0.15 * safezoneW);
		    y = 0.81 * safezoneH + safezoneY;
			w = 0.1 * safezoneW;
			h = 0.0329999 * safezoneH;
		};
        class MsgTargetBtn: RscButton_infiSTAR {
			idc = 1801;
			text = "Message Target";
			x = (0.57 * safezoneW + safezoneX) + (2 * 0.15 * safezoneW);
		    y = 0.81 * safezoneH + safezoneY;
			w = 0.1 * safezoneW;
			h = 0.0329999 * safezoneH;
		};
        class MainEdit: SG_ctrlEditMultiCode {
			idc = 1402;
			x = 0.534 * safezoneW + safezoneX;
			y = 0.85 * safezoneH + safezoneY;
			w = 0.4655 * safezoneW;
			h = 0.15 * safezoneH;
            colorBackground[] = {
                0,
                0,
                0,
                0.8
            };
		};
        class PlayerSearch: RscEdit_infiSTAR {
			idc = 1400;
			text = "";
			x = safezoneX;
			y = 0.0617197 * safezoneH + safezoneY;
			w = 0.189063 * safezoneW;
			h = 0.044 * safezoneH;
		};
        class PlayerList: RscListBox_infiSTAR {
			idc = 1500;
			x = safezoneX;
			y = (0.0617197 * safezoneH + safezoneY) + 0.06 * safezoneH;
			w = 0.189063 * safezoneW;
			h = (0.938333 * safezoneH) - (0.06 * safezoneH);
            colorBackground[] = {
                0,
                0,
                0,
                0.6
            };
		};
		class SpawnList: RscListBox_infiSTAR {
			idc = 1502;
			x = 0.188975 * safezoneW + safezoneX;
			y = 0.185 * safezoneH + safezoneY;
			w = 0.344271 * safezoneW;
			h = 0.815 * safezoneH;
            colorBackground[] = {
                0,
                0,
                0,
                0.6
            };
		};
		class SpawnSearch: RscEdit_infiSTAR {
			idc = 1401;
			text = "";
			x = 0.1964 * safezoneW + safezoneX;
			y = 0.125933 * safezoneH + safezoneY;
			w = 0.326563 * safezoneW;
			h = 0.044 * safezoneH;
		};
        class MainList: RscListBox_infiSTAR {
			idc = 1501;
			x = 0.188975 * safezoneW + safezoneX;
			y = 0.185 * safezoneH + safezoneY;
			w = 0.344271 * safezoneW;
			h = 0.815 * safezoneH;
            colorBackground[] = {
                0,
                0,
                0,
                0.6
            };
		};
		class MainMenuBtn: RscButton_infiSTAR {
			idc = 1817;
			text = "Main Menu";
			x = 0.005 + safezoneX;
			y = 0.0379694 * safezoneH + safezoneY;
			w = 0.06 * safezoneW;
			h = 0.02 * safezoneH;
			onButtonDown = "((ctrlParent (_this select 0)) displayCtrl 1502) ctrlShow false; ((ctrlParent (_this select 0)) displayCtrl 1501) ctrlShow true;";
		};
		class PlayerListBtn: RscButton_infiSTAR {
			idc = 1816;
			text = "Player List";
			x = 0.01 + safezoneX + (0.06 * safezoneW);
			y = 0.0379694 * safezoneH + safezoneY;
			w = 0.06 * safezoneW;
			h = 0.02 * safezoneH;
		};
		class SpawnMenuBtn: RscButton_infiSTAR {
			idc = -1;
			text = "Spawn Menu";
			x = 0.015 + safezoneX + (0.06 * safezoneW) * 2;
			y = 0.0379694 * safezoneH + safezoneY;
			w = 0.06 * safezoneW;
			h = 0.02 * safezoneH;
			onButtonDown = "((ctrlParent (_this select 0)) displayCtrl 1501) ctrlShow false; ((ctrlParent (_this select 0)) displayCtrl 1502) ctrlShow true;";
		};
		class AdminLogBtn: RscButton_infiSTAR {
			idc = 1815;
			default = "true";
			text = "Admin Logs";
			x = 0.202072 * safezoneW + safezoneX;
			y = 0.0379694 * safezoneH + safezoneY;
			w = 0.0625001 * safezoneW;
			h = 0.02 * safezoneH;
		};
		class HackerLogsBtn: RscButton_infiSTAR {
			idc = 1814;
			text = "Hacker Logs";
			x = 0.287975 * safezoneW + safezoneX;
			y = 0.0379694 * safezoneH + safezoneY;
			w = 0.0625001 * safezoneW;
			h = 0.02 * safezoneH;
		};
		class DeathLogsBtn: RscButton_infiSTAR {
			idc = 1808;
			text = "Death Logs";
			x = 0.373981 * safezoneW + safezoneX;
			y = 0.0379694 * safezoneH + safezoneY;
			w = 0.0625001 * safezoneW;
			h = 0.02 * safezoneH;
		};
		class LoadoutsBtn: RscButton_infiSTAR {
			idc = 1809;
			text = "Loadouts";
			x = 0.459884 * safezoneW + safezoneX;
			y = 0.0379694 * safezoneH + safezoneY;
			w = 0.0625001 * safezoneW;
			h = 0.02 * safezoneH;
		};
		class WeaponsBtn: RscButton_infiSTAR {
			idc = 1813;
			text = "Weapons";
			x = 0.1964 * safezoneW + safezoneX;
			y = 0.0819514 * safezoneH + safezoneY;
			w = 0.07 * safezoneW;
			h = 0.0329999 * safezoneH;
		};
		class VehiclesBtn: RscButton_infiSTAR {
			idc = 1812;
			text = "Vehicles";
			x = 0.1964 * safezoneW + safezoneX + (1 * 0.085 * safezoneW);
			y = 0.0819514 * safezoneH + safezoneY;
			w = 0.07 * safezoneW;
			h = 0.0329999 * safezoneH;
		};
		class VItemsBtn: RscButton_infiSTAR {
			idc = 1811;
			text = "V-Items";
			x = 0.1964 * safezoneW + safezoneX + (2 * 0.085 * safezoneW);
			y = 0.0819514 * safezoneH + safezoneY;
			w = 0.07 * safezoneW;
			h = 0.0329999 * safezoneH;
		};
        class BackpacksBtn: RscButton_infiSTAR {
			idc = 1810;
			text = "Backpacks";
			x = 0.1964 * safezoneW + safezoneX + (3 * 0.085 * safezoneW);
			y = 0.0819514 * safezoneH + safezoneY;
			w = 0.07 * safezoneW;
			h = 0.0329999 * safezoneH;
		};

        class ViewerBtn: RscButton_infiSTAR
		{
			idc = 1807;
			x = 0;
			y = 0;
			w = 0;
			h = 0;
		};
    };
};