#define HUD_STATS_W 67
#define HUD_STATS_H 30
#define HUD_STATS_GAP_W (2 * GRID_W)
#define HUD_STATS_GAP_H (2 * GRID_H)
#define HUD_BACKGROUND {0.1, 0.1, 0.1, 0.9}
#define HUD_DIRECTIONBAR_W 100

#define HUD_STARTPOS_X (safezoneW + safezoneX) - (HUD_STATS_W * GRID_W) - GAP_W
#define HUD_STARTPOS_Y ((safezoneY + safezoneH) - GAP_H)
class SG_HUD {
	idd          = 346342;
	duration     = 10e10;
	scriptName   = "SG_HUD";
	onLoad       = "[_this, 'OnLoad'] call SG_HudLoad";
	onUnload     = "[_this, 'OnUnload'] call SG_HudLoad";

	class controlsBackground {};
	class controls {
		class DirectionGroup: SG_ctrlControlsGroupNoScrollbars {
			idc = 4;
			x   = CENTER_X - (HUD_DIRECTIONBAR_W * 0.5) * GRID_W;
			y   = safezoneY + (SIZE_M * GRID_H);
			w   = HUD_DIRECTIONBAR_W * GRID_W;
			h   = SIZE_M * GRID_H;
			class Controls {
				class CardinalPointLeft: SG_ctrlStatic {
					idc               = 1;
					x                 = 0;
					y                 = 0;
					w                 = SIZE_M * GRID_W;
					h                 = SIZE_M * GRID_H;
					style             = ST_CENTER;
					colorBackground[] = HUD_BACKGROUND;
				};
				class CardinalPointRight: CardinalPointLeft {
					idc = 3;
					x   = (HUD_DIRECTIONBAR_W * GRID_W) - (SIZE_M * GRID_W);
				};
				class DirectionBar: CardinalPointLeft {
					idc               = 2;
					x                 = SIZE_M * GRID_W;
					y                 = 0;
					w                 = (HUD_DIRECTIONBAR_W * GRID_W) - ((SIZE_M * GRID_W) * 2);
					colorBackground[] = {0.1, 0.1, 0.1, 0.5};
					font              = "RobotoCondensedBold";
				};
			};
		};
		class StatusIcons: SG_ctrlControlsGroupNoScrollbars {
			idc = 5;
			x   = HUD_STARTPOS_X;
			y   = (HUD_STARTPOS_Y - (HUD_STATS_H * GRID_H)) - (HUD_STATS_GAP_H / 2) - (SIZE_XL * GRID_H) - (SIZE_XL * GRID_H) - (SIZE_XL * GRID_H) - (HUD_STATS_GAP_H / 2) - (HUD_STATS_GAP_H / 2);
			w   = HUD_STATS_W * GRID_W;
			h   = SIZE_XL * GRID_H;
			class controls {
				class IconEarplugs: SG_ctrlButtonToolbar {
					idc    = 6;
					x      = 0;
					y      = 0;
					w      = SIZE_XL * GRID_W;
					h      = SIZE_XL * GRID_H;
					onLoad = "(_this select 0) ctrlSetText '\SG_HUD\images\displays\Hud\earplugs.paa'";
					colorBackground[] = HUD_BACKGROUND;
				};
				class IconHandcuffs: SG_ctrlButtonToolbar {
					idc    = 7;
					x      = (SIZE_XL * GRID_W) + GRID_W;
					y      = 0;
					w      = SIZE_XL * GRID_W;
					h      = SIZE_XL * GRID_H;
					onLoad = "(_this select 0) ctrlSetText '\SG_HUD\images\displays\Hud\handcuffs.paa'";
					colorBackground[] = HUD_BACKGROUND;
				};
			};
		};

		class XPBar: SG_ctrlControlsGroupNoScrollbars {
			idc = 21;
			x   = HUD_STARTPOS_X;
			y   = (HUD_STARTPOS_Y - (HUD_STATS_H * GRID_H)) - (HUD_STATS_GAP_H / 2) - (SIZE_XL * GRID_H) - (HUD_STATS_GAP_H / 2) - (SIZE_XL * GRID_H);
			w   = HUD_STATS_W * GRID_W;
			h   = SIZE_XL * GRID_H;
			class controls {
				// class Background: SG_ctrlStatic {
				// 	idc               = -1;
				// 	x                 = 0;
				// 	y                 = 0;
				// 	w                 = HUD_STATS_W * GRID_W;
				// 	h                 = SIZE_XL * GRID_H;
				// 	colorBackground[] = HUD_BACKGROUND;
				// };

				class LeftLevel: SG_ctrlStatic {
					idc               = 22;
					font              = "RobotoCondensedBold";
					text              = "150";
					x                 = 0;
					y                 = 0;
					w                 = SIZE_XL * GRID_W;
					h                 = SIZE_XL * GRID_H;
					style             = ST_CENTER;
					colorBackground[] = HUD_BACKGROUND;
				};
				class RightLevel: LeftLevel {
					idc               = 23;
					x                 = (HUD_STATS_W * GRID_W) - (SIZE_XL * GRID_W);
				};

				class EXPBarBack: SG_ctrlStatic {
					idc               = -1;
					x                 = SIZE_XL * GRID_W;
					y                 = 0;
					w                 = (HUD_STATS_W * GRID_W) - (SIZE_XL * GRID_W) - (SIZE_XL * GRID_W);
					h                 = SIZE_XL * GRID_H;
					colorBackground[] = {0.2, 0.2, 0.2, 1};
				};
				class EXPBarStrips: SG_ctrlStaticBackgroundDisableTiles {
					idc               = -1;
					x                 = SIZE_XL * GRID_W;
					y                 = 0;
					w                 = (HUD_STATS_W * GRID_W) - (SIZE_XL * GRID_W) - (SIZE_XL * GRID_W);
					h                 = SIZE_XL * GRID_H;
				};
				class EXPBar: SG_ctrlProgress {
					idc               = 24;
					x                 = SIZE_XL * GRID_W;
					y                 = 0;
					w                 = (HUD_STATS_W * GRID_W) - (SIZE_XL * GRID_W) - (SIZE_XL * GRID_W);
					h                 = SIZE_XL * GRID_H;
					colorBar[]        = {0.3, 0.3, 0.3, 1};
					colorFrame[]      = {0, 0, 0, 0};
				};
			};
		};

		class MoneyThreat: SG_ctrlControlsGroupNoScrollbars {
			idc = 19;
			x   = HUD_STARTPOS_X;
			y   = (HUD_STARTPOS_Y - (HUD_STATS_H * GRID_H)) - (HUD_STATS_GAP_H / 2) - (SIZE_XL * GRID_H);
			w   = HUD_STATS_W * GRID_W;
			h   = SIZE_XL * GRID_H;
			class controls {
				class Background: SG_ctrlStatic {
					idc               = -1;
					x                 = 0;
					y                 = 0;
					w                 = HUD_STATS_W * GRID_W;
					h                 = SIZE_XL * GRID_H;
					colorBackground[] = HUD_BACKGROUND;
				};
				class Money: SG_ctrlStatic {
					idc               = 10;
					font              = "RobotoCondensedBold";
					x                 = 0;
					y                 = 0;
					w                 = (HUD_STATS_W * GRID_W) / 2;
					h                 = SIZE_XL * GRID_H;
				};
				class Threat: Money {
					idc               = 20;
					x                 = ((HUD_STATS_W * GRID_W) / 2);
					style             = ST_RIGHT;
				};
			};
		};


		class StatsGroup: SG_ctrlControlsGroupNoScrollbars {
			idc = 12;
			x   = HUD_STARTPOS_X;
			y   = HUD_STARTPOS_Y - (HUD_STATS_H * GRID_H);
			w   = HUD_STATS_W * GRID_W;
			h   = HUD_STATS_H * GRID_H;
			class controls {
				class Background: SG_ctrlStatic {
					idc               = -1;
					x                 = 0;
					y                 = 0;
					w                 = HUD_STATS_W * GRID_W;
					h                 = HUD_STATS_H * GRID_H;
					colorBackground[] = HUD_BACKGROUND;
				};
				class HungerIcon: SG_ctrlStaticPictureKeepAspect {
					idc               = 13;
					text              = "SG_HUD\images\displays\Hud\hunger.paa";
					x                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 2) - (SIZE_M * GRID_W);
					y                 = HUD_STATS_GAP_H;
					w                 = SIZE_M * GRID_W;
					h                 = SIZE_M * GRID_H;
				};
				class HungerProgressBackground: SG_ctrlStatic {
					idc               = -1;
					x                 = HUD_STATS_GAP_W;
					y                 = HUD_STATS_GAP_H + (((SIZE_M * GRID_H) / 2.5) / 2) + (0.38 * GRID_H);
					w                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 4) - (SIZE_M * GRID_W);
					h                 = ((SIZE_M * GRID_H) / 2.5);
					colorBackground[] = {0.2, 0.2, 0.2, 1};
				};
				class HungerProgressStripes: SG_ctrlStaticBackgroundDisableTiles {
					idc               = -1;
					x                 = HUD_STATS_GAP_W;
					y                 = HUD_STATS_GAP_H + (((SIZE_M * GRID_H) / 2.5) / 2) + (0.38 * GRID_H);
					w                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 4) - (SIZE_M * GRID_W);
					h                 = ((SIZE_M * GRID_H) / 2.5);
				};
				class HungerProgress: SG_ctrlProgress {
					idc               = 14;
					x                 = HUD_STATS_GAP_W;
					y                 = HUD_STATS_GAP_H + (((SIZE_M * GRID_H) / 2.5) / 2) + (0.38 * GRID_H);
					w                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 4) - (SIZE_M * GRID_W);
					h                 = ((SIZE_M * GRID_H) / 2.5);
					colorBar[]        = {0.3, 0.3, 0.3, 1};
					colorFrame[]      = {0, 0, 0, 0};
				};
				class ThirstIcon: SG_ctrlStaticPictureKeepAspect {
					idc               = 15;
					text              = "SG_HUD\images\displays\Hud\thirst.paa";
					x                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 2) - (SIZE_M * GRID_W);
					y                 = (HUD_STATS_GAP_H * 2) + ((SIZE_M * GRID_H) * 1);
					w                 = SIZE_M * GRID_W;
					h                 = SIZE_M * GRID_H;
				};
				class ThirstProgressBackground: SG_ctrlStatic {
					idc               = -1;
					x                 = HUD_STATS_GAP_W;
					y                 = (((HUD_STATS_GAP_H + (((SIZE_M * GRID_H) / 2.5) / 2)) + ((SIZE_M * GRID_H) / 2.5)) * 2) + (0.38 * GRID_H);
					w                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 4) - (SIZE_M * GRID_W);
					h                 = ((SIZE_M * GRID_H) / 2.5);
					colorBackground[] = {0.2, 0.2, 0.2, 1};
				};
				class ThirstProgressStripes: SG_ctrlStaticBackgroundDisableTiles {
					idc               = -1;
					x                 = HUD_STATS_GAP_W;
					y                 = (((HUD_STATS_GAP_H + (((SIZE_M * GRID_H) / 2.5) / 2)) + ((SIZE_M * GRID_H) / 2.5)) * 2) + (0.38 * GRID_H);
					w                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 4) - (SIZE_M * GRID_W);
					h                 = ((SIZE_M * GRID_H) / 2.5);
				};
				class ThirstProgress: SG_ctrlProgress {
					idc               = 16;
					x                 = HUD_STATS_GAP_W;
					y                 = (((HUD_STATS_GAP_H + (((SIZE_M * GRID_H) / 2.5) / 2)) + ((SIZE_M * GRID_H) / 2.5)) * 2) + (0.38 * GRID_H);
					w                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 4) - (SIZE_M * GRID_W);
					h                 = ((SIZE_M * GRID_H) / 2.5);
					colorBar[]        = {0.3, 0.3, 0.3, 1};
					colorFrame[]      = {0, 0, 0, 0};
				};
				class HealthIcon: SG_ctrlStaticPictureKeepAspect {
					idc               = 17;
					text              = "SG_HUD\images\displays\Hud\health.paa";
					x                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 2) - (SIZE_M * GRID_W);
					y                 = (HUD_STATS_GAP_H * 3) + ((SIZE_M * GRID_H) * 2);
					w                 = SIZE_M * GRID_W;
					h                 = SIZE_M * GRID_H;
				};
				class HealthProgressBackground: SG_ctrlStatic {
					idc               = -1;
					x                 = HUD_STATS_GAP_W;
					y                 = ((HUD_STATS_GAP_H + (((SIZE_M * GRID_H) / 2.5) / 2)) + ((SIZE_M * GRID_H) / 2.5)) * 3 + ((SIZE_M * GRID_H) / 2.5) + (0.38 * GRID_H);
					w                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 4) - (SIZE_M * GRID_W);
					h                 = ((SIZE_M * GRID_H) / 2.5);
					colorBackground[] = {0.2, 0.2, 0.2, 1};
				};
				class HealthProgressStripes: SG_ctrlStaticBackgroundDisableTiles {
					idc               = -1;
					x                 = HUD_STATS_GAP_W;
					y                 = ((HUD_STATS_GAP_H + (((SIZE_M * GRID_H) / 2.5) / 2)) + ((SIZE_M * GRID_H) / 2.5)) * 3 + ((SIZE_M * GRID_H) / 2.5) + (0.38 * GRID_H);
					w                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 4) - (SIZE_M * GRID_W);
					h                 = ((SIZE_M * GRID_H) / 2.5);
				};
				class HealthProgress: SG_ctrlProgress {
					idc               = 18;
					x                 = HUD_STATS_GAP_W;
					y                 = ((HUD_STATS_GAP_H + (((SIZE_M * GRID_H) / 2.5) / 2)) + ((SIZE_M * GRID_H) / 2.5)) * 3 + ((SIZE_M * GRID_H) / 2.5) + (0.38 * GRID_H);
					w                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 4) - (SIZE_M * GRID_W);
					h                 = ((SIZE_M * GRID_H) / 2.5);
					colorBar[]        = {0.3, 0.3, 0.3, 1};
					colorFrame[]      = {0, 0, 0, 0};
				};
				class WeightIcon: SG_ctrlStaticPictureKeepAspect {
					idc               = 25;
					text              = "a3\ui_f\data\igui\cfg\simpletasks\types\backpack_ca.paa";
					x                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 2) - (SIZE_M * GRID_W);
					y                 = (HUD_STATS_GAP_H * 4) + ((SIZE_M * GRID_H) * 3);
					w                 = SIZE_M * GRID_W;
					h                 = SIZE_M * GRID_H;
				};
				class WeightProgressBackground: SG_ctrlStatic {
					idc               = -1;
					x                 = HUD_STATS_GAP_W;
					y                 = ((HUD_STATS_GAP_H + (((SIZE_M * GRID_H) / 2.5) / 2)) + ((SIZE_M * GRID_H) / 2.5)) * 4 + ((SIZE_M * GRID_H) / 2.5) + ((SIZE_M * GRID_H) / 2.5) + (0.38 * GRID_H);
					w                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 4) - (SIZE_M * GRID_W);
					h                 = ((SIZE_M * GRID_H) / 2.5);
					colorBackground[] = {0.2, 0.2, 0.2, 1};
				};
				class WeightProgressStripes: SG_ctrlStaticBackgroundDisableTiles {
					idc               = -1;
					x                 = HUD_STATS_GAP_W;
					y                 = ((HUD_STATS_GAP_H + (((SIZE_M * GRID_H) / 2.5) / 2)) + ((SIZE_M * GRID_H) / 2.5)) * 4 + ((SIZE_M * GRID_H) / 2.5) + ((SIZE_M * GRID_H) / 2.5) + (0.38 * GRID_H);
					w                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 4) - (SIZE_M * GRID_W);
					h                 = ((SIZE_M * GRID_H) / 2.5);
				};
				class WeightProgress: SG_ctrlProgress {
					idc               = 26;
					x                 = HUD_STATS_GAP_W;
					y                 = ((HUD_STATS_GAP_H + (((SIZE_M * GRID_H) / 2.5) / 2)) + ((SIZE_M * GRID_H) / 2.5)) * 4 + ((SIZE_M * GRID_H) / 2.5) + ((SIZE_M * GRID_H) / 2.5) + (0.38 * GRID_H);
					w                 = (HUD_STATS_W * GRID_W) - (HUD_STATS_GAP_W * 4) - (SIZE_M * GRID_W);
					h                 = ((SIZE_M * GRID_H) / 2.5);
					colorBar[]        = {0.3, 0.3, 0.3, 1};
					colorFrame[]      = {0, 0, 0, 0};
				};
			};
		};
	};
};