#define MG_W 125
#define MG_H 35
#define MG_HEADER_H 7.5
#define MG_GAP_W (2 * GRID_W)

#define MG_BAR_W MG_W * 0.8
#define MG_BAR_H MG_H * 0.20

#define MG_BACKGROUND {0.1, 0.1, 0.1, 0.9}

#define MG_COLOR {"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.77])", "(profilenamespace getvariable ['GUI_BCG_RGB_G',0.51])", "(profilenamespace getvariable ['GUI_BCG_RGB_B',0.08])", 1 }

#define MG_STARTPOS_X CENTER_X - (MG_W * 0.5) * GRID_W
#define MG_STARTPOS_Y CENTER_Y - (MG_H * 0.5) * GRID_H

class SG_MiniGame {
	idd          = 0;
	scriptName   = "SG_MiniGameDisplay";
	onLoad 		 = "[ 'onLoad', _this ] call SG_MiniGameDisplay;";
	onUnload  	 = "[ 'onUnload', _this ] call SG_MiniGameDisplay;";

	class controlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = 1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
	};
	class controls {

		class HeaderBar: SG_ctrlControlsGroupNoScrollbars {
			idc = 2;
			x   = MG_STARTPOS_X;
			y   = MG_STARTPOS_Y - (MG_HEADER_H * GRID_H);
			w   = MG_W * GRID_W;
			h   = MG_HEADER_H * GRID_H;
			class Controls {
				class Background : SG_ctrlStaticFooter {
					x = 0;
					y = 0;
					w   = MG_W * GRID_W;
					h   = MG_HEADER_H * GRID_H;
					colorBackground[] = MG_COLOR;
				};

				class Header : SG_RscText {
					idc  = 3;
					text = "MINIGAME";
					w    = MG_W * GRID_W;
					h    = MG_HEADER_H * GRID_H;
					colorBackground[] = {0,0,0,0};
					colorText[] = { 1, 1, 1, 1 };
					shadow = 0;
					size = 2;
					style = ST_CENTER;
				};
			};
		};

		class ButtonGroup: SG_ctrlControlsGroupNoScrollbars {
			idc = 4;
			x   = MG_STARTPOS_X;
			y   = MG_STARTPOS_Y;
			w   = MG_W * GRID_W;
			h   = MG_H * GRID_H;
			class Controls {
				class Background : SG_ctrlStaticFooter {
					w = MG_W * GRID_W;
					h = MG_H * GRID_H;
					colorBackground[] = { 0.1, 0.1, 0.1, 1 };
				};

				class MainBar : SG_RscText {
					idc = 5;
					x = ((MG_W * 0.5) * GRID_W) - ((MG_BAR_W * 0.5)  * GRID_W);
					y = ((MG_H * 0.5) * GRID_H) - ((MG_BAR_H * 0.5) * GRID_H);
					w   = MG_BAR_W * GRID_W;
					h   = MG_BAR_H * GRID_H;
					text = "";
					colorBackground[] = {0.8,0,0,1};
				};

				class MoveBar : SG_RscText {
					idc = 6;
					x = ((MG_W * 0.5) * GRID_W) - ((MG_BAR_W * 0.5)  * GRID_W);
					y = ((MG_H * 0.5) * GRID_H) - ((MG_BAR_H * 0.5) * GRID_H);
					w   = (MG_BAR_W * 0.15) * GRID_W;
					h   = MG_BAR_H * GRID_H;
					text = "";
					colorBackground[] = {0,0.8,0,1};
				};

				class PlayerBar : SG_RscText {
					idc = 7;
					x = ((MG_W * 0.5) * GRID_W) - ((MG_BAR_W * 0.5)  * GRID_W);
					y = ((MG_H * 0.5) * GRID_H) - ((MG_BAR_H * 0.5) * GRID_H);
					w   = (MG_BAR_W * 0.01) * GRID_W;
					h   = MG_BAR_H * GRID_H;
					text = "";
					colorBackground[] = {0.8,0.8,0.8,1};
				};
				
			};
		};
	};
};