class SG_CreateGang {
	idd = 2805;
	scriptName = "SG_CreateGang";
	onLoad = [ 'onLoad', _this ] call SG_CreateGang;
	class controlsBackground {
		class BackgroundDisable : SG_ctrlStaticBackgroundDisable {
			idc = 0x1;
			colorBackground[] = { 0.15, 0.15, 0.15, 0.6 };
		};
	};

	class Controls {
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT START (by Kaiden Smith, v1.063, #Sapoxu)
		////////////////////////////////////////////////////////
		class Background : SG_ctrlStaticBackground {
			idc = 3;

			x = 0.416675 * safezoneW + safezoneX;
			y = 0.37042 * safezoneH + safezoneY;
			w = 0.166666 * safezoneW;
			h = 0.111111 * safezoneH;
		};
		class Title : SG_ctrlStaticTitle {
			idc = 1002;
			text = "Create Gang"; //--- ToDo: Localize;
			x = 0.416675 * safezoneW + safezoneX;
			y = 0.35194 * safezoneH + safezoneY;
			w = 0.166666 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
		class CreateGang : SG_ctrlDefaultButton {
			idc = 5;
			colorBackgroundActive[] = { 1, 1, 1, 0.5 };
			colorFocused[] = { 1, 1, 1, 0.5 };

			text = "Create"; //--- ToDo: Localize;
			x = 0.447922 * safezoneW + safezoneX;
			y = 0.41662 * safezoneH + safezoneY;
			w = 0.0490196 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
		class Cancel : CreateGang {
			idc = 6;

			text = "Cancel"; //--- ToDo: Localize;
			x = 0.5 * safezoneW + safezoneX;
			y = 0.41662 * safezoneH + safezoneY;
			w = 0.0490196 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
		class NameBox : SG_ctrlEditNoRect {
			idc = 7;
			colorBackgroundActive[] = { 1, 1, 1, 0.5 };
			colorFocused[] = { 1, 1, 1, 0.5 };

			text = "Gang Name"; //--- ToDo: Localize;
			x = 0.458337 * safezoneW + safezoneX;
			y = 0.38494 * safezoneH + safezoneY;
			w = 0.0796568 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT END
		////////////////////////////////////////////////////////
	};
};