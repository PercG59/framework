class Life_Client_Core {
	tag = "SG";

	class Master_Directory {
		file = "core";
		class initCiv {};
		class initCop {};
		class initMedic {};
		class initOpf {};
		class survival {};
	};

	class SQL_Socket {
		file = "core\session";
		class dataQuery {};
		class insertPlayerInfo {};
		class requestReceived {};
		class syncData {};
		class updatePartial {};
		class updateRequest {};
	};

	class Actions {
		file = "core\actions";
		class arrestAction {};
		class buyLicense {};
		class dropFishingNet {};
		class escortAction {};
		class gather {};
		class healHospital {};
		class impoundAction {};
		class mine {};
		class packupSpikes {};
		class pickupItem {};
		class postBail {};
		class processAction {};
		class pulloutAction {};
		class putInCar {};
		class removeContainer {};
		class repairVehicle {};
		class restrainAction {};
		class robAction {};
		class searchAction {};
		class searchVehAction {};
		class stopEscorting {};
		class storeVehicle {};
		class surrender {};
		class ticketAction {};
		class unrestrain {};
		class gpsTracker {};
		class robShops {};
		class refillMags {};
		class unflip {};
		class breakDownHouse {};
		class houseCrateInit {};
		class lockpickChest {};
		class launderMoney {};
		class barrier {};
	};

	class Civilian {
		file = "core\civilian";
		class animations {};
		class civLoadout {};
		class jail {};
		class jailMe {};
		class knockedOut {};
		class knockoutAction {};
		class ragdoll {};
		class robPerson {};
		class robReceive {};
		class tazed {};
		class tazedHit {};
		class tieingAction {};
		class blindfold {};
		class blindfoldAction {};
		class removeBlindfold {};
		class untie {};
	};

	class Config {
		file = "core\config";
		class houseConfig {};
		class itemWeight {};
		class vehicleAnimate {};
		class vehicleWeightCfg {};
	};

	class Cop {
		file = "core\cop";
		class arrestDialog_Arrest {};
		class backupCall {};
		class callBackup {};
		class containerInvSearch {};
		class crashTackled {};
		class copLoadout {};
		class copSearch {};
		class licenseCheck {};
		class licensesRead {};
		class removeWeaponAction {};
		class restrain {};
		class searchClient {};
		class seizeClient {};
		class spikeStripEffect {};
		class tackleAction {};
		class ticketGive {};
		class ticketPrompt {};
		class vehInvSearch {};
		class openThreatMenu {};
		class changeThreat {};
		class openArrestMenu {};
		class flashbang {};
		// class switchTaser {};
	};

	class Opfor {
		file = "core\opfor";
		class opfLoadout {};
	};

	class Dialog_Controls {
		file = "dialog\function";
		class bankDeposit {};
		class bankDepositAll {};
		class bankTransfer {};
		class bankWithdraw {};
		class displayHandler {};
		class garageLBChange {};
		class guiPrompt {};
		class impoundMenu {};
		class sellGarage {};
		class spawnCamera {};
		class spawnConfirm {};
		class spawnMenu {};
		class unimpound {};
		class wireTransfer {};
	};

	class Functions {
		file = "core\functions";
		class AANBank {};
		class accType {};
		class actionKeyHandler {};
		class animSync {};
		class calWeightDiff {};
		class dropItems {};
		class fetchCfgDetails {};
		class fetchVehInfo {};
		class handleInv {};
		class handleItem {};
		class hudSetup {};
		class inventoryClosed {};
		class inventoryOpened {};
		class isUIDActive {};
		class keyHandler {};
		class keyBinds {};
		class loadDeadGear {};
		class loadGear {};
		class nearATM {};
		class nearestDoor {};
		class nearUnits {};
		class numberText {};
		class vehicleTags {};
		class isNumber {};
		class pullOutVeh {};
		class revealObjects {};
		class saveGear {};
		class searchPosEmpty {};
		class simDisable {};
		class stripDownPlayer {};
		class whereAmI {};
		class getIndex {};
		class markerMenu {};
		class markerMenuMap {};
		class pickupItems {};
		class pickupItemsUpdate {};
		class radArea {};
		class randomRound {};
		class removeItems {};
		class setEngineHit {};
		class rpr {};
		class pushVehicle {};
		class clearVehicleAmmo {};
		class nearestInteraction {};
		class setupStationService {};
	};

	class DMV {
		file = "core\dmv";
		class licenseTestStart {};
		class questionResults {};
	};

	class Quests {
		file = "core\quests";
		class relic1 {};
		class relic2 {};
		class relic3 {};
		class relic4 {};
		class mapQuest {};
		class relicReward {};
		class relicRewardMajor {};
		class relicRewardMap {};
		class antiMatterSample {};
		class antiMatterReward {};
		class gatherResearch {};
	};

	class Gangs {
		file = "core\gangs";
		class gangDisbanded {};
		class gangInvite {};
		class gangInvitePlayer {};
		class gangKick {};
		class gangLeave {};
		class initGang {};
		class gangOpen {};
		class gangGetRank {};
	};

	class Housing {
		file = "core\housing";
		class buyHouse {};
		class copBreakDoor {};
		class copHouseOwner {};
		class garageRefund {};
		class getBuildingPositions {};
		class initHouses {};
		class lightHouse {};
		class lockHouse {};
		class lockupHouse {};
		class placeContainer {};
		class PlayerInBuilding {};
		class raidHouse {};
		class sellHouse {};
	};

	class Items {
		file = "core\items";
		class bandage {};
		class redgull {};
		class cprKit {};
		class speedBomb {};
		class morphine {};
		class jerrycanRefuel {};
		class jerryRefuel {};
		class lockpick {};
		class placestorage {};
		class spikeStrip {};
		class storageBox {};
		class engineDisable {};
	};

	class Medical_System {
		file = "core\medical";
		class blackOutIn {};
		class killfeed {};
		class medicLoadout {};
		class medicRequest {};
		class medicMarkers {};
		class requestMedic {};
		class respawned {};
		class revivePlayer {};
	};

	class Network {
		file = "core\functions\network";
		class setFuel {};
		class broadcast {};
	};

	class Shops {
		file = "core\shops";
		class 3dPreviewDisplay {};
		class 3dPreviewExit {};
		class 3dPreviewInit {};
		class atmMenu {};
		class buyClothes {};
		class clothingFilter {};
		class clothingMenu {};
		class fuelLBchange {};
		class fuelStatOpen {};
		class levelCheck {};
		class vehicleShopBuy {};
		class vehicleShopMenu {};
		class virt_buy {};
		class virt_menu {};
		class virt_sell {};
		class virt_update {};
		class weaponShopFill {};
		class weaponShopMenu {};
		class weaponShopCompatible {};
		class weaponShopIndex {};
	};

	class Vehicle {
		file = "core\vehicle";
		class addVehicle2Chain {};
		class FuelRefuelcar {};
		class lockVehicle {};
		class openInventory {};
		class vehicleOwners {};
		class vehicleWeight {};
		class vehInventory {};
		class vehStoreItem {};
		class vehTakeItem {};
		class insureVehicle {};
		class s_onSliderChange {};
	};

	class warrants {
		file = "core\warrants";
		class addWarrants {};
		class issueWarrant {};
		class openWarrants {};
		class receiveWarrants {};
		class updateWarrants {};
	};
};
