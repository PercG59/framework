class CfgGangs {
	class Member_Management {
		Needed_Rank_Invites = 3;
		Needed_Rank_Promote = 2;
		Needed_Rank_Demote = 3;
		Needed_Rank_Kick = 2;
		Needed_Rank_UseBank = 2;
		Needed_Rank_Freq = 1;
		Needed_Rank_GangShedStorage = 3;
		Needed_Rank_WarRequests = 3;
		Rank_Array[] = { "Recruit", "Member", "Senior Member", "Co-Owner", "Owner" };
	};

	class Shed {
		class Land_SM_01_shed_F {
			price = 500000;
			upkeep = 75000;
			storage[] = {
				{ { -2.06055, 0.667969, -1.7908 }, { 0.0127876, 0.999918, 0 } },
				{ { 1.23633, 0.667969, -1.79079 }, { 0.0127876, 0.999918, 0 } }
			};
			spawn_point[] = { -6.75977, 0.246094, -1.76634 };
		};
		class Land_House_C_3_EP1 {
			price = 250000;
			upkeep = 50000;
			storage[] = {
				{ { 5.35107,2.85596,-0.51667 }, { 0.0127876, 0.999918, 0 } },
				{ { -6.47607,-0.970215,0.576141 }, { 0.0127876, 0.999918, 0 } }
			};
			spawn_point[] = { 5.53662,-1.31238,-4.00147 };
		};
	};

	class Data {
		gang_bank[] = {
			{0,100000},
			{1,150000},
			{2,250000},
			{3,350000},
			{4,450000},
			{5,500000},
			{6,650000},
			{7,0} // this is max tasks!
		};
	};
};