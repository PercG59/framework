#define true 1
#define false 0

class Housing {
	class Takistan {

		class Land_House_K_1_EP1 {
			price = 350000;
			numberCrates = 2;
			restrictedPos[] = {};
			canGarage = true;
			garageSpawnPos[] = {};
			garageSpawnDir = 0;
			garageBlacklists[] = {};
			lightPos[] = { -3.3, 1, 2.5 };
		};
		class Land_House_L_3_EP1 : Land_House_K_1_EP1{};
		class Land_House_K_6_EP1 : Land_House_K_1_EP1{};
		class Land_House_K_5_EP1 : Land_House_K_1_EP1{};
		class Land_House_K_8_EP1 : Land_House_K_1_EP1{};
		class Land_House_K_3_EP1 : Land_House_K_1_EP1{};
	};
};