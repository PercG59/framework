#define true 1
#define false 0

class HousingLoot {
	class Land_House_K_1_EP1 {
		lootPositions[] = {
			{ -0.983887,5.15527,1.56479 },
			{ -3.30322,2.88025,1.54668 },
			{ 3.22461,5.28101,1.56487 },
			{ 3.4165,2.12482,1.4319 }
		};
	};
	class Land_House_L_3_EP1 {
		lootPositions[] = {
			{ -2.78955,2.61597,-0.232048 },
			{ -5.28662,2.4173,-0.229591 }
		};
	};
	class Land_House_K_6_EP1 {
		lootPositions[] = {
			{ -0.492432,-2.88867,4.45065 },
			{ -0.28833,-3.02344,1.46881 },
			{ 2.94116,-0.3125,-1.61041 },
			{ -0.389404,5.16211,-1.61041 }
		};
	};
	class Land_House_K_5_EP1 {
		lootPositions[] = {
			{ -3.34546,1.34363,1.51627 },
			{ 3.51819,-0.359863,2.33037 }
		};
	};
	class Land_House_K_8_EP1 {
		lootPositions[] = {
			{ -2.48145,-1.44092,-2.54391 },
			{ 0.129883,2.729,0.250946 },
			{ 0.196289,3.59375,3.35754 }
		};
	};
	class Land_House_K_3_EP1 {
		lootPositions[] = {
			{ -2.15674,5.89038,-0.5401 },
			{ -4.63477,1.33813,-0.79776 },
			{ -0.461426,3.87354,2.81476 }
		};
	};

	class Land_i_House_Small_01_V1_F {
		lootPositions[] = {
			{ 0.146484, -3.63135, -0.961539 },
			{ -3.46484, 0.302979, -0.961539 }
		};
	};
	class Land_i_House_Small_01_V2_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_01_V3_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_02_V1_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_02_V2_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_02_V3_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_01_b_blue_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_01_b_brown_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_01_b_pink_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_01_b_white_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_01_b_whiteblue_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_01_b_yellow_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_02_b_blue_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_02_b_brown_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_02_b_pink_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_02_b_white_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_02_b_whiteblue_F : Land_i_House_Small_01_V1_F{};
	class Land_i_House_Small_02_b_yellow_F : Land_i_House_Small_01_V1_F{};

	class Land_JD_Cargo_Black {
		lootPositions[] = {
			{ -1.76855,0.00292969,-1.31854 }
		};
	};
	class Land_JD_Cargo_Blue : Land_JD_Cargo_Black{};
	class Land_JD_Cargo_Brown : Land_JD_Cargo_Black{};
	class Land_JD_Cargo_Green : Land_JD_Cargo_Black{};
	class Land_JD_Cargo_Grey : Land_JD_Cargo_Black{};
	class Land_JD_Cargo_Lime : Land_JD_Cargo_Black{};
	class Land_JD_Cargo_Orange : Land_JD_Cargo_Black{};
	class Land_JD_Cargo_Pink : Land_JD_Cargo_Black{};
	class Land_JD_Cargo_Red : Land_JD_Cargo_Black{};
	class Land_JD_Cargo_White : Land_JD_Cargo_Black{};
	class Land_JD_Cargo_Yellow : Land_JD_Cargo_Black{};

	class Land_i_House_Small_03_V1_F {
		lootPositions[] = {
			{ 0.477539, 2.71582, 0.0643115 },
			{ -4.4834, 3.87012, 0.0643115 },
			{ -3.86865, -1.21143, 0.0643115 },
			{ 3.66699, -3.83154, 0.0643115 }
		};
	};
	class Land_i_House_Small_03_V3_F : Land_i_House_Small_03_V1_F {};

	class Land_i_Stone_HouseSmall_V1_F {
		lootPositions[] = {
			{ -1.62793, 3.49316, -0.612101 },
			{ -7.91357, 3.6416, -0.612101 },
			{ 7.37451, 3.8457, -0.612101 },
			{ 3.44824, 3.20557, -0.612101 },
			{ -1.32764, 0.251465, -0.612101 }
		};
	};
	class Land_i_Stone_HouseSmall_V2_F : Land_i_Stone_HouseSmall_V1_F {};
	class Land_i_Stone_HouseSmall_V3_F : Land_i_Stone_HouseSmall_V1_F {};

	class Land_i_House_Big_01_V1_F {
		lootPositions[] = {
			{ 1.69141, 5.40186, -3.02887 },
			{ 1.21338, 5.30127, -3.02901 },
			{ 1.54004, -5.20874, -3.12363 }
		};
	};
	class Land_i_House_Big_01_V2_F : Land_i_House_Big_01_V1_F{};
	class Land_u_House_Big_01_V1_F : Land_i_House_Big_01_V1_F{};
	class Land_i_House_Big_01_b_blue_F : Land_i_House_Big_01_V1_F{};
	class Land_i_House_Big_01_b_brown_F : Land_i_House_Big_01_V1_F{};
	class Land_i_House_Big_01_b_pink_F : Land_i_House_Big_01_V1_F{};
	class Land_i_House_Big_01_b_white_F : Land_i_House_Big_01_V1_F{};
	class Land_i_House_Big_01_b_whiteblue_F : Land_i_House_Big_01_V1_F{};
	class Land_i_House_Big_01_b_yellow_F : Land_i_House_Big_01_V1_F{};

	class Land_i_House_Big_02_V1_F {
		lootPositions[] = {
			{ 3.40137, 2.31055, -3.22534 },
			{ -2.93799, -2.29956, -3.16225 },
			{ -3.15088, -2.33008, -3.15208 }
		};
	};
	class Land_i_House_Big_02_V2_F : Land_i_House_Big_02_V1_F{};
	class Land_i_House_Big_02_b_blue_F : Land_i_House_Big_02_V1_F{};
	class Land_i_House_Big_02_b_brown_F : Land_i_House_Big_02_V1_F{};
	class Land_i_House_Big_02_b_pink_F : Land_i_House_Big_02_V1_F{};
	class Land_i_House_Big_02_b_white_F : Land_i_House_Big_02_V1_F{};
	class Land_i_House_Big_02_b_whiteblue_F : Land_i_House_Big_02_V1_F{};
	class Land_i_House_Big_02_b_yellow_F : Land_i_House_Big_02_V1_F{};

	class Land_HouseA1 {
		lootPositions[] = {
			{ -7.33984, -4.76001, 0.0976062 },
			{ 4.24316, -1.19702, 0.0976062 },
			{ 4.76953, 3.99951, 0.0976062 }
		};
	};
	class Land_HouseC_R : Land_HouseA1{};
	class Land_HouseB1 : Land_HouseA1{};
	class Land_HouseB : Land_HouseA1{};
	class Land_HouseA : Land_HouseA1{};
	class Land_HouseC1_l : Land_HouseA1{};

	class Land_HouseB1_L {
		lootPositions[] = {
			{ 6.51807, -3.0127, -0.000954628 },
			{ -5.40186, 8.52832, -0.000954628 },
			{ -3.33496, 0.24707, -0.000954628 }
		};
	};

	class Land_Ranch_DED_Ranch_01_F {
		lootPositions[] = {
			{ 3.48145, 2.59229, -2.08521 },
			{ -2.74414, 3.21777, -2.08521 },
			{ -4.73242, -8.19385, -2.08521 },
			{ 2.24512, -8.85059, -2.08521 }
		};
	};
	class Land_Ranch_DED_Ranch_02_F : Land_Ranch_DED_Ranch_01_F {};

	class Land_Home6b_DED_Home6b_01_F {
		lootPositions[] = {
			{ -0.534729, -4.5979, 0.204372 },
			{ 5.97742, 2.04077, 3.25362 },
			{ -6.17633, 4.63159, 3.2433 },
			{ -4.03381, 4.47363, 0.204372 }
		};
	};

	class Land_Home3r_DED_Home3r_01_F : Land_Home6b_DED_Home6b_01_F {};

	class Land_i_House_Big_01_V3_F {
		lootPositions[] = {
			{ 1.92285, -2.43359, -2.67145 },
			{ -2.21094, -2.71484, 0.920776 },
			{ 2.80103, -5.16309, 0.920715 },
			{ 2.16211, 5.1543, 0.920715 }
		};
	};

	class Land_i_House_Big_02_V3_F {
		lootPositions[] = {
			{ -3.12305, 1.39063, -2.58389 },
			{ -2.94043, 3.80713, -2.58395 },
			{ 2.96582, 0.814453, -2.58401 },
			{ 2.9375, 3.60156, -2.58401 },
			{ -2.76563, -2.30762, 0.83609 },
			{ -2.4834, 2.30713, 0.836029 }
		};
	};

	class Land_ivory_trailer_01 {
		lootPositions[] = {
			{ 0.151855, 6.86621, -2.96618 },
			{ -0.496582, -0.304688, -2.96618 }
		};
	};

	class Land_ivory_trailer_02 {
		lootPositions[] = {
			{ 7.11719, 1.20508, -1.96712 },
			{ -5.65918, -1.0708, -1.96713 }
		};
	};

	class Land_ivory_trailer_03 {
		lootPositions[] = {
			{ 3.07422, -5.24805, -1.48889 },
			{ -2.73633, 4.79102, -1.48889 }
		};
	};

	class Land_ivory_trailer_04 {
		lootPositions[] = {
			{ -3.53271, -4.92334, -2.46079 },
			{ 3.19531, 4.78613, -2.46079 }
		};
	};

	class Land_ivory_trailer_05 {
		lootPositions[] = {
			{ 5.42285, -2.61523, -1.80613 },
			{ -5.40625, 2.88086, -1.80613 }
		};
	};

	class Land_ivory_trailer_06 {
		lootPositions[] = {
			{ -3.10693, -5.69189, -1.39651 },
			{ 3.57129, 6.46631, -1.39651 }
		};
	};

	class Land_Ark_Mansion1 {
		lootPositions[] = {
			{ -2.33398,11.2441,-0.0431747 }
		};
	};

	class Land_House_Mansion_1 {
		lootPositions[] = {
			{ -2.10742,12.6797,0.00143814 }
		};
	};
};


