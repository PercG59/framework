class CfgMining {
	// Not Used
	
	Positions[] = { 
		// Mine Locations
		{ 2856.547, 9727.056, 0.00143433 }, { 2857.849, 9735.913, 0.00143433 }, 
		{ 2852.805, 9741.748, 0.00143433 }, { 2848.112, 9729.777, 0.00143433 }, 
		{ 2844.875, 9739.197, 0.00143433 }, { 2840.805, 9747.617, 0.00143433 }, 
		{ 2831.438, 9745.723, 0.00154114 }, { 2829.06, 9735.621, 0.00151062 }, 
		{ 2829.092, 9727.231, 0.00143433 }, { 2838.549, 9723.031, 0.00144958 }
	};

	class Ores {
		class VG_RubyOre {
			resource = "rubyOre";
			name = "Ruby Ore";
		};
		class VG_DiamondOre {
			resource = "diamondOre";
			name = "Diamond Ore";
		};
		class VG_CoalOre {
			resource = "coalOre";
			name = "Coal Ore";
		};
		class VG_IronOre {
			resource = "ironOre";
			name = "Iron Ore";
		};
		class VG_GoldOre {
			resource = "goldOre";
			name = "Gold Ore";
		};
		class VG_SilverOre {
			resource = "silverOre";
			name = "Silver Ore";
		};
		class VG_SapphireOre {
			resource = "sapphireOre";
			name = "Sapphire Ore";
		};
		class VG_GemOre {
			resource = "emeraldOre";
			name = "Emerald Ore";
		};
	};
};