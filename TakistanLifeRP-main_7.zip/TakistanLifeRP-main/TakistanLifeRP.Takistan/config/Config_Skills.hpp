class CfgSkillz {

	////////////////////
	//Professional perks
	////////////////////
	class BleedoutSpeedProf {
		name = "Bleedout Speed Decrease";
		description = "You bleed out 75% slower. You get a respawn button after the normal death time has passed.";
		image = "";
		level = 2;
		points = 3;
		reqskills[] = { "" };
		type = "Professional";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Death_Speed = 1.75;" };
	};
	class HomeOwnershipProf {
		name = "Home Ownership";
		description = "Gain the ability to buy houses and garages";
		image = "";
		level = 7;
		points = 5;
		reqskills[] = { "BleedoutSpeedProf" };
		type = "Professional";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Home_Ownership = true;" };
	};
	class BurglaryAlarmProf {
		name = "Burglary Alarm";
		description = "Learn how to avoid houses alarms from going off! (-30%)";
		image = "";
		level = 9;
		points = 7;
		reqskills[] = { "HomeOwnershipProf" };
		type = "Professional";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Alarm_Chance = 0.33;" };
	};
	class StabalizeLengthProf {
		name = "Stabalize Length";
		description = "Increase your stabalize length (+50%)";
		image = "";
		level = 12;
		points = 9;
		reqskills[] = { "BurglaryAlarmProf" };
		type = "Professional";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Stabalize_Length = 90;" };
	};
	class PaycheckDirectDepoProf {
		name = "Paycheck Direct Diposit";
		description = "All paychecks will get direct deposit'd into your bank account.";
		image = "";
		level = 15;
		points = 12;
		reqskills[] = { "StabalizeLengthProf" };
		type = "Professional";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Direct_Deposit = true;" };
	};
	class PaycheckIncreaseProf {
		name = "Paycheck Increase";
		description = "Receive more money from paychecks (+50%).";
		image = "";
		level = 19;
		points = 13;
		reqskills[] = { "CPRTrainingProf" };
		type = "Professional";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Paycheck_Increase = 1.5;" };
	};
	class CPRTrainingProf {
		name = "CPR Training";
		description = "Improves chances of reviving when doing CPR to 50%";
		image = "";
		level = 25;
		points = 13;
		reqskills[] = { "PaycheckDirectDepoProf" };
		type = "Professional";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Skills_CprChance = 0.5;" };
	};
	class AviationTrainingProf {
		name = "Aviation Training";
		description = "Gain access to the air shops to buy aircrafts";
		image = "";
		level = 29;
		points = 15;
		reqskills[] = { "PaycheckIncreaseProf" };
		type = "Professional";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Aviation_Training = true;" };
	};
	class RebelTrainingProf {
		name = "Rebel Training";
		description = "Gain the ability to use the shops at the rebel outpost";
		image = "";
		level = 33;
		points = 15;
		reqskills[] = { "AviationTrainingProf" };
		type = "Professional";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Rebel_Training = true;" };
	};

	////////////////////
	//Workingman Perks
	////////////////////
	class InfiniteStamWork {
		name = "Infinite Stamina";
		description = "Allows you to run indefinitely";
		image = "";
		level = 2;
		points = 2;
		reqskills[] = { "" };
		type = "WorkingMan";
		side[] = { "CIV" };
		initScript[] = { 1, "player enableStamina false;" };
	};
	class ProcessingSpeedWork {
		name = "Processing Speed";
		description = "Process materials more efficiently (+30%)";
		image = "";
		level = 6;
		points = 8;
		reqskills[] = { "" };
		type = "WorkingMan";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Process_Speed = 0.7;" };
	};
	class RepairWork {
		name = "Repairing Speed";
		description = "Allows 50% faster repairing";
		image = "";
		level = 6;
		points = 4;
		reqskills[] = { "ProcessingSpeedWork" };
		type = "WorkingMan";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Skills_RepairSpeed = 0.5;" };
	};
	class OreMiningWork {
		name = "Ore Mining";
		description = "Gather 50% more with a pickaxe.";
		image = "";
		level = 11;
		points = 5;
		reqskills[] = { "RepairWork" };
		type = "WorkingMan";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Ore_Mining = true;" };
	};
	class PaycheckIncreaseWork {
		name = "Paycheck Increase";
		description = "Receive more money from paychecks (+50%).";
		image = "";
		level = 16;
		points = 7;
		reqskills[] = { "OreMiningWork" };
		type = "WorkingMan";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Paycheck_Increase = 1.5;" };
	};
	class LowGearTraining {
		name = "Manual Drive Training";
		description = "Gain the ability to use Low Gear Mode when driving a car, making traversing hills easier.";
		image = "";
		level = 12;
		points = 10;
		reqskills[] = { "" };
		type = "WorkingMan";
		side[] = { "CIV" };
		initScript[] = { 0, "Low_Gear_Mode = true;" };
	};
	class RebelTrainingWork {
		name = "Rebel Training";
		description = "Gain the ability to use the shops at the rebel outpost";
		image = "";
		level = 19;
		points = 12;
		reqskills[] = { "PaycheckIncreaseWork" };
		type = "WorkingMan";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Rebel_Training = true;" };
	};
	class CarryWeightWork {
		name = "Big Backpack";
		description = "Carry more v-items on you (+20%).";
		image = "";
		level = 24;
		points = 11;
		reqskills[] = { "RebelTrainingWork" };
		type = "WorkingMan";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Vitem_Modifier = 1.2;" };
	};
	class RepairNoToolsWork {
		name = "Reparing without Tools";
		description = "Don't have a toolkit? No problem. Now you can repair just as fast without.";
		image = "";
		level = 28;
		points = 12;
		reqskills[] = { "CarryWeightWork" };
		type = "WorkingMan";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Repair_NoTools = true;" };
	};
	class AviationTrainingWork {
		name = "Aviation Training";
		description = "Gain access to the air shops to buy aircrafts";
		image = "";
		level = 32;
		points = 13;
		reqskills[] = { "RepairNoToolsWork" };
		type = "WorkingMan";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Aviation_Training = true;" };
	};

	////////////////////
	//Hustler Perks
	////////////////////
	class BurglaryAlarmHust {
		name = "Burglary Alarm";
		description = "Learn how to avoid houses alarms from going off! (-20%)";
		image = "";
		level = 2;
		points = 2;
		reqskills[] = { "" };
		type = "Hustler";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Alarm_Chance = 0.25;" };
	};
	class MagazineRepackingHust {
		name = "Magazine Repacking";
		description = "Allows you to repack magazines";
		image = "";
		level = 4;
		points = 3;
		reqskills[] = { "BurglaryAlarmHust" };
		type = "Hustler";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Skills_Repack = true;" };
	};
	class ChopshopHust {
		name = "Chopping Benefits";
		description = "Receive more money from chopping vehicles (+30%).";
		image = "";
		level = 6;
		points = 5;
		reqskills[] = { "MagazineRepackingHust" };
		type = "Hustler";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Skills_Chopping = 1.3;" };
	};
	class AviationTrainingHust {
		name = "Aviation Training";
		description = "Gain access to the air shops to buy aircrafts";
		image = "";
		level = 9;
		points = 7;
		reqskills[] = { "ChopshopHust" };
		type = "Hustler";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Aviation_Training = true;" };
	};
	class LSDGatheringHust {
		name = "LSD Gathering";
		description = "Learn to gather frogs to make LSD (estimated at 15% more profit than cocaine)"; 
		image = "";
		level = 12;
		points = 7;
		reqskills[] = { "AviationTrainingHust" };
		type = "Hustler";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_LSD_Gathering = true;" };
	};
	class RebelTrainingHust {
		name = "Rebel Training";
		description = "Gain the ability to use the shops at the rebel outpost";
		image = "";
		level = 15;
		points = 12;
		reqskills[] = { "LSDGatheringHust" };
		type = "Hustler";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Rebel_Training = true;" };
	};
	class CPRTrainingHust {
		name = "CPR Training";
		description = "Improves chances of reviving when doing CPR to 50%";
		image = "";
		level = 17;
		points = 10;
		reqskills[] = { "RebelTrainingHust" };
		type = "Hustler";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Skills_CprChance = 0.5;" };
	};
	class GanjaGrowingHust {
		name = "Ganja Growth";
		description = "Your weed grows faster (+30%).";
		image = "";
		level = 23;
		points = 11;
		reqskills[] = { "CPRTrainingHust" };
		type = "Hustler";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Skills_Ganja = 0.7;" };
	};
	class LockpickingHust {
		name = "Lockpicking Master";
		description = "Reduce the chance of triggering an alarm at CPA (-30%).";
		image = "";
		level = 26;
		points = 13;
		reqskills[] = { "GanjaGrowingHust" };
		type = "Hustler";
		side[] = { "CIV" };
		initScript[] = { 0, "SG_Skills_Lockpicker = 0.7;" };
	};

	/* West Only */
	class west_InfiniteStam {
		name = "Infinite Stamina";
		description = "Allows you to run indefinitely";
		image = "";
		level = 2;
		points = 2;
		reqskills[] = { "" };
		type = "WorkingMan";
		side[] = { "WEST" };
		initScript[] = { 1, "player enableStamina false;" };
	};

	class west_MagazineRepacking {
		name = "Magazine Repacking";
		description = "Allows you to repack magazines";
		image = "";
		level = 4;
		points = 3;
		reqskills[] = { "west_InfiniteStam" };
		type = "WorkingMan";
		side[] = { "WEST" };
		initScript[] = { 0, "SG_Skills_Repack = true;" };
	};

	class west_StabalizeLength {
		name = "Stabalize Length";
		description = "Increase your stabalize length (+50%)";
		image = "";
		level = 8;
		points = 3;
		reqskills[] = { "west_MagazineRepacking" };
		type = "WorkingMan";
		side[] = { "WEST" };
		initScript[] = { 0, "SG_Stabalize_Length = 90;" };
	};

	class west_Impound1 {
		name = "Impounding speed";
		description = "Allows 50% faster impounding";
		image = "";
		level = 12;
		points = 3;
		reqskills[] = { "west_StabalizeLength" };
		type = "WorkingMan";
		side[] = { "WEST" };
		initScript[] = { 0, "SG_Skills_ImpoundSpeed = 0.5;" };
	};

	class west_CPRTraining {
		name = "CPR Training";
		description = "Improves chances of reviving when doing CPR to 50%";
		image = "";
		level = 15;
		points = 4;
		reqskills[] = { "west_Impound1" };
		type = "WorkingMan";
		side[] = { "WEST" };
		initScript[] = { 0, "SG_Skills_CprChance = 0.5;" };
	};

	class west_Repair {
		name = "Repairing Speed";
		description = "Allows 50% faster repairing";
		image = "";
		level = 19;
		points = 4;
		reqskills[] = { "west_CPRTraining" };
		type = "WorkingMan";
		side[] = { "WEST" };
		initScript[] = { 0, "SG_Skills_RepairSpeed = 0.5;" };
	};

	class west_FreemagRefill {
		name = "Magazine Refill";
		description = "Allows you to refill magazines for free at the PD";
		image = "";
		level = 24;
		points = 5;
		reqskills[] = { "west_Repair" };
		type = "WorkingMan";
		side[] = { "WEST" };
		initScript[] = { 0, "SG_Skills_Refill = true;" };
	};

	/* Medic only */
	class guer_InfiniteStam {
		name = "Infinite Stamina";
		description = "Allows you to run indefinitely";
		image = "";
		level = 2;
		points = 2;
		reqskills[] = { "" };
		type = "WorkingMan";
		side[] = { "GUER" };
		initScript[] = { 1, "player enableStamina false;" };
	};

	class guer_StabalizeLength {
		name = "Stabalize Length";
		description = "Increase your stabalize length (+50%)";
		image = "";
		level = 8;
		points = 3;
		reqskills[] = { "guer_InfiniteStam" };
		type = "WorkingMan";
		side[] = { "GUER" };
		initScript[] = { 0, "SG_Stabalize_Length = 90;" };
	};

	class guer_Impound1 {
		name = "Impounding speed I";
		description = "Allows 50% faster impounding";
		image = "";
		level = 12;
		points = 3;
		reqskills[] = { "guer_StabalizeLength" };
		type = "WorkingMan";
		side[] = { "GUER" };
		initScript[] = { 0, "SG_Skills_ImpoundSpeed = 0.5;" };
	};

	class guer_Repair1 {
		name = "Repairing Speed I";
		description = "Allows 50% faster repairing";
		image = "";
		level = 19;
		points = 4;
		reqskills[] = { "guer_Impound1" };
		type = "WorkingMan";
		side[] = { "GUER" };
		initScript[] = { 0, "SG_Skills_RepairSpeed = 0.5;" };
	};

	class guer_Impound2 {
		name = "Impounding speed II";
		description = "Allows 75% faster impounding";
		image = "";
		level = 12;
		points = 3;
		reqskills[] = { "guer_Repair1" };
		type = "WorkingMan";
		side[] = { "GUER" };
		initScript[] = { 0, "SG_Skills_ImpoundSpeed = 0.25;" };
	};

	class guer_Repair2 {
		name = "Repairing Speed II";
		description = "Allows 75% faster repairing";
		image = "";
		level = 19;
		points = 4;
		reqskills[] = { "guer_Impound2" };
		type = "WorkingMan";
		side[] = { "GUER" };
		initScript[] = { 0, "SG_Skills_RepairSpeed = 0.25;" };
	};
};

class CfgSkillActions {
	class VehiclePurchased {
		expToAdd = 100;
		message = "Vehicle Purchased";
	};

	class ItemProcessed {
		expToAdd = 20;
		message = "Items Processed (20xp per item you processed)";
	};

	class VehicleLockpicked {
		expToAdd = 100;
		message = "Vehicle Lockpicked";
	};

	class VehicleImpounded {
		expToAdd = 50;
		message = "Impounded Vehicle";
	};

	class Suicide {
		expToAdd = 450;
		message = "For our brothers";
	};

	class buyHouse {
		expToAdd = 700;
		message = "Property Purchasing";
	};

	class playerJailed {
		expToAdd = 800;
		message = "Cleaning the streets";
	};

	class robshop {
		expToAdd = 350;
		message = "Armed Robbery";
	};

	class robbank {
		expToAdd = 1300;
		message = "Armed Bank Robbery";
	};

	class robevidence {
		expToAdd = 1500;
		message = "Evidence Locker Robbery";
	};

	class FixSafe {
		expToAdd = 1300;
		message = "Fixed the Safe!";
	};

	class DMV {
		expToAdd = 300;
		message = "Drivers Test Passed";
	};

	class PickupEvidence {
		expToAdd = 150;
		message = "Picked up Evidence";
	};

	class CPR {
		expToAdd = 150;
		message = "Picked up a brother!";
	};

	class Stabalize {
		expToAdd = 200;
		message = "Extended lifetime for someone!";
	};

	class Revive {
		expToAdd = 250;
		message = "Helped out the injured!";
	};

	class burglary {
		expToAdd = 350;
		message = "Burglary";
	};

	class playtime {
		expToAdd = 75;
		message = "Thanks For Playing";
	};

	class playtime_servername {
		expToAdd = 200;
		message = "Thanks For Playing";
	};

	class gather {
		expToAdd = 50;
		message = "Gathered Crop";
	};

	class ticket_signed {
		expToAdd = 125;
		message = "Slap on the wrist";
	};

	class weed_sieze {
		expToAdd = 50;
		message = "Yoinking the dank";
	};

	class weed_grow {
		expToAdd = 50;
		message = "Growing the dank";
	};

	class repairshit {
		expToAdd = 25;
		message = "Repairing some shit";
	};
	/*
	class organHarvested {
		expToAdd = 1000;
		message = "Sicko mode";
	}
	*/
};

class CfgSkillLevels {
	class Level_0 {
		displayName = "Rank 0";
		expRequired = 0;
		perkPointsOnUnlock = 1;
	};

	class Level_1 {
		displayName = "Rank 1";
		expRequired = 85;
		perkPointsOnUnlock = 2;
	};

	class Level_2 {
		displayName = "Rank 2";
		expRequired = 340;
		perkPointsOnUnlock = 2;
	};

	class Level_3 {
		displayName = "Rank 3";
		expRequired = 765;
		perkPointsOnUnlock = 2;
	};

	class Level_4 {
		displayName = "Rank 4";
		expRequired = 1360;
		perkPointsOnUnlock = 2;
	};

	class Level_5 {
		displayName = "Rank 5";
		expRequired = 2125;
		perkPointsOnUnlock = 5;
	};

	class Level_6 {
		displayName = "Rank 6";
		expRequired = 3060;
		perkPointsOnUnlock = 2;
	};

	class Level_7 {
		displayName = "Rank 7";
		expRequired = 4165;
		perkPointsOnUnlock = 2;
	};

	class Level_8 {
		displayName = "Rank 8";
		expRequired = 5440;
		perkPointsOnUnlock = 2;
	};

	class Level_9 {
		displayName = "Rank 9";
		expRequired = 6885;
		perkPointsOnUnlock = 2;
	};

	class Level_10 {
		displayName = "Rank 10";
		expRequired = 8500;
		perkPointsOnUnlock = 5;
	};

	class Level_11 {
		displayName = "Rank 11";
		expRequired = 10285;
		perkPointsOnUnlock = 2;
	};

	class Level_12 {
		displayName = "Rank 12";
		expRequired = 12240;
		perkPointsOnUnlock = 2;
	};

	class Level_13 {
		displayName = "Rank 13";
		expRequired = 14365;
		perkPointsOnUnlock = 2;
	};

	class Level_14 {
		displayName = "Rank 14";
		expRequired = 16660;
		perkPointsOnUnlock = 2;
	};

	class Level_15 {
		displayName = "Rank 15";
		expRequired = 19125;
		perkPointsOnUnlock = 5;
	};

	class Level_16 {
		displayName = "Rank 16";
		expRequired = 21760;
		perkPointsOnUnlock = 2;
	};

	class Level_17 {
		displayName = "Rank 17";
		expRequired = 24565;
		perkPointsOnUnlock = 2;
	};

	class Level_18 {
		displayName = "Rank 18";
		expRequired = 27540;
		perkPointsOnUnlock = 2;
	};

	class Level_19 {
		displayName = "Rank 19";
		expRequired = 30685;
		perkPointsOnUnlock = 2;
	};

	class Level_20 {
		displayName = "Rank 20";
		expRequired = 34000;
		perkPointsOnUnlock = 10;
	};

	class Level_21 {
		displayName = "Rank 21";
		expRequired = 37485;
		perkPointsOnUnlock = 3;
	};

	class Level_22 {
		displayName = "Rank 22";
		expRequired = 41140;
		perkPointsOnUnlock = 3;
	};

	class Level_23 {
		displayName = "Rank 23";
		expRequired = 44965;
		perkPointsOnUnlock = 3;
	};

	class Level_24 {
		displayName = "Rank 24";
		expRequired = 48960;
		perkPointsOnUnlock = 3;
	};

	class Level_25 {
		displayName = "Rank 25";
		expRequired = 53125;
		perkPointsOnUnlock = 5;
	};

	class Level_26 {
		displayName = "Rank 26";
		expRequired = 57460;
		perkPointsOnUnlock = 3;
	};

	class Level_27 {
		displayName = "Rank 27";
		expRequired = 61965;
		perkPointsOnUnlock = 3;
	};

	class Level_28 {
		displayName = "Rank 28";
		expRequired = 66640;
		perkPointsOnUnlock = 3;
	};

	class Level_29 {
		displayName = "Rank 29";
		expRequired = 71485;
		perkPointsOnUnlock = 3;
	};

	class Level_30 {
		displayName = "Rank 30";
		expRequired = 76500;
		perkPointsOnUnlock = 10;
	};

	class Level_31 {
		displayName = "Rank 31";
		expRequired = 81685;
		perkPointsOnUnlock = 3;
	};

	class Level_32 {
		displayName = "Rank 32";
		expRequired = 87040;
		perkPointsOnUnlock = 3;
	};

	class Level_33 {
		displayName = "Rank 33";
		expRequired = 92565;
		perkPointsOnUnlock = 3;
	};

	class Level_34 {
		displayName = "Rank 34";
		expRequired = 98260;
		perkPointsOnUnlock = 3;
	};

	class Level_35 {
		displayName = "Rank 35";
		expRequired = 104125;
		perkPointsOnUnlock = 5;
	};

	class Level_36 {
		displayName = "Rank 36";
		expRequired = 110160;
		perkPointsOnUnlock = 3;
	};

	class Level_37 {
		displayName = "Rank 37";
		expRequired = 116365;
		perkPointsOnUnlock = 3;
	};

	class Level_38 {
		displayName = "Rank 38";
		expRequired = 122740;
		perkPointsOnUnlock = 3;
	};

	class Level_39 {
		displayName = "Rank 39";
		expRequired = 129285;
		perkPointsOnUnlock = 3;
	};

	class Level_40 {
		displayName = "Rank 40";
		expRequired = 136000;
		perkPointsOnUnlock = 10;
	};

	class Level_41 {
		displayName = "Rank 41";
		expRequired = 142885;
		perkPointsOnUnlock = 3;
	};

	class Level_42 {
		displayName = "Rank 42";
		expRequired = 149940;
		perkPointsOnUnlock = 3;
	};

	class Level_43 {
		displayName = "Rank 43";
		expRequired = 157165;
		perkPointsOnUnlock = 3;
	};

	class Level_44 {
		displayName = "Rank 44";
		expRequired = 164560;
		perkPointsOnUnlock = 3;
	};

	class Level_45 {
		displayName = "Rank 45";
		expRequired = 172125;
		perkPointsOnUnlock = 5;
	};

	class Level_46 {
		displayName = "Rank 46";
		expRequired = 179860;
		perkPointsOnUnlock = 3;
	};

	class Level_47 {
		displayName = "Rank 47";
		expRequired = 187765;
		perkPointsOnUnlock = 3;
	};

	class Level_48 {
		displayName = "Rank 48";
		expRequired = 195840;
		perkPointsOnUnlock = 3;
	};

	class Level_49 {
		displayName = "Rank 49";
		expRequired = 204085;
		perkPointsOnUnlock = 3;
	};

	class Level_50 {
		displayName = "Rank 50";
		expRequired = 212500;
		perkPointsOnUnlock = 10;
	};
};