/*
*    Format:
*        3: STRING (Conditions) - Must return boolean :
*            String can contain any amount of conditions, aslong as the entire
*            string returns a boolean. This allows you to check any levels, licenses etc,
*            in any combination. For example:
*                "call life_coplevel && license_civ_someLicense"
*            This will also let you call any other function.
*
*/
class CfgSpawnPoints {
	class Takistan {
		class Civilian {
			class Rasman {
				displayName = "Rasman";
				description = "The Capital City of Takistan and the largest city in Northern Takistan";
				spawnMarker = "civ_spawn_rasman";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\spawn.paa";
				conditions = "";
				// conditions = "license_civ_reb isEqualTo false && license_civ_passport isEqualTo true";
				radius = 300;
			};
			class Nagara {
				displayName = "Nagara";
				description = "Nagara. It's Nagara. There's nothing more to say about it.";
				spawnMarker = "civ_spawn_nagara";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\spawn.paa";
				conditions = "";
				radius = 300;
			};
			class Feruz {
				displayName = "Feruz Abad";
				description = "The largest city in Southern Takistan";
				spawnMarker = "civ_spawn_feruz";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\spawn.paa";
				conditions = "";
				radius = 300;
			};
			class LoyManara {
				displayName = "Loy Manara";
				description = "The second largest city in Southern Takistan and a popular tourist spot.";
				spawnMarker = "civ_spawn_loymanara";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\spawn.paa";
				conditions = "";
				radius = 300;
			};
			class Shukurkalay {
				displayName = "Shukurkalay";
				description = "I dont know why you'd ever spawn here";
				spawnMarker = "civ_spawn_shukur";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\spawn.paa";
				conditions = "";
				radius = 300;
			};
			class Rebel {
				displayName = "Rebel";
				description = "Rebels gain access to spawn here.";
				spawnMarker = "civ_spawn_rebel";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\villa.paa";
				conditions = "false";
				radius = 200;
			};
		};

		class Cop {
			class NATO_AirBase {
				displayName = "NATO Headquarters";
				description = "The Main HQ of NATO Forces in Takistan";
				spawnMarker = "cop_spawn_AirBase";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\safehouse.paa";
				conditions = "call life_copdept in ['NATO','CIA','Command']";
				radius = 100;
			};

			class NATO_HQ {
				displayName = "Takistan Police HQ";
				description = "The Main HQ of the Takistan National Police";
				spawnMarker = "cop_spawn_PoliceHQ";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\safehouse.paa";
				conditions = "";
				radius = 100;
			};

			class Base_Garmsar {
				displayName = "Garmsar Police Station";
				description = "Garmsar Police Station";
				spawnMarker = "cop_spawn_Garmsar";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\safehouse.paa";
				conditions = "";
				radius = 100;
			};

			class Base_CIA {
				displayName = "CIA Headquarters";
				description = "Special Activities Center for CIA";
				spawnMarker = "cop_spawn_CIA";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\safehouse.paa";
				conditions = "call life_copdept in ['CIA','Command']";
				radius = 100;
			};
		};

		class Medic {
			class Medic_UN {
				displayName = "North Takistan Hospital";
				description = "The Primary Medical Centre in Northern Takistan";
				spawnMarker = "medic_spawn_UN";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\safehouse.paa";
				conditions = "";
				radius = 40;
			};
			class Medic_SouthUN {
				displayName = "South Takistan Hospital";
				description = "The Primary Medical Centre in Southern Takistan";
				spawnMarker = "medic_spawn_South";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\safehouse.paa";
				conditions = "";
				radius = 40;
			};
		};

		class Opf {
			class Opf_Station {
				displayName = "Takistan Police Station";
				description = "The Main Police Station of the Provisional Republic of Takistan";
				spawnMarker = "opf_spawn_station";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\safehouse.paa";
				conditions = "";
				radius = 40;
			};

			class Opf_South {
				displayName = "Russian Army HQ";
				description = "The Main HQ of the Russian Army in Takistan";
				spawnMarker = "opf_spawn_south";
				icon = "\SG_Core\images\displays\displaySpawns\TreeIcons\safehouse.paa";
				conditions = "call life_opfdept in ['AFRF','Command']";
				radius = 40;
			};
		};
	};
};
