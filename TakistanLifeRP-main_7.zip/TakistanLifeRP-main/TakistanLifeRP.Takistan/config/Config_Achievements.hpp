class CfgAchievements {
	sound_progress = "orange_timeline_iconfadein";
	sound_complete = "orange_periodswitch_notification";
	notification_complete_life = 7;
	notification_progress_life = 4;
	class RebelSupplies {
		// Locked
		title_locked = "Rebel Supplies";
		description_locked = "Make your way through PVP Island and get to the rebel supplies!";
		icon_locked = "\SG_Core\images\achievements\rebelsupplies_locked.jpg";

		// Unlocked
		title_unlocked = "Rebel Supplies";
		description_unlocked = "Make your way through PVP Island and get to the rebel supplies!";
		icon_unlocked = "\SG_Core\images\achievements\rebelsupplies.jpg";

		// Hidden from view until it has been achieved
		hidden = 0;

		// True/False, update player on achivement progress
		show_progress = 1;

		// Amount of X required to gain achievement
		// 0 - true/false || >= 1 - percent based
		count = 0;

		// Reward/script executed once Unlocked
		action = "";
	};

	/* //Harvesting
	class HarvestWheat: RebelSupplies {
		title_locked = "Wheat Harvest";
		description_locked = "Harvested your first wheat!";
		icon_locked = "\SG_Core\images\achievements\wheat_locked.jpg";

		title_unlocked = "Wheat Harvest";
		description_unlocked = "Harvested your first wheat!";
		icon_unlocked = "\SG_Core\images\achievements\wheat.jpg";

		action = "";
	};
	class HarvestSunFlower: RebelSupplies {
		title_locked = "Sunflower Harvest";
		description_locked = "Harvested your first sunflower!";
		icon_locked = "\SG_Core\images\achievements\sunflower_locked.jpg";

		title_unlocked = "Sunflower Harvest";
		description_unlocked = "Harvested your first sunflower!";
		icon_unlocked = "\SG_Core\images\achievements\sunflower.jpg";

		action = "";
	};
	class HarvestCorn: RebelSupplies {
		title_locked = "Corn Harvest";
		description_locked = "Harvested your first corn!";
		icon_locked = "\SG_Core\images\achievements\corn_locked.jpg";

		title_unlocked = "Corn Harvest";
		description_unlocked = "Harvested your first corn!";
		icon_unlocked = "\SG_Core\images\achievements\corn.jpg";

		action = "";
	};
	class HarvestBeans: RebelSupplies {
		title_locked = "Beans Harvest";
		description_locked = "Harvested your first beans!";
		icon_locked = "\SG_Core\images\achievements\beans_locked.jpg";

		title_unlocked = "Beans Harvest";
		description_unlocked = "Harvested your first beans!";
		icon_unlocked = "\SG_Core\images\achievements\beans.jpg";

		action = "";
	};
	class HarvestCotton: RebelSupplies {
		title_locked = "Cotton Harvest";
		description_locked = "Harvested your first cotton!";
		icon_locked = "\SG_Core\images\achievements\cotton_locked.jpg";

		title_unlocked = "Cotton Harvest";
		description_unlocked = "Harvested your first cotton!";
		icon_unlocked = "\SG_Core\images\achievements\cotton.jpg";

		action = "";
	};
	class HarvestPumpkin: RebelSupplies {
		title_locked = "Pumpkin Harvest";
		description_locked = "Harvested your first pumpkin!";
		icon_locked = "\SG_Core\images\achievements\pumpkin_locked.jpg";

		title_unlocked = "Pumpkin Harvest";
		description_unlocked = "Harvested your first pumpkin!";
		icon_unlocked = "\SG_Core\images\achievements\pumpkin.jpg";

		action = "";
	};
	class HarvestPoppy: RebelSupplies {
		title_locked = "Poppy Harvest";
		description_locked = "Harvested your first poppy!";
		icon_locked = "\SG_Core\images\achievements\poppy_locked.jpg";

		title_unlocked = "Poppy Harvest";
		description_unlocked = "Harvested your first poppy!";
		icon_unlocked = "\SG_Core\images\achievements\poppy.jpg";

		action = "";
	};
	class HarvestCoco: RebelSupplies {
		title_locked = "Coco Harvest";
		description_locked = "Harvested your first coco!";
		icon_locked = "\SG_Core\images\achievements\coco_locked.jpg";

		title_unlocked = "Coco Harvest";
		description_unlocked = "Harvested your first coco!";
		icon_unlocked = "\SG_Core\images\achievements\coco.jpg";

		action = "";
	};
	*/

	//Purchase
	class SportsCar : RebelSupplies {
		title_locked = "Purchase Sportscar";
		description_locked = "Purchase a sportscar from the luxury vehicle shop.";
		icon_locked = "\SG_Core\images\achievements\sportscar_locked.jpg";

		title_unlocked = "Purchase Sportscar";
		description_unlocked = "Purchase a sportscar from the luxury vehicle shop.";
		icon_unlocked = "\SG_Core\images\achievements\sportscar.jpg";

		action = "";
	};
	class BuyYacht : RebelSupplies {
		title_locked = "Purchase Yacht";
		description_locked = "Purchase a yacht from the boat shop.";
		icon_locked = "\SG_Core\images\achievements\yacht_locked.jpg";

		title_unlocked = "Purchase Yacht";
		description_unlocked = "Purchase a yacht from the boat shop.";
		icon_unlocked = "\SG_Core\images\achievements\yacht.jpg";

		action = "";
	};
	class BuyHeli : RebelSupplies {
		title_locked = "Purchase Helicopter";
		description_locked = "Purchase a helicopter from the air shop.";
		icon_locked = "\SG_Core\images\achievements\helicopter_locked.jpg";

		title_unlocked = "Purchase Helicopter";
		description_unlocked = "Purchase a helicopter from the air shop.";
		icon_unlocked = "\SG_Core\images\achievements\helicopter.jpg";

		action = "";
	};
	class BuyHouse : RebelSupplies {
		title_locked = "Purchase House";
		description_locked = "Purchase an estate.";
		icon_locked = "\SG_Core\images\achievements\buyhouse_locked.jpg";

		title_unlocked = "Purchase House";
		description_unlocked = "Purchase an estate.";
		icon_unlocked = "\SG_Core\images\achievements\buyhouse.jpg";

		action = "";
	};
	class PlantWeed : RebelSupplies {
		title_locked = "Ganja Farmer";
		description_locked = "Planted your first cannabis seeds in your house.";
		icon_locked = "\SG_Core\images\achievements\ganja_locked.jpg";

		title_unlocked = "Ganja Farmer";
		description_unlocked = "Planted your first cannabis seeds in your house.";
		icon_unlocked = "\SG_Core\images\achievements\ganja.jpg";

		action = "";
	};

	//Majors
	class RobBank : RebelSupplies {
		title_locked = "Payday";
		description_locked = "Rob the New Metro bank successfully.";
		icon_locked = "\SG_Core\images\achievements\payday_locked.jpg";

		title_unlocked = "Payday";
		description_unlocked = "Rob the New Metro bank successfully.";
		icon_unlocked = "\SG_Core\images\achievements\payday.jpg";

		action = "";
	};
};