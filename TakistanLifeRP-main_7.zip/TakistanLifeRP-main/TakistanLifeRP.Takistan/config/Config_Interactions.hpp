class CfgInteractions {
	class ModShop {
		title = "Mod Shop";
		action = "call SG_ModShop;";
		check = "player getVariable ['life_is_alive',false] && { SG_Int_Distance < 5 } && { 'ModShop' in SG_Interaction_VVN }";
	};

	class GPSStartHack {
		title = "Start Verizon Hack";
		action = "call SG_GPS_StartHack;";
		check = "alive player && { SG_Int_Distance < 5 } && { SG_Interaction_Target isEqualTo SG_GPSBox && !(missionNamespace getVariable ['SG_GPSHack',false]) && (playerSide isEqualTo civilian)}";
	};

	class GPSStopHack {
		title = "Stop Verizon Hack";
		action = "call SG_GPS_StopHack;";
		check = "alive player && { SG_Int_Distance < 5 } && { SG_Interaction_Target isEqualTo SG_GPSBox && (missionNamespace getVariable ['SG_GPSHack',false]) && (playerSide isEqualTo west)}";
	};

	class Plant {
		title = "Plant";
		action = "call SG_RandomPlant;";
		check = "surfaceType position player == '#TKPole' && { isNull objectParent player && !isOnRoad player && (playerSide isEqualTo civilian || call life_copdept IN ['CIA']) && count (call SG_HasSeeds) > 0 }";
	};

	class AdministerNarcan {
		title = "Administer Narcan";
		action = "[SG_Interaction_Target] spawn SG_Drugs_Narcan;";
		check = "(SG_Interaction_Target getVariable ['SG_Overdose', false]) && { SG_Int_Distance < 5 }";
	};

	class DrugTestUser {
		title = "Initiate Drug Test";
		action = "[SG_Interaction_Target] spawn SG_Drugs_TestUser;";
		check = "life_inv_drugtestkit > 0 && {(isPlayer SG_Interaction_Target) && (SG_Interaction_Target getVariable ['life_is_alive', false]) && { SG_Int_Distance < 5 }}";
	};

	class Harvest {
		title = "Harvest";
		action = "[SG_Interaction_Target,life_carryWeight,life_maxWeight,(missionNamespace getVariable ['SG_Skills_farmingMultiplier', 0])] remoteExec ['SG_HarvestPlant', 2];";
		check = "typeOf (SG_Interaction_Target) IN SG_AllowedPlants && {SG_Int_Distance <= 3} && { isNull (objectParent player) && (playerSide isEqualTo civilian || call life_copdept IN ['CIA']) }";
	};

	class DigUpPlant {
		title = "Dig Up";
		action = "[SG_Interaction_Target, player] remoteExec ['SG_DigUpPlant', 2];";
		check = "typeOf (SG_Interaction_Target) IN SG_AllowedPlants && { SG_Int_Distance < 5 && isNull (objectParent player) && playerSide isEqualTo west }";
	};

	// class RemoveBarricade {
	// 	title = "Remove Barricade";
	// 	action = "[SG_Interaction_Target] spawn SG_RemoveBarricade;";
	// 	check = "typeOf (SG_Interaction_Target) IN ['Land_AR_CivilianBarricade','Land_AR_PoliceShield'] && { SG_Int_Distance < 5 && isNull (objectParent player) && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) }";
	// };

	class ViewTickets {
		title = "View Tickets";
		action = "call SG_ViewTickets";
		check = "'CourtHouse' in SG_Interaction_VVN && { SG_Int_Distance < 5 }";
	};

	class FuelPump {
		title = "Use Pump";
		action = "call SG_fnc_fuelStatOpen";
		check = "'GasPump' in SG_Interaction_VVN && { SG_Int_Distance <= 15 && isNull (objectParent player) }";
	};

	class PolicePC {
		title = "Police PC";
		action = "call SG_OpenPolicePC;";
		check = "!isNull (objectParent player) && { call SG_InCopCar && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained', false]) }";
	};

	class RepairObject {
		title = "Repair Object";
		action = "closeDialog 0; call SG_CleanStreet;";
		check = "playerSide isEqualto civilian && { (player getVariable ['SG_Job','Unemployed'] isEqualto 'Repair Man') && isNull (objectParent player) }";
	};

	class TruckTransport {
		title = "Truck Transports";
		action = "[] spawn SG_TruckTransportMenu";
		check = "alive SG_Interaction_Target && { 'TruckTransport' in SG_Interaction_VVN && playerSide isEqualTo civilian && (player getVariable ['SG_Job','Unemployed'] isEqualto 'Trucking Transport') }";
	};

	class RaiseBridge {
		title = "Raise Drawbridge";
		action = "[SG_Interaction_Target] spawn SG_DrawBridgeRaise";
		check = "typeOf SG_Interaction_Target isEqualTo 'land_HL_Pont_levis' && { missionNameSpace getVariable ['life_inv_keycard', 0] > 0 && cursorObject animationPhase 'lever_pont' < 0.5 && SG_Int_Distance < 30 }";
	};

	class LowerBridge {
		title = "Lower Drawbridge";
		action = "[SG_Interaction_Target] spawn SG_DrawBridgeLower";
		check = "typeOf SG_Interaction_Target isEqualTo 'land_HL_Pont_levis' && { missionNameSpace getVariable ['life_inv_keycard', 0] > 0 && cursorObject animationPhase 'lever_pont' > 0.5 && SG_Int_Distance < 30 }";
	};

	class ClockIn {
		title = "Clock In";
		action = "[SG_Interaction_Target] call SG_SignInJob";
		check = "playerside isEqualTo civilian && { player getVariable ['SG_Job','Unemployed'] isEqualTo 'Unemployed' && (vehicleVarName SG_Interaction_Target) find SG_GoingToJob > -1 && SG_JobTimer > 0 }";
	};

	class ClockOut {
		title = "Clock Out";
		action = "[] call SG_SignOffJob";
		check = "playerside isEqualTo civilian && { player getVariable ['SG_Job','Unemployed'] != 'Unemployed' && (vehicleVarName SG_Interaction_Target) find (player getVariable ['SG_Shop','None']) > -1 }";
	};

	class JailMarket {
		title = "Jail Legal Market";
		action = "[SG_Interaction_Target,'','','jaillegal'] spawn SG_fnc_virt_menu";
		check = "'JailJobs' in SG_Interaction_VVN && { playerSide in [civilian,west] && life_is_arrested && SG_Int_Distance <= 5 }";
	};

	class SearchTrash {
		title = "Search Trash Pile";
		action = "[SG_Interaction_Target] spawn SG_SearchTrash;";
		check = "'SG_Garbage' in SG_Interaction_VVN && { playerSide in [civilian,west] && life_is_arrested && SG_Int_Distance <= 5 }";
	};

	class JailWorkshop {
		title = "Jail Workshop";
		action = "['jailworkshop'] spawn SG_fnc_weaponShopMenu;";
		check = "'JailWorkshop' in SG_Interaction_VVN && { playerSide in [civilian,west] && life_is_arrested && SG_Int_Distance <= 5 }";
	};

	class GiveDrill {
		title = "Give Pickaxe";
		action = "remoteExec ['SG_GiveJailEquipment',SG_Interaction_Target]";
		check = "(call(life_coplevel)) > 0 && playerSide isEqualTo west && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Int_Distance <= 6 && isNull (objectParent player) && side SG_Interaction_Target == civilian && SG_Interaction_Target getVariable ['arrested',false] && !(player getVariable ['restrained',false])";
	};

	class CheckBlood {
		title = "Check Blood";
		action = "private _unit = SG_Interaction_Target getVariable ['CorpseUnit', objNull]; [format['%1 has %2 blood left!', name _unit, [getPlayerUID _unit] call SG_GetBlood],false] call SG_Noty;";
		check = "SG_Interaction_Target getVariable ['life_is_alive',true] isEqualto false && !(player getVariable ['inHostage',false]) && SG_Int_Distance <= 3 && isNull (objectParent player)";
	};

	class PlaySlots {
		title = "Play Slots";
		action = "[] spawn SG_StartSlots;";
		check = "!isNil 'CasinoSlots_1' && {player inArea CasinoSlots_1 OR player inArea CasinoSlots_2}";
	};

	class OpenATM {
		title = "Access ATM";
		action = "[] spawn SG_fnc_atmMenu;";
		check = "(call SG_fnc_nearATM || typeof SG_Interaction_Target in (getArray (missionConfigFile >> 'CFGMaster' >> 'GameSettings' >> 'atm_types'))) && !(player getVariable ['restrained',false]) && SG_Int_Distance < 5";
	};

	class OpenATMCom {
		title = "Access ATM";
		action = "[] spawn SG_fnc_atmMenu;";
		check = "typeof SG_Interaction_Target isEqualto 'Land_CommonwealthBank' && { !(player getVariable ['restrained',false]) && SG_Int_Distance < 15 }";
	};

	class SearchDumpster {
		title = "Search Dumpster";
		action = "[SG_Interaction_Target] spawn SG_SearchDumpster;";
		check = "(typeof SG_Interaction_Target in (getArray (missionConfigFile >> 'CFGMaster' >> 'GameSettings' >> 'dumpster_types'))) && !(player getVariable ['restrained',false]) && SG_Int_Distance < 5 && playerside isEqualTo civilian";
	};

	class robATM {
		title = "Rob ATM";
		action = "[SG_Interaction_Target] spawn SG_RobATM;";
		check = "(typeof SG_Interaction_Target in (getArray (missionConfigFile >> 'CFGMaster' >> 'GameSettings' >> 'atm_types'))) && !(player getVariable ['restrained',false]) && SG_Int_Distance < 3 && playerside isEqualTo civilian && life_inv_boltcutter >= 1";
	};

	class robContainer {
		title = "Search Container";
		action = "[SG_Interaction_Target] spawn SG_SearchContainer;";
		check = "('Land_JD_Cargo' in typeOf CursorObject) && !(player getVariable ['restrained',false]) && SG_Int_Distance < 5 && playerside isEqualTo civilian && life_inv_boltcutter >= 1";
	};

	class SkinSheep {
		title = "Skin Sheep";
		action = "[SG_Interaction_Target] spawn SG_Hunting_SkinSheep;";
		check = "(typeOf SG_Interaction_Target isEqualTo 'Sheep_random_F') && {!(player getVariable ['restrained',false]) && {SG_Int_Distance < 5 && {!(alive SG_Interaction_Target)}}}";
	};

	class SpawnMenu {
		title = "Spawn Menu";
		action = "call SG_fnc_spawnMenu;";
		check = "'SpawnMenu' in SG_Interaction_VVN && { !(player getVariable ['restrained',false]) && player getVariable ['life_is_alive',false] }";
	};

	class SetName {
		title = "Set Name";
		action = "[SG_Interaction_Target] call SG_SetName;";
		check = "SG_Interaction_Target isKindOf 'Man' && { SG_Int_Distance <= 5 && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target }";
	};

	class Whitelist {
		title = "Whitelist";
		action = "[playerSide] call SG_OpenWhitelist;";
		check = "SG_Interaction_Target isKindOf 'Man' && { SG_Int_Distance <= 5 && SG_Interaction_Target getVariable ['life_is_alive',false] && !(SG_Interaction_Target getVariable ['restrained',false]) && ((playerSide isEqualTo west && call(life_coplevel) >= 6) || (playerSide isEqualTo east && call(life_opflevel) >= 6) || (playerSide isEqualTo independent && call(life_mediclevel) >= 3) || call(life_adminLevel) > 0) && isPlayer SG_Interaction_Target }";
	};

	class LicenseManager {
		title = "License Manager";
		action = "[playerSide] call SG_OpenLicenseManager;";
		check = "SG_Interaction_Target isKindOf 'Man' && { SG_Int_Distance <= 5 && SG_Interaction_Target getVariable ['life_is_alive',false] && !(SG_Interaction_Target getVariable ['restrained',false]) && ((playerSide isEqualTo west && call(life_coplevel) >= 6) || (playerSide isEqualTo east && call(life_opflevel) >= 6) || (playerSide isEqualTo independent && call(life_mediclevel) >= 3) || call(life_adminLevel) > 0) && isPlayer SG_Interaction_Target }";
	};

	// ???
	class Unknown {
		title = "Unknown";
		action = "[SG_Interaction_Target,'','','unknown'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { 'Unknown' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class PlutoniumSeller {
		title = "Plutonium Trader";
		action = "[SG_Interaction_Target,'','','plutonium'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'PlutoniumSeller' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class JailGoods {
		title = "Sell/Buy Items";
		action = "[SG_Interaction_Target,'','','jail'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Tyrone' in SG_Interaction_VVN && playerSide isEqualto civilian && life_is_arrested }";
	};

	class JailWeapons {
		title = "Buy Weapons";
		action = "['jail'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Tyrone' in SG_Interaction_VVN && playerSide isEqualto civilian && life_is_arrested }";
	};

	class JailClothes {
		title = "Buy Clothes";
		action = "['jaildive'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && { 'JailClothing' in SG_Interaction_VVN && playerSide isEqualto civilian && life_is_arrested }";
	};

	class GoldCoinTrader {
		title = "Coin Trader";
		action = "[SG_Interaction_Target,'','','goldcoin'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { 'GoldCoinTrader' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class Blackjack {
		title = "Blackjack";
		action = "[] spawn SG_BlackjackOpen";
		check = "alive SG_Interaction_Target && { 'Blackjack' in SG_Interaction_VVN && SG_Int_Distance <= 5 }";
	};

	class WongsMarket {
		title = "Wongs Market";
		action = "[SG_Interaction_Target,'','','wongs'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Wongs' in SG_Interaction_VVN }";
	};

	class FishMarket {
		title = "Fish Market";
		action = "[SG_Interaction_Target,'','','fishmarket'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Fish' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class GutTurtle {
		title = "Gut Turtle";
		action = "[SG_Interaction_Target] spawn SG_GutTurtle;";
		check = "(typeOf SG_Interaction_Target isEqualTo 'Turtle_F') && {!(player getVariable ['restrained',false]) && {SG_Int_Distance < 5 && {!(alive SG_Interaction_Target)}}}";
	};

	class BurglaryMarket {
		title = "Burglary Market";
		action = "[SG_Interaction_Target,'','','burglary'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Burglary' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class DrugDealer {
		title = "Drug Dealer";
		action = "[SG_Interaction_Target,'','','drugdealer'] spawn SG_fnc_virt_menu;";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 7.5  && 'DrugDealer' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class GangDrugDealer {
		title = "Gang Drug Dealer";
		action = "[SG_Interaction_Target,'','','drugdealer'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 7.5  && 'GangDealer' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class IngotTrader {
		title = "Ingot Trader";
		action = "[SG_Interaction_Target,'','','ingots'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5  && 'ingot_trader' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class MineralTrader {
		title = "Mineral Trader";
		action = "[SG_Interaction_Target,'','','minerals'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5  && 'mineral_trader' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class RelicTurnIn {
		title = "Turn in Relics";
		action = "[] spawn SG_fnc_relicReward";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Relic_trader' in SG_Interaction_VVN && missionNamespace getVariable ['SG_Skills_relicReward',0] isEqualTo 0 }";
	};

	class RelicTurnInMajor {
		title = "Turn in Major Relics";
		action = "[] spawn SG_fnc_relicRewardMajor";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Relic_trader' in SG_Interaction_VVN && missionNamespace getVariable ['SG_Skills_relicReward2',0] isEqualTo 0 }";
	};

	class RelicTurnInMap {
		title = "Turn in Maps";
		action = "[] spawn SG_fnc_relicRewardMap";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Relic_trader' in SG_Interaction_VVN && missionNamespace getVariable ['SG_Skills_relicReward3',0] isEqualTo 0 }";
	};

	class RelicTurnInAnti {
		title = "Turn in Antimatter Sample";
		action = "[] spawn SG_fnc_antiMatterReward";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Relic_trader' in SG_Interaction_VVN && missionNamespace getVariable ['SG_Skills_relicReward4',0] isEqualTo 0 }";
	};

	class Archeologist {
		title = "Archeologist";
		action = "[SG_Interaction_Target,'','','archeologist'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Relic_trader' in SG_Interaction_VVN && playerSide isEqualto civilian && player getVariable ['mav_ttm_var_relicReward2',false] }";
	};

	class QuestMap {
		title = "Collect Map Piece";
		action = "[SG_Interaction_Target] call SG_fnc_mapQuest";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { SG_Interaction_Target in [SG_MapCrate1,SG_MapCrate2,SG_MapCrate3] && ((getModelInfo SG_Interaction_Target) # 0) isEqualTo 'plp_ct_woodboxhuge.p3d'}";
	};

	class Relic1 {
		title = "Collect Relic";
		action = "[] spawn SG_fnc_relic1";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Relic1' in SG_Interaction_VVN && life_inv_relic1 isEqualto 0 }";
	};

	class Relic2 {
		title = "Collect Relic";
		action = "[] spawn SG_fnc_relic2";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Relic2' in SG_Interaction_VVN && life_inv_relic2 isEqualto 0 }";
	};

	class Relic3 {
		title = "Collect Relic";
		action = "[] spawn SG_fnc_relic3";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Relic3' in SG_Interaction_VVN && life_inv_relic3 isEqualto 0 }";
	};

	class Relic4 {
		title = "Collect Relic";
		action = "[] spawn SG_fnc_relic4";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'Relic4' in SG_Interaction_VVN && life_inv_relic4 isEqualto 0 }";
	};

	class BailMan {
		title = "Post Bail";
		action = "[] spawn SG_fnc_postBail";
		check = "alive SG_Interaction_Target && { 'BailMan' in SG_Interaction_VVN && playerSide isEqualto civilian && life_is_arrested }";
	};

	class GatherUnknown {
		title = "Gather Unknown";
		action = "[] spawn SG_fnc_gatherResearch";
		check = "alive SG_Interaction_Target && { 'GatherQuestion' in SG_Interaction_VVN && playerSide isEqualto civilian && isNull (objectParent player) && SG_Int_Distance < 4 }";
	};

	class AntiMatterSample {
		title = "Take Sample";
		action = "[] spawn SG_fnc_antiMatterSample";
		check = "alive SG_Interaction_Target && { ((getModelInfo SG_Interaction_Target) # 0) isEqualTo 'jd_antimatter.p3d' && playerSide isEqualto civilian && isNull (objectParent player) && SG_Int_Distance < 4 && life_inv_antiMatter <= 0 && missionNamespace getVariable ['SG_Skills_relicReward3',0] isEqualTo 1 }";
	};

	class DonatorWeapons {
		title = "Donator Weapons";
		action = "['donatorWeapons'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && { 'Rebel' in SG_Interaction_VVN && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) && (call life_donorlevel >= 2) && SG_Int_Distance < 5 }";
	};

	class GangShop {
		title = "Gang Weapons";
		action = "['gangWeapons'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && { 'GangWeapons' in SG_Interaction_VVN && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) && SG_Int_Distance < 5 }";
	};

	class RebelShop {
		title = "Rebel Weapons";
		action = "['rebelNormal'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && { 'Rebel' in SG_Interaction_VVN && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) && SG_Int_Distance < 5 && license_civ_reb }";
	};

	class AdvRebelShop {
		title = "Advanced Rebel Weapons";
		action = "['rebelAdvanced'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && { 'Rebel' in SG_Interaction_VVN && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) && SG_Int_Distance < 5 && license_civ_AdvReb }";
	};

	class RebelClothingShop {
		title = "Rebel Clothing";
		action = "['rebel'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && { 'Rebel' in SG_Interaction_VVN && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) && SG_Int_Distance < 5 && license_civ_reb }";
	};

	class RebelMarket {
		title = "Rebel Market";
		action = "[SG_Interaction_Target,'','','rebel'] spawn SG_fnc_virt_menu;";
		check = "alive SG_Interaction_Target && { 'Rebel' in SG_Interaction_VVN && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) && SG_Int_Distance < 5 && license_civ_reb }";
	};

	class WarpointShop {
		title = "Warpoint Weapons";
		action = "['warpoint'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && { 'Warpoint' in SG_Interaction_VVN && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) && SG_Int_Distance < 5 && license_civ_reb }";
	};

	class Market {
		title = "Market";
		action = "[SG_Interaction_Target,'','','market'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('Market' in SG_Interaction_VVN || [SG_Interaction_Target, 'GenStore'] call SG_Lib_isPlayerShop) }";
	};

	class IllegalMarket {
		title = "Illegal Market";
		action = "[SG_Interaction_Target,'','','illegal'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'illegalm' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class IllegalClothing {
		title = "Illegal Clothing/Utils";
		action = "['illegal'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'illegalm' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class FarmingMarket {
		title = "Farming Market";
		action = "[SG_Interaction_Target,'','','farming'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'Farming' in SG_Interaction_VVN }";
	};

	class GasMarket {
		title = "Station Market";
		action = "[SG_Interaction_Target,'','','f_station_coffee'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'GasStation' in SG_Interaction_VVN }";
	};

	class LotteryTicket {
		title = "Buy Lotto Ticket";
		action = "[player] remoteExec ['SG_CheckTick',2];";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'GasStation' in SG_Interaction_VVN }";
	};

	class GasGeneralStore {
		title = "Station Store";
		action = "['f_station_store'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'GasStation' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class GeneralStore {
		title = "General Store";
		action = "['genstore'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('GenStore' in SG_Interaction_VVN || [SG_Interaction_Target, 'GenStore'] call SG_Lib_isPlayerShop) && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) }";
	};

	class WeaponShop {
		title = "Weapon Shop";
		action = "['gun'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('GunStore' in SG_Interaction_VVN || [SG_Interaction_Target, 'GunStore'] call SG_Lib_isPlayerShop) && license_civ_gun && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) }";
	};

	class WongsGunStore {
		title = "Weapon Store";
		action = "['WongsGuns'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('Wongs' in SG_Interaction_VVN && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA'])) }";
	};

	class RifleShop {
		title = "Rifle Shop";
		action = "['rifle'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('RifleStore' in SG_Interaction_VVN || [SG_Interaction_Target, 'RifleStore'] call SG_Lib_isPlayerShop) && license_civ_rifle && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) }";
	};

	class RifleLicense {
		title = "Rifle Lisc. - $27,500";
		action = "['rifle'] spawn SG_fnc_buyLicense;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('RifleStore' in SG_Interaction_VVN || [SG_Interaction_Target, 'GunStore'] call SG_Lib_isPlayerShop) && !license_civ_rifle && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) }";
	};

	// class GunClothing {
	// 	title = "Protection";
	// 	action = "['gun_clothing'] spawn SG_fnc_clothingMenu;";
	// 	check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('GunStore' in SG_Interaction_VVN || [SG_Interaction_Target, 'GunStore'] call SG_Lib_isPlayerShop) && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) }";
	// };

	class WeaponShopLicense {
		title = "Gun Lisc. - $22,500";
		action = "['gun'] spawn SG_fnc_buyLicense;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('GunStore' in SG_Interaction_VVN || [SG_Interaction_Target, 'GunStore'] call SG_Lib_isPlayerShop) && !license_civ_gun && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) }";
	};

	class ClothingShop {
		title = "Bruce's Clothing";
		action = "['bruce'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('ClothingShop' in SG_Interaction_VVN || [SG_Interaction_Target, 'ClothingShop'] call SG_Lib_isPlayerShop) && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) }";
	};

	class DivingGear {
		title = "Diving Gear";
		action = "['dive'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && 'CivB' in SG_Interaction_VVN && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) && !(player getVariable ['inHostage',false]) && license_civ_dive";
	};

	class ChopShop {
		title = "Chop Shop";
		action = "['chop_shop_3'] call SG_ChopshopOpen";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'ChopShop' in SG_Interaction_VVN && playerSide isEqualto civilian }";
	};

	class VehicleShop {
		title = "Vehicle Shop";
		action = "['civ_car','civ','Normal Cars'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('VehicleShop' in SG_Interaction_VVN || [SG_Interaction_Target, 'VehicleShop'] call SG_Lib_isPlayerShop) && (playerSide isEqualto civilian || (call life_copdept) IN ['CIA']) }";
	};

	class LuxuryShop {
		title = "Luxury Vehicles";
		action = "['civ_car_luxury','civ','Luxury Dealership'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'LuxuryVehShop' in SG_Interaction_VVN && (playerSide isEqualto civilian || (call life_copdept) IN ['CIA'])  && license_civ_driver }";
	};

	// class SportsVehicleShop {
	// 	title = "High End Vehicles";
	// 	action = "['civ_car_sports','civ','High End Vehicle Store'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
	// 	check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'LuxuryVehShop' in SG_Interaction_VVN && (playerSide isEqualto civilian || (call life_copdept) IN ['CIA']) && license_civ_driver }";
	// };

	class RebVehicleShop {
		title = "Rebel Vehicle Shop";
		action = "['reb_car','civ','Normal Cars'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('CarsR' in SG_Interaction_VVN || [SG_Interaction_Target, 'VehicleShop'] call SG_Lib_isPlayerShop) && (playerSide isEqualto civilian || (call life_copdept) IN ['CIA'])}";
	};

	class AdvRebVehicleShop {
		title = "Advanced Rebel Vehicle Shop";
		action = "['adv_reb_car','civ','Advanced Rebel'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('CarsR' in SG_Interaction_VVN || [SG_Interaction_Target, 'VehicleShop'] call SG_Lib_isPlayerShop) && (playerSide isEqualto civilian && license_civ_AdvReb || (call life_copdept) IN ['CIA'])}";
	};

	class TruckShop {
		title = "Truck Shop";
		action = "['civ_truck','civ','New & Used Trucks'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Truck';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'TruckShop' in SG_Interaction_VVN && isNull (objectParent player) && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) }";
	};

	class BoatShop {
		title = "Boat Shop";
		action = "['civ_ship','civ','Lewis'' Boat Rentals & Ownership'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Boat';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CivB' in SG_Interaction_VVN && isNull (objectParent player) && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) && license_civ_driver }";
	};

	class BoatGarage {
		title = "Garage";
		action = "['Boat'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CivB' in SG_Interaction_VVN && isNull (objectParent player) && playerSide isEqualto civilian }";
	};

	class StoreBoat {
		title = "Store Boat";
		action = "[] spawn SG_fnc_storeVehicle;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CivB' in SG_Interaction_VVN && isNull (objectParent player) && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_garage_store }";
	};

	class AirShop {
		title = "Air Shop";
		action = "['civ_air','civ','Airial Autos'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Air';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'AirShop' in SG_Interaction_VVN && isNull (objectParent player) && (playerSide isEqualto civilian || call (life_copdept) IN ['CIA']) }";
	};

	class AirGarage {
		title = "Air Garage";
		action = "['Air'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'AirShop' in SG_Interaction_VVN && isNull (objectParent player) && (playerSide isEqualto civilian || call (life_copdept) IN ['CIA']) }";
	};

	class StoreGarageAir {
		title = "Store Vehicle";
		action = "[] spawn SG_fnc_storeVehicle;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'AirShop' in SG_Interaction_VVN && isNull (objectParent player) && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) && !(player getVariable ['inHostage',false]) && !life_garage_store }";
	};

	class RebAirShop {
		title = "Rebel Air Shop";
		action = "['reb_air','civ','Rebel Aircraft'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Air';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'RebAir' in SG_Interaction_VVN && isNull (objectParent player) && (playerSide isEqualto civilian && license_civ_reb || call (life_copdept) IN ['CIA']) }";
	};

	class AdvRebAirShop {
		title = "Advanced Rebel Air Shop";
		action = "['adv_reb_air','civ','Rebel Aircraft'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Air';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'RebAir' in SG_Interaction_VVN && isNull (objectParent player) && (playerSide isEqualto civilian && license_civ_AdvReb || call (life_copdept) IN ['CIA']) }";
	};

	class RebAirGarage {
		title = "Air Garage";
		action = "['Air'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'RebAir' in SG_Interaction_VVN && isNull (objectParent player) && (playerSide isEqualto civilian && license_civ_reb || call (life_copdept) IN ['CIA']) }";
	};

	class RebStoreGarageAir {
		title = "Store Vehicle";
		action = "[] spawn SG_fnc_storeVehicle;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'RebAir' in SG_Interaction_VVN && isNull (objectParent player) && (playerSide isEqualto civilian && license_civ_reb || call (life_copdept) IN ['CIA']) && !(player getVariable ['inHostage',false]) && !life_garage_store }";
	};

	class Garage {
		title = "Vehicle Garage";
		action = "['Car'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CarGarage' in SG_Interaction_VVN && isNull (objectParent player) }";
	};

	class StoreGarage {
		title = "Store Vehicle";
		action = "[] spawn SG_fnc_storeVehicle;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CarGarage' in SG_Interaction_VVN && isNull (objectParent player) && !(player getVariable ['inHostage',false]) && !life_garage_store }";
	};

	class FactionGarage {
		title = "Vehicle Garage";
		action = "['Car',true] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { !(player getVariable ['inHostage',false]) && isNull (objectParent player) && (('GangGarage' in SG_Interaction_VVN && (group player) getVariable ['gang_id',-1] isEqualto (missionNameSpace getVariable ['SG_GangHideout1',0])) || ('GangGarage' in SG_Interaction_VVN && (group player) getVariable ['gang_id',-1] isEqualto (missionNameSpace getVariable ['SG_GangHideout1',0]))) }";
	};

	class FactionStoreGarage {
		title = "Store Vehicle";
		action = "[] spawn SG_fnc_storeVehicle;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { isNull (objectParent player) && !(player getVariable ['inHostage',false]) && !life_garage_store && (('GangGarage' in SG_Interaction_VVN && (group player) getVariable ['gang_id',-1] isEqualto (missionNameSpace getVariable ['SG_GangHideout1',0])) || ('GangGarage' in SG_Interaction_VVN && (group player) getVariable ['gang_id',-1] isEqualto (missionNameSpace getVariable ['SG_GangHideout1',0]))) }";
	};

	class DriverLicense {
		title = "Drivers License - $3,000";
		action = "['driver'] spawn SG_fnc_buyLicense;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('Licenses' in SG_Interaction_VVN || [SG_Interaction_Target, 'Licenses'] call SG_Lib_isPlayerShop) && isNull (objectParent player) && !license_civ_driver && playerSide isEqualTo civilian }";
	};

	// class BoatLicense {
	// 	title = "Boat Lisc. - $3,500";
	// 	action = "['boat'] spawn SG_fnc_buyLicense;";
	// 	check = "alive SG_Interaction_Target && { ('Licenses' in SG_Interaction_VVN || [SG_Interaction_Target, 'Licenses'] call SG_Lib_isPlayerShop) && isNull (objectParent player) && !license_civ_boat && playerSide isEqualTo civilian }";
	// };

	class TruckLicense {
		title = "Truck Lisc. - $12,500";
		action = "['trucking'] spawn SG_fnc_buyLicense;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('Licenses' in SG_Interaction_VVN || [SG_Interaction_Target, 'Licenses'] call SG_Lib_isPlayerShop) && isNull (objectParent player) && !license_civ_trucking && playerSide isEqualTo civilian }";
	};

	class DivingLicense {
		title = "Diving Licence - $4,000";
		action = "['dive'] spawn SG_fnc_buyLicense;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CivB' in SG_Interaction_VVN && isNull (objectParent player) && !license_civ_dive && playerSide isEqualTo civilian }";
	};

	class RebelLicense {
		title = "Rebel License - $100,000";
		action = "['reb'] spawn SG_fnc_buyLicense;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'Rebel' in SG_Interaction_VVN && isNull (objectParent player) && !license_civ_reb && playerSide isEqualTo civilian }";
	};

	class AdvRebelLicense {
		title = "Advanced Rebel - $750,000";
		action = "['AdvReb'] spawn SG_fnc_buyLicense;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'Rebel' in SG_Interaction_VVN && isNull (objectParent player) && !license_civ_AdvReb && playerSide isEqualTo civilian }";
	};

	class ImpoundLot {
		title = "Impound Lot";
		action = "['Impound'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'ImpoundLot' in SG_Interaction_VVN && isNull (objectParent player) }";
	};

	class ImpoundMenu {
		title = "Impound Menu";
		action = "call SG_ImpoundVehicleMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'ImpoundLot' in SG_Interaction_VVN && player getVariable ['SG_Job','Unemployed'] isEqualto 'Tow Truck Driver' && playerSide == civilian }";
	};

	class RobStore {
		title = "Rob Store";
		action = "[SG_Interaction_Target,player] spawn SG_fnc_robShops;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { (['RifleStore','GunStore','GasStation','GenStore','ClothingShop','Market'] findIf { _x in SG_Interaction_VVN }) isNotEqualTo -1 && isNull (objectParent player) && (playerSide isEqualTo civilian || call (life_copdept) IN ['CIA']) }";
	};

	class TransportMissions {
		title = "Start Mission";
		action = "['Update coming to this, please stand by for this.',true] spawn SG_Noty";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'TransportMission' in SG_Interaction_VVN && isNull (objectParent player) && playerSide isEqualTo civilian }";
	};

	class ItemShopCop {
		title = "Item Shop";
		action = "[SG_Interaction_Target,'','','cop'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { (['CopShop','CIAShop'] findIf { _x in SG_Interaction_VVN }) isNotEqualTo -1 && playerSide isEqualto west && !(player getVariable ['inHostage',false]) }";
	};

	class ClothingShopCop {
		title = "Police Clothing";
		action = "['cop'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopShop' in SG_Interaction_VVN && playerSide isEqualto west && !(player getVariable ['inHostage',false]) }";
	};

	class ItemShopOpf {
		title = "Item Shop";
		action = "[SG_Interaction_Target,'','','opf'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'OpfShop' in SG_Interaction_VVN && playerSide isEqualto east && !(player getVariable ['inHostage',false]) }";
	};

	class ClothingShopOpf {
		title = "Opfor Clothing";
		action = "['opf'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'OpfShop' in SG_Interaction_VVN && playerSide isEqualto east && !(player getVariable ['inHostage',false]) }";
	};

	class ClothingShopCopCiv {
		title = "Civilian Clothing";
		action = "['bruce'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CIAShop' in SG_Interaction_VVN && playerSide isEqualto west && call life_copdept IN ['CIA'] && !(player getVariable ['inHostage',false]) }";
	};

	class ClothingShopCopRebel {
		title = "Rebel Clothing";
		action = "['rebel'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CIAShop' in SG_Interaction_VVN && playerSide isEqualto west && call life_copdept IN ['CIA'] && !(player getVariable ['inHostage',false]) }";
	};

	class ClothingShopCIA {
		title = "CIA Clothing";
		action = "['CIA'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CIAShop' in SG_Interaction_VVN && playerSide isEqualto west && !(player getVariable ['inHostage',false]) }";
	};

	class WeaponShopCIA {
		title = "CIA Weapons";
		action = "['CIA'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CIAShop' in SG_Interaction_VVN && playerSide isEqualto west && !(player getVariable ['inHostage',false]) }";
	};

	class fortBluforShop {
		title = "Fortifications Shop";
		action = "[SG_Interaction_Target,'','','fortBluforShop'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'fortBluforShop' in SG_Interaction_VVN && playerSide isEqualto west && !(player getVariable ['inHostage',false]) }";
	};

	class fortOpforShop {
		title = "Fortifications Shop";
		action = "[SG_Interaction_Target,'','','fortOpforShop'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'fortOpforShop' in SG_Interaction_VVN && playerSide isEqualto east && !(player getVariable ['inHostage',false]) }";
	};

	class ClothingShopDOJ {
		title = "DOJ Clothing";
		action = "['DOJC'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { (['CopShop','DOJShop'] findIf { _x in SG_Interaction_VVN }) isNotEqualTo -1 && (license_civ_DOJ || call life_copdept isEqualTo 'DOJ') && !(player getVariable ['inHostage',false]) }";
	};

	class WeaponShopCop {
		title = "Police Weapons";
		action = "['cop'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopShop' in SG_Interaction_VVN && playerSide isEqualto west && !(player getVariable ['inHostage',false]) }";
	};

	class WeaponShopOpf {
		title = "Opfor Weapons";
		action = "['opf'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'OpfShop' in SG_Interaction_VVN && playerSide isEqualto east && !(player getVariable ['inHostage',false]) }";
	};

	class RefillMagsCop {
		title = "Refill Mags";
		action = "[] spawn SG_fnc_refillMags;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { (['CopShop','CIAShop'] findIf { _x in SG_Interaction_VVN }) isNotEqualTo -1 && playerSide isEqualto west && !(player getVariable ['inHostage',false]) }";
	};

	class RefillMagsOpf {
		title = "Refill Mags";
		action = "[] spawn SG_fnc_refillMags;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'OpfShop' in SG_Interaction_VVN && playerSide isEqualto east && !(player getVariable ['inHostage',false]) }";
	};

	class RefillMagsCiv {
		title = "Refill Mags";
		action = "[] spawn SG_fnc_refillMags;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'Rebel' in SG_Interaction_VVN && playerSide isEqualto civilian && !(player getVariable ['inHostage',false]) }";
	};

	class VehicleShopCop {
		title = "Vehicle Shop";
		action = "['cop_car','cop','Police Vehicle Shop'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopGarage' in SG_Interaction_VVN && playerSide isEqualto west && !(player getVariable ['inHostage',false]) }";
	};

	class VehicleShopOpf {
		title = "Vehicle Shop";
		action = "['opf_car','opf','Opfor Vehicle Shop'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'OpfGarage' in SG_Interaction_VVN && playerSide isEqualto east && !(player getVariable ['inHostage',false]) }";
	};

	class VehicleShopCopCiv {
		title = "Civilian Vehicle Shop";
		action = "['civ_car','cop','Civilian Vehicle Shop'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopGarage' in SG_Interaction_VVN && playerSide isEqualto west && call life_copdept IN ['CIA'] && !(player getVariable ['inHostage',false]) }";
	};

	class VehicleShopCopRebel {
		title = "Rebel Vehicle Shop";
		action = "['reb_car','cop','Rebel Vehicle Shop'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopGarage' in SG_Interaction_VVN && playerSide isEqualto west && call life_copdept IN ['CIA'] && !(player getVariable ['inHostage',false]) }";
	};

	class VehicleShopCopUC {
		title = "CIA Vehicle Shop";
		action = "['uc_car','cop','CIA Shop'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopGarage' in SG_Interaction_VVN && playerSide isEqualto west && call life_copdept IN ['CIA'] && !(player getVariable ['inHostage',false]) }";
	};

	class WarVehicleShopCop {
		title = "War Vehicle Shop";
		action = "['cop_war','cop','BLUFOR Wartime Vehicle Shop'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopGarage' in SG_Interaction_VVN && playerSide isEqualto west && !(player getVariable ['inHostage',false]) }";
	};

	class WarVehicleShopOpf {
		title = "War Vehicle Shop";
		action = "['opf_war','opf','OPFOR Wartime Vehicle Shop'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'OpfGarage' in SG_Interaction_VVN && playerSide isEqualto east && !(player getVariable ['inHostage',false]) }";
	};

	class GarageCop {
		title = "Vehicle Garage";
		action = "['Car'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopGarage' in SG_Interaction_VVN && playerSide isEqualto west && !(player getVariable ['inHostage',false]) }";
	};

	class GarageOpf {
		title = "Vehicle Garage";
		action = "['Car'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'OpfGarage' in SG_Interaction_VVN && playerSide isEqualto east && !(player getVariable ['inHostage',false]) }";
	};

	class StoreGarageCop {
		title = "Store Vehicle";
		action = "[] spawn SG_fnc_storeVehicle;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopGarage' in SG_Interaction_VVN && playerSide isEqualTo west && !(player getVariable ['inHostage',false]) && !life_garage_store }";
	};

	class StoreGarageOpf {
		title = "Store Vehicle";
		action = "[] spawn SG_fnc_storeVehicle;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'OpfGarage' in SG_Interaction_VVN && playerSide isEqualTo east && !(player getVariable ['inHostage',false]) && !life_garage_store }";
	};

	class AirShopCop {
		title = "Air Shop";
		action = "['cop_air','cop','Police Helis'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Air';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopAir' in SG_Interaction_VVN && playerSide isEqualTo west && !(player getVariable ['inHostage',false]) }";
	};

	class AirShopOpf {
		title = "Air Shop";
		action = "['opf_air','opf','Opfor Helis'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Air';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'OpfAir' in SG_Interaction_VVN && playerSide isEqualTo east && !(player getVariable ['inHostage',false]) }";
	};

	class AirWarShopCop {
		title = "Wartime Air Shop";
		action = "['cop_war_air','cop','BLUFOR Wartime Aircraft Shop'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Air';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopWarAir' in SG_Interaction_VVN && playerSide isEqualTo west && !(player getVariable ['inHostage',false]) }";
	};

	class AirWarShopOpf {
		title = "Wartime Air Shop";
		action = "['opf_war_air','opf','OFPOR Wartime Aircraft Shop'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Air';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'OpfWarAir' in SG_Interaction_VVN && playerSide isEqualTo east && !(player getVariable ['inHostage',false]) }";
	};

	class AirGarageCop {
		title = "Air Garage";
		action = "['Air'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopAir' in SG_Interaction_VVN && playerSide isEqualTo west && !(player getVariable ['inHostage',false]) }";
	};

	class AirGarageOpf {
		title = "Air Garage";
		action = "['Air'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'OpfAir' in SG_Interaction_VVN && playerSide isEqualTo east && !(player getVariable ['inHostage',false]) }";
	};

	class StoreGarageAirCop {
		title = "Store Vehicle";
		action = "[] spawn SG_fnc_storeVehicle;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopAir' in SG_Interaction_VVN && isNull (objectParent player) && playerSide isEqualTo west && !(player getVariable ['inHostage',false]) && !life_garage_store }";
	};

	class StoreGarageAirOpf {
		title = "Store Vehicle";
		action = "[] spawn SG_fnc_storeVehicle;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'OpfAir' in SG_Interaction_VVN && isNull (objectParent player) && playerSide isEqualTo east && !(player getVariable ['inHostage',false]) && !life_garage_store }";
	};

	class BoatShopCop {
		title = "Boat Shop";
		action = "['cop_boat','cop','Police's Boats and Watercraft'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Boat';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopBoat' in SG_Interaction_VVN && playerSide isEqualto west && !(player getVariable ['inHostage',false]) }";
	};

	class BoatGarageCop {
		title = "Garage";
		action = "['Boat'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'CopBoat' in SG_Interaction_VVN && playerSide isEqualto west && !(player getVariable ['inHostage',false]) }";
	};

	class CopDivingGear {
		title = "Diving Gear";
		action = "['cop_boat'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && 'CopBoat' in SG_Interaction_VVN && playerSide isEqualTo west && !(player getVariable ['inHostage',false])";
	};

	class BoatShopEMS {
		title = "Boat Shop";
		action = "['ems_boat','med','EMS Boats and Watercraft'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Boat';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'EMSB' in SG_Interaction_VVN && playerSide isEqualto independent && !(player getVariable ['inHostage',false]) }";
	};

	class BoatGarageEMS {
		title = "Garage";
		action = "['Boat'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'EMSB' in SG_Interaction_VVN && playerSide isEqualto independent && !(player getVariable ['inHostage',false]) }";
	};

	class MedDivingGear {
		title = "Diving Gear";
		action = "['ems_boat'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && 'EMSB' in SG_Interaction_VVN && playerSide isEqualTo independent && !(player getVariable ['inHostage',false])";
	};

	class DropFishingNet {
		title = "Drop Net";
		action = "[] spawn SG_fnc_dropFishingNet;";
		check = "(surfaceisWater (getPos vehicle player)) && (vehicle player isKindOf 'Ship') && life_carryWeight < life_maxWeight && speed (vehicle player) < 2 && speed (vehicle player) > -1 && !life_net_dropped";
	};

	class PlaceSpike {
		title = "Place Spikestrip";
		action = "detach life_spikeStrip; life_spikeStrip = objNull;";
		check = "!isNull life_spikestrip && { isNull (objectParent player) }";
	};

	class PackupSpike {
		title = "Packup Spikestrip";
		action = "[] spawn SG_fnc_packupSpikes";
		check = "_spikes = nearestObjects[getPos player,['Land_JD_SpikeStrip'],8] select 0; !isNil '_spikes' && SG_Int_Distance < 5 && !isNil {(_spikes getVariable 'SG_DroppedItem')}";
	};

	class HealHospital {
		title = "Medical Aid - $50";
		action = "[SG_Interaction_Target] spawn SG_fnc_healHospital";
		check = "'HealStand' in SG_Interaction_VVN && SG_Int_Distance < 5";
	};

	class PatrolMissionsCop {
		title = "Patrol Missions";
		action = "[] spawn SG_ReceivePatrolMission";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('CopShop' in SG_Interaction_VVN) && playerSide isEqualTo west }";
	};

	class PatrolMissionsOpfor {
		title = "Patrol Missions";
		action = "[] spawn SG_ReceivePatrolMission";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('OpfShop' in SG_Interaction_VVN) && playerSide isEqualTo east }";
	};

	class PatrolMissionsMedic {
		title = "Patrol Missions";
		action = "[] spawn SG_ReceivePatrolMission";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('MedicShop' in SG_Interaction_VVN) && playerSide isEqualTo independent }";
	};

	class ItemShopMedic {
		title = "Item Shop";
		action = "[SG_Interaction_Target,'','','med_market'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('MedicShop' in SG_Interaction_VVN || typeOf SG_Interaction_Target IN ['SG_EMS_Ambulance','d3s_fseries_17_Rescue','d3s_FredM2_EMS','MM_Pierce_Arrow_XT_Hevy','MM_Pierce_Arrow_XT_Engine_Short']) && playerSide isEqualTo independent }";
	};

	class WeaponShopMedic {
		title = "Utility Shop";
		action = "['med_basic'] spawn SG_fnc_weaponShopMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('MedicShop' in SG_Interaction_VVN || typeOf SG_Interaction_Target IN ['d3s_fseries_17_Rescue','d3s_FredM2_EMS','MM_Pierce_Arrow_XT_Hevy','MM_Pierce_Arrow_XT_Engine_Short']) && playerSide isEqualTo independent }";
	};

	class ClothingShopMedic {
		title = "Clothing Shop";
		action = "['med_clothing'] spawn SG_fnc_clothingMenu;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { ('MedicShop' in SG_Interaction_VVN || typeOf SG_Interaction_Target IN ['d3s_fseries_17_Rescue','d3s_FredM2_EMS','MM_Pierce_Arrow_XT_Hevy','MM_Pierce_Arrow_XT_Engine_Short']) && playerSide isEqualTo independent }";
	};

	class VehicleShopMedic {
		title = "Vehicle Shop";
		action = "['med_shop','med','Medic Vehicle Shop'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Car';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'MedicGarage' in SG_Interaction_VVN && playerSide isEqualTo independent }";
	};

	class GarageMedic {
		title = "Vehicle Garage";
		action = "['Car'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'MedicGarage' in SG_Interaction_VVN && playerSide isEqualTo independent }";
	};

	class StoreGarageMedic {
		title = "Store Vehicle";
		action = "[] spawn SG_fnc_storeVehicle;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'MedicGarage' in SG_Interaction_VVN && playerSide isEqualTo independent && !life_garage_store }";
	};

	class AirMedShop {
		title = "Air Shop";
		action = "['med_air_hs','med','Medic Helis'] spawn SG_fnc_vehicleShopMenu; SG_CurrentVehicleShop = 'Air';";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'AirMedShop' in SG_Interaction_VVN && playerSide isEqualTo independent }";
	};

	class StoreGarageAirMed {
		title = "Store Vehicle";
		action = "[] spawn SG_fnc_storeVehicle;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'AirMedShop' in SG_Interaction_VVN && playerSide isEqualTo independent }";
	};

	class AirGarageMed {
		title = "Air Garage";
		action = "['Air'] spawn SG_Garage;";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && { 'AirMedShop' in SG_Interaction_VVN && playerSide isEqualto independent }";
	};

	/*class TakeHostage  {
		title = "Take Hostage";
		action = "[SG_Interaction_Target] spawn SG_TakeHostage;";
		check = "isNil 'SG_EnableHostage' && { isPlayer SG_Interaction_Target && (handgunWeapon player != '') && SG_Interaction_Target getVariable ['inHostage',false] isEqualto false && !(player getVariable ['inHostage',false]) && (currentWeapon player != '') && currentWeapon player != primaryWeapon player && isPlayer SG_Interaction_Target && (SG_Int_Distance < 2) && (([SG_Interaction_Target, player] call BIS_fnc_relativeDirTo) < 220) && (([SG_Interaction_Target, player] call BIS_fnc_relativeDirTo) > 130) && SG_Interaction_Target getVariable ['life_is_alive',true] && playerSide isEqualto civilian && !(player getVariable ['restrained',false]) }";
	};*/

	class ReleaseHostage {
		title = "Release Hostage";
		action = "SG_EnableHostage = false;";
		check = "!isNil 'SG_EnableHostage'";
	};

	class PointGunForward {
		title = "Point Gun Forward";
		action = "SG_HostageMode = 'shoot';";
		check = "!isNil 'SG_EnableHostage' && { missionNamespace getVariable ['SG_HostageMode',''] isEqualto 'hostage' }";
	};

	class PointGunHostage {
		title = "Point Gun at Hostage";
		action = "SG_HostageMode = 'hostage';";
		check = "!isNil 'SG_EnableHostage' && { missionNamespace getVariable ['SG_HostageMode',''] isEqualto 'shoot' }";
	};

	class CaptureHideout1 {
		title = "Capture Gang Hideout";
		action = "['GangHideout1',SG_Interaction_Target] spawn SG_CaptureBase";
		check = "playerSide isEqualTo civilian && { !isNil {(group player) getVariable 'gang_owner'} && SG_Int_Distance < 5 && 'GangHideout1' in SG_Interaction_VVN && ((SG_Interaction_Target getVariable ['owner',0]) != (group player getVariable ['gang_id',0])) && (!(SG_Interaction_Target getVariable ['inCapture',false])) }";
	};

	class CaptureArmsDealer {
		title = "Capture Arms Dealer";
		action = "['Arms Dealer',SG_Interaction_Target] spawn SG_CaptureBase";
		check = "playerSide isEqualTo civilian && { !isNil {(group player) getVariable 'gang_owner'} && SG_Int_Distance < 5 && 'SG_ArmsDealerFlag' in SG_Interaction_VVN && ((SG_Interaction_Target getVariable ['owner',0]) != (group player getVariable ['gang_id',0])) && (!(SG_Interaction_Target getVariable ['inCapture',false])) }";
	};

	class DecaptureArmsDealer {
		title = "Decapture Arms Dealer";
		action = "['Arms Dealer',SG_Interaction_Target] spawn SG_DecaptureBaseCop";
		check = "playerSide in [west, east] && { SG_Int_Distance < 5 && 'SG_ArmsDealerFlag' in SG_Interaction_VVN && ((SG_Interaction_Target getVariable ['owner',0]) != (group player getVariable ['gang_id',0])) && (!(SG_Interaction_Target getVariable ['inCapture',false])) }";
	};

	class DecaptureInsurgentBase {
		title = "Neutralise Insurgent Base";
		action = "['Insurgent',SG_Interaction_Target] spawn SG_DecaptureBaseCop";
		check = "playerSide in [west, east] && { SG_Int_Distance < 5 && 'SG_InsurgentFlag' in SG_Interaction_VVN && ((SG_Interaction_Target getVariable ['owner',0]) != (group player getVariable ['gang_id',0])) && (!(SG_Interaction_Target getVariable ['inCapture',false])) }";
	};

	class DecaptureCriminalBase {
		title = "Neutralise Criminal Base";
		action = "['Criminal',SG_Interaction_Target] spawn SG_DecaptureBaseCop";
		check = "playerSide in [west, east] && { SG_Int_Distance < 5 && 'SG_CriminalFlag' in SG_Interaction_VVN && ((SG_Interaction_Target getVariable ['owner',0]) != (group player getVariable ['gang_id',0])) && (!(SG_Interaction_Target getVariable ['inCapture',false])) }";
	};

	class CaptureInsurgent {
		title = "Capture Insurgent Base";
		action = "['Insurgent',SG_Interaction_Target] spawn SG_CaptureBase";
		check = "playerSide isEqualTo civilian && { !isNil {(group player) getVariable 'gang_owner'} && SG_Int_Distance < 5 && 'SG_InsurgentFlag' in SG_Interaction_VVN && ((SG_Interaction_Target getVariable ['owner',0]) != (group player getVariable ['gang_id',0])) && (!(SG_Interaction_Target getVariable ['inCapture',false])) }";
	};

	class CaptureCriminal {
		title = "Capture Criminal Base";
		action = "['Criminal',SG_Interaction_Target] spawn SG_CaptureBase";
		check = "playerSide isEqualTo civilian && { !isNil {(group player) getVariable 'gang_owner'} && SG_Int_Distance < 5 && 'SG_CriminalFlag' in SG_Interaction_VVN && ((SG_Interaction_Target getVariable ['owner',0]) != (group player getVariable ['gang_id',0])) && (!(SG_Interaction_Target getVariable ['inCapture',false])) }";
	};

	class TurninTruckChopShop {
		title = "Unload Truck";
		action = "['Chop',SG_Interaction_Target] spawn SG_HandIn";
		check = "playerSide isEqualTo civilian && { SG_Int_Distance < 40 && 'ChopShop' in SG_Interaction_VVN && !(isNull truckMissionVeh) && ((SG_Interaction_Target distance truckMissionVeh) <= 40) }";
	};

	class TurninTruckMissionCop {
		title = "Unload Truck";
		action = "['Cop',SG_Interaction_Target] spawn SG_HandIn";
		check = "playerSide isEqualTo west && { SG_Int_Distance < 40 && 'evidencelocker' in SG_Interaction_VVN && !(isNull truckMissionVeh) && ((SG_Interaction_Target distance truckMissionVeh) <= 40) }";
	};

	class JobMenu {
		title = "Job Menu";
		action = "closeDialog 0; call SG_JobMenu;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && (typeof SG_Interaction_Target == 'Land_Centrelink') && {SG_Int_Distance <= 6} }";
	};

	class PickupPaycheck {
		title = "Pickup Paycheck";
		action = "call SG_PickupPaycheck";
		check = "('PayCheck' in SG_Interaction_VVN || (typeof SG_Interaction_Target in (getArray (missionConfigFile >> 'CFGMaster' >> 'GameSettings' >> 'atm_types'))) && SG_Int_Distance < 5) || ((['CopShop','CIAShop'] findIf { _x in SG_Interaction_VVN }) isNotEqualTo -1 && playerSide isEqualto west) || ('OpfShop' in SG_Interaction_VVN && playerSide isEqualto east)";
	};

	class PickupItem {
		title = "Pickup Item";
		action = "CB = true; cbitem = SG_Interaction_Target; cbitem enableSimulationGlobal true; cbitem attachTo [player,[0.2,2.2,1.3]]; cbitem setpos [getpos cbitem select 0,getpos cbitem select 1,0];";
		check = "player isKindOf 'Man' && { player getVariable ['life_is_alive',false] && SG_Int_Distance <= 5 && SG_Interaction_Target getVariable 'CB_Item_Owner' isEqualTo getPlayerUID player && CB isEqualTo false }";
	};

	class PlaceItem {
		title = "Place Item";
		action = "[getPosATL cbitem,vectorUp cbitem,vectorDir cbitem,typeOf cbitem] remoteExec ['SG_PlaceItem',2]; deleteVehicle cbitem; CB=false;";
		check = "player isKindOf 'Man' && { player getVariable ['life_is_alive',false] && CB }";
	};

	class RemoveItem {
		title = "Remove Item";
		action = "[SG_Interaction_Target] call SG_CheckpointBuilderRemove;";
		check = "player isKindOf 'Man' && { player getVariable ['life_is_alive',false] && SG_Int_Distance <= 5 && SG_Interaction_Target getVariable 'CB_Item_Owner' isEqualto getPlayerUID player && CB isEqualTo false }";
	};

	class SeizeItems {
		title = "Seize Items";
		action = "call SG_SeizeWeapons;";
		check = "playerSide in [west, east] && { !(player getVariable ['inHostage',false]) && (count(nearestObjects [player,['weaponholder', 'JD_Box'],3])>0) && !(player getVariable ['playerSurrender',false]) && !(player getVariable ['restrained',false]) }";
	};

	class OpenDoor {
		title = "Lockpick Door";
		action = "[] spawn SG_OpenDoor;";
		check = "playerSide isEqualTo civilian && { player getVariable ['restrained',false] isEqualTo false && !(player getVariable ['inHostage',false]) && life_inv_lockpick > 0 && (typeOf SG_Interaction_Target) in ['Land_MainSection','Land_Gaol_Main','Land_M_Prison','Land_M_Prison_2','Land_M_Tower','Land_M_prisongate'] && !([SG_Interaction_Target] call SG_Lib_GetDoor isEqualto '') }";
	};

	class SearchEvidenceCop {
		title = "Search through Evidence";
		action = "[SG_Interaction_Target] spawn SG_SEARCHEVIDENCE;";
		check = "playerSide in [west, east] && { SG_Interaction_Target getVariable ['isEvidence',false] && SG_Int_Distance < 5 }";
	};

	class SearchEvidenceCiv {
		title = "Destroy Evidence";
		action = "[SG_Interaction_Target] spawn SG_SEARCHEVIDENCE;";
		check = "SG_Interaction_Target getVariable ['isEvidence',false] && { SG_Int_Distance < 10 && ((playerSide) isEqualTo civilian) }";
	};

	class TurnOffPower {
		title = "Override Power";
		action = "['TurnOff'] spawn SG_ManagePower;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && vehicleVarName SG_Interaction_Target == 'CPAPowerStation' && SG_Int_Distance < 3 && missionNamespace getVariable ['SG_Power',false] } && { life_inv_poweroverrider > 0 }";
	};

	class TurnOnPower {
		title = "Turn On Power";
		action = "['TurnOn'] spawn SG_ManagePower;";
		check = "playerSide in [west, east] && { !(player getVariable ['inHostage',false]) && vehicleVarName SG_Interaction_Target == 'CPAPowerStation' && SG_Int_Distance < 3 && !(missionNamespace getVariable ['SG_Power',false]) }";
	};

	class RobEvidenceLocker {
		title = "Rob Evidence Locker";
		action = "[SG_Interaction_Target,'Rob'] spawn SG_EvidenceLocker;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && vehicleVarName SG_Interaction_Target == 'evidencelocker' && SG_Int_Distance < 3 && !(SG_Interaction_Target getVariable ['SG_EvidenceOpen',false]) }";
	};

	class PlaceCharge {
		title = "Plant Blasting Charge";
		action = "[SG_Interaction_Target] call SG_PlantCharge;";
		check = "playerSide isEqualTo civilian && { life_inv_blastingcharge > 0 } && !(isNull SG_Interaction_Target) && {SG_Interaction_Target isEqualTo SG_PrisonGate} && { SG_Int_Distance < 5 } && {!(SG_Interaction_Target getVariable ['JailPlanted',false])}";
	};

	class FixJailGate {
		title = "Repair Prison Wall";
		action = "[SG_Interaction_Target] spawn SG_RepairGate;";
		check = "playerSide isEqualTo west && !(isNull SG_Interaction_Target) && 'jail_brokenWall' in SG_Interaction_VVN && { SG_Int_Distance < 5 }";
	};

	class FixEvidence {
		title = "Fix Evidence Locker";
		action = "[SG_Interaction_Target,'Fix'] spawn SG_EvidenceLocker";
		check = "playerSide in [west, east] && { !(player getVariable ['inHostage',false]) && vehicleVarName SG_Interaction_Target == 'evidencelocker' && SG_Int_Distance < 3 && SG_Interaction_Target getVariable ['SG_EvidenceOpen',false] }";
	};

	// class SearchGarbage {
	// 	title = "Search Through Garbage";
	// 	action = "[] spawn SG_SearchGarbage;";
	// 	check = "playerSide isEqualTo civilian && { !(player getVariable ['restrained', false]) && !(player getVariable ['inHostage',false]) && SG_Int_Distance < 3 && alive SG_Interaction_Target && 'SG_Garbage' in SG_Interaction_VVN }";
	// };

	class BreakDownDoor {
		title = "Break Down Door";
		action = "[SG_Interaction_Target] spawn SG_fnc_copBreakDoor; closeDialog 0;";
		check = "SG_Interaction_Target call SG_IsHouse && { playerSide in [west, independent] && !(player getVariable ['inHostage',false]) && SG_Int_Distance <= 25 && (isClass (missionConfigFile >> 'Housing' >> worldName >> (typeOf SG_Interaction_Target))) }";
	};

	class SearchHouse {
		title = "Search House";
		action = "[SG_Interaction_Target] call SG_fnc_raidHouse; closeDialog 0;";
		check = "SG_Interaction_Target call SG_IsHouse && { playerSide in [west, east] && !(player getVariable ['inHostage',false]) && !isNil {SG_Interaction_Target getVariable 'house_owner'} && SG_Int_Distance <= 25 }";
	};

	class HouseRegistration {
		title = "House Registration";
		action = "[SG_Interaction_Target] call SG_HouseRegistration; closeDialog 0;";
		check = "SG_Interaction_Target call SG_IsHouse && { playerSide in [west, east] && !(player getVariable ['inHostage',false]) && !isNil {SG_Interaction_Target getVariable 'house_owner'} && SG_Int_Distance <= 25 }";
	};

	class HouseRaid {
		title = "Raid Property";
		action = "[SG_Interaction_Target] spawn SG_HouseRaidStorage; closeDialog 0;";
		check = "SG_Interaction_Target call SG_IsHouse && { playerSide in [west, east] && !(player getVariable ['inHostage',false]) && !isNil {SG_Interaction_Target getVariable 'house_owner'} && SG_Int_Distance <= 25 }";
	};

	class LockupHouse {
		title = "Lockup House";
		action = "[SG_Interaction_Target] call SG_fnc_lockupHouse; closeDialog 0;";
		check = "SG_Interaction_Target call SG_IsHouse && { playerSide in [west, east] && !(player getVariable ['inHostage',false]) && !isNil {SG_Interaction_Target getVariable 'house_owner'} && SG_Int_Distance <= 25 }";
	};

	class BuyHouse {
		title = "Buy House";
		action = "closeDialog 0; [SG_Interaction_Target] spawn SG_fnc_buyHouse;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && isNil {SG_Interaction_Target getVariable 'house_owner'} && !(SG_Interaction_Target in life_vehicles) && SG_Int_Distance <= 12 && (isClass (missionConfigFile >> 'Housing' >> worldName >> (typeOf SG_Interaction_Target))) }";
	};

	class SellHouse {
		title = "Sell House";
		action = "closeDialog 0; [SG_Interaction_Target] spawn SG_fnc_sellHouse;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && ((SG_Interaction_Target getVariable 'house_owner') select 0) isEqualTo (getPlayerUID player) && SG_Int_Distance <= 15 && (isClass (missionConfigFile >> 'Housing' >> worldName >> (typeOf SG_Interaction_Target))) }";
	};

	class AccessGarageHouse {
		title = "Access Garage";
		action = "['Car',true] spawn SG_Garage;";
		check = "(isClass (missionConfigFile >> 'Housing' >> worldName >> (typeOf SG_Interaction_Target))) && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && ((SG_Interaction_Target getVariable 'house_owner') select 0) isEqualTo (getPlayerUID player) && SG_Int_Distance <= 15";
	};

	class StoreGarageHome {
		title = "Store Vehicle";
		action = "[] spawn SG_fnc_storeVehicle; closeDialog 0;";
		check = "(isClass (missionConfigFile >> 'Housing' >> worldName >> (typeOf SG_Interaction_Target))) && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && ((SG_Interaction_Target getVariable 'house_owner') select 0) isEqualTo (getPlayerUID player) && SG_Int_Distance <= 15";
	};

	class UnlockStorage {
		title = "Unlock Storage";
		action = "[SG_Interaction_Target] spawn SG_fnc_lockHouse; closeDialog 0;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && ((SG_Interaction_Target getVariable 'house_owner') select 0) isEqualTo (getPlayerUID player) && SG_Interaction_Target getVariable['locked',true] && SG_Int_Distance <= 15 && (isClass (missionConfigFile >> 'Housing' >> worldName >> (typeOf SG_Interaction_Target))) }";
	};

	class LockStorage {
		title = "Lock Storage";
		action = "[SG_Interaction_Target] spawn SG_fnc_lockHouse; closeDialog 0;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && ((SG_Interaction_Target getVariable 'house_owner') select 0) isEqualTo (getPlayerUID player) && !(SG_Interaction_Target getVariable ['locked',true]) && SG_Int_Distance <= 15 && (isClass (missionConfigFile >> 'Housing' >> worldName >> (typeOf SG_Interaction_Target))) }";
	};

	class LightsOn {
		title = "Turn Lights On";
		action = "[SG_Interaction_Target] spawn SG_fnc_lightHouse; closeDialog 0;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && ((SG_Interaction_Target getVariable 'house_owner') select 0) isEqualTo (getPlayerUID player) && isNull (SG_Interaction_Target getVariable ['lightSource',ObjNull]) && SG_Int_Distance <= 15 && (isClass (missionConfigFile >> 'Housing' >> worldName >> (typeOf SG_Interaction_Target))) }";
	};

	class LightsOff {
		title = "Turn Lights Off";
		action = "[SG_Interaction_Target] spawn SG_fnc_lightHouse; closeDialog 0;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && ((SG_Interaction_Target getVariable 'house_owner') select 0) isEqualTo (getPlayerUID player) && !isNull (SG_Interaction_Target getVariable ['lightSource',ObjNull]) && SG_Int_Distance <= 15 && (isClass (missionConfigFile >> 'Housing' >> worldName >> (typeOf SG_Interaction_Target))) }";
	};

	class MutePlayer {
		title = "Mute Player";
		action = "['Mute',SG_Interaction_Target] spawn SG_PlayerVoice;";
		check = "!(player getVariable ['inHostage',false]) && { SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Int_Distance <= 6 && isNull (objectParent player) && !(SG_Interaction_Target getVariable ['SG_Muted',false]) }";
	};

	class UnmutePlayer {
		title = "Unmute Player";
		action = "['Unmute',SG_Interaction_Target] spawn SG_PlayerVoice;";
		check = "!(player getVariable ['inHostage',false]) && { SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Int_Distance <= 6 && isNull (objectParent player) && SG_Interaction_Target getVariable ['SG_Muted',false] }";
	};

	class GiveItems {
		title = "Give Items";
		action = "call SG_GiveItems;";
		check = "SG_Interaction_Target isKindOf 'Man' && { SG_Int_Distance <= 5 && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && isNull (objectParent player) && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained', false]) && !(player getVariable ['playerSurrender',false]) }";
	};

	class GiveMoney {
		title = "Give Money";
		action = "[SG_Interaction_Target] call SG_GiveMoneyMenu;";
		check = "SG_Interaction_Target isKindOf 'Man' && { SG_Int_Distance <= 5 && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && isNull (objectParent player) && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained', false]) && !(player getVariable ['playerSurrender',false]) }";
	};

	class StabilizePlayer {
		title = "Stabilize Player";
		action = "closeDialog 0; [SG_Interaction_Target] spawn SG_StabilizePlayer";
		check = "life_inv_stabilizer > 0 && {isPlayer SG_Interaction_Target} && {!(player getVariable ['inHostage',false])} && {!(SG_Interaction_Target getVariable ['life_is_alive',false])} && {SG_Int_Distance <= 3} && {isNull (objectParent player)}";
	};

	class MedicalPlayer {
		title = "Medical";
		action = "[SG_Interaction_Target] spawn SG_OpenMedicalMenu;";
		check = "SG_Interaction_Target getVariable ['life_is_alive',false] && { (isPlayer SG_Interaction_Target) && playerSide isEqualto independent && !(player getVariable ['inHostage',false]) && SG_Int_Distance <= 4 && isNull (objectParent player) }";
	};

	class MedicalDeadPlayer {
		title = "Medical";
		action = "[SG_Interaction_Target,true] spawn SG_OpenMedicalMenu;";
		check = "!(isNull SG_Interaction_Target) && { !(alive SG_Interaction_Target) && playerSide isEqualto independent && !(player getVariable ['inHostage',false]) && SG_Int_Distance <= 4 && isNull (objectParent player) }";
	};

	class TiePerson {
		title = "Tie Player";
		action = "[] spawn SG_fnc_tieingAction; closeDialog 0;";
		check = "SG_Interaction_Target getVariable ['life_is_alive',false] && { isPlayer SG_Interaction_Target && !(SG_Interaction_Target getVariable ['restrained', false]) && SG_Int_Distance <= 3.5 && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && life_inv_zipties > 0 && ((animationState SG_Interaction_Target) == 'Incapacitated' || (animationState SG_Interaction_Target) == 'unconscious' || (animationState SG_Interaction_Target) == 'unconsciousoutprone' || SG_Interaction_Target getVariable 'playerSurrender') }";
	};

	class EscortPlayer {
		title = "Escort Player";
		action = "[SG_Interaction_Target] spawn SG_fnc_escortAction; closeDialog 0;";
		check = "(playerSide in [west, east] || (playerSide isEqualTo civilian && playerSide isEqualTo (SG_Interaction_Target getVariable ['restrainType',sideEmpty]))) && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && !(SG_Interaction_Target getVariable ['Escorting',false]) && SG_Int_Distance <= 6 && isNull (objectParent player) && ((SG_Interaction_Target getVariable['restrained',false]))  && !(player getVariable ['restrained',false]) && isNull (objectParent SG_Interaction_Target)";
	};

	class StopEscortPlayer {
		title = "Stop Player Escort";
		action = "call SG_fnc_stopEscorting; closeDialog 0;";
		check = "!(player getVariable ['inHostage',false]) && { player getVariable ['isEscorting',false] && isNull (objectParent player) }";
	};

	class EscortPlayerEMS {
		title = "Escort Player";
		action = "[SG_Interaction_Target] spawn SG_fnc_escortAction; closeDialog 0;";
		check = "call(life_mediclevel) > 0 && { playerSide isEqualTo independent && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && !(SG_Interaction_Target getVariable ['Escorting',false]) && SG_Int_Distance <= 6 && isNull (objectParent player) && !(player getVariable ['restrained',false]) && isNull (objectParent SG_Interaction_Target) }";
	};

	class Unrestrain {
		title = "Unrestrain Player";
		action = "[SG_Interaction_Target] spawn SG_fnc_unrestrain;";
		check = "(playerSide in [west, east] || (playerSide isEqualTo civilian && playerSide isEqualTo (SG_Interaction_Target getVariable ['restrainType',sideEmpty]))) && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Interaction_Target getVariable ['restrained',false] && SG_Int_Distance <= 6 && isNull (objectParent player) && !(player getVariable ['restrained',false])";
	};

	class CheckLicences {
		title = "Check Licenses";
		action = "[player] remoteExec ['SG_fnc_licenseCheck',SG_Interaction_Target]";
		check = "(playerSide in [west, east] || (playerSide isEqualTo civilian && playerSide isEqualTo (SG_Interaction_Target getVariable ['restrainType',sideEmpty]))) && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Interaction_Target getVariable ['restrained',false] && SG_Int_Distance <= 6 && isNull (objectParent player)";
	};

	class SearchPlayer {
		title = "Strip Search Player";
		action = "[SG_Interaction_Target] spawn SG_fnc_searchAction; closeDialog 0;";
		check = "playerSide in [west, east] && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Interaction_Target getVariable ['restrained',false] && SG_Int_Distance <= 6 && isNull (objectParent player)  && !(player getVariable ['restrained',false])";
	};

	class CheckResidue {
		title = "Check for Residue";
		action = "[SG_Interaction_Target] spawn SG_CheckResidue; closeDialog 0;";
		check = "life_inv_gsrTest > 0 && playerSide in [west, east] && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Interaction_Target getVariable ['restrained',false] && SG_Int_Distance <= 6 && isNull (objectParent player)  && !(player getVariable ['restrained',false])";
	};

	class WashHands {
		title = "Wash Hands";
		action = "[] spawn SG_WashHands; closeDialog 0;";
		check = "surfaceIsWater position player && !isNil {(player getVariable 'SG_LastShotResidue')} && isNull (objectParent player) && !(player getVariable ['restrained',false])";
	};

	class HarvestOrgans {
		title = "Harvest Organs";
		action = "[SG_Interaction_Target] spawn SG_HarvestOrgans; closeDialog 0;";
		check = " playerSide isEqualTo civilian && life_inv_scalpel > 0 && !(player getVariable ['inHostage',false]) && {SG_Interaction_target getVariable ['Corpse', false]} && {SG_Interaction_Target isKindOf 'Man'} && {playerSide isEqualTo civilian} && {!(SG_Interaction_Target getVariable ['life_is_alive',false])} && {SG_Int_Distance <= 3} && {isNull (objectParent player)}  && {!(player getVariable ['restrained',false])} && {!(SG_Interaction_Target getVariable ['SG_OrgansHarvested',false])}";
	};

	class SearchPlayerCiv {
		title = "Strip Search Player";
		action = "[] remoteExecCall ['SG_fnc_removeWeaponAction',SG_Interaction_Target]; closeDialog 0;";
		check = " playerSide isEqualTo civilian && { (playerSide isEqualTo (SG_Interaction_Target getVariable ['restrainType',sideEmpty])) && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Interaction_Target getVariable ['restrained',false] && SG_Int_Distance <= 6 && isNull (objectParent player) && !(player getVariable ['restrained',false]) }";
	};

	class ShacklePlayer {
		title = "Shackle Player";
		action = "[SG_Interaction_Target] spawn SG_ShaklePlayer; closeDialog 0;";
		check = "playerSide in [west, east] && (vehicle SG_Interaction_Target isEqualTo player) && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && !(SG_Interaction_Target getVariable ['Escorting',false]) && SG_Int_Distance <= 6 && isNull (objectParent player) && !(player getVariable ['restrained',false]) && !(SG_Interaction_Target getVariable ['SG_Shackled',false])";
	};

	class UnshacklePlayer {
		title = "Remove Shackles";
		action = "[SG_Interaction_Target] spawn SG_RemoveShackles; closeDialog 0;";
		check = "playerSide in [west, east] && SG_Interaction_Target getVariable ['SG_Shackled',false] && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && !(SG_Interaction_Target getVariable ['Escorting',false]) && SG_Int_Distance <= 6 && isNull (objectParent player) && !(player getVariable ['restrained',false])";
	};

	class BlindfoldPlayer {
		title = "Blindfold";
		action = "[] spawn SG_fnc_blindfoldAction";
		check = "life_inv_blindfold > 0 && { !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Interaction_Target getVariable ['restrained',false] && !(SG_Interaction_Target getVariable ['blindfolded',false]) && SG_Int_Distance <= 5 && isNull (objectParent player) && !(player getVariable ['restrained',false]) && !(player getVariable ['playerSurrender',false]) }";
	};

	class UnBlindfoldPlayer {
		title = "Remove Blindfold";
		action = "[SG_Interaction_Target] call SG_fnc_removeBlindfold";
		check = "!(player getVariable ['inHostage',false]) && { SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Interaction_Target getVariable ['restrained',false] && SG_Interaction_Target getVariable ['blindfolded',false] && SG_Int_Distance <= 5 && isNull (objectParent player) && !(player getVariable ['restrained',false]) && !(player getVariable ['playerSurrender',false]) }";
	};

	class TicketPlayer {
		title = "Ticket Player";
		action = "closeDialog 0; [SG_Interaction_Target] call SG_fnc_ticketAction;";
		check = "call(life_coplevel) > 0 && { playerSide isEqualTo west && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Int_Distance <= 6 && isNull (objectParent player) && side SG_Interaction_Target in [civilian, independent] }";
	};

	class ArrestPlayer {
		title = "Arrest Player";
		action = "closeDialog 0; [SG_Interaction_Target] spawn SG_fnc_openArrestMenu;";
		check = "call(life_coplevel) > 0 && { playerSide isEqualTo west && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Interaction_Target getVariable ['restrained',false] && SG_Int_Distance <= 6 && isNull (objectParent player) && (player distance (getMarkerPos 'cop_spawn_AirBase') < 150 || player distance (getMarkerPos 'cop_spawn_NATOHQ') < 150 || player distance (getMarkerPos 'cop_spawn_CIA') < 150 || player distance (getMarkerPos 'Takistan_Prison') < 150) && !(player getVariable ['restrained',false]) && side SG_Interaction_Target == civilian && !(missionNamespace getVariable ['life_is_arrested',false]) }";
	};

	class PutInCar {
		title = "Put Player In Car";
		action = "[SG_Interaction_Target] call SG_fnc_putInCar;";
		check = "(playerSide in [west, east] || (playerSide isEqualTo civilian && playerSide isEqualTo (SG_Interaction_Target getVariable ['restrainType',sideEmpty]))) && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Interaction_Target getVariable ['restrained',false] && SG_Int_Distance <= 5 && !(player getVariable ['restrained',false])";
	};

	class PutInCarEMS {
		title = "Put Player In Car";
		action = "[SG_Interaction_Target] call SG_fnc_putInCar;";
		check = "call(life_mediclevel) > 0 && { playerSide isEqualTo independent && !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable ['life_is_alive',false] && isPlayer SG_Interaction_Target && SG_Int_Distance <= 5 && !(player getVariable ['restrained',false]) }";
	};

	class RobPerson {
		title = "Rob Player";
		action = "call SG_fnc_robAction;";
		check = "SG_Interaction_Target getVariable ['life_is_alive',false] && { isPlayer SG_Interaction_Target && !(SG_Interaction_Target getVariable ['robbed',false]) && SG_Int_Distance <= 3.5 && ((animationState SG_Interaction_Target) == 'Incapacitated' || (animationState SG_Interaction_Target) == 'unconscious' || (animationState SG_Interaction_Target) == 'unconsciousoutprone' || SG_Interaction_Target getVariable ['playerSurrender',false] || (playerSide isEqualTo civilian && playerSide isEqualTo (SG_Interaction_Target getVariable ['restrainType',sideEmpty]))) && !(player getVariable ['restrained',false]) && !([playerSide, side SG_Interaction_Target] isEqualTo [west, west]) }";
	};

	class PushVehicle {
		title = "Push Vehicle";
		action = "[SG_Interaction_Target] spawn SG_fnc_pushVehicle; closeDialog 0;";
		check = "typeOf SG_Interaction_Target != 'GurneyTabl' && { (SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Air' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 8 && local SG_Interaction_Target && isNull (objectParent player) }";
	};

	class RepairVehicle {
		title = "Repair Vehicle";
		action = "[SG_Interaction_Target] spawn SG_fnc_repairVehicle; closeDialog 0;";
		check = "typeOf SG_Interaction_Target != 'GurneyTabl' && { (SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Air' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 8 && isNull (objectParent player) }";
	};

	class LockpickVehicle {
		title = "Lockpick Vehicle";
		action = "[] spawn SG_fnc_lockpick; closeDialog 0;";
		check = "typeOf SG_Interaction_Target != 'GurneyTabl' && { (SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Air' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 8 && life_inv_lockpick > 0 && isNull (objectParent player) && alive SG_Interaction_Target && locked SG_Interaction_Target isEqualTo 2 }";
	};

	class GPSVehicle {
		title = "Track Vehicle";
		action = "[SG_Interaction_Target] spawn SG_fnc_gpsTracker; closeDialog 0;";
		check = "(SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Air' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 8 && life_inv_gpstracker > 0 && isNull (objectParent player) && alive SG_Interaction_Target";
	};

	class FillVehicle {
		title = "Fill Vehicle";
		action = "[SG_Interaction_Target] spawn SG_fnc_gangConvoyFill; closeDialog 0;";
		check = "SG_Interaction_Target isKindOf 'Car' && { SG_Int_Distance <= 8 && typeOf SG_Interaction_Target isEqualto 'C_Truck_02_covered_F' && isNull (objectParent player) && alive SG_Interaction_Target && (SG_Interaction_Target getVariable ['convoyFilled',false]) && SG_Interaction_Target getVariable 'notFilled' && !(SG_Interaction_Target getVariable ['convoyFinished',false]) && SG_Interaction_Target getVariable 'convoyMid' }";
	};

	class DeliverSupplies {
		title = "Deliver Suppplies";
		action = "[SG_Interaction_Target] spawn SG_fnc_gangConvoyFinish; closeDialog 0;";
		check = "SG_Interaction_Target isKindOf 'Car' && { SG_Int_Distance <= 8 && typeOf SG_Interaction_Target isEqualto 'C_Truck_02_covered_F' && isNull (objectParent player) && alive SG_Interaction_Target && SG_Interaction_Target getVariable 'convoyFilled' && !(SG_Interaction_Target getVariable ['notFilled',false]) && SG_Interaction_Target getVariable 'convoyFinished' && !(SG_Interaction_Target getVariable ['convoyEnd',false]) }";
	};

	class Registration {
		title = "Registration";
		action = "[SG_Interaction_Target] call SG_fnc_searchVehAction; closeDialog 0;";
		check = "playerSide in [west, east] && { !(player getVariable ['inHostage',false]) && (SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Air' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 6 && isNull (objectParent player) &&  !(SG_Interaction_Target isEqualTo truckMissionVeh) }";
	};

	class SearchVehicle {
		title = "Search Vehicle";
		action = "[SG_Interaction_Target] spawn SG_fnc_vehInvSearch; closeDialog 0;";
		check = "playerSide in [west, east] && { !(player getVariable ['inHostage',false]) && (SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Air' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 6 && isNull (objectParent player) }";
	};

	class PulloutPlayers {
		title = "Pullout Players";
		action = "[SG_Interaction_Target] spawn SG_fnc_pulloutAction; closeDialog 0;";
		check = "playerSide in [west, east, independent] && { (SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Air' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 6 && isNull (objectParent player) && count crew SG_Interaction_Target > 0 && !(player getVariable ['restrained',false]) }";
	};

	class ImpoundVehicle {
		title = "Impound Vehicle";
		action = "[SG_Interaction_Target] spawn SG_fnc_impoundAction; closeDialog 0;";
		check = "playerSide in [west, east] && { !(player getVariable ['inHostage',false]) && (SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Air' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 6 && isNull (objectParent player) && !(SG_Interaction_Target isEqualTo truckMissionVeh) && !(player getVariable ['restrained',false]) }";
	};

	class PulloutPlayersCiv {
		title = "Pullout Players";
		action = "[SG_Interaction_Target] spawn SG_fnc_pulloutAction; closeDialog 0;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && SG_Interaction_Target in life_vehicles && (SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Air' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 6 && isNull (objectParent player) && count crew SG_Interaction_Target > 0 && !(player getVariable ['restrained',false]) }";
	};

	class ImpoundVehicleMed {
		title = "Impound Vehicle";
		action = "[SG_Interaction_Target] spawn SG_fnc_impoundAction; closeDialog 0;";
		check = "call(life_mediclevel) > 0 && { playerSide isEqualTo independent && (SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Air' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 6 && isNull (objectParent player) && !(SG_Interaction_Target isEqualTo truckMissionVeh) }";
	};

	class UnflipVehicle {
		title = "Unflip Vehicle";
		action = "[SG_Interaction_Target] call SG_fnc_unFlip; closeDialog 0;";
		check = "typeOf SG_Interaction_Target != 'GurneyTabl' && { (SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 6 && isNull (objectParent player) && !(player getVariable ['restrained',false]) }";
	};

	class InstallEjector {
		title = "Install Ejector";
		action = "[SG_Interaction_Target] spawn SG_EjectionSeat;";
		check = "playerSide == civilian && { typeOf SG_Interaction_Target != 'GurneyTabl' && (SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 6 && isNull (objectParent player) && !(player getVariable ['restrained',false]) && life_inv_seatejector > 0 }";
	};

	class TicketDriverInCar {
		title = "Ticket The Driver";
		action = "closeDialog 0; [SG_Interaction_Target] call SG_fnc_ticketAction;";
		check = "call(life_coplevel) > 0 && { playerSide isEqualTo west && !(player getVariable ['inHostage',false]) && (SG_Interaction_Target isKindOf 'Car' || SG_Interaction_Target isKindOf 'Air' || SG_Interaction_Target isKindOf 'Ship' || SG_Interaction_Target isKindOf 'Tank') && SG_Int_Distance <= 6 && isNull (objectParent player) && SG_Interaction_Target getVariable 'isTicketed' isEqualto 0 }";
	};

	class RemoveContainer {
		title = "Remove Container";
		action = "SG_Interaction_Target spawn SG_fnc_removeContainer;";
		check = "typeOf SG_Interaction_Target isEqualto 'B_supplyCrate_F' && {SG_Int_Distance < 3} || typeOf SG_Interaction_Target isEqualTo 'Box_IND_Grenades_F' && {SG_Int_Distance < 3}";
	};

	class SearchContainer {
		title = "Search Container";
		action = "[life_container_activeObj] spawn SG_fnc_containerInvSearch;";
		check = "typeOf SG_Interaction_Target isEqualto 'B_supplyCrate_F' && playerSide in [west, east] && !(player getVariable ['inHostage',false]) && call (life_coplevel) > 0 || typeOf SG_Interaction_Target isEqualto 'Box_IND_Grenades_F' && playerSide in [west, east] && !(player getVariable ['inHostage',false]) && call (life_coplevel) > 0";
	};

	class CoalProcessing {
		title = "Process Coal";
		action = "closeDialog 0; [SG_Interaction_Target,'coal'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { 'CoalProcess' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_coalOre > 0 }";
	};

	class IronProcessing {
		title = "Process Iron";
		action = "closeDialog 0; [SG_Interaction_Target,'iron'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { 'IronProcess' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_ironOre > 0 }";
	};

	class DiamondProcessing {
		title = "Process Diamond";
		action = "closeDialog 0; [SG_Interaction_Target,'diamond'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { 'DiamondProcess' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_diamondOre > 0 }";
	};

	class OilProcessing {
		title = "Process Oil";
		action = "closeDialog 0; [SG_Interaction_Target,'oil'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { 'OilProcess' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_oil_unprocessed > 0 }";
	};

	class RubberProcessing {
		title = "Process Rubber";
		action = "closeDialog 0; [SG_Interaction_Target,'rubber'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { 'RubberProcess' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_rubberU > 0 }";
	};

	class ClothProcessing {
		title = "Process Wool";
		action = "closeDialog 0; [SG_Interaction_Target,'cloth'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { 'ClothProcess' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_wool > 0 }";
	};

	class AcidProcessing {
		title = "Process Magic Toads";
		action = "closeDialog 0; [SG_Interaction_Target,'acid'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'DMTP' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_toad > 0 }";
	};

	class AcidDoubleProcessing {
		title = "Process Acid";
		action = "closeDialog 0; [SG_Interaction_Target,'DMT'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'DMTP' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_acid > 0 }";
	};

	class RubyProcessing {
		title = "Cut Ruby";
		action = "closeDialog 0; [SG_Interaction_Target,'ruby'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { 'RubyProcess' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_rubyore > 0 }";
	};

	class UraniumProcessing {
		title = "Process Uranium";
		action = "closeDialog 0; [SG_Interaction_Target,'uranium'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { 'UraniumP' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_uraniumU > 0 }";
	};

	class CocaineProcessing {
		title = "Process Coca Leaves";
		action = "closeDialog 0; [SG_Interaction_Target,'cocaine'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'CocaineP' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_cocoleaf > 0 }";
	};

	class CocaineDoubleProcessing {
		title = "Process Cocaine";
		action = "closeDialog 0; [SG_Interaction_Target,'crack'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'CocaineP' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_cocaine > 0 }";
	};

	class MDMAProcessing {
		title = "Process Sassafras";
		action = "closeDialog 0; [SG_Interaction_Target,'sassafras'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'MDMAP' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_sassafras > 0 }";
	};

	class MDMADoubleProcessing {
		title = "Process MDMA";
		action = "closeDialog 0; [SG_Interaction_Target,'molly'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'MDMAP' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_MDMA > 0 }";
	};

	class HeroinProcessing {
		title = "Process Opium";
		action = "closeDialog 0; [SG_Interaction_Target,'opium'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'HeroinP' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_opium > 0 }";
	};

	class HeroinDoubleProcessing {
		title = "Process Heroin";
		action = "closeDialog 0; [SG_Interaction_Target,'heroin'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'HeroinP' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_heroin > 0 }";
	};

	class WeedProcessing {
		title = "Process Hindu Bud";
		action = "closeDialog 0; [SG_Interaction_Target,'weed'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'WeedPro' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_hinduBud > 0 }";
	};

	class WeedDoubleProcessing {
		title = "Process Kush";
		action = "closeDialog 0; [SG_Interaction_Target,'hash'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'WeedPro' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_hindukush > 0 }";
	};

	class DecryptIntel {
		title = "Decrypt Intelligence";
		action = "closeDialog 0; [SG_Interaction_Target,'intel'] spawn SG_fnc_processAction";
		check = "alive SG_Interaction_Target && { 'IntelSpec' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse && life_inv_encryptedIntel > 0 }";
	};

	class RubySmelting {
		title = "Smelt Ruby Ore";
		action = "closeDialog 0; ['ruby'] spawn SG_Smelt";
		check = "life_inv_rubyore > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'smelting' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class DiamondSmelting {
		title = "Smelt Diamond Ore";
		action = "closeDialog 0; ['diamond'] spawn SG_Smelt";
		check = "life_inv_diamondore > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'smelting' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class CoalSmelting {
		title = "Smelt Coal Ore";
		action = "closeDialog 0; ['coal'] spawn SG_Smelt";
		check = "life_inv_coalore > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'smelting' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class IronSmelting {
		title = "Smelt Iron Ore";
		action = "closeDialog 0; ['iron'] spawn SG_Smelt";
		check = "life_inv_ironore > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'smelting' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class CopperSmelting {
		title = "Smelt Copper Ore";
		action = "closeDialog 0; ['copper'] spawn SG_Smelt";
		check = "life_inv_copperore > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'smelting' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class EmeraldSmelting {
		title = "Smelt Emerald Ore";
		action = "closeDialog 0; ['emerald'] spawn SG_Smelt";
		check = "life_inv_emeraldOre > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'smelting' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class EmeraldRefining {
		title = "Refine Emerald";
		action = "closeDialog 0; ['emerald'] spawn SG_Refine";
		check = "life_inv_emerald > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'refinery' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class GoldSmelting {
		title = "Smelt Gold Ore";
		action = "closeDialog 0; ['gold'] spawn SG_Smelt";
		check = "life_inv_goldOre > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'smelting' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class GoldRefining {
		title = "Refine Gold";
		action = "closeDialog 0; ['gold'] spawn SG_Refine";
		check = "life_inv_gold > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'refinery' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class SilverSmelting {
		title = "Smelt Silver Ore";
		action = "closeDialog 0; ['silver'] spawn SG_Smelt";
		check = "life_inv_silverOre > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'smelting' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class SilverRefining {
		title = "Refine Silver";
		action = "closeDialog 0; ['silver'] spawn SG_Refine";
		check = "life_inv_silver > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'refinery' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class SapphireSmelting {
		title = "Smelt Sapphire Ore";
		action = "closeDialog 0; ['sapphire'] spawn SG_Smelt";
		check = "life_inv_sapphireOre > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'smelting' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class SapphireRefining {
		title = "Refine Sapphire";
		action = "closeDialog 0; ['sapphire'] spawn SG_Refine";
		check = "life_inv_sapphire > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'refinery' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class RubyRefining {
		title = "Refine Ruby";
		action = "closeDialog 0; ['ruby'] spawn SG_Refine";
		check = "life_inv_ruby > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'refinery' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class DiamondRefining {
		title = "Refine Diamond";
		action = "closeDialog 0; ['diamond'] spawn SG_Refine";
		check = "life_inv_diamond > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'refinery' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class CoalRefining {
		title = "Refine Coal";
		action = "closeDialog 0; ['coal'] spawn SG_Refine";
		check = "life_inv_coal > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'refinery' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class IronRefining {
		title = "Refine Iron";
		action = "closeDialog 0; ['iron'] spawn SG_Refine";
		check = "life_inv_iron > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'refinery' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class CopperRefining {
		title = "Refine Copper";
		action = "closeDialog 0; ['copper'] spawn SG_Refine";
		check = "life_inv_copper > 0 && { SG_Int_Distance < 5 } && { alive SG_Interaction_Target && 'refinery' in SG_Interaction_VVN && playerSide isEqualTo civilian && !(player getVariable ['inHostage',false]) && !life_is_processing && !SG_Action_InUse }";
	};

	class MineralsTrader {
		title = "Trader";
		action = "[SG_Interaction_Target,'','','minerals'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 5 } && { 'MineralsTrader' in SG_Interaction_VVN && playerSide isEqualTo civilian }";
	};

	class OilTrader {
		title = "Trader";
		action = "[SG_Interaction_Target,'','','oil'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { 'OilTrader' in SG_Interaction_VVN && playerSide isEqualTo civilian }";
	};

	class UraniumTrader {
		title = "Trader";
		action = "[SG_Interaction_Target,'','','uranium'] spawn SG_fnc_virt_menu";
		check = "alive SG_Interaction_Target && { 'UraniumTrader' in SG_Interaction_VVN && playerSide isEqualTo civilian }";
	};

	class PickupBarrier {
		title = "Pickup Object";
		action = "[typeOf cursorObject,2] spawn SG_fnc_barrier;";
		check = "player getVariable ['life_is_alive',false] && { SG_Int_Distance < 5 } && playerSide in [west, east] && { !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && cursorObject getVariable 'placeableObject' == true }";
	};

	class PickupNearestBarrier {
		title = "Pickup Object";
		action = "[typeOf (nearestObjects [getPos player, ['Land_CamoNetVar_EAST_EP1','Land_CamoNet_EAST_EP1','Land_CamoNetVar_NATO_EP1','Land_CamoNet_NATO_EP1','CamoNet_INDP_F','CamoNet_INDP_open_F','RoadBarrier_F', 'Land_Razorwire_F'], 5] select 0),2] spawn SG_fnc_barrier;";
		check = "player getVariable ['life_is_alive',false] && playerSide in [west, east] && { !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) } && nearestObjects [getPos player, ['Land_CamoNetVar_EAST_EP1','Land_CamoNet_EAST_EP1','Land_CamoNetVar_NATO_EP1','Land_CamoNet_NATO_EP1','CamoNet_INDP_F','CamoNet_INDP_open_F','RoadBarrier_F', 'Land_Razorwire_F'], 5] select 0 getVariable 'placeableObject' == true";
	};

	class PickupItems {
		title = "Pickup Item(s)";
		action = "[] spawn SG_fnc_pickupItems;";
		check = "player getVariable ['life_is_alive',false] && { SG_Int_Distance < 5 } && { !(player getVariable ['inHostage',false]) && ((typeOf SG_Interaction_Target) == 'Land_Suitcase_F') && !(player getVariable ['restrained',false]) && !(SG_Interaction_Target getVariable ['BankCase',false]) }";
	};

	class PickupMoney {
		title = "Pickup Money";
		action = "closeDialog 0; if (SG_Interaction_Target getVariable ['inUse',false] isEqualto false) then {[SG_Interaction_Target,true] remoteExecCall ['TON_fnc_pickupAction',2]};";
		check = "player getVariable ['life_is_alive',false] && { !(player getVariable ['inHostage',false]) && ((typeOf SG_Interaction_Target) == 'Land_Money_F') && {!(SG_Interaction_Target getVariable ['inUse',false])} && SG_Int_Distance < 5 }";
	};

	class RobHouse {
		title = "Break Into House";
		action = "[SG_Interaction_Target] spawn SG_fnc_breakDownHouse; closeDialog 0;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable['locked',true] && SG_Int_Distance <= 15 && (isClass (missionConfigFile >> 'Housing' >> worldName >> (typeOf SG_Interaction_Target))) && (!(getPlayerUID player IN (SG_Interaction_Target getVariable ['house_owner',[]]))) && SG_Interaction_Target getVariable ['SG_HouseRobbed',false] isEqualTo false }";
	};

	class RobHouseCrate {
		title = "Lockpick Chest";
		action = "[SG_Interaction_Target] spawn SG_fnc_lockpickChest; closeDialog 0;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && SG_Interaction_Target getVariable['SG_HouseRobberyCrate',false] && SG_Interaction_Target getVariable ['SG_HouseRobberyCrateRobbed',false] isEqualto false && SG_Int_Distance <= 5 && typeOf SG_Interaction_Target isEqualTo 'plp_cts_WeathCrateBigBrown' }";
	};

	class PlaceC4Charge {
		title = "Place Explosive Charge";
		action = "[SG_Interaction_Target] spawn SG_SWATRaid; closeDialog 0;";
		check = "!(player getVariable ['inHostage',false]) && { (((toLowerANSI ([SG_Interaction_Target] call SG_Lib_GetDoor)) find 'door') > -1) && !(SG_Interaction_Target getVariable [format ['%1c4charge',([SG_Interaction_Target] call SG_Lib_GetDoor)],false]) && life_inv_doorc4 >= 1 && !(player getVariable ['restrained',false]) }";
	};

	class DoorBolt {
		title = "Bolt Door";
		action = "[SG_Interaction_Target] spawn SG_BoltLock; closeDialog 0;";
		check = "!(player getVariable ['inHostage',false]) && { (((toLowerANSI ([SG_Interaction_Target] call SG_Lib_GetDoor)) find 'door') > -1) && !(SG_Interaction_Target getVariable [format ['%1boltLocked',([SG_Interaction_Target] call SG_Lib_GetDoor)],false]) && life_inv_boltLocker >= 1 }";
	};

	class RemoveDoorBolt {
		title = "Remove Door Bolt";
		action = "[SG_Interaction_Target] spawn SG_RemoveBoltLock; closeDialog 0;";
		check = "!(player getVariable ['inHostage',false]) && { (((toLowerANSI ([SG_Interaction_Target] call SG_Lib_GetDoor)) find 'door') > -1) && (SG_Interaction_Target getVariable [format ['%1boltLocked',([SG_Interaction_Target] call SG_Lib_GetDoor)],false]) && life_inv_boltcutter >= 1 }";
	};
	/*
	class CrowbarGarageBM {
		title = "Break Into Garage";
		action = "[SG_Interaction_Target] spawn SG_CrowbarGarageBM;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && (typeOf SG_Interaction_Target isEqualTo 'Land_Banque_Altis') && ([SG_Interaction_Target] call SG_Lib_GetDoor in ['porte_01_07','porte_03_07']) }";
	};
	class CrackDoubleBM {
		title = "Crack Door Code";
		action = "[SG_Interaction_Target] spawn SG_CodeCrackBM;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && (typeOf SG_Interaction_Target isEqualTo 'Land_Banque_Altis') && ([SG_Interaction_Target] call SG_Lib_GetDoor find 'double_porte' > -1) }";
	};
	class CrackPorteBM {
		title = "Crack Door Code";
		action = "[SG_Interaction_Target] spawn SG_CodeCrackBM;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && (typeOf SG_Interaction_Target isEqualTo 'Land_Banque_Altis') && ([SG_Interaction_Target] call SG_Lib_GetDoor find 'porte_' > -1) && (count ([SG_Interaction_Target] call SG_Lib_GetDoor) <= 8) && ([SG_Interaction_Target] call SG_Lib_GetDoor != 'porte_3') }";
	};
	class LockpickVentBM {
		title = "Lockpick Vent";
		action = "[SG_Interaction_Target] spawn SG_LockpickVentBM;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && (typeOf SG_Interaction_Target isEqualTo 'Land_Banque_Altis') && ([SG_Interaction_Target] call SG_Lib_GetDoor find 'trap_' > -1) && (SG_Interaction_Target getVariable [format['%1_unlocked',[SG_Interaction_Target] call SG_Lib_GetDoor],false] isEqualTo false) }";
	};
	class KillGeneratorBM {
		title = "Kill Generator";
		action = "[SG_Interaction_Target] spawn SG_KillGeneratorBM;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && ((vehicleVarName SG_Interaction_Target) isEqualTo 'SG_BankGen') && (SG_Interaction_Target getVariable ['SG_BankGenKilled',false] isEqualTo false) }";
	};
	class StartDrillBM {
		title = "Place Drill";
		action = "[SG_Interaction_Target] spawn SG_StartDrillBM;";
		check = "playerSide isEqualTo civilian && { !(player getVariable ['inHostage',false]) && (typeOf SG_Interaction_Target isEqualTo 'Land_Banque_Altis') && ([SG_Interaction_Target] call SG_Lib_GetDoor isEqualTo 'porte_coffre') && (SG_Interaction_Target getVariable ['SG_DrillPlacedBM',false] isEqualTo false) }";
	};
	class StealMoney {
		title = "Steal Money";
		action = "[SG_Interaction_Target, 'Take'] spawn SG_TakeBag;";
		check = "playerSide != independent && { !(player getVariable ['inHostage',false]) && ((vehicleVarName SG_Interaction_Target) find 'SG_MajorMoney' > -1) }";
	};
	class ConfiscateMoney {
		title = "Confiscate Money";
		action = "[SG_Interaction_Target] spawn SG_ConfiscateMoney;";
		check = "playerSide isEqualTo west && { !(player getVariable ['inHostage',false]) && ((vehicleVarName SG_Interaction_Target) find 'SG_MajorMoney' > -1) }";
	};
	*/
	/*
	Kaiden - not using now since fini say nono
	class SwitchSpeakerMode {
		title = "Switch Speaker Mode";
		action = "[SG_Interaction_Target] call SG_RPRSpeakerMode;";
		check = "SG_Interaction_Target getVariable ['life_is_alive',false] && { isPlayer SG_Interaction_Target && SG_Int_Distance <= 3.5 && ((animationState SG_Interaction_Target) == 'Incapacitated' || (animationState SG_Interaction_Target) == 'unconscious' || (animationState SG_Interaction_Target) == 'unconsciousoutprone' || SG_Interaction_Target getVariable ['playerSurrender',false] || (playerSide isEqualTo civilian && playerSide isEqualTo (SG_Interaction_Target getVariable ['restrainType',sideEmpty]))) && !(player getVariable ['restrained',false]) }";
	};
	*/
	class DrillCasino {
		title = "Place Drill";
		action = "[SG_Interaction_Target] call SG_ActionPlaceDrill";
		check = "alive SG_Interaction_Target && { playerSide isEqualTo civilian} && {SG_Interaction_Target isEqualTo SG_Casino} && {[SG_Interaction_Target] call SG_Lib_GetDoor IN ['buildingcasino2_vaultdoor'] } && {!(SG_Casino getVariable ['SG_VaultOpen', false])}";
	};
	class DrillCasinoRemove {
		title = "Remove Drill";
		action = "deleteVehicle SG_VaultDrill; deleteVehicle SG_VaultGen;";
		check = "alive SG_Interaction_Target && {!isNull SG_VaultDrill} && {SG_Interaction_Target isEqualTo SG_VaultDrill} && {SG_VaultDrill getVariable ['finished', false]}";
	};
	class GeneratorCasino {
		title = "Attach Generator";
		action = "[SG_Interaction_Target] call SG_ActionPlaceGenerator";
		check = "alive SG_Interaction_Target && {!isNull SG_VaultDrill} && {SG_Interaction_Target isEqualTo SG_VaultDrill} && {!(SG_VaultDrill getVariable ['generator', false])} && {!(SG_VaultDrill getVariable ['finished', false])}";
	};
	class GeneratorCasinoRemove {
		title = "Remove Generator";
		action = "[] spawn SG_RemoveGenerator;";
		check = "alive SG_Interaction_Target && {!isNull SG_VaultGen} && {SG_Interaction_Target isEqualTo SG_VaultGen}";
	};
	class RepairCasinoVault {
		title = "Repair Vault";
		action = "[] spawn SG_CasinoRepair;";
		check = "alive SG_Interaction_Target && {!isNull SG_CasinoVault} && {SG_Interaction_Target isEqualTo SG_CasinoVault} && {SG_CasinoVault getVariable ['SG_VaultOpen', false]}";
	};
	class LockCasino {
		title = "Lock Vault";
		action = "[] spawn SG_CasinoFix;";
		check = "alive SG_Interaction_Target && {SG_Interaction_Target isEqualTo SG_Casino} && {[SG_Interaction_Target] call SG_Lib_GetDoor IN ['buildingcasino2_vaultdoor'] } && {SG_Casino getVariable ['SG_VaultOpen', false]}";
	};
	// class PickupBag {
	// 	title = "Pickup Bag";
	// 	action = "[SG_Interaction_Target, 'Pickup'] spawn SG_TakeBag;";
	// 	check = "SG_Int_Distance < 5 && { typeOf SG_Interaction_Target isEqualto 'Land_Sleeping_bag_blue_folded_F' && SG_Interaction_Target getVariable ['SG_CanTakeBag',false] && (call SG_NoBag) isEqualTo -1 && playerside != independent && SG_Interaction_Target getVariable ['CasinoBag',false] }";
	// };
	// class DropBag {
	// 	title = "Drop Bag";
	// 	action = "[objNull,'Drop'] spawn SG_TakeBag;";
	// 	check = "count (attachedObjects player) > 0 && {typeOf _x isEqualTo 'Land_Sleeping_bag_blue_folded_F'} forEach (attachedObjects player)";
	// };
	// class LaunderMoney {
	// 	title = "Launder Money";
	// 	action = "[SG_Interaction_Target,attachedObjects player] spawn SG_fnc_launderMoney;";
	// 	check = "playerSide isEqualTo civilian && { count (attachedObjects player) > 0 && 'MoneyLaunder' in SG_Interaction_VVN }";
	// };
	// class GiveMoneyBag {
	// 	title = "Turn in money bag";
	// 	action = "[attachedObjects player] spawn SG_TurnInBag;";
	// 	check = "playerSide isEqualTo west && { count (attachedObjects player) > 0 && 'CopShop' in SG_Interaction_VVN && {typeOf _x isEqualTo 'Land_Sleeping_bag_blue_folded_F'} forEach (attachedObjects player) }";
	// };
	// class StreetCleaning  {
	// 	title = "Become Street Cleaner";
	// 	action = "['StreetCleaner'] spawn SG_JobStart;";
	// 	check = "playerSide isEqualTo civilian && {'StreetCleaning' in SG_Interaction_VVN} && {!SG_Job_Working}";
	// };
	// class EndJob  {
	// 	title = "End your shift";
	// 	action = "[] spawn SG_JobEnd;";
	// 	check = "playerSide isEqualTo civilian && {'StreetCleaning' in SG_Interaction_VVN} && {SG_Job_Working}";
	// };
	class RepairPlant {
		title = "Repair object";
		action = "[SG_Interaction_Target] spawn SG_RepairObject;";
		check = "playerSide in [west, independent] && { SG_Int_Distance < 5 } && {'plant' in ((getModelInfo SG_Interaction_Target) select 1)} && {!(alive SG_Interaction_Target)}";
	};
	class SafehouseStart {
		title = "Start Safehouse";
		action = "['SG_StartSafehouse'] call SG_DoRe;";
		check = "SG_Interaction_VVN isEqualTo 'SG_SafehouseFlag' && { SG_Int_Distance < 5 } && {!(SG_Interaction_Target getVariable ['active', false])}";
	};
	class LoadoutCiv {
		title = "Loadouts";
		action = "createDialog 'SG_Loadouts';";
		check = "'Rebel' in SG_Interaction_VVN && { SG_Int_Distance < 5 } && {playerSide isEqualTo civilian}";
	};
	class LoadoutCop {
		title = "Loadouts";
		action = "createDialog 'SG_Loadouts';";
		check = "(['CopShop','CIAShop'] findIf { _x in SG_Interaction_VVN }) isNotEqualTo -1 && { SG_Int_Distance < 5 } && {playerSide isEqualTo west}";
	};
	class LoadoutOpf {
		title = "Loadouts";
		action = "createDialog 'SG_Loadouts';";
		check = "'OpfShop' in SG_Interaction_VVN && { SG_Int_Distance < 5 } && {playerSide isEqualTo east}";
	};
	class LoadoutMed {
		title = "Loadouts";
		action = "createDialog 'SG_Loadouts';";
		check = "'MedicShop' in SG_Interaction_VVN && { SG_Int_Distance < 5 } && {playerSide isEqualTo independent}";
	};
	class BuyApartment {
		title = "Buy Apartment";
		action = "[] spawn SG_BuyApartmentClient";
		check = "(playerSide isEqualTo civilian) && {isClass (missionConfigFile >> 'Apartment' >> worldName >> (typeOf SG_Interaction_Target)) && {(!([SG_Interaction_Target] call SG_Lib_GetDoor isEqualto ''))}}";
	};
	class PayApartmentRent {
		title = "Pay Rent";
		action = "[SG_Interaction_Target] call SG_PayRent;";
		check = "(playerSide isEqualTo civilian) && {isClass (missionConfigFile >> 'Apartment' >> worldName >> (typeOf SG_Interaction_Target)) && {(!([SG_Interaction_Target] call SG_Lib_GetDoor isEqualto ''))} && {!isNull ([SG_Interaction_Target, getPlayerUID player] call SG_FindApartment)}}";
	};
	class BuyShed {
		title = "Buy Shed";
		action = "[SG_Interaction_Target] spawn SG_BuyShedClient";
		check = "(playerSide isEqualTo civilian) && {!(isNull SG_Interaction_Target)} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)} && {!(((group player) getVariable ['gang_id', -1]) isEqualTo -1)} && {!(SG_Interaction_Target getVariable ['shed', false])} && {isClass (missionConfigFile >> 'CfgGangs' >> 'Shed' >> (typeOf SG_Interaction_Target))}";
	};
	class ShedGarage {
		title = "Garage";
		action = "['Car',true] spawn SG_Garage;";
		check = "(playerSide isEqualTo civilian) && {!(isNull SG_Interaction_Target)} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)} && {!(((group player) getVariable ['gang_id', -1]) isEqualTo -1)} && {(SG_Interaction_Target getVariable ['shed', false])} && {((group player) getVariable ['gang_id', -1]) isEqualTo (SG_Interaction_Target getVariable ['owner', -1])}";
	};
	class ShedStoreVehicle {
		title = "Store Vehicle";
		action = "[] spawn SG_fnc_storeVehicle;";
		check = "(playerSide isEqualTo civilian) && {!(isNull SG_Interaction_Target)} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)} && {!(((group player) getVariable ['gang_id', -1]) isEqualTo -1)} && {(SG_Interaction_Target getVariable ['shed', false])} && {((group player) getVariable ['gang_id', -1]) isEqualTo (SG_Interaction_Target getVariable ['owner', -1])}";
	};
	class CoinFlip {
		title = "CoinFlip";
		action = "[SG_Interaction_Target] spawn SG_DoCoinflip;";
		check = "!(isNull SG_Interaction_Target) && {isPlayer SG_Interaction_Target} && {SG_Int_Distance <= 5}";
	};
	class RobFed {
		title = "Rob Fed";
		action = "[SG_Interaction_Target] spawn SG_StartFed;";
		check = "!(isNull SG_Interaction_Target) && {SG_Interaction_Target isEqualTo SG_Fed} && {([SG_Interaction_Target] call SG_Lib_GetDoor) isEqualTo 'vaultdoor'} && {!(SG_Interaction_Target getVariable ['open', false])}";
	};
	class OpenFed {
		title = "Open Vault";
		action = "[SG_Interaction_Target] spawn SG_OpenFed;";
		check = "!(isNull SG_Interaction_Target) && {SG_Interaction_Target isEqualTo SG_Fed} && {([SG_Interaction_Target] call SG_Lib_GetDoor) isEqualTo 'vaultdoor'} && {SG_Interaction_Target getVariable ['open', false]} && {(SG_Interaction_Target animationSourcePhase 'VaultHandle_sound_source') isEqualTo 0}";
	};
	class CloseFed {
		title = "Lock Vault";
		action = "[SG_Interaction_Target] spawn SG_CloseFed;";
		check = "!(isNull SG_Interaction_Target) && {SG_Interaction_Target isEqualTo SG_Fed} && {([SG_Interaction_Target] call SG_Lib_GetDoor) isEqualTo 'vaultdoor'} && {(SG_Interaction_Target getVariable ['open', false])} && {(SG_Interaction_Target animationSourcePhase 'VaultHandle_sound_source') isEqualTo 1}";
	};
	class CollectFed {
		title = "Collect Gold";
		action = "[SG_Interaction_Target] spawn SG_CollectGold;";
		check = "!(isNull SG_Interaction_Target) && { SG_Int_Distance < 3 } && {'SG_FedVault' in (vehicleVarName SG_Interaction_Target)} && {SG_Fed getVariable ['open', false]} && {playerSide isEqualTo civilian}";
	};
	class PlaceWeedPot {
		title = "Place Pot";
		action = "[false, SG_Interaction_Target] spawn SG_DetachPot;";
		check = "!(isNull SG_PlantPot)";
	};
	class PutAwayWeedPot {
		title = "Put away";
		action = "[true, SG_Interaction_Target] spawn SG_DetachPot;";
		check = "(!(isNull SG_PlantPot) || {typeOf SG_Interaction_Target isEqualTo 'Land_JD_WeedPlant'}) && {SG_Int_Distance <= 3}";
	};
	class CheckWeed {
		title = "Check Plant";
		action = "[SG_Interaction_Target] spawn SG_CheckWeedPlant;";
		check = "(typeOf SG_Interaction_Target isEqualTo 'Land_JD_WeedPlant') && {SG_Int_Distance <= 3}";
	};
	class HarvestWeed {
		title = "Harvest";
		action = "[SG_Interaction_Target] spawn SG_HarvestWeed;";
		check = "(typeOf SG_Interaction_Target isEqualTo 'Land_JD_WeedPlant') && {SG_Int_Distance <= 3} && {SG_Interaction_Target animationSourcePhase 'Growth_source' == 1}";
	};
	class SeizeWeed {
		title = "Seize Weed";
		action = "[SG_Interaction_Target] spawn SG_SeizeWeed;";
		check = "(typeOf SG_Interaction_Target isEqualTo 'Land_JD_WeedPlant') && { playerSide in [west, east] } && {SG_Int_Distance <= 3}";
	};
	class HackComputer {
		title = "Hack Police Servers";
		action = "[SG_Interaction_Target] spawn SG_HackSheriffComputer";
		check = "alive SG_Interaction_Target && { 'Computer' in SG_Interaction_VVN } && { playerSide isEqualto civilian } && { life_inv_injectionHack > 0 } && { SG_Interaction_Target getVariable ['SG_LaptopState',''] isEqualTo ''}";
	};
	class RunVirus {
		title = "Run Virus";
		action = "[SG_Interaction_Target] spawn SG_RunComputerVirus";
		check = "alive SG_Interaction_Target && { 'Computer' in SG_Interaction_VVN } && { playerSide isEqualto civilian } && { life_inv_injectionHack > 0 } && { SG_Interaction_Target getVariable ['SG_LaptopState',''] isEqualTo 'Virus'}";
	};
	class ShowCode {
		title = "Show Code";
		action = "[SG_Interaction_Target] call SG_ShowComputerCode";
		check = "alive SG_Interaction_Target && { 'Computer' in SG_Interaction_VVN } && { playerSide isEqualto civilian } && { SG_Interaction_Target getVariable ['SG_LaptopState',''] isEqualTo 'Code'}";
	};
	class LoginToVault {
		title = "Input Vault Code";
		action = "[SG_Interaction_Target] spawn SG_LoginToVault";
		check = "alive SG_Interaction_Target && { 'SheriffVault' in SG_Interaction_VVN } && { playerSide isEqualto civilian }";
	};
	class BlackMarket {
		title = "Black Market";
		action = "[SG_Interaction_Target,'','','blackmarket'] spawn SG_fnc_virt_menu;";
		check = "alive SG_Interaction_Target && { SG_Int_Distance < 7.5}  && {'BlackM' in SG_Interaction_VVN} && {playerSide isEqualto civilian}";
	};
	class StartBank {
		title = "Start Bank";
		action = "[SG_Interaction_Target] call SG_StartBankRobbery;";
		check = "alive SG_Interaction_Target && {SG_Interaction_Target isEqualTo SG_BankMetro} && {!(SG_Interaction_Target getVariable ['BankOpen', false])} && {([SG_Interaction_Target] call SG_Lib_GetDoor) isEqualTo 'door_13'}";
	};
	class RemoveBankDrill {
		title = "Remove Drill";
		action = "[SG_Interaction_Target] call SG_RemoveBankDrill;";
		check = "alive SG_Interaction_Target && {SG_Interaction_Target isEqualTo SG_BankDrill} && {(SG_BankMetro getVariable ['Drill', false])} && {(SG_Interaction_Target animationSourcePhase 'Progress_source') >= 1}";
	};
	class RepairVault {
		title = "Repair Vault";
		action = "[SG_Interaction_Target] spawn SG_RepairBank;";
		check = "alive SG_Interaction_Target && {SG_Interaction_Target isEqualTo SG_BankMetro} && {(SG_Interaction_Target getVariable ['BankOpen', false])} && {!(SG_Interaction_Target getVariable ['Drill', false])} && {([SG_Interaction_Target] call SG_Lib_GetDoor) isEqualTo 'door_13'}";
	};
	class LockpickDeposit {
		title = "Lockpick Deposit Box";
		action = "[SG_Interaction_Target] spawn SG_LockpickDepositBox;";
		check = "alive SG_Interaction_Target && {SG_Interaction_Target isEqualTo SG_SafteyBoxes} && {(SG_Interaction_Target getVariable ['BankOpen', false])} && {!(SG_BankMetro getVariable ['Drill', false])} && {'door_' in ([SG_Interaction_Target, true] call SG_Lib_GetDoor)}";
	};
	class GasStationPower {
		title = "Trip Power";
		action = "[SG_Interaction_Target] spawn SG_GasSationPower;";
		check = "alive SG_Interaction_Target && {'SG_GasPower' in SG_Interaction_VVN} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class EmbassyHackPartial {
		title = "Hack Computer";
		action = "[SG_Interaction_Target] spawn SG_EmbassyHackComputerPartial;";
		check = "alive SG_Interaction_Target && {'EmbassyLaptop' in SG_Interaction_VVN} && {!('End' in SG_Interaction_VVN)} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class EmbassyCheckPassword {
		title = "Check Code";
		action = "[SG_Interaction_Target] spawn SG_EmbassyGetCode;";
		check = "alive SG_Interaction_Target && {'EmbassyLaptop' in SG_Interaction_VVN} && {!('End' in SG_Interaction_VVN)} && {SG_Interaction_Target getVariable ['Hacked', false]} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class EmbassyHackMain {
		title = "Hack Main Computer";
		action = "[SG_Interaction_Target] spawn SG_EmbassyHackMain;";
		check = "alive SG_Interaction_Target && {'EmbassyLaptop' in SG_Interaction_VVN} && {'End' in SG_Interaction_VVN} && {!(SG_Interaction_Target getVariable ['Hacked', false])} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class EmbassyRepair {
		title = "Repair Computers";
		action = "[SG_Interaction_Target] spawn SG_EmbassyRepair;";
		check = "alive SG_Interaction_Target && {'EmbassyLaptop' in SG_Interaction_VVN} && {'End' in SG_Interaction_VVN} && {SG_Interaction_Target getVariable ['Hacked', false]} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
		class NukeHackPartial {
		title = "Hack Computer";
		action = "[SG_Interaction_Target] spawn SG_NukeHackComputerPartial;";
		check = "alive SG_Interaction_Target && {'NukeLaptop' in SG_Interaction_VVN} && {!('End' in SG_Interaction_VVN)} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class NukeCheckPassword {
		title = "Check Code";
		action = "[SG_Interaction_Target] spawn SG_NukeGetCode;";
		check = "alive SG_Interaction_Target && {'NukeLaptop' in SG_Interaction_VVN} && {!('End' in SG_Interaction_VVN)} && {SG_Interaction_Target getVariable ['Hacked', false]} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class NukeHackMain {
		title = "Hack Main Computer";
		action = "[SG_Interaction_Target] spawn SG_NukeHackMain;";
		check = "alive SG_Interaction_Target && {'NukeLaptop' in SG_Interaction_VVN} && {'End' in SG_Interaction_VVN} && {!(SG_Interaction_Target getVariable ['Hacked', false])} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class NukeRepair {
		title = "Repair Computers";
		action = "[SG_Interaction_Target] spawn SG_NukeRepair;";
		check = "alive SG_Interaction_Target && {'NukeLaptop' in SG_Interaction_VVN} && {'End' in SG_Interaction_VVN} && {SG_Interaction_Target getVariable ['Hacked', false]} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class ArtGallery  {
		title = "Rob Art Gallery";
		action = "[SG_Interaction_Target,'Art'] spawn SG_StartMajorCrime";
		check = "alive SG_Interaction_Target && {'ArtVault' in SG_Interaction_VVN} && {isNull (objectParent player)} && {playerSide isEqualTo civilian} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class FixMajorVault {
		title = "Fix Vault";
		action = "[SG_Interaction_Target] spawn SG_FixMajorCrime;";
		check = "SG_Interaction_Target getVariable ['bankOpen',false] && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class RobBank  {
		title = "Rob Bank Vault";
		action = "[SG_Interaction_Target,'Bank'] spawn SG_StartMajorCrime";
		check = "alive SG_Interaction_Target && {'BankVault' in SG_Interaction_VVN} && {isNull (objectParent player)} && {playerSide isEqualTo civilian} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class BankBarricade  {
		title = "Toggle Barricades";
		action = "[] spawn SG_BankBarricade";
		check = "alive SG_Interaction_Target && {'bankCrate' in SG_Interaction_VVN} && {isNull (objectParent player)} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class CPABridge  {
		title = "Toggle Bridge";
		action = "[] spawn SG_CPABridge";
		check = "alive SG_Interaction_Target && {'CPA_Plank' in SG_Interaction_VVN} && {isNull (objectParent player)} && {SG_Int_Distance <= ([SG_Interaction_Target,5] call SG_CalcDistance)}";
	};
	class CPAUnlockDoors  {
		title = "Unlock HQ Doors";
		action = "[] spawn SG_CPAUnlockDoors";
		check = "alive SG_Interaction_Target && {'CPA_HQ' in SG_Interaction_VVN} && {isNull (objectParent player)} && {SG_Int_Distance <= ([SG_Interaction_Target,15] call SG_CalcDistance)}";
	};
	class CPALockDoors  {
		title = "Lock HQ Doors";
		action = "[] spawn SG_CPALockDoors";
		check = "alive SG_Interaction_Target && {'CPA_HQ' in SG_Interaction_VVN} && {isNull (objectParent player)} && {SG_Int_Distance <= ([SG_Interaction_Target,15] call SG_CalcDistance)}";
	};
	class AttachSpeedbomb {
		title = "Attach Speed Bomb";
		action = "[SG_Interaction_Target] spawn SG_fnc_speedBomb";
		check = "alive SG_Interaction_Target && SG_Int_Distance < 5 && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && !(SG_Interaction_Target getVariable ['_speedBomb', false]) && SG_Interaction_Target isKindOf 'LandVehicle' && life_inv_speedBomb > 0";
	};
	/*class RepairBorder  {
		title = "Repair Wall";
		action = "[] spawn SG_RepairBorderWall;";
		check = "playerSide isEqualTo west && !isNil {nearestObject [player, 'Land_HelipadEmpty_F']} && player distance (nearestObject [player, 'Land_HelipadEmpty_F']) < 10 && ((vehicle player) isEqualTo player)";
	};
	class PlaceBorderCharge  {
		title = "Place Border Charge";
		action = "[SG_Interaction_Target,30] spawn SG_PlaceBorderCharge;";
		check = "playerSide isEqualTo civilian && life_inv_borderCharge >= 1 && (getModelInfo SG_Interaction_Target select 0) isEqualTo 'a_castle_wall1_20.p3d' && ((vehicle player) isEqualTo player) isEqualTo true && (player distance SG_Interaction_Target) < 10";
	};*/
};
class CfgDances {
	class StopDance  {
		title = "Stop Dancing";
		action = "closeDialog 0; [player,'stop'] remoteExec ['SG_fnc_Animations', -2]";
		check = "alive player && {isNull (objectParent player)} && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && player getVariable ['isDancing',false]";
	};
	class Dance1  {
		title = "Dance 1";
		action = "closeDialog 0; [player,'Acts_Dance_01'] remoteExec ['SG_fnc_Animations', -2]";
		check = "alive player && {isNull (objectParent player)} && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && !(player getVariable ['isDancing',false])";
	};
	class Dance2  {
		title = "Dance 2";
		action = "closeDialog 0; [player,'Acts_Dance_02'] remoteExec ['SG_fnc_Animations', -2]";
		check = "alive player && {isNull (objectParent player)} && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && !(player getVariable ['isDancing',false])";
	};
	class Dance3  {
		title = "Hip Hop Dance";
		action = "closeDialog 0; [player,'SG_hiphopdance'] remoteExec ['SG_fnc_Animations', -2]";
		check = "alive player && {isNull (objectParent player)} && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && !(player getVariable ['isDancing',false])";
	};
	class Dance4  {
		title = "Nightclub Dance";
		action = "closeDialog 0; [player,'SG_nightclubdance'] remoteExec ['SG_fnc_Animations', -2]";
		check = "alive player && {isNull (objectParent player)} && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && !(player getVariable ['isDancing',false])";
	};
	class Dance5  {
		title = "Robot Dance";
		action = "closeDialog 0; [player,'SG_robotdance'] remoteExec ['SG_fnc_Animations', -2]";
		check = "alive player && {isNull (objectParent player)} && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && !(player getVariable ['isDancing',false])";
	};
	class Dance6  {
		title = "Russian Dance";
		action = "closeDialog 0; [player,'SG_russiandance'] remoteExec ['SG_fnc_Animations', -2]";
		check = "alive player && {isNull (objectParent player)} && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && !(player getVariable ['isDancing',false])";
	};
	class Dance7  {
		title = "House Dance";
		action = "closeDialog 0; [player,'SG_Dance_House1'] remoteExec ['SG_fnc_Animations', -2]";
		check = "alive player && {isNull (objectParent player)} && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && !(player getVariable ['isDancing',false])";
	};
	class Dance8  {
		title = "Samba Dance";
		action = "closeDialog 0; [player,'SG_Dance_Samba'] remoteExec ['SG_fnc_Animations', -2]";
		check = "alive player && {isNull (objectParent player)} && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && !(player getVariable ['isDancing',false])";
	};
	class Dance9  {
		title = "Ivan Dance";
		action = "closeDialog 0; [player,'SG_DuoIvan'] remoteExec ['SG_fnc_Animations', -2]";
		check = "alive player && {isNull (objectParent player)} && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && !(player getVariable ['isDancing',false])";
	};
	class Dance10  {
		title = "Stephen Dance";
		action = "closeDialog 0; [player,'SG_DuoStephan'] remoteExec ['SG_fnc_Animations', -2]";
		check = "alive player && {isNull (objectParent player)} && !(player getVariable ['inHostage',false]) && !(player getVariable ['restrained',false]) && !(player getVariable ['isDancing',false])";
	};
};