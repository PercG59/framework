class Licenses {

	// Civilian Licenses

	class driver {
		variable = "driver";
		displayName = "STR_License_Driver";
		price = 3000;
		illegal = false;
		side = "civ";
	};

	class passport {
		variable = "passport";
		displayName = "STR_License_Passport";
		price = 0;
		illegal = false;
		side = "civ";
	};

	class boat {
		variable = "boat";
		displayName = "STR_License_Boat";
		price = 3500;
		illegal = false;
		side = "civ";
	};

	class trucking {
		variable = "trucking";
		displayName = "STR_License_Truck";
		price = 12500;
		illegal = false;
		side = "civ";
	};

	class gun {
		variable = "gun";
		displayName = "STR_License_Firearm";
		price = 22500;
		illegal = false;
		side = "civ";
	};
	
	class rifle {
		variable = "rifle";
		displayName = "STR_License_rifle";
		price = 27500;
		illegal = false;
		side = "civ";
	};

	class dive {
		variable = "dive";
		displayName = "STR_License_Diving";
		price = 4000;
		illegal = false;
		side = "civ";
	};

	class home {
		variable = "home";
		displayName = "STR_License_Home";
		price = 7500;
		illegal = false;
		side = "civ";
	};

	class DOJ {
		variable = "DOJ";
		displayName = "STR_License_DOJ";
		price = -1;
		illegal = false;
		side = "civ";
	};

	class BAR {
		variable = "BAR";
		displayName = "STR_License_BAR";
		price = -1;
		illegal = false;
		side = "civ";
	};

	// BLUFOR Licenses

	class demo {
		variable = "demo";
		displayName = "STR_License_demo";
		price = -1;
		illegal = false;
		side = "cop";
	};

	class marksman {
		variable = "marksman";
		displayName = "STR_License_marksman";
		price = -1;
		illegal = false;
		side = "cop";
	};

	class aviation {
		variable = "aviation";
		displayName = "STR_License_aviation";
		price = -1;
		illegal = false;
		side = "cop";
	};

	// OPFOR Licenses

	class opfdemo {
		variable = "opfDemo";
		displayName = "STR_License_demo";
		price = -1;
		illegal = false;
		side = "opf";
	};

	class opfmarksman {
		variable = "opfMarksman";
		displayName = "STR_License_marksman";
		price = -1;
		illegal = false;
		side = "opf";
	};

	class opfaviation {
		variable = "opfAviation";
		displayName = "STR_License_aviation";
		price = -1;
		illegal = false;
		side = "opf";
	};

	// Rebel Licenses

	class reb {
		variable = "reb";
		displayName = "STR_License_reb";
		price = 100000;
		illegal = true;
		side = "civ";
	};

	class AdvReb {
		variable = "AdvReb";
		displayName = "STR_License_AdvReb";
		price = 750000;
		illegal = true;
		side = "civ";
	};
};
