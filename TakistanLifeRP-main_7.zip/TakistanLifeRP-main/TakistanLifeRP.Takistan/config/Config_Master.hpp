class CfgMaster {
	class Branch {
		//Server Version
		serverVersion = 0.001;

		//Dev Server Name
		devServerName = "dev";

		//main - Live, dev - Development Build
		currentBranch = "main";
	};

	class Security {
		//Player UID's that can bypass addon check
		bypassAddonCheck[] = { "123" };

		//List of CfgPatches that you want to confirm are running
		patchesToVerify[] = { "SG_Core" };

		//Turn on to stop people from saving gear on combat logs (*IN TESTING*)
		combatLogFix = false;
	};

	class Jail {
		class Settings {
			// Minimum and maximum time for jail in minutes.
			minTime = 5;
			maxTime = 15;

			//If true, it will seize stuff in there inventory, otherwise it will keep gear if cop forgets to patdown
			jail_autoSeizeInv = true;

			//Virtual Items that you want to be seized
			jail_seize_vItems[] = { "zipties", "blindfold", "spikeStrip", "lockpick", "goldenbarz3", "blastingcharge", "boltcutter", "cannabis", "marijuana", "cocoleaf","cocaine", "crack", "MDMA", "molly", "heroin", "heroinPure", "marijuana", "acid", "DMT", "turtle_raw" };

			//Force inmates to walk while in jail if true
			jail_forceWalk = true;

			// Loadout player gets when sent to jail
			class Loadout {
				uniform = "CUP_U_O_RUS_Ratnik_Pink";
				backpack = "TRYK_B_Belt_BLK";
				headgear = "";
				goggles = "";
				vest = "";
			};
		};

		class Locations {
			class Takistan_Prison {
				name = "North Takistan Correctional Facility";
				description = "Correctional Facility for the North of Takistan";
				icon = "";

				class JailCellLocations {
					//Using modelToWorld for jail positions
					useModelToWorld = false;

					//Spawnpoints for jail prisoners
					jailPositions[] = {
						{ 6215.556,10551.336,0 }
					};
				};

				class ReleaseArea {
					//Direction to release them in (getDir player)
					direction = 120;

					//Position to release them at (getPosATL player)
					positionATL[] = { 6260.803,11216.265,0.0971351 };
				};
			};
		};
	};

	class MajorCrimes {
		//Time in minutes that players cannot deposit money after selling stolen gold.
		noatm_timer = 10;
		blacklistedWeapons[] = { "SG_Pickaxe", "Mr_Camera_News", "Mr_Micro_News", "Binocular", "taser" };

		bag_sellPrice = 100000;
		bag_confPrice = 15000;

		// class Bank {
		// 	requiredItem = "blastingcharge";
		// 	numberOfCops = 8;

		// 	//Door animations
		// 	electricDoors[] = { "door_4_rot", "door_5_rot", "door_6_rot", "door_7_rot", "door_10_rot", "door_17_rot", "door_18_rot", "door_19_rot", "door_20_rot", "door_21_rot", "door_22_rot", "door_23_rot", "door_24_rot", "door_25_rot", "door_26_rot" };
		// };

		class BankOld {
			time = 750;

			/*
				The format for items is very specfic!

				randomWeight - the value of giving this item from the total. Number
				itemGive - The item to give. String
				itemRandom - The random amount of items to give. Array of 3 nums

				eg {12, "lockpick", {1,2, 10}}
			*/
			items[] = {
				{0.4, "markedMoney",{1,1,1}},
				{0.6, "diamondJewelery",{1,1,1}},
				{0.6, "rubyJewelery",{1,1,1}},
				{0.6, "sapphireJewelery",{1,1,1}},
				{0.6, "amethystJewelery",{1,1,1}},
				{5, "",{0,0,0}}
			};

			// Number of items to give when opening the Deposit Box
			numberOfItems[] = {0,1,3};

			requiredItem = "vaultDrill";
			numberOfCops = 8;
		};

		class Fed {
			time = 750;

			item = "goldBar";
			amount = 8;

			requiredItem = "blastingcharge";
			numberOfCops = 8;
		};

		class Art {
			time = 750;
			items[] = {{"fineArt",10}};
			requiredItem = "blastingcharge";
			numberOfCops = 8;
			vault = "ArtVault";
		};

		class Bank {
			time = 750;
			items[] = {{"markedMoney",25}};
			requiredItem = "blastingcharge";
			numberOfCops = 8;
			vault = "BankVault";
		};

		class Casino {
			displayName = "Springfield Casino";
			buildingClassName = "Land_buildingsCasino2";
			buildingVaultInteract = "buildingcasino2_vaultdoor";
			buildingVaultAnim = "vaultdoor";

			items[] = {
				{"casinoChip",{30,50,60}}
			};

			numberOfCops = 8;
			drillTimer = 480;
			devTimer = 60;
		};

		class Safehouse {
			startmsg = "The Safehouse has started it will end in 10 minutes!";
			// Setup is done like this: { Time, "How long the time is in seconds", prize money for that time}
			setup[] = {
				{ 300, "5 minutes", 17500},
				{ 60, "4 minutes", 17500},
				{ 60, "3 minutes", 17500 },
				{ 60, "2 minutes", 17500 },
				{ 60, "1 minutes", 17500 },
				{ 30, "30 seconds" ,17500 },
				{ 20, "10 seconds", 20000 } // Leave this one here!
			};
		};

		class SheriffRobbery {
            // Number of weapons to give you
            weapon_amount = 3;

            //Weapons to get in Sheriffs Vault
            weapon_array[] = {"hlc_rifle_bcmjack","hlc_rifle_RU556","CUP_arifle_Mk16_STD_FG","CUP_hgun_M17_Coyote"};   
        };

		class Embassy {
            // Number of weapons to give you
            weapon_amount = 3;

            //Weapons to get in Sheriffs Vault
            weapon_array[] = {"launch_B_Titan_F","CUP_srifle_AS50","srifle_DMR_03_F","srifle_EBR_F","LMG_Mk200_F"};   

			// vItems to give
            vItems[] = {
				{"encryptedIntel",10}
			};
        };

		class Nuke {
			items[] = {
				{"plutonium",28}
			};
		};
	};

	class PatrolPoints {

		patrolPointsCop[] = {
			{
				
				{ 1617.23,11667.7,0 },
				{ 4689.26,9512.76,0 },
				{ 8255.04,7784.81,0 },
				{ 8386.98,11075.7,0 },
				{ 5520.26,9312.89,0 }
			},
			{
				{ 5686.82,8946.58,0 },
				{ 9751.89,11557,0 },
				{ 6253.06,10710.8,0 },
				{ 3080.46,9954.02,0 },
				{ 1819.51,11938.2,0 }
			},
			{
				{ 4207.07,10690.9,0 },
				{ 5603.24,9861.05,0 },
				{ 9120.07,6768.73,0 },
				{ 9276.11,10052.8,0 },
				{ 12280.3,10372.4,0 }
			},
			{
				{ 11034.4,6297.49,0 },
				{ 8247.4,7970.91,0 },
				{ 12280.3,10372.4,0 },
				{ 11455.7,8232.43,0 },
				{ 6256.65,11052.9,0 }
			}
		};

		patrolPointsOpfor[] = {
			{
				
				{ 5326.19,4717.66,0 },
				{ 8733.56,4868.67,0 },
				{ 10022.6,2348.81,0 },
				{ 6091.75,1158.36,0 },
				{ 3652.14,4316.15,0 }
			},
			{
				{ 1537.72,5737.63,0 },
				{ 200.426,2833.14,0 },
				{ 6114.11,5643.71,0 },
				{ 8893,5288.72,0 },
				{ 8497.46,2469.25,0 }
			},
			{
				{ 5219.33,6181.24,0 },
				{ 6726.84,6070.08,0 },
				{ 9019.03,5883.05,0 },
				{ 8541.42,2465.22,0 },
				{ 6527.54,2091.98,0 }
			},
			{
				{ 2029.9,7703.1,0 },
				{ 1560.39,3658.83,0 },
				{ 5086.58,6129.43,0 },
				{ 6627.99,5691.04,0 },
				{ 9019.03,5883.05,0 }
			}
		};

		patrolPointsMedic[] = {
			{
				
				{ 2716.11,7973.54,0 },
				{ 3082.86,9948.71,0 },
				{ 1815.39,11941,0 },
				{ 4099.26,10920.5,0 },
				{ 5604.53,9863.7,0 }
			},
			{
				{ 6756.56,12158.5,0 },
				{ 5708.25,9915.13,0 },
				{ 6849.73,8916.96,0 },
				{ 8247.8,7785.31,0 },
				{ 10874.4,6303.4,0 }
			},
			{
				{ 5525.37,8911.53,0 },
				{ 8249.39,7786.2,0 },
				{ 9291.18,10062,0 },
				{ 10511.7,11089.8,0 },
				{ 12273.3,10366.3,0 }
			}
		};
	};

	class Medical {
		//Duration of bleedout before bleeding out and dying, in seconds.
		bleedoutDuration = 600;

		//Duration if no medics are online
		bleedoutDurationOffline = 300;

		//The amount of time added to the bleedout timer when stabilized, in seconds
		stabilizeLenght = 225;

		// The amount of time removed from the bleedout timer when a player has their organs harvested
		harvestedTime = 60;

		//Revive fee that players have to pay and medics, only EMS are rewarded with this amount.
		revivalFee = 5000;

		//Fee to heal at a hospital NPC
		hospitalFee = 50;
	};

	class Saving {
		//Save virtual items
		save_virtualItems = true;

		//Save illegal items
		save_illegalItems = false;

		//Save food, and water?
		save_playerStats = true;

		//Save civilian location
		save_civilianPosition = true;

		//Save vehicle virtual items
		save_vehicle_virtualItems = false;

		//Save illegal items in vehicle
		save_vehicle_illegalItems = false;

		//Save arma inventory items in vehicle
		save_vehicle_inventory = false;

		//Save the vehicles fuel and damage
		save_vehicle_fuel = true;
		save_vehicle_damage = true;
	};

	class GameSettings {
		//Set to false to disable the ARMA 3 fatigue system.
		enable_fatigue = false;

		//List of atm ClassNames to use
		atm_types[] = { "Land_JD_ATM", "Land_Atm_02_F", "Land_ATM_01_malden_F", "Land_ATM_02_malden_F", "TR8_ATM", "Land_Mattaust_ATM", "Land_AR_ATM", "Terminal_ATM", "MW_ATMWall" };

		// List of Dumpster Classnames to use
		dumpster_types[] = { "Land_Dumpster_DED_Dumpster_01_F", "Land_JD_Dumpster" };

		//false - Group leaders can access the commander view. true [default] - Group leaders cannot access the commander view.
		disableCommanderView = true;

		//Enable the donor level set in database (var = life_donorlevel; levels = 0,1). ATTENTION! Before enabling, read: https://www.bistudio.com/community/game-content-usage-rules & https://www.bistudio.com/monetization
		donor_level = false;

		//Enable bonus to paychecks if player has server name in steam name
		paycheck_bonus = false;
		paycheck_serverName = "TakistanRP";

		DisableTFAR = false;

		banned_words[] = { "fuck", "shit", "prick", "nigger", "nigga", "jiggaboo", "spic", "faggot", "fag", "bitch", "paki", "coon", "nignog", "niglet", "porch monkey", "porchmonkey", "chink", "gook", "towelhead", "spick", "wetback", "beaner" };

		clothing_masks[] = { "G_Bandanna_khk", "H_RacingHelmet_1_black_F", "H_RacingHelmet_1_blue_F", "H_RacingHelmet_2_F", "H_RacingHelmet_1_F", "H_RacingHelmet_1_green_F", "H_RacingHelmet_1_orange_F", "H_RacingHelmet_1_red_F", "H_RacingHelmet_3_F", "H_RacingHelmet_4_F", "H_RacingHelmet_1_white_F", "H_RacingHelmet_1_yellow_F", "G_Balaclava_blk", "G_Balaclava_oli", "CUP_G_RUS_Balaclava_Ratnik", "CUP_G_RUS_Balaclava_Ratnik_winter_v2", "CUP_U_O_RUS_Ratnik_BeigeDigital", "CUP_RUS_Balaclava_blk" };

		class Player {
			//Amount of cash each side starts with
			bank_cop = 75000;
			bank_opf = 75000;
			bank_civ = 75000;
			bank_med = 75000;

			//Tax that player pays when transferring money from ATM. Tax = Amount * multiplier
			bank_transferTax = .05;

			//How much to tax when using a debit card
			debit_tax = .05;

			//Maximum number of houses a player can own.
			house_limit = 5;

			//The maximum weight allowed without having a backpack
			nobag_maxWeight = 40;
		};

		class GovFactions {
			//Max Cop Whitelist Level
			cop_maxLevel = 8;

			//Cop Rank Display Names
			cop_rankArray[] = { "No Level","Private","Private First Class","Corporal","Sergeant","Staff Sergeant","Lieutenant","Captain","Command" };

			//Cop required level to whitelist
			cop_whitelistLevel = 6;

			//Amount of cop departments Default: 4
			cop_departmentsCount = 4;

			//Cop Department
			cop_departmentsArray[] = { "none", "Takistan Police", "NATO", "CIA", "Command" };
			cop_deptNoWhitelist[] = { "CIA", "Command"};

			class CopLoadouts {
				//TypeOf loadout vehicle for cops (so the class name)
				cop_loadoutVeh = "";
			};

			//Max Opfor Whitelist Level
			opf_maxLevel = 8;

			//Opfor Rank Display Names : TODO: Maybe do a translations of the ranks for the larp??
			opf_rankArray[] = { "No Level","Private","Private First Class","Corporal","Sergeant","Staff Sergeant","Lieutenant","Captain","Command" };

			//Opfor required level to whitelist
			opf_whitelistLevel = 6;

			//Amount of Opfor departments
			opf_departmentsCount = 4;

			//Opfor department
			opf_departmentsArray[] = { "none", "TLA", "AFRF", "FIS", "Command"};
			opf_deptNoWhitelist[] = { "FIS","Command" };


			//Max Medic Whitelist Level
			med_maxLevel = 4;

			//Med Rank Display Names
			med_rankArray[] = { "Paramedic", "Trained Paramedic", "Private Contractor", "Surgeon General", "Company CEO" };

			//Medic required level to whitelist
			med_whitelistLevel = 3;

			//Amount of medic departments Default: 1
			med_departmentsCount = 1;

			//Medic Department Names Default: (EMS - 0, PMC - 1)
			med_departmentsArray[] = { "EMS", "PMC" };

			//DOJ Members ID's
			doj_members[] = {};
		};

		class Gangs {
			//Gang creation price
			gang_price = 45000;

			//The base cost for purchasing additional slots in a gang
			gang_upgradeBase = 4000;

			//Multiplier times off base upgrade price
			gang_upgradeMultiplier = 2.5;

			//Spawn location for Gang Hideout 1
			GangHideout1[] = { 7678.066, 1313.97, 3.01241 };

			// Arms Dealer
			arms_dealer = 0.15;
		};

		class EscapeMenu {
			//Time required to pass before you can click the abort button in the escape menu.
			escapeMenu_timer = 12;

			//Display the players UID & serverName specified below in the escape menu.
			escapeMenu_displayExtras = true;

			//Text displayed in the escape menu. Make it short.. around 20 characters.
			escapeMenu_displayText = "Thanks for playing!";
		};
	};

	class Events {
		class SupplyCrate {
			//Enable the supply crate event
			enable_supplyCrate = true;

			//Amount of players to make the crate spawn
			supply_playerCount = 15;

			//Time for drops
			supply_minTime = 35;
			supply_maxTime = 55;

			//Amount of weapons the crate wil spawn
			supply_weaponsCount = 2;

			//Weapon, Attachments, Rarity (using selectRandomWeighted)
			supply_weapons[] = {
				{ "arifle_ARX_hex_F", "30Rnd_65x39_caseless_green" },
				{ "CUP_srifle_RSASS_Sand", "CUP_20Rnd_762x51_B_M110" },
				{ "srifle_EBR_F", "20Rnd_762x51_Mag" }
			};

			supply_items[] = {
				{ "FHQ_optic_AC11704" },
				{ "optic_Hamr" },
				{ "optic_Arco_blk_F" }
			};
		};

		class Maverick {
			//Enable double xp for talent tree
			enable_doubleXP = false;
		};

		class WeaponTransport {
			// Enable weapon transport mission.
			enable_weaponTransport = true;

			//Where the transport truck will spawn.
			spawn_points[] = { "event_transport_spawn1" };

			// Transport truck class name.
			truck_class[] = { "O_Truck_03_ammo_f" };

			//The vehicle will be required the be repaired.
			truck_startBroken = true;

			//The amount of rewards it will give you.
			reward_amount = 4;

			//Rewards put the array here. (Can be an VItem, Class Name or Cash)
			cop_reward[] = { { "money", 50000 } };
			gang_reward[] = { { "money", 50000 }, { "marijuana", 30 }, { "MDMA", 30 }, { "cocaine", 20 } };
			chop_reward[] = { { "money", 30000 } };

			// If you deliver in this time you will get a bonus. (Time in seconds)
			special_rewardtime = 420;
			special_rewardamount = 6;
		};

		class AsylumSeeker {
			// Enable the Asylum Seeker mission
			enable_asylumseeker = true;

			// The amount to spawn
			spawn_amount[] = { 3, 6 }; // Make sure only 2 values in array
			// Distance it should spawn them apart
			spawn_distance = 500;

			// How much to give them? 0 to stop it
			civ_reward = 50000;
			cop_reward = 0;
			medic_reward = 0;
		};

		class WeaponsCache {
			//Enable or disable the event
			enabled = false;

			//Amount of players needed before event can start
			playerCount = 0; //30

			//Cops online before cache can be robbed
			numberOfCops = 0; //7

			//Amount of time before each charge blows in seconds
			chargeTimer = 10; //120

			//Random weapons array {weapon,mag}
			weapons[] = {};

			//Random scopes array
			scopes[] = {};
		};

		class WeaponSpawns {
			/*
				This can be any class name that is a weapon ammo will be added from the first ammo type.

				The number is the amount to be added to the random total.
				if there are two options and item 1 has value of 1 and the
				second has a value of 999 there will be a 999/1000 that item 
				is the second.
			*/
			weapons[] = {};
		};

		class Quest {

			spawnPos[] = {5673.22,1186.46,0.393005};
		};
	};

	class Shops {
		class Fuel {
			//Cost of fuel per liter at fuel stations (if not defined for the vehicle already).
			fuel_cost = 15;

			//Cost to refuel an empty fuel canister at the fuel station pumps. (Be wary of your buy/sell prices on fuel cans to prevent exploits...)
			fuelCan_refuel = 1500;
		};

		class Vehicle {
			//Vehicles that can only be rented and not purchased
			vehicleShop_rentalOnly[] = {};

			// Vehicles that will be crushed instead of impounded throught the cop interaction
			illegalVehicles[]  = { "CUP_I_BTR40_MG_TKG", "CUP_O_Datsun_PK_Random", "CUP_O_Hilux_AGS30_TK_INS", "CUP_O_Hilux_DSHKM_TK_INS", "CUP_O_Hilux_armored_DSHKM_TK_INS", "CUP_O_Hilux_zu23_TK_INS", "CUP_O_Hilux_SPG9_TK_INS", "CUP_O_Hilux_BMP1_TK_INS", "CUP_O_Hilux_btr60_TK_INS", "CUP_O_Hilux_igla_TK_INS", "CUP_O_Hilux_armored_BMP1_TK_INS", "CUP_I_BMP1_TK_GUE", "CUP_O_BMP2_ZU_TKA", "CUP_I_T34_TK_GUE", "CUP_I_MTLB_pk_NAPA", "CUP_O_UH1H_slick_TKA", "CUP_B_AC47_Spooky_USA" };

			//Vehicle Pruchase Prices (Vehicle Pruchase Price * multiplier)
			vehicle_purchase_multiplier_CIVILIAN = 1;
			vehicle_purchase_multiplier_COP = 1;
			vehicle_purchase_multiplier_OPF = 1;
			vehicle_purchase_multiplier_MEDIC = 1;

			//Vehicle Rental Prices (Vehicle Rental Price * multiplier)
			vehicle_rental_multiplier_CIVILIAN = .80;
			vehicle_rental_multiplier_COP = .5;
			vehicle_rental_multiplier_MEDIC = .55;

			//Vehicle Sell Prices (Vehicle Sell Price * multiplier)
			vehicle_sell_multiplier_CIVILIAN = .5;
			vehicle_sell_multiplier_COP = .5;
			vehicle_sell_multiplier_OPF = .5;
			vehicle_sell_multiplier_MEDIC = .5;

			//Chop Shop price for vehicles. TO AVOID EXPLOITS NEVER SET HIGHER THAN A PURCHASE/RENTAL multipler!   Payout = Config_vehicle Price * multiplier
			vehicle_chopShop_multiplier = 0.4;
			vehicle_chopClaim_multiplier = 0.15;

			//Pull from garage cost  (Buy Price * multiplier)
			vehicle_storage_fee_multiplier = .02;

			//Impound Multiplier *Never set higher then cop multipliers above* (Config_vehicle Price * multiplier)
			vehicle_cop_impound_multiplier = .01;

			//Price to mod vehicle
			vehicle_modShop_price = 5000;

			// This will only cover is the vehicle blows up.
			vehicle_insurnace_price_l1 = 0.25;

			// This will include the previous level but also chopping of the vehicle.
			vehicle_insurnace_price_l2 = 0.5;

			vehicle_preview_position[] = { 8257.672,2130.651,0.1 };

			vehicle_preview_disable_siren[] = { "d3s_200_16", "d3s_e39_03", "d3s_e38_98" };
		};
	};

	CarShopSpawns[] = { "impoundPoint1","cop_car_7", "impoundPoint2", "civcar1", "civcar2", "civcar3", "civcar4", "civcar5", "civcar6", "civcar7", "civcar8", "civcar9", "civcar10", "civcar11", "civcar12", "civcar13", "civcar14", "civcar15", "civcar16", "civcar17", "civcar18", "civcar19", "civcar20", "civcar21", "civcarlux1", "civcarlux1_1", "civcarsport1", "civcarlux2", "civcarlux3", "civcarlux4", "civtruck1", "civtruck2", "car_g_1", "car_g_2", "car_g_3", "car_g_4", "car_g_5", "car_g_6", "car_g_7", "car_g_8", "car_g_9", "car_g_10", "car_g_11", "car_g_12", "car_g_13", "car_g_14", "car_g_15", "car_g_16", "car_g_17", "car_g_18", "car_g_19", "car_g_20", "cop_car_3", "cop_car_4", "cop_car_5", "cop_car_6", "cop_car_7", "cop_car_8", "cop_car_9","cop_car_10", "cop_car_11", "cop_car_12", "cop_car_13", "med_car_1", "med_car_2", "med_car_3", "med_car_4", "med_car_5", "gangcar", "gangcar_1", "opf_car_1", "opf_car_2" };
	AirShopSpawns[] = { "RebAir","civair1", "civair2", "civair3", "civair4", "copair1", "copair2","copair2_2","copair2_1", "copair3", "copair4", "copair3_1", "medair1", "medair2", "medair3","medair4", "airg1", "airg2","opfor_air_1", "opf_air_1", "opf_air_2" };
	BoatShopSpawns[] = { "civ_ship_1", "civ_ship_2", "civ_ship_3", "civ_ship_4", "civ_ship_5", "cop_ship_1", "cop_ship_2", "cop_ship_3", "cop_ship_4", "cop_ship_5", "ems_ship_1", "ems_ship_2", "ems_ship_3" };

	/* Hunting & Fishing System Configurations */
	animaltypes_fish[] = { "Salema_F", "Ornate_random_F", "Mackerel_F", "Tuna_F", "Mullet_F", "CatShark_F", "Turtle_F" };

	/* Array of Items the Risk Bonus is Applied To (Illegal Resources) */
	riskBonus_items[] = { "hindukush", "hash", "cocaine", "crack", "heroin", "heroinPure", "acid", "DMT" };
	
	class MiniGame {
		/* Type of minigame (Sound: The sound that is played everytime you press [E], Add: Amount of percentage between 1 and the add value that is added) */
		class houseRobbery {
			sound = "breakDown";
			add = 20;
		};
		class gasStation {
			sound = "codeCrack";
			add = 20;
		};
		class WeaponCache_MainDoor {
			sound = "codeCrack";
			add = 7;
		};
		class BankMajor_CrowBar {
			sound = "crowbarCling";
			add = 7;
		};
		class BankMajor_CodeCrack {
			sound = "codeCrack";
			add = 7;
		};
		class BankMajor_KillGen {
			sound = "codeCrack";
			add = 7;
		};
	};

	class Lottery {

		class ScratchOff {
			prizes[] = {
				{ 0.999, 500000 },
				{ 0.99, 250000 },
				{ 0.97, 70000 },
				{ 0.90, 12000 },
				{ 0.70, 7500 },
				{ 0.60, 2500 },
				{ 0, 0 }
			};
		};
	};

	class Hunting {
		// Animals to spawn for hunting
		class Sheep {
			amount = 35;
		};
	};
};

#include "Config_Weapons.hpp"
#include "Config_Clothing.hpp"
#include "Config_Licenses.hpp"
#include "Config_Vehicles.hpp"
#include "Config_vItems.hpp"
#include "Config_Gather.hpp"
#include "Config_SpawnPoints.hpp"
#include "Config_Process.hpp"
#include "Config_Housing.hpp"
#include "Config_HouseLoot.hpp"
#include "Config_Interactions.hpp"
#include "Config_Jail.hpp"
#include "Config_Gangs.hpp"
//#include "Config_Skills.hpp"
#include "Config_Factions.hpp"
#include "Config_Mining.hpp"
#include "Config_Website.hpp"
#include "Config_Jobs.hpp"
#include "Config_Achievements.hpp"
#include "Config_Rewards.hpp"
#include "Config_DynMarket.hpp"
#include "Config_Titles.hpp"
#include "Config_Apartments.hpp"
#include "Config_Warpoints.hpp"
#include "Config_Farming.hpp"