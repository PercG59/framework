
class Jobs {
	class Default {
		name = "name";
		description = "description";
		paycheck = 0;		// per minute
		initScript = "";	// script when starting job
		endScript = "";		// script when ending job
		failScript = "";	// script when ending job
		payCondition = "";	// check to be *on* job
		failCondition = ""; // if true you will be fired
		playerLimit = 2;	// how many players can be on this job at a time
		idleTime = 5;		// how many times you can fail payCondition before you are fired
	};

	class StreetCleaner : Default {
		name = "Street cleaner";
		description = "description";
		paycheck = 2200;								  // per minute
		initScript = "SG_StreetCleaner_Start";			  // script when starting job
		endScript = "SG_StreetCleaner_End";				  // script when ending job
		failScript = "SG_StreetCleaner_Fail";			  // script when ending job
		payCondition = "SG_StreetCleaner_PayCondition";	  // check to be *on* job
		failCondition = "SG_StreetCleaner_FailCondition"; // if true you will be fired
		playerLimit = 2;								  // how many players can be on this job at a time
		idleTime = 5;									  // how many times you can fail payCondition before you are fired
	};
};
