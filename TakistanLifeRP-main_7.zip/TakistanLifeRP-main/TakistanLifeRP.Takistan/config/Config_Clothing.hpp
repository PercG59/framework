/*
*    ARRAY FORMAT:
*        0: STRING (Classname)
*        1: STRING (Display Name, leave as "" for default)
*        2: SCALAR (Price)
*        3: STRING (Conditions) - Must return boolean :
*            String can contain any amount of conditions, aslong as the entire
*            string returns a boolean. This allows you to check any levels, licenses etc,
*            in any combination. For example:
*                "call life_coplevel && license_civ_someLicense"
*            This will also let you call any other function.
*
*   Clothing classnames can be found here: https://community.bistudio.com/wiki/Arma_3_CfgWeapons_Equipment
*   Backpacks/remaining classnames can be found here (TIP: Search page for "pack"): https://community.bistudio.com/wiki/Arma_3_CfgVehicles_EMPTY
*
*/
class Clothing {
	class bruce {
		title = "STR_Shops_C_Bruce";
		conditions = "";
		side = "";
		uniforms[] = {
			{ "NONE", $STR_C_Remove_uniforms, 0, "" },
            { "U_C_IDAP_Man_cargo_F", "", 200, "" },
            { "U_C_IDAP_Man_Jeans_F", "", 200, "" },
            { "U_C_IDAP_Man_casual_F", "", 200, "" },
            { "U_C_IDAP_Man_shorts_F", "", 200, "" },
            { "EF_FEM_3_9B2", "", 200, "" },
            { "U_C_IDAP_Man_Tee_F", "", 200, "" },
            { "U_C_IDAP_Man_TeeShorts_F", "", 200, "" },
			{ "U_I_C_Soldier_Bandit_4_F", "", 200, "" },
			{ "U_I_C_Soldier_Bandit_1_F", "", 200, "" },
			{ "U_I_C_Soldier_Bandit_2_F", "", 200, "" },
			{ "U_I_C_Soldier_Bandit_5_F", "", 200, "" },
			{ "U_I_C_Soldier_Bandit_3_F", "", 200, "" },
			{ "EF_FEM_3_9W", "", 200, "" },
			{ "EF_FEM_3_9_2GRBK", "", 200, "" },
			{ "EF_FEM_3_9_2BLRD", "", 200, "" },
			{ "U_C_ArtTShirt_01_v6_F", "", 200, "" },
			{ "U_C_ArtTShirt_01_v1_F", "", 200, "" },
			{ "U_C_Man_casual_2_F", "", 200, "" },
			{ "U_C_ArtTShirt_01_v2_F", "", 200, "" },
			{ "U_C_ArtTShirt_01_v4_F", "", 200, "" },
			{ "U_C_Man_casual_3_F", "", 200, "" },
			{ "U_C_Man_casual_1_F", "", 200, "" },
			{ "U_C_ArtTShirt_01_v5_F", "", 200, "" },
            { "U_C_ArtTShirt_01_v3_F", "", 200, "" },
            { "EF_HM_B1", "", 200, "" },
            { "EF_FEM_4_2BL2", "", 200, "" },
            { "EF_FEM_4A2", "", 200, "" },
            { "EF_suit_7", "", 200, "" },
            { "EF_suit_6", "", 200, "" },
            { "EF_suit_8", "", 200, "" },
            { "CUP_U_O_CHDKZ_Bardak", "", 200, "" },
            { "CUP_U_O_CHDKZ_Lopotev", "", 200, "" },
            { "CUP_U_C_Citizen_01", "", 200, "" },
            { "CUP_U_C_Citizen_04", "", 200, "" },
            { "CUP_U_C_Citizen_02", "", 200, "" },
            { "CUP_U_C_Citizen_03", "", 200, "" },
            { "CUP_U_C_Priest_01", "", 200, "" },
			{ "EF_HM_LPBL", "", 200, "" },
			{ "EF_M_jkt1_3", "", 200, "" },
			{ "EF_M_jkt4", "", 200, "" },
			{ "EF_M_jkt2_2", "", 200, "" },
			{ "EF_M_jkt1", "", 200, "" },
			{ "EF_M_jkt22", "", 200, "" },
			{ "EF_HM_OD2", "", 200, "" },
			{ "EF_HM_PP2", "", 200, "" },
			{ "EF_HM_BL1", "", 200, "" },
			{ "U_C_Driver_2", "", 200, "" },
			{ "U_C_Poloshirt_blue", "", 200, "" },
			{ "U_C_Poloshirt_burgundy", "", 200, "" },
			{ "U_C_Poloshirt_redwhite", "", 200, "" },
			{ "U_C_Poloshirt_salmon", "", 200, "" },
			{ "U_C_Poloshirt_stripped", "", 200, "" },
			{ "U_C_Poloshirt_tricolour", "", 200, "" },
			{ "U_Competitor", "", 200, "" },
			{ "U_C_ConstructionCoverall_Black_F", "", 200, "" },
			{ "U_C_ConstructionCoverall_Blue_F", "", 200, "" },
			{ "U_C_ConstructionCoverall_Red_F", "", 200, "" },
			{ "U_C_ConstructionCoverall_Vrana_F", "", 200, "" },
			{ "U_C_Driver_1_black", "", 200, "" },
			{ "U_C_Driver_1_blue", "", 200, "" },
			{ "U_C_Uniform_Farmer_01_F", "", 200, "" },
			{ "U_C_Driver_4", "", 200, "" },
			{ "U_C_Driver_1", "", 200, "" },
			{ "U_C_Driver_3", "", 200, "" },
			{ "U_C_Driver_1_green", "", 200, "" },
			{ "U_C_Driver_1_orange", "", 200, "" },
			{ "U_C_Driver_1_red", "", 200, "" },
			{ "U_C_Driver_1_yellow", "", 200, "" },
			{ "U_C_Driver_1_white", "", 200, "" },
			{ "U_C_FormalSuit_01_black_F", "", 1000, "" },
			{ "U_C_FormalSuit_01_grey_F", "", 1000, "" }, // broken in game
			{ "U_C_FormalSuit_01_khaki_F", "", 1000, "" },
			{ "U_C_FormalSuit_01_blue_F", "", 1000, "" },
			{ "U_C_FormalSuit_01_tshirt_black_F", "", 1000, "" },
			{ "U_C_FormalSuit_01_tshirt_grey_F", "", 1000, "" }, //broken in game
			{ "U_O_R_Gorka_01_F", "", 200, "" },
			{ "U_O_R_Gorka_01_brown_F", "", 200, "" },
			{ "U_BG_Guerilla1_1", "", 200, "" },
			{ "U_BG_Guerilla1_2_F", "", 200, "" },
			{ "U_BG_Guerilla2_2", "", 200, "" },
			{ "U_BG_Guerilla2_1", "", 200, "" },
			{ "U_BG_Guerilla2_3", "", 200, "" },
			{ "U_BG_Guerilla3_1", "", 200, "" },
			{ "CUP_U_C_Profiteer_02", "", 200, "" },
			{ "CUP_U_C_Tracksuit_02", "", 200, "" },
			{ "CUP_U_C_Tracksuit_01", "", 200, "" },
			{ "CUP_U_C_Tracksuit_04", "", 200, "" },
			{ "CUP_U_C_Tracksuit_03", "", 200, "" },
			{ "CUP_U_C_Villager_01", "", 200, "" },
			{ "CUP_U_C_Villager_04", "", 200, "" },
			{ "CUP_U_C_Villager_02", "", 200, "" },
			{ "CUP_U_C_Villager_03", "", 200, "" },
			{ "U_I_Wetsuit", "", 200, "" },
			{ "CUP_U_C_Woodlander_01", "", 200, "" },
			{ "CUP_U_C_Woodlander_02", "", 200, "" },
			{ "CUP_U_C_Woodlander_03", "", 200, "" },
			{ "CUP_U_C_Woodlander_04", "", 200, "" },
			{ "CUP_U_C_Worker_03", "", 200, "" },
			{ "CUP_U_C_Worker_04", "", 200, "" },
			{ "CUP_U_C_Worker_02", "", 200, "" },
			{ "CUP_U_C_Worker_01", "", 200, "" },
			{ "U_C_Poor_1", "", 200, "" },
			{ "U_C_CBRN_Suit_01_Blue_F", "", 50000, "" },
			{ "CUP_U_C_Labcoat_02", "", 200, "" },
			{ "CUP_U_C_Labcoat_03", "", 200, "" },
			{ "CUP_U_C_Labcoat_01", "", 200, "" },
			{ "CUP_O_TKI_Khet_Partug_08", "", 200, "" },
			{ "CUP_O_TKI_Khet_Partug_07", "", 200, "" },
			{ "CUP_O_TKI_Khet_Partug_06", "", 200, "" },
			{ "CUP_O_TKI_Khet_Partug_05", "", 200, "" },
			{ "CUP_O_TKI_Khet_Partug_04", "", 200, "" },
			{ "CUP_O_TKI_Khet_Partug_03", "", 200, "" },
			{ "CUP_O_TKI_Khet_Partug_02", "", 200, "" },
			{ "CUP_O_TKI_Khet_Partug_01", "", 200, "" },
			{ "CUP_O_TKI_Khet_Jeans_04", "", 200, "" },
			{ "CUP_O_TKI_Khet_Jeans_03", "", 200, "" },
			{ "CUP_O_TKI_Khet_Jeans_02", "", 200, "" },
			{ "CUP_O_TKI_Khet_Jeans_01", "", 200, "" },
			{ "U_C_Journalist", "", 200, "" },
			{ "U_OrestesBody", "", 200, "" },
			{ "U_C_HunterBody_grn", "", 200, "" },
			{ "CUP_U_C_Rocker_01", "", 200, "" },
			{ "CUP_U_C_Rocker_03", "", 200, "" },
			{ "CUP_U_C_Rocker_02", "", 200, "" },
			{ "CUP_U_C_Rocker_04", "", 200, "" },
			{ "U_C_Uniform_Scientist_02_F", "", 200, "" },
			{ "U_C_Uniform_Scientist_02_formal_F", "", 200, "" },
			{ "U_C_man_sport_1_F", "", 200, "" },
			{ "U_C_man_sport_3_F", "", 200, "" },
			{ "U_C_man_sport_2_F", "", 200, "" },
			{ "CUP_U_C_Suit_01", "", 200, "" },
			{ "CUP_U_C_Suit_02", "", 200, "" },
			{ "CUP_U_C_Suit_03", "", 200, "" },
			{ "CUP_U_C_Functionary_jacket_02", "", 200, "" },
			{ "CUP_U_C_Functionary_jacket_01", "", 200, "" },
			{ "CUP_U_C_Functionary_jacket_03", "", 200, "" },
			{ "U_C_Man_casual_6_F", "", 200, "" },
			{ "U_C_Man_casual_4_F", "", 200, "" },
			{ "U_C_Man_casual_5_F", "", 200, "" },
			{ "CUP_U_C_racketeer_02", "", 200, "" },
			{ "CUP_U_C_racketeer_03", "", 200, "" },
			{ "CUP_U_C_racketeer_04", "", 200, "" },
			{ "CUP_U_C_racketeer_01", "", 200, "" },
			{ "TRYK_OVERALL_nok_flesh", "", 200, "" },
			{ "CUP_U_C_Profiteer_04", "", 200, "" },
			{ "CUP_U_C_Profiteer_01", "", 200, "" },
			{ "CUP_U_C_Profiteer_03", "", 200, "" },
			{ "CUP_U_C_Profiteer_02", "", 200, "" },
			{ "TRYK_U_B_wh_blk_Rollup_CombatUniform", "", 200, "" },
			{ "TRYK_U_B_PCUGs_OD", "", 200, "" },
			{ "TRYK_shirts_DENIM_ylb_Sleeve", "", 200, "" },
			{ "TRYK_shirts_DENIM_BK_Sleeve", "", 200, "" },
			{ "TRYK_shirts_DENIM_WH_Sleeve", "", 200, "" },
			{ "TRYK_shirts_DENIM_RED2_Sleeve", "", 200, "" },
			{ "CUP_O_TKI_Khet_Jeans_04", "", 200, "" },
			{ "CUP_O_TKI_Khet_Jeans_03", "", 200, "" },
			{ "CUP_O_TKI_Khet_Partug_08", "", 200, "" },
			{ "CUP_O_TKI_Khet_Partug_04", "", 200, "" },
			{ "CUP_O_TKI_Khet_Partug_06", "", 200, "" },
			{ "CUP_O_TKI_Khet_Partug_03", "", 200, "" },
			{ "CUP_U_C_Labcoat_02", "", 200, "" },
			{ "CUP_U_C_Mechanic_02", "", 200, "" },
			{ "CUP_U_C_Mechanic_03", "", 200, "" },
			{ "CUP_U_C_Pilot_01", "", 200, "" },
			{ "EF_MKJKT", "", 200, "" },
			{ "EF_MKJKT2", "", 200, "" },
			{ "EF_M_jkt3", "", 200, "" },
			{ "EF_M_jkt2_32", "", 200, "" },
			{ "EF_FEM_10A_BK", "", 200, "" },
			{ "EF_FEM_10A_BK_W", "", 200, "" },
			{ "EF_FEM_10A_R_BK", "", 200, "" },
			{ "EF_HM_LPBP", "", 200, "" },
			{ "EF_HM_LPBW", "", 200, "" },
			{ "EF_HM_LPBR", "", 200, "" },
			{ "EF_MX1", "", 200, "" },
			{ "EF_suit_4", "", 200, "" },
			{ "EF_suit_1", "", 200, "" },
			{ "EF_suit_2", "", 200, "" },
			{ "EF_suit_3", "", 200, "" },
			{ "TRYK_U_B_PCUGs_gry", "", 200, "" },
			{ "TRYK_U_B_PCUGs_BLK_R", "", 200, "" },
			{ "TRYK_shirts_DENIM_WH_Sleeve", "", 200, "" },
			{ "TRYK_shirts_DENIM_BL", "", 200, "" },
		};

		headgear[] = {
			{ "NONE", $STR_C_Remove_headgear, 0, "" },
            {"H_Bandanna_gry", "", 200, "" },
            {"H_Bandanna_blu", "", 200, "" },
            {"H_Bandanna_cbr", "", 200, "" },
			{"CUP_H_FR_BandanaGreen", "", 200, "" },
			{"H_Bandanna_surfer_blk", "", 200, "" },
			{"CUP_H_FR_BandanaWdl", "", 200, "" },
			{"CUP_H_C_Beanie_01", "", 200, "" },
			{"CUP_H_C_Beanie_03", "", 200, "" },
			{"CUP_H_C_Beanie_04", "", 200, "" },
			{"H_Beret_blk", "", 200, "" },
			{"CUP_H_ChDKZ_Beret", "", 200, "" },
			{"CUP_H_SLA_BeretRed", "", 200, "" },
			{"CUP_H_RUS_Cap_ATACSAU", "", 200, "" },
			{"CUP_H_RUS_Cap_ATACSFG", "", 200, "" },
			{"H_Cap_grn_BI", "", 200, "" },
			{"H_Cap_blk", "", 200, "" },
			{"H_Cap_blu", "", 200, "" },
			{"H_Cap_blk_CMMG", "", 200, "" },
			{"CUP_H_C_MAGA_01", "", 200, "" },
			{"H_Cap_surfer", "", 200, "" },
			{"H_EarProtectors_black_F", "", 200, "" },
			{"H_EarProtectors_yellow_F", "", 200, "" },
			{"EF_FHAT_BK", "", 200, "" },
			{"EF_FHAT_BW", "", 200, "" },
            {"EF_FHAT_CL", "", 200, "" },
			{"EF_wig_DHB", "", 200, "" },
			{"H_Construction_earprot_black_F", "", 200, "" },
			{"H_Construction_earprot_orange_F", "", 200, "" },
			{"H_Construction_earprot_red_F", "", 200, "" },
			{"H_Construction_earprot_yellow_F", "", 200, "" },
			{"H_Hat_blue", "", 200, "" },
			{"H_Hat_brown", "", 200, "" },
            {"H_Hat_checker", "", 200, "" },
            {"H_Hat_grey", "", 200, "" },
            {"H_Hat_tan", "", 200, "" },
			{"H_RacingHelmet_1_black_F", "", 200, "" },
			{"H_RacingHelmet_1_blue_F", "", 200, "" },
			{"H_RacingHelmet_2_F", "", 200, "" },
			{"H_RacingHelmet_1_F", "", 200, "" },
			{"H_RacingHelmet_1_green_F", "", 200, "" },
			{"H_RacingHelmet_1_orange_F", "", 200, "" },
			{"H_RacingHelmet_1_red_F", "", 200, "" },
			{"H_RacingHelmet_3_F", "", 200, "" },
			{ "H_RacingHelmet_4_F", "", 200, "" },
            { "H_RacingHelmet_1_white_F", "", 200, "" },
            { "H_RacingHelmet_1_yellow_F", "", 200, "" },
            { "H_Hat_Safari_olive_F", "", 200, "" },
            { "H_Hat_Safari_sand_F", "", 200, "" },
            { "H_Shemag_olive", "", 200, "" },
            { "H_ShemagOpen_tan", "", 200, "" },
            { "H_ShemagOpen_khk", "", 200, "" },
            { "H_Helmet_Skate", "", 200, "" },
            { "H_StrawHat", "", 200, "" },
			{ "H_StrawHat_dark", "", 200, "" },
			{ "CUP_H_TKI_Lungee_Open_01", "", 200, "" },
			{ "CUP_H_TKI_Lungee_Open_04", "", 200, "" },
			{ "CUP_H_TKI_Pakol_1_01", "", 200, "" },
			{ "CUP_H_TKI_Pakol_2_04", "", 200, "" },
			{ "CUP_H_TKI_Pakol_2_05", "", 200, "" },
			{ "CUP_H_TKI_Pakol_2_06", "", 200, "" },
			{ "CUP_H_TKI_SkullCap_01", "", 200, "" },
			{ "CUP_H_TKI_SkullCap_02", "", 200, "" },
			{ "CUP_H_TKI_SkullCap_03", "", 200, "" },
			{ "CUP_H_TKI_SkullCap_04", "", 200, "" },
			{ "CUP_H_TKI_SkullCap_05", "", 200, "" },
			{ "CUP_H_TKI_SkullCap_06", "", 200, "" },
			{ "H_Hat_Tinfoil_F", "", 5000, "" },
			{ "CUP_H_C_Ushanka_02", "", 200, "" },
			{ "CUP_H_C_Ushanka_01", "", 200, "" },
			{ "CUP_H_C_Ushanka_04", "", 200, "" },
			{ "H_WirelessEarpiece_F", "", 690, "" }
		};

		goggles[] = {
			{ "NONE", $STR_C_Remove_goggles, 0, "" },
            { "G_Aviator", "", 250, "" },
			{ "G_Balaclava_blk", "", 200, "" },
			{ "G_Balaclava_oli", "", 200, "" },
			{ "CUP_G_RUS_Balaclava_Ratnik", "", 200, "" },
			{ "G_Bandanna_aviator", "", 200, "" },
			{ "G_Bandanna_beast", "", 250, "" },
			{ "G_Bandanna_blk", "", 250, "" },
			{ "G_Bandanna_khk", "", 250, "" },
			{ "G_Bandanna_oli", "", 250, "" },
			{ "G_Bandanna_sport", "", 250, "" },
			{ "CUP_Beard_Black", "", 250, "" },
			{ "CUP_Beard_Blonde", "", 200, "" },
			{ "CUP_Beard_Brown", "", 200, "" },
			{ "EF_MSG_T", "", 500, "" },
			{ "EF_MSG_BK", "", 230, "" },
			{ "EF_MSG_BL", "", 260, "" },
			{ "EF_MSG_BW", "", 260, "" },
			{ "EF_MSG_C", "", 260, "" },
			{ "EF_MSG_G", "", 260, "" },
			{ "EF_MSG_P", "", 260, "" },
			{ "EF_RG1", "", 260, "" },
			{ "EF_RG2", "", 260, "" },
			{ "G_Lowprofile", "", 260, "" },
			{ "CUP_G_Scarf_Face_Blk", "", 260, "" },
			{ "CUP_G_Scarf_Face_Red", "", 260, "" },
			{ "CUP_G_Scarf_Face_White", "", 260, "" },
			{ "CUP_G_Oakleys_Drk", "", 260, "" },
			{ "CUP_G_Oakleys_Embr", "", 260, "" },
			{ "G_Respirator_blue_F", "", 50, "" },
			{ "G_Respirator_white_F", "", 50, "" },
			{ "CUP_G_TK_RoundGlasses", "", 260, "" },
			{ "CUP_G_TK_RoundGlasses_blk", "", 260, "" },
			{ "CUP_G_TK_RoundGlasses_gold", "", 260, "" },
			{ "G_EyeProtectors_F", "", 260, "" },
			{ "G_Shades_Black", "", 260, "" },
			{ "G_Shades_Blue", "", 260, "" },
			{ "G_Shades_Green", "", 260, "" },
			{ "G_Shades_Red", "", 260, "" },
			{ "G_Spectacles", "", 260, "" },
			{ "G_Sport_Red", "", 260, "" },
			{ "G_Sport_Blackyellow", "", 260, "" },
			{ "G_Sport_BlackWhite", "", 260, "" },
			{ "G_Sport_Blackred", "", 260, "" },
			{ "G_Sport_Greenblack", "", 260, "" },
			{ "G_Squares_Tinted", "", 260, "" },
			{ "G_Squares", "", 260, "" },
			{ "G_Spectacles_Tinted", "", 260, "" },
		};

		vests[] = {
			{ "NONE", $STR_C_Remove_vests, 0, "" },
			{ "V_DeckCrew_blue_F", "", 350, "" },
			{ "V_DeckCrew_red_F", "", 350, "" },
			{ "V_DeckCrew_yellow_F", "", 350, "" },
			{ "V_LegStrapBag_black_F", "", 350, "" },
			{ "V_LegStrapBag_coyote_F", "", 350, "" },
			{ "V_LegStrapBag_olive_F", "", 350, "" },
			{ "V_Pocketed_black_F", "", 350, "" },
			{ "V_Pocketed_coyote_F", "", 350, "" },
			{ "V_Pocketed_olive_F", "", 350, "" },
			{ "V_Safety_blue_F", "", 350, "" },
			{ "V_Safety_orange_F", "", 350, "" },
			{ "V_Safety_yellow_F", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket1_04", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket1_06", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket1_01", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket1_05", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket1_02", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket1_03", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket5_04", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket5_05", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket5_02", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket5_06", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket5_01", "", 350, "" },
			{ "CUP_V_O_TK_OfficerBelt", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket6_04", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket6_05", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket6_02", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket6_06", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket6_03", "", 350, "" },
			{ "CUP_V_OI_TKI_Jacket6_01", "", 350, "" }
		};

		backpacks[] = {
			{ "NONE", $STR_C_Remove_backpacks, 0, "" },
			{ "CUP_B_AlicePack_Khaki", "", 5000, "" },
			{ "CUP_B_AlicePack_OD", "", 5000, "" },
			{ "B_AssaultPack_blk", "", 4000, "" },
			{ "B_AssaultPack_cbr", "", 4000, "" },
			{ "B_AssaultPack_dgtl", "", 4000, "" },
			{ "B_AssaultPack_rgr", "", 4000, "" },
			{ "B_AssaultPack_ocamo", "", 4000, "" },
			{ "B_Carryall_cbr", "", 10000, "" },
			{ "B_Carryall_eaf_F", "", 10000, "" },
			{ "B_Carryall_green_F", "", 10000, "" },
			{ "B_Carryall_khk", "", 10000, "" },
			{ "EF_FBAG_BK", "", 1000, "" },
			{ "EF_FBAG_BW", "", 1000, "" },
			{ "EF_FBAG_VL", "", 1000, "" },
			{ "B_CivilianBackpack_01_Everyday_Black_F", "", 2000, "" },
			{ "B_CivilianBackpack_01_Everyday_Vrana_F", "", 2000, "" },
			{ "CUP_B_HikingPack_Civ", "", 2500, "" },
			{ "B_Kitbag_cbr", "", 3500, "" },
			{ "B_Kitbag_rgr", "", 3500, "" },
			{ "B_Kitbag_sgg", "", 3500, "" },
			{ "B_Kitbag_tan", "", 3500, "" },
			{ "CUP_B_GER_Pack_Flecktarn", "", 5000, "" },
			{ "CUP_B_GER_Pack_Tropentarn", "", 5000, "" },
			{ "B_Messenger_Black_F", "", 2000, "" },
			{ "B_Messenger_Coyote_F", "", 2000, "" },
			{ "B_Messenger_Gray_F", "", 2000, "" },
			{ "B_Messenger_Olive_F", "", 2000, "" },
			{ "B_CivilianBackpack_01_Sport_Blue_F", "", 3000, "" },
			{ "B_CivilianBackpack_01_Sport_Green_F", "", 3000, "" },
			{ "B_CivilianBackpack_01_Sport_Red_F", "", 3000, "" },
			{ "B_LegStrapBag_black_F", "", 2000, "" },
			{ "B_LegStrapBag_coyote_F", "", 2000, "" },
			{ "B_LegStrapBag_olive_F", "", 2000, "" }
		};
	};

	class rebel {
		title = "STR_Shops_C_Rebel";
		conditions = "";
		side = "";
		uniforms[] = {
			{ "NONE", $STR_C_Remove_uniforms, 0, "" },
			{ "TRYK_ZARATAKI", "", 1000, "" },
			{ "TRYK_ZARATAKI2", "", 1000, "" },
			{ "TRYK_ZARATAKI3", "", 1000, "" },
			{ "CUP_U_O_CHDKZ_Kam_01", "", 1000, "" },
			{ "CUP_U_O_CHDKZ_Kam_03", "", 1000, "" },
			{ "CUP_U_O_CHDKZ_Kam_02", "", 1000, "" },
			{ "CUP_U_O_CHDKZ_Commander", "", 1000, "" },
			{ "CUP_U_O_CHDKZ_Kam_04", "", 1000, "" },
			{ "CUP_U_O_CHDKZ_Kam_08", "", 1000, "" },
			{ "CUP_U_O_CHDKZ_Kam_05", "", 1000, "" },
			{ "CUP_U_O_CHDKZ_Kam_07", "", 1000, "" }
		};

		headgear[] = {
			{ "NONE", $STR_C_Remove_headgear, 0, "" },
			{"H_ShemagOpen_tan", "", 200, ""},
			{"H_ShemagOpen_khk", "", 200, ""},
			{"CUP_H_TK_Lungee", "", 200, ""},
			{"CUP_H_PASGTv2_DCU", "", 2000, ""},
			{"CUP_H_SLA_Helmet_DES_worn", "", 2500, ""},
			{"CUP_H_WZ67_EAGLE", "", 3000, ""}
		};

		goggles[] = {
			{ "NONE", $STR_C_Remove_goggles, 0, "" },
			{ "CUP_G_RUS_Balaclava_Ratnik_winter_v2", "", 500, "" },
			{ "G_Balaclava_blk", "", 500, "" },
			{ "G_Blindfold_01_black_F", "", 50, "" },
			{ "CUP_G_Tan_Scarf_Shades_Beard", "", 200, "" },
			{ "CUP_G_White_Scarf_Shades_Beard", "", 200, "" },
			{ "G_RegulatorMask_F", "Gas Mask", 10000, "" },
			{ "TAC_SF10", "Gas Mask", 10000, "" }
		};

		vests[] = {
			{ "NONE", $STR_C_Remove_vests, 0, "" },
			{ "V_Chestrig_khk", "", 3000, "" },
			{ "CUP_V_O_TK_Vest_1", "", 3000, "" },
			{ "CUP_V_RUS_Smersh_New_Light_Spectre", "", 3000, "" },
			{ "CUP_V_O_SLA_Flak_Vest03", "", 5000, "" },
			{ "CUP_V_CDF_6B3_2_DST", "", 7000, "" },
			{ "CUP_V_B_Interceptor_Rifleman_DCU", "", 8000, "" },
			{ "V_PlateCarrierGL_mtp", "", 20000, "" },
			{ "SuicideVest", "Suicide Vest", 125000, "" }
		};

		backpacks[] = {
			{ "NONE", $STR_C_Remove_backpacks, 0, "" },
			{ "TRYK_B_CarryCUP_B_RPGPack_Khakiall_blk", "", 5000, "" }
		};
	};

	class cop {
		title = "STR_Shops_C_Police";
		conditions = "";
		side = "cop";
		uniforms[] = {
			{ "NONE", $STR_C_Remove_uniforms, 0, "" },
			// Takistan Police
			{ "TRYK_U_B_BLKTAN_CombatUniform", "", 1000, "true" },
			{ "TRYK_U_B_BLKTANR_CombatUniformTshirt", "", 1000, "true" },

			// NATO
			{ "CUP_U_B_USArmy_ACU_OCP", "", 1000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
            { "CUP_U_B_USArmy_ACU_Rolled_Gloves_OCP", "", 1000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
            { "CUP_U_B_BAF_MTP_UBACSLONGKNEE_Gloves", "", 1000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "TRYK_U_B_ARO1_CombatUniform", "", 1000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "TRYK_U_B_ARO1R_CombatUniform", "", 1000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "U_B_ParadeUniform_01_US_F", "", 2500, "call life_copdept in ['NATO', 'CIA', 'Command']" },

			// Command
            { "TRYK_U_B_GRTAN_CombatUniform", "", 1000, "call life_copdept in ['Command']" },
            { "TRYK_U_B_BLKTANR_CombatUniformTshirt", "", 1000, "call life_copdept in ['Command']" }
		};

		headgear[] = {
			{ "NONE", $STR_C_Remove_headgear, 0, "" },

            // Takistan Police
			{ "EF_Mcap_PB", "", 500, "true" },
			{ "TRYK_H_PASGT_BLK", "", 2500, "true" },
			{ "H_Beret_02", "", 500, "true" },
			
			// NATO
			{ "CUP_H_USA_Cap_TREAD_DEF", "", 500, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "CUP_H_USArmy_HelmetACH_Headset_OCP", "", 5000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "CUP_H_USArmy_HelmetACH_OCP", "", 5000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "CUP_H_USArmy_HelmetACH_GCOVERED_Headset_OCP", "", 5000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "CUP_H_USArmy_HelmetACH_GCOVERED_OCP", "", 5000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "CUP_H_BAF_MTP_Mk6_GOGGLES_PRR", "", 500, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "CUP_H_OpsCore_Tan", "", 5000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "CUP_H_BAF_PARA_BERET", "", 500, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "H_ParadeDressCap_01_US_F", "", 500, "call life_copdept in ['NATO', 'CIA', 'Command']" },

			// Command
            { "H_Beret_Colonel", "", 2500, "call life_copdept in ['Command']" }
		};

		goggles[] = {
			{ "NONE", $STR_C_Remove_goggles, 0, "" },
			{ "CUP_RUS_Balaclava_blk", "", 125, "" },
			{ "G_Aviator", "", 75, "" },
			{ "CUP_PMC_Facewrap_Black", "", 125, "" },
			{ "CUP_PMC_Facewrap_Tan", "", 125, "" },
			{ "CUP_G_PMC_Facewrap_Tan_Glasses_Dark", "", 125, "" },
			{ "CUP_G_PMC_Facewrap_Black_Glasses_Dark", "", 125, "" },
			{ "CUP_G_ESS_BLK_Facewrap_Black", "", 125, "" },
            { "CUP_G_ESS_KHK_Scarf_Tan", "", 125, "" },
            { "CUP_Beard_Black", "", 125, "" },
            { "CUP_Beard_Blonde", "", 125, "" },
            { "CUP_G_ESS_KHK_Dark", "", 125, "" },
            { "G_Spectacles_Tinted", "", 125, "" },
            { "CUP_G_ESS_KHK_Scarf_Tan", "", 125, "" },
            { "G_Bandanna_beast", "", 125, "" },
            { "G_Bandanna_tan", "", 125, "" },
            { "CUP_G_ESS_KHK_Scarf_Face_Tan", "", 250, "" },
            { "CUP_G_ESS_KHK_Scarf_Tan_Beard", "", 250, "" },
            { "CUP_G_ESS_KHK_Scarf_Tan_Beard_Blonde", "", 250, "" },
            { "CUP_G_Tan_Scarf_Shades_GPS_Beard_Blonde", "", 250, "" },
            { "CUP_G_Tan_Scarf_Shades_GPS_Beard", "", 250, "" },
            { "CUP_G_Scarf_Face_Tan", "", 125, "" },
            { "G_Balaclava_combat", "", 125, "" },
			{ "G_AirPurifyingRespirator_01_F", "Gas Mask", 5000, "true" },
			{ "TAC_SF10", "Gas Mask", 5000, "true" },
		};

		vests[] = {
			{ "NONE", $STR_C_Remove_vests, 0, "" },

			// Takistan Police
			{ "TAC_V_tacv1_P", "", 2000, "true" },
			{ "TAC_V_tacv1_P2", "", 2000, "true" },
			{ "EF_MBA_POLICE", "", 2000, "true" },
			{ "EF_MBA_B_POLICE", "", 2000, "true" },
			{ "EF_GSG9_1P", "", 2000, "true" },
			{ "EF_GSG9_2P", "", 2000, "true" },
			{ "TAC_PBDFG2CPL_BK", "", 2000, "true" },
			{ "TAC_PBDFG2CPP_BK_1", "", 2000, "true" },
			{ "TAC_PBDFG2P_B", "", 2000, "true" },
			{ "TAC_FS_FO_P", "", 2000, "true" },

			// NATO
			{ "CUP_V_B_IOTV_OCP_SL_USArmy", "", 4500, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "CUP_V_B_IOTV_OCP_Medic_USArmy", "", 4500, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "CUP_V_B_IOTV_OCP_Rifleman_USArmy", "", 4500, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "CUP_V_B_BAF_MTP_Osprey_Mk4_Rifleman", "", 5000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "TAC_SEAL_RRV21_AOR1", "", 4000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "TAC_SEAL_RRV26_AOR1", "", 4000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "TAC_SEAL_RRV23L_AOR1", "", 4000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "TAC_SEAL_RRV27_AOR1", "", 4000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "TAC_SEAL_RRV21D_AOR1", "", 4000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "TAC_SEAL_RRV21DG_AOR1", "", 4000, "call life_copdept in ['NATO', 'CIA', 'Command']" },
		};

		backpacks[] = {
			{ "NONE", $STR_C_Remove_backpacks, 0, "" },

			// Takistan Police
			{ "TRYK_B_Belt_AOR1", "", 1500, "true" },
			{ "TAC_LBT_LEGAB2_BK", "", 1500, "true" },
			{ "TAC_BP_buttB_B", "", 1500, "true" },
			{ "CUP_B_AssaultPack_Black", "", 1500, "true" },
			{ "TRYK_B_Belt_AOR1", "", 1500, "true" },
			{ "B_AssaultPack_cbr", "", 2000, "true" },
			{ "TRYK_B_Kitbag_Base", "", 2500, "true" },
			{ "CUP_B_USPack_Black", "", 2500, "true" },

			// NATO
			{ "CUP_B_Motherlode_MTP", "", 2500, "call life_copdept in ['NATO', 'CIA', 'Command']" },
			{ "TAC_LBT_LEGAB_CY", "", 2500, "call life_copdept in ['NATO', 'CIA', 'Command']" }
		};
	};

	class opf {
		title = "STR_Shops_C_Police";
		conditions = "";
		side = "opf";
		uniforms[] = {
			{"NONE", $STR_C_Remove_uniforms, 0, "" },
			// TLA
			{ "CUP_U_O_SLA_MixedCamo", "", 500, "true" },
			{ "CUP_U_O_SLA_Desert", "", 500, "true" },
			// AFRF
			{ "CUP_U_O_RUS_Soldier_VKPO_MSV_BeigeDigital_gloves_pads", "", 500, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "CUP_U_O_RUS_Soldier_VKPO_MSV_BeigeDigital_rolled_up_gloves_pads", "", 500, "call life_opfdept in ['AFRF','FIS','Command']" },
			// FIS
			{ "CUP_U_O_RUS_Ratnik_BeigeDigital", "", 500, "call life_opfdept in ['FIS','Command']" },
			// Command
			{ "CUP_U_O_SLA_Officer_Suit", "", 500, "call life_opfdept in ['Command']" }
		};

		headgear[] = {
			{"NONE", $STR_C_Remove_headgear, 0, "" },
			// TLA
			{ "CUP_H_TK_Helmet", "", 1000, "true" },
			{ "CUP_H_RUS_SSH68_olive", "", 125, "true" },
			{ "CUP_H_SLA_Helmet_DES", "", 125, "true" },
			{ "CUP_H_RUS_TSH_4_Brown", "", 125, "true" },
			{ "CUP_H_TK_TankerHelmet", "", 125, "true" },
			{ "CUP_H_RUS_ZSH_Shield_Down", "", 125, "true" },
			// AFRF
			{ "CUP_H_RUS_6B47_v2_GogglesUp_BeigeDigital", "", 1000, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "CUP_H_RUS_6B47_v2_GogglesClosed_BeigeDigital", "", 1000, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "CUP_H_RUS_6B47_v2_BeigeDigital", "", 1000, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "CUP_H_RUS_6B47_v2_GogglesDown_BeigeDigital", "", 1000, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "CUP_H_RUS_6B47_SF_headset_goggles_desert", "", 1000, "call life_opfdept in ['AFRF','FIS','Command']" },
			// FIS
			{ "CUP_H_RUS_Altyn_Shield_Down_khaki", "", 1500, "call life_opfdept in ['FIS','Command']" },
			{ "CUP_H_RUS_Altyn_Goggles_khaki", "", 1500, "call life_opfdept in ['FIS','Command']" },
			{ "CUP_H_RUS_Altyn_Shield_Up_khaki", "", 1500, "call life_opfdept in ['FIS','Command']" },
			{ "CUP_H_RUS_Beret_Spetsnaz", "", 250, "call life_opfdept in ['FIS','Command']" },
			// Command
			{ "CUP_H_SLA_OfficerCap", "", 250, "call life_opfdept in ['Command']" }
		};

		goggles[] = {
			{"NONE", $STR_C_Remove_goggles, 0, "" },
			{ "CUP_RUS_Balaclava_blk", "", 100, "true" },
			{ "CUP_RUS_Balaclava_grn", "", 100, "true" },
			{ "CUP_RUS_Balaclava_tan", "", 100, "true" },
			{ "G_Bandanna_khk", "", 100, "true" },
			{ "G_Bandanna_oli", "", 100, "true" },
			{ "G_Bandanna_tan", "", 100, "true" },
			{ "CUP_G_ESS_BLK_Scarf_Face_Grn", "", 100, "true" },
			{ "CUP_G_ESS_BLK_Scarf_Face_Red", "", 100, "true" },
			{ "CUP_G_ESS_BLK_Scarf_Face_Tan", "", 100, "true" },
			{ "CUP_FR_NeckScarf", "", 100, "true" },
			{ "CUP_FR_NeckScarf2", "", 100, "true" },
			{ "CUP_FR_NeckScarf5", "", 100, "true" },
			// Misc
			{ "G_AirPurifyingRespirator_01_F", "Gas Mask", 5000, "true" },
			{ "TAC_SF10", "Gas Mask", 5000, "true" }
		};

		vests[] = {
			{"NONE", $STR_C_Remove_vests, 0, "" },
			// TLA
			{ "CUP_V_O_SLA_6B3_1_WDL", "", 2000, "true" },
			{ "CUP_V_O_SLA_6B3_2_WDL", "", 2000, "true" },
			{ "CUP_V_O_SLA_6B3_3_WDL", "", 2000, "true" },
			{ "CUP_V_O_SLA_6B3_4_WDL", "", 2000, "true" },
			{ "CUP_V_O_SLA_6B3_5_WDL", "", 2000, "true" },
			{ "CUP_V_O_SLA_6B3_1_DES", "", 2000, "true" },
			{ "CUP_V_O_SLA_6B3_2_DES", "", 2000, "true" },
			{ "CUP_V_O_SLA_6B3_3_DES", "", 2000, "true" },
			{ "CUP_V_O_SLA_6B3_4_DES", "", 2000, "true" },
			{ "CUP_V_O_SLA_6B3_5_DES", "", 2000, "true" },
			// AFRF
			{ "CUP_Vest_RUS_6B45_Sh117_PKP_BeigeDigital", "", 2500, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "CUP_Vest_RUS_6B45_Sh117_BeigeDigital", "", 2500, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "CUP_Vest_RUS_6B45_Sh117_PKP_Nut_BeigeDigital", "", 2500, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "CUP_Vest_RUS_6B45_Sh117_PKP_Full_BeigeDigital", "", 2500, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "CUP_Vest_RUS_6B45_Sh117_VOG_Full_BeigeDigital", "", 2500, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "TAC_EI_RRV1_Coyote", "", 2500, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "TAC_EI_RRVCVHAK_Coyote2", "", 2500, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "TAC_EI_RRV24_Coyote", "", 2500, "call life_opfdept in ['AFRF','FIS','Command']" },
			{ "TAC_EI_RRV23_Coyote", "", 2500, "call life_opfdept in ['AFRF','FIS','Command']" },
		};

		backpacks[] = {
			{"NONE", $STR_C_Remove_backpacks, 0, "" },
			{ "CUP_O_RUS_Patrol_bag_BeigeDigital", "", 1500, "true" },
			{ "CUP_O_RUS_Patrol_bag_BeigeDigital_Shovel", "", 1500, "true" },
			{ "CUP_B_AlicePack_Bedroll", "", 2000, "true" },
			{ "CUP_B_AlicePack_OD", "", 2000, "true" },
			{ "B_Kitbag_rgr", "", 2000, "true" },
			{ "B_Kitbag_tan", "", 2000, "true" },
			{ "CUP_B_TK_Medic_Desert", "", 2000, "true" },
			{ "CUP_B_RPGPack_Khaki", "", 2000, "true" },
			{ "CUP_B_Kombat_Olive", "", 2000, "true" },

		};
	};

    class CIA {
		title = "STR_Shops_C_Police";
		conditions = "call life_copdept in ['CIA']";
		side = "cop";
		uniforms[] = {
			{ "NONE", $STR_C_Remove_uniforms, 0, "" },
            { "CUP_I_B_PMC_Unit_42", "", 20, "" },
            { "CUP_I_B_PMC_Unit_41", "", 20, "" },
            { "CUP_I_B_PMC_Unit_43", "", 20, "" },
            { "CUP_I_B_PMC_Unit_40", "", 20, "" },
            { "CUP_I_B_PMC_Unit_39", "", 20, "" },
            { "CUP_I_B_PMC_Unit_36", "", 20, "" },
            { "CUP_I_B_PMC_Unit_38", "", 20, "" },
            { "CUP_I_B_PMC_Unit_37", "", 20, "" },
            { "CUP_I_B_PMC_Unit_24", "", 20, "" },
            { "CUP_U_CRYE_G3C_BLK", "", 20, "" },
            { "CUP_U_CRYE_V3_Full", "", 20, "" },
            { "CUP_U_CRYE_V3_Roll", "", 20, "" }
		};
		headgear[] = {
			{ "NONE", $STR_C_Remove_headgear, 0, "" },
            { "CUP_H_OpsCore_Black", "", 25, "" },
            { "CUP_H_OpsCore_Tan", "", 25, "" },
            { "CUP_H_OpsCore_Grey", "", 25, "" },
            { "CUP_H_OpsCore_Covered_MCAM", "", 25, "" },
            { "TRYK_R_CAP_BLK", "", 25, "" },
            { "TRYK_r_cap_blk_Glasses", "", 25, "" },
            { "TRYK_H_woolhat", "", 25, "" },
            { "TRYK_H_headsetcap_blk_Glasses", "", 25, "" },
            { "TRYK_H_Bandana_H", "", 25, "" },
            { "CUP_H_PMC_Cap_PRR_Grey", "", 25, "" },
            { "CUP_H_PMC_Cap_Back_EP_Grey", "", 25, "" },
            { "CUP_H_PMC_Cap_Back_Grey", "", 25, "" },
            { "CUP_H_USA_Cap_NY_DEF", "", 25, "" },
            { "H_Cap_usblack", "", 25, "" },
            { "H_Booniehat_khk", "", 25, "" },
            { "CUP_H_PMC_Cap_Back_Tan", "", 25, "" },
            { "CUP_H_PMC_Cap_Back_EP_Tan", "", 25, "" },
            { "CUP_H_PMC_Cap_Back_PRR_Tan", "", 25, "" },
            { "CUP_H_PMC_Cap_PRR_Tan", "", 25, "" },
            { "H_CrewHelmetHeli_B", "", 25, "" }
		};
		goggles[] = {
			{ "NONE", $STR_C_Remove_goggles, 0, "" },
            { "G_Balaclava_blk", "", 15, "" },
            { "G_Balaclava_TI_blk_F", "", 15, "" },
            { "CUP_G_ESS_BLK_Scarf_Blk", "", 15, "" },
            { "CUP_G_ESS_BLK_Scarf_Red", "", 15, "" },
            { "CUP_G_ESS_BLK_Scarf_Face_Blk", "", 15, "" },
            { "CUP_G_ESS_BLK_Scarf_Face_Red", "", 15, "" },
            { "CUP_G_ESS_BLK_Scarf_Face_White", "", 15, "" },
            { "CUP_G_ESS_BLK_Scarf_Blk_Beard", "", 15, "" },
            { "CUP_G_ESS_BLK_Scarf_Blk_Beard_Blonde", "", 15, "" },
            { "CUP_G_ESS_BLK_Scarf_Red_Beard_Blonde", "", 15, "" },
            { "CUP_G_ESS_BLK_Scarf_Red_Beard", "", 15, "" },
            { "CUP_G_ESS_BLK_Scarf_White_Beard", "", 15, "" },
            { "CUP_G_ESS_BLK_Scarf_White_Beard_Blonde", "", 15, "" },
            { "CUP_G_Scarf_Face_Blk", "", 15, "" },
            { "CUP_G_Scarf_Face_Red", "", 15, "" },
            { "CUP_G_Scarf_Face_White", "", 15, "" },
            { "CUP_G_ESS_KHK_Scarf_Tan", "", 15, "" },
            { "G_Aviator", "", 15, "" },
            { "CUP_Beard_Black", "", 15, "" },
            { "CUP_Beard_Blonde", "", 15, "" },
            { "CUP_G_ESS_KHK_Dark", "", 15, "" },
            { "G_Spectacles_Tinted", "", 15, "" },
            { "CUP_G_ESS_KHK_Scarf_Tan", "", 15, "" },
            { "G_Bandanna_beast", "", 15, "" },
            { "G_Bandanna_tan", "", 15, "" },
            { "CUP_G_ESS_KHK_Scarf_Face_Tan", "", 15, "" },
            { "CUP_G_ESS_KHK_Scarf_Tan_Beard", "", 15, "" },
            { "CUP_G_ESS_KHK_Scarf_Tan_Beard_Blonde", "", 15, "" },
            { "CUP_G_Tan_Scarf_Shades_GPS_Beard_Blonde", "", 15, "" },
            { "CUP_G_Tan_Scarf_Shades_GPS_Beard", "", 15, "" },
            { "CUP_G_Scarf_Face_Tan", "", 15, "" }
		};
		vests[] = {
			{ "NONE", $STR_C_Remove_vests, 0, "" },
			{ "CUP_V_CPC_tlbelt_coy", "", 200, "" },
            { "CUP_V_CPC_medical_coy", "", 200, "" },
            { "CUP_V_CPC_tlbelt_mc", "", 200, "" },
            { "CUP_V_CPC_medical_mc", "", 200, "" },
            { "TRYK_V_ArmorVest_Delta2", "", 200, "" },
            { "TRYK_V_ArmorVest_Delta", "", 200, "" }
		};
		backpacks[] = {
			{ "NONE", $STR_C_Remove_backpacks, 0, "" },
			{ "SG_PoliceBelt", "", 70, "" },
            { "SG_Invis_Carryall", "", 70, "" },
            { "B_AssaultPack_mcamo", "", 70, "" },
            { "B_FieldPack_cbr", "", 70, "" },
            { "B_Kitbag_tan", "", 70, "" },
            { "TRYK_B_BAF_BAG_CYT", "", 70, "" },
            { "TRYK_B_Kitbag_blk", "", 700, "" },
            { "TRYK_B_Medbag_BK", "", 700, "" },
            { "CUP_B_AssaultPack_Black", "", 700, "" },
            { "CUP_B_USPack_Black", "", 700, "" },
            { "TRYK_B_BAF_BAG_BLK", "", 700, "" },
			{ "B_Parachute", "", 700, "" },
			{ "B_UAV_01_backpack_F", "", 2000, "call life_copdept in ['Command','CIA']" }
		};
	};

	class gun_clothing {
		title = "STR_Shops_C_Gun";
		conditions = "license_civ_gun";
		side = "civ";
		uniforms[] = {
			{ "NONE", $STR_C_Remove_uniforms, 0, "" }
		};

		headgear[] = {
			{ "NONE", $STR_C_Remove_headgear, 0, "" }
		};

		vests[] = {
			{ "NONE", $STR_C_Remove_vests, 0, "" },
		};

		backpacks[] = {
			{ "NONE", $STR_C_Remove_backpacks, 0, "" }
		};
	};

	class med_clothing {
		title = "STR_MAR_EMS_Clothing_Shop";
		conditions = "";
		side = "med";
		uniforms[] = {
			{ "NONE", $STR_C_Remove_uniforms, 0, "" },
			{ "EF_M_EMS_U", "", 500, "" },
			{ "EF_MKJKT_EMS", "", 500, "" },
			{ "EF_MKJKT_EMS2", "", 500, "" },
			{ "EF_FEM_4_5_EMS", "", 500, "" },
			{ "EF_FEM_3A_EMS", "", 500, "" },
            { "EF_FEM_3_9_GR", "", 500, "" },
			{ "EF_suit_7", "", 500, "" }

		};
		headgear[] = {
			{ "NONE", $STR_C_Remove_headgear, 0, "" },
			{ "EF_Mcap_EMSB", "", 100, "" },
			{ "EF_Fcap_EMSB", "", 100, "" },

		};
		goggles[] = {
			{ "NONE", $STR_C_Remove_goggles, 0, "" },
            { "G_Respirator_blue_F", "", 15, "" },
            { "G_Respirator_white_F", "", 15, "" },
            { "G_Respirator_yellow_F", "", 15, "" },
			{ "EF_SC_TTBR2_NV", "", 200, "" },
			{ "EF_SC_TTBRF3_NV", "", 200, "" },
			{ "EF_FSG_V", "", 200, "" },
			{ "EF_MSG_T", "", 200, "" },
			{ "CUP_NVG_HMNVS", "", 5000, "" }

		};
		vests[] = {
			{ "NONE", $STR_C_Remove_vests, 0, "" },
            { "g_rc_vest_bullet", "", 2500, "" },
            { "redCross_vest_light_red", "", 1000, "" },
            { "RedCross_Vest_MediumCommand", "", 1000, "" },
            { "redCross_vest_light_white", "", 1000, "" }

		};
		backpacks[] = {
			{ "NONE", $STR_C_Remove_backpacks, 0, "" },
			{ "TRYK_B_Medbag", "", 2000, "" },
			{ "TRYK_B_Medbag_OD", "", 2000, "" }
		};
	};
};