class CfgGather {
	class Resources {
		class apple {
			amount = 5;
			zones[] = { "apple_1", "apple_2", "apple_3", "apple_4" };
			item = "";
			zoneSize = 30;
		};

		class peach {
			amount = 5;
			zones[] = { "peaches_1", "peaches_2", "peaches_3", "peaches_4" };
			item = "";
			zoneSize = 30;
		};

		class MDMA {
			amount = 1;
			zones[] = { "MDMA_1" };
			item = "";
			zoneSize = 30;
		};

		class cotton {
			amount = 1;
			zones[] = { "cotton_1" };
			item = "";
			zoneSize = 30;
		};

		class wheat {
			amount = 1;
			zones[] = { "wheat_1" };
			item = "";
			zoneSize = 30;
		};

		class sunflower {
			amount = 1;
			zones[] = { "sunflower_1" };
			item = "";
			zoneSize = 30;
		};

		class rubberU {
			amount = 2;
			zones[] = { "rubber_1" };
			item = "";
			zoneSize = 30;
		};

		class goldcoin {
			amount = 1;
			zones[] = { "goldcoin_1" };
			item = "";
			zoneSize = 30;
		};

		class wool {
			amount = 3;
			zones[] = { "wool_1" };
			item = "";
			zoneSize = 30;
		};

		class toad {
			amount = 2;
			zones[] = { "lsd_1" };
			zoneSize = 50;
		};

		class sassafras {
			amount = 1;
			zones[] = { "sassafras_1" };
			zoneSize = 50;
		};

		class opium {
			amount = 2;
			zones[] = { "opium_1" };
			zoneSize = 50;
		};

		class hinduBud {
			amount = 2;
			zones[] = { "weed_1" };
			zoneSize = 50;
		};

		class cocoleaf {
			amount = 2;
			zones[] = { "cocaine_1" };
			zoneSize = 50;
		};

		class uraniumU {
			amount = 2;
			zones[] = { "uranium_1" };
			item = "pdrill";
			zoneSize = 50;
		};
	};

	class Minerals {
		class rich_oil_unprocessed {
			amount = 4;
			zones[] = { "oil_field_1" };
			item = "hardenedpickaxe";
			mined[] = { "oil_unprocessed" };
			zoneSize = 30;
		};

		class poor_oil_unprocessed {
			amount = 2;
			zones[] = { "oil_field_2" };
			item = "hardenedpickaxe";
			mined[] = { "oil_unprocessed" };
			zoneSize = 30;
		};

		class ironOre {
			amount = 3;
			zones[] = { "iron_mine" };
			item = "hardenedpickaxe";
			mined[] = { "ironOre" };
			zoneSize = 30;
		};

		class copperOre {
			amount = 2;
			zones[] = { "copper_mine" };
			item = "hardenedpickaxe";
			mined[] = { "copperOre" };
			zoneSize = 30;
		};

		class diamondOre {
			amount = 2;
			zones[] = { "diamond_mine" };
			item = "hardenedpickaxe";
			mined[] = { "diamondOre" };
			zoneSize = 30;
		};

		class sapphireOre {
			amount = 2;
			zones[] = { "sapphire_mine" };
			item = "hardenedpickaxe";
			mined[] = { "sapphireOre" };
			zoneSize = 30;
		};

		class coalOre {
			amount = 2;
			zones[] = { "coal_mine" };
			item = "hardenedpickaxe";
			mined[] = { "coalOre" };
			zoneSize = 30;
		};

		class silverOre {
			amount = 2;
			zones[] = { "silver_mine" };
			item = "hardenedpickaxe";
			mined[] = { "silverOre" };
			zoneSize = 30;
		};

		class goldOre {
			amount = 2;
			zones[] = { "gold_mine" };
			item = "hardenedpickaxe";
			mined[] = { "goldOre" };
			zoneSize = 30;
		};
	};
};
