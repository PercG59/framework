/*
*    ARRAY FORMAT:
*        0: STRING (Classname): Item Classname
*        1: STRING (Description): Description of item
*        2: SCALAR (Buy price): Cost of item
*        3: STRING (Conditions): Same as above conditions string
*        4: STRING (Nickname): Nickname that will appear purely in the shop dialog

POLICE SHOP RANKS/DEPARTMENTS

Ranks:
1- open for any Ranks
2- NCOs
3- Specialized units
4 - Commands

DEPARTMENTS:
NATO
Air
CIA
Command
*/

class WeaponShops {
	class cop {
		name = "Cop Weapon Shop";
		conditions = "";
		side = "cop";
		weapons[] = {
			// Level 0
			{ "taser", "", 100, "true", "" },
			{ "CUP_hgun_Glock17_tan", "", 4000, "true", "" },
			{ "hlc_pistol_P226R_Combat", "", 4000, "true", "" },
			{ "hlc_pistol_P226R_40Elite", "", 4000, "true", "" },
			{ "CUP_hgun_Duty", "", 4000, "true", "" }, // CZ75 DUTY
			{ "CUP_hgun_M9A1", "", 4000, "true", "" },

			// Level 1
			{ "CUP_hgun_Mk23", "", 4000, "true", "" },
			{ "CUP_hgun_M17_Black", "", 4000, "true", "" },
			{ "hlc_wp_m16a2", "", 17500, "true", "" },
			{ "hlc_smg_mp5a2", "", 16500, "true", "" },
			{ "hlc_smg_mp5k_PDW", "", 15000, "true", "" },
			{ "hlc_rifle_auga2lsw_b", "", 22000, "true", "" },
			{ "CUP_arifle_L85A2_G", "", 23000, "true", "" },
			{ "CUP_Famas_F1_Rail", "", 20000, "true", "" },

			// Level 2
			{ "CUP_arifle_G36A_RIS", "", 18000, "true", "" },
			{ "hlc_wp_xm4", "", 13000, "true", "" },
			{ "CUP_smg_MP7", "", 13000, "true", "" },

			// Level 3
			{ "hlc_rifle_G36C", "", 21500, "call life_coplevel >= 2", "" },
			{ "hlc_rifle_416D10", "", 25000, "call life_coplevel >= 2", "" },
			{ "CUP_arifle_XM8_Railed", "", 25000, "call life_coplevel >= 2", "" },
			{ "CUP_arifle_X95", "", 27500, "call life_coplevel >= 2", "" },
			{ "CUP_srifle_L129A1_HG_d", "", 27500, "call life_coplevel >= 2", "" },
			{ "CUP_arifle_M4A3_black", "", 27500, "call life_coplevel >= 2", "" },

			// Level 4
			{ "hlc_rifle_ACR_Carb_black", "", 32750, "call life_coplevel >= 2", "" },
			{ "CUP_smg_p90_black", "", 22500, "call life_coplevel >= 2", "" },

			// Level 5
			{ "hlc_smg_mp5sd5", "", 29500, "call life_coplevel >= 2", "" },
			{ "hlc_rifle_g3sg1ris", "", 37500, "call life_coplevel >= 2", "" },
			{ "hlc_rifle_416C", "", 35000, "call life_coplevel >= 2", "" },

			// Level 6
			{ "hlc_rifle_mk18mod0", "", 45000, "call life_coplevel >= 3", "" },
			{ "hlc_m249_pip1", "", 62500, "call life_coplevel >= 3", "" },
			{ "CUP_srifle_M24_blk", "", 70000, "call life_coplevel >= 3", "" },
			{ "CUP_arifle_HK417_12", "", 50000, "call life_coplevel >= 3", "" },

			//Command
			{ "hlc_lmg_mk48mod1", "", 75000, "call life_coplevel >= 4", "" },
			{ "hlc_rifle_honeybadger", "", 37500, "call life_coplevel >= 4", "" },
			{ "CUP_glaunch_Mk13", "", 20000, "call life_coplevel >= 4", "" },

			// Launchers
			{ "CUP_launch_M72A6_Loaded", "", 32000, "call life_coplevel >= 2", "" },
			{ "CUP_launch_M136_Loaded", "", 40000, "call life_coplevel >= 2", "" },
			
			// Marksman Specialist
			{ "CUP_srifle_RSASS_Black", "", 55000, "license_cop_marksman", "" },
			{ "hlc_rifle_PSG1A1_RIS", "", 60000, "license_cop_marksman", "" },
			{ "hlc_rifle_M21_Rail", "", 62500, "license_cop_marksman", "" },
			{ "hlc_rifle_awmagnum_BL", "", 82500, "license_cop_marksman", "" },
			{ "hlc_rifle_FN3011Tactical_grey", "", 70000, "license_cop_marksman", "" },
			{ "CUP_srifle_M24_blk", "", 78500, "license_cop_marksman", "" },

			// Demolition Specialist
			{ "CUP_launch_Mk153Mod0", "", 52500, "license_cop_demo", "" },
			{ "CUP_launch_FIM92Stinger_Loaded", "", 85000, "license_cop_demo", "" },
			
		};

		magazines[] = {
			{ "vvv_np_magazine_taser", "", 20, "", "" },
			{ "hlc_12Rnd_40SW_B_P226", "", 75, "", "" },
			{ "16Rnd_9x21_Mag", "", 75, "", "" },
			{ "16Rnd_9x21_green_Mag", "", 75, "", "" },
			{ "16Rnd_9x21_red_Mag", "", 75, "", "" },
			{ "16Rnd_9x21_yellow_Mag", "", 150, "", "" },
			{ "CUP_17Rnd_9x19_glock17", "", 150, "", "" },
			{ "hlc_15Rnd_9x19_B_P226", "", 75, "", "" },
			{ "hlc_15Rnd_9x19_JHP_P226", "", 75, "", "" },
			{ "CUP_21Rnd_9x19_M17_Black", "", 75, "", "" },
			{ "CUP_12Rnd_45ACP_mk23", "", 75, "", "" },
			{ "CUP_30Rnd_556x45_X95", "", 75, "", "" },
			{ "hlc_30Rnd_9x19_B_MP5", "", 75, "", "" },
			{ "CUP_40Rnd_46x30_MP7", "", 150, "", "" },
			{ "CUP_40Rnd_46x30_MP7_Red_Tracer", "", 150, "", "" },
			{ "50Rnd_570x28_SMG_03", "", 150, "", "" },
			{ "29rnd_300BLK_STANAG", "", 150, "", "" },
			{ "hlc_30rnd_556x45_EPR", "", 150, "", "" },
			{ "hlc_30rnd_556x45_SOST", "", 150, "", "" },
			{ "hlc_30rnd_556x45_SPR", "", 150, "", "" },
			{ "hlc_30rnd_556x45_S", "", 150, "", "" },
			{ "hlc_30rnd_556x45_t", "", 150, "", "" },
			{ "CUP_30Rnd_556x45_G36", "", 150, "", "" },
			{ "hlc_30rnd_556x45_EPR_G36", "", 150, "", "" },
			{ "hlc_30rnd_556x45_SPR_G36", "", 150, "", "" },
			{ "CUP_30Rnd_556x45_XM8", "", 150, "", "" },
			{ "CUP_20Rnd_762x51_B_M110", "", 150, "", "" },
			{ "CUP_20Rnd_TE1_Green_Tracer_762x51_M110", "", 150, "", "" },
			{ "hlc_20rnd_762x51_b_G3", "", 150, "", "" },
			{ "hlc_20rnd_762x51_T_G3", "", 150, "", "" },
			{ "hlc_20Rnd_762x51_B_M14", "", 150, "", "" },
			{ "hlc_20Rnd_762x51_T_M14", "", 150, "", "" },
			{ "hlc_200rnd_556x45_M_SAW", "", 150, "", "" },
			{ "hlc_200rnd_556x45_B_SAW", "", 150, "", "" },
			{ "hlc_200rnd_556x45_T_SAW", "", 30, "", "" },
			{ "hlc_100Rnd_762x51_M_M60E4", "", 150, "", "" },
			{ "hlc_100Rnd_762x51_B_M60E4", "", 150, "", "" },
			{ "hlc_100Rnd_762x51_T_M60E4", "", 150, "", "" },
			{ "1Rnd_SmokeYellow_Grenade_shell", "Recommended to be used with a gas mask.", 7500, "", "Teargas Shell" },
			{ "hlc_100Rnd_762x51_Barrier_M60E4", "", 2000, "", "" },
			{ "hlc_5rnd_300WM_FMJ_AWM", "", 1000, "", "" },
			{ "hlc_5rnd_300WM_mk248_AWM", "", 1000, "", "" },
			{ "hlc_10Rnd_762x51_B_fal", "", 150, "", "" },
			{ "CUP_20Rnd_762x51_HK417", "", 150, "", "" },
			{ "CUP_20Rnd_TE1_Green_Tracer_762x51_HK417", "", 150, "", "" },
			{ "CUP_20Rnd_TE1_Yellow_Tracer_762x51_HK417", "", 150, "", "" },
			{ "hlc_30Rnd_556x45_B_AUG", "", 150, "", "" },
			{ "hlc_30Rnd_556x45_SOST_AUG", "", 150, "", "" },
			{ "CUP_25Rnd_556x45_Famas_Tracer_Red", "", 150, "", "" },
			{ "CUP_25Rnd_556x45_Famas", "", 150, "", "" },
			{ "CUP_20Rnd_762x51_L129_M", "", 150, "", "" },
			{ "CUP_5Rnd_762x51_M24", "", 150, "", "" },
			{ "CUP_M72A6_M", "", 150, "", "" },
			{ "CUP_M136_M", "", 150, "", "" },
			{ "CUP_Stinger_M", "", 150, "", "" },
			{ "CUP_SMAW_HEAA_M", "Anti-Armour Round", 17500, "", "" },
			{ "CUP_SMAW_HEDP_M", "Dual-Purpose Round", 20000, "", "" },
			{ "CUP_SMAW_NE_M", "Bunker Buster Round", 25000, "", "" },
			{ "CUP_SMAW_Spotting", "9x51mm Spotting Rounds", 250, "", "" }
		};

		items[] = {
			{ "CUP_NVG_PVS14", "AN/PVS-14", 150, "true", "" },
			{ "CUP_NVG_GPNVG_black", "GPNVG-18", 150, "", "" },
			{ "TFAR_anprc152", "Use this to communicate from distance", 150, "true", "" },
			{ "Binocular", "", 250, "true", "" },
			{ "Rangefinder", "", 15, "true", "" },
			{ "ItemGPS", "", 500, "true", "" },
			{ "ItemMap", "", 10, "true", "" },
			{ "ItemCompass", "", 10, "true", "" },
			{ "SmokeShell", "", 250, "", "" },
			{ "CUP_HandGrenade_M67", "", 5000, "call life_coplevel >= 2", "" },
			{ "SmokeShellYellow", "Recommended to be used with a gas mask.", 7500, "call life_coplevel >= 2", "Teargas Grenade" }
		};

		attachments[] = {
			// Weapon Specific Optics
			{ "CUP_optic_SMAW_Scope", "", 2000, "", "" },
			// Red Dots
			{ "CUP_optic_MicroT1", "", 200, "true", "" },
			{ "CUP_optic_AIMM_MICROT1_BLK", "", 100, "true", "" },
			{ "CUP_optic_AC11704_Black", "", 100, "true", "" },
			{ "CUP_optic_Eotech553_Black", "", 100, "true", "" },
			{ "HLC_Optic_Romeo1_RX", "", 100, "true", "" },
			{ "hlc_acc_TLR1", "", 100, "true", "" },
			{ "HLC_Optic228_Docter_CADEX", "", 100, "true", "" },
			{ "CUP_optic_VortexRazor_UH1_Black", "", 200, "true", "" },
			{ "optic_Holosight_blk_F", "", 200, "true", "" },
			// Medium Range
			{ "CUP_optic_AIMM_COMPM4_BLK", "", 500, "", "" },
			{ "CUP_optic_ACOG_TA01NSN_RMR_Black", "", 500, "", "" },
			{ "CUP_optic_Elcan_SpecterDR_KF_RMR_black", "", 500, "", "" },
			{ "CUP_optic_ACOG", "", 500, "", "" },
			{ "CUP_optic_Elcan_SpecterDR_RMR_black", "", 500, "", "" },
			{ "optic_ERCO_blk_F", "", 500, "", "" },
			{ "optic_MRCO", "", 500, "", "" },
			{ "optic_Arco_blk_F", "", 500, "", "" },
			{ "optic_Hamr", "", 500, "", "" },
			{ "hlc_optic_ATACR_Offset", "", 500, "call life_coplevel >= 5", "" },
			// Long Range
			{ "optic_KHS_blk", "", 5000, "call life_coplevel >= 2", "" },
			{ "optic_DMS", "", 5000, "call life_coplevel >= 2", "" },
			{ "CUP_optic_SB_11_4x20_PM", "", 5000, "call life_coplevel >= 2", "" },
			{ "CUP_optic_LeupoldMk4", "", 5000, "call life_coplevel >= 2", "" },
			{ "CUP_optic_LeupoldMk4_20x40_LRT", "", 5000, "call life_coplevel >= 2", "" },
			{ "optic_LRPS", "", 5000, "call life_coplevel >= 3", "" },
			// Lasers & Other
			{ "muzzle_snds_L", "", 200, "", "" },
			{ "CUP_muzzle_snds_mk23", "", 1000, "", "" },
			{ "CUP_acc_ANPEQ_15_Flashlight_Black_L", "", 200, "", "" },
			{ "CUP_acc_ANPEQ_15_Top_Flashlight_Black_L", "", 200, "", "" },
			{ "CUP_acc_ANPEQ_15_Flashlight_Tan_L", "", 200, "", "" },
			{ "CUP_acc_ANPEQ_15_Top_Flashlight_Tan_L", "", 200, "", "" },
			{ "CUP_acc_CZ_M3X", "", 200, "", "" },
			{ "CUP_acc_mk23_lam_f", "", 200, "", "" },
			{ "CUP_muzzle_snds_mk23", "", 200, "", "" },
			{ "CUP_acc_CZ_M3X", "", 200, "", "" },
			{ "hlc_muzzle_556NATO_M42000", "", 1000, "", "" },
			{ "hlc_muzzle_556NATO_rotexiiic_tan", "", 1000, "", "" }
		};
	};

	class opf {
		name = "OPFOR Weapon Shop";
		conditions = "call life_opflevel >= 1";
		side = "opf";
		weapons[] = {
			//Private
			{ "taser", "", 100, "call life_opflevel >= 1", "" },
			{ "hlc_pistol_P226WestGerman", "", 400, "call life_opflevel >= 1", "" },
			{ "CUP_hgun_Makarov", "", 400, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_AS_VAL", "", 20000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_AS_VAL_flash_top", "", 20000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_SR3M_Vikhr_VFG", "", 12000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_SR3M_Vikhr_VFG_top_rail", "", 12000, "call life_opflevel >= 1", "" },
			{ "CUP_smg_vityaz_vfg", "", 12000, "call life_opflevel >= 1", "" },
			{ "CUP_smg_bizon", "", 12000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_OTS14_GROZA", "", 15000, "call life_opflevel >= 1", "" },
			{ "CUP_smg_SA61", "", 8000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_ak12", "", 25000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_aku12", "", 25000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_ak74", "", 20000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_ak74_MTK", "", 21000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_ak74m", "", 20000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_ak74m_MTK", "", 21000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_aks74u", "", 18000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_aks74u_MTK", "", 18500, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_aek971", "", 25000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_aek971_mtk", "", 26000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_AK107", "", 32000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_AK107_railed", "", 35000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_AK104", "", 32000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_AK104_railed", "", 35000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_AK109", "", 40000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_AK109_railed", "", 45000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_AK15_black", "", 40000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_AK15_VG_black", "", 42000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_AKMN_railed", "", 22000, "call life_opflevel >= 1", "" },
			{ "CUP_arifle_Sa58RIS2", "", 30000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_FAL5061Rail", "", 39000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_g3sg1ris", "", 45000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_RPK12", "", 55000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_rpk74n", "", 45000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_rpk", "", 43000, "call life_opflevel >= 1", "" },
			{ "CUP_lmg_PKM_B50_vfg", "", 70000, "call life_opflevel >= 1", "" },
			{ "CUP_lmg_PKM_top_rail_B50_vfg", "", 70000, "call life_opflevel >= 1", "" },
			{ "CUP_lmg_Pecheneg_B50_vfg", "", 70000, "call life_opflevel >= 1", "" },
			{ "CUP_lmg_Pecheneg_top_rail_B50_vfg", "", 70000, "call life_opflevel >= 1", "" },
			{ "hlc_rifle_saiga12k", "", 12000, "call life_opflevel >= 1", "" },
			{ "CUP_srifle_Mosin_Nagant", "", 10000, "call life_opflevel >= 1", "" },
			{ "CUP_srifle_SVD", "", 71250, "call life_opflevel >= 1", "" },
			{ "CUP_srifle_SVD_top_rail", "", 75000, "call life_opflevel >= 1", "" },
			{ "CUP_srifle_VSSVintorez", "", 68500, "call life_opflevel >= 1", "" },
			{ "CUP_launch_9K32Strela_Loaded", "", 95000, "call life_opflevel >= 3", "" },
			{ "CUP_launch_Igla_Loaded", "", 95000, "call life_opflevel >= 3", "" },
			{ "CUP_launch_RPG7V", "", 70000, "call life_opflevel >= 2", "" },
			{ "CUP_launch_RPG18_Loaded", "", 50000, "call life_opflevel >= 2", "" }
		};
		magazines[] = {
			{ "vvv_np_magazine_taser", "", 20, "", "" },
			{ "hlc_15Rnd_9x19_B_P226", "", 75, "", "" },
			{ "CUP_8Rnd_9x18_Makarov_M", "", 75, "", "" },
			{ "hlc_15Rnd_9x19_JHP_P226", "", 75, "", "" },
			{ "hlc_15Rnd_9x19_SD_P226", "", 75, "", "" },
			{ "CUP_20Rnd_9x39_SP5_VSS_M", "", 75, "", "" },
			{ "CUP_30Rnd_9x39_SP5_VIKHR_M", "", 75, "", "" },
			{ "CUP_30Rnd_9x19AP_Vityaz", "", 75, "", "" },
			{ "CUP_64Rnd_9x19_Bizon_M", "", 75, "", "" },
			{ "CUP_64Rnd_Green_Tracer_9x19_Bizon_M", "", 75, "", "" },
			{ "CUP_20Rnd_9x39_SP5_GROZA_M", "", 75, "", "" },
			{ "CUP_20Rnd_B_765x17_Ball_M", "", 75, "", "" },
			{ "hlc_30Rnd_545x39_B_AK", "", 75, "", "" },
			{ "hlc_30Rnd_545x39_t_ak", "", 75, "", "" },
			{ "hlc_30Rnd_545x39_EP_ak", "", 75, "", "" },
			{ "hlc_30Rnd_545x39_S_AK", "", 75, "", "" },
			{ "hlc_30Rnd_762x39_b_ak", "", 75, "", "" },
			{ "hlc_30Rnd_762x39_t_ak", "", 75, "", "" },
			{ "hlc_30rnd_762x39_s_ak", "", 75, "", "" },
			{ "hlc_30Rnd_762x39_AP_ak", "", 75, "", "" },
			{ "CUP_30Rnd_Sa58_M", "", 75, "", "" },
			{ "CUP_30Rnd_Sa58_M_TracerG", "", 75, "", "" },
			{ "hlc_60Rnd_545x39_b_rpk", "", 75, "", "" },
			{ "hlc_60Rnd_545x39_t_rpk", "", 75, "", "" },
			{ "hlc_60Rnd_545x39_EP_rpk", "", 75, "", "" },
			{ "CUP_100Rnd_TE4_LRT4_762x54_PK_Tracer_Green_M", "", 75, "", "" },
			{ "hlc_10rnd_12g_buck_S12", "", 75, "", "" },
			{ "hlc_10rnd_12g_slug_S12", "", 75, "", "" },
			{ "CUP_5Rnd_762x54_Mosin_M", "", 75, "", "" },
			{ "CUP_10Rnd_762x54_SVD_M", "", 75, "", "" },
			{ "CUP_10Rnd_762x54_SVD_M", "", 75, "", "" },
			{ "hlc_10Rnd_762x51_B_fal", "", 75, "", "" },
			{ "hlc_10Rnd_762x51_mk316_fal", "", 75, "", "" },
			{ "hlc_10Rnd_762x51_barrier_fal", "", 75, "", "" },
			{ "hlc_10Rnd_762x51_T_fal", "", 75, "", "" },
			{ "hlc_20Rnd_762x51_B_fal", "", 75, "", "" },
			{ "hlc_20Rnd_762x51_barrier_fal", "", 75, "", "" },
			{ "hlc_20rnd_762x51_b_G3", "", 75, "", "" },
			{ "hlc_20rnd_762x51_barrier_G3", "", 75, "", "" },
			{ "hlc_20rnd_762x51_T_G3", "", 75, "", "" },
			{ "CUP_10Rnd_9x39_SP5_VSS_M", "", 75, "", "" },
			{ "CUP_20Rnd_9x39_SP5_VSS_M", "", 75, "", "" },
			{ "CUP_Strela_2_M", "", 20000, "", "" },
			{ "CUP_Igla_M", "", 20000, "", "" },
			{ "CUP_PG7V_M", "", 20000, "", "" },
			{ "CUP_OG7_M", "", 20000, "", "" },
			{ "CUP_PG7VL_M", "", 20000, "", "" },
			{ "CUP_PG7VR_M", "", 20000, "", "" },
			{ "CUP_RPG18_M", "", 20000, "", "" }
		};
		Items[] = {
			{ "CUP_NVG_PVS14", "AN/PVS-14", 150, "true", "" },
			{ "TFAR_anprc152", "Use this to communicate from distance", 150, "true", "" },
			{ "Binocular", "", 250, "call life_opflevel >= 1", "" },
			{ "Rangefinder", "", 15, "call life_opflevel >= 1", "" },
			{ "ItemGPS", "", 500, "call life_opflevel >= 1", "" },
			{ "ItemMap", "", 10, "call life_opflevel >= 1", "" },
			{ "ItemCompass", "", 10, "call life_opflevel >= 1", "" },
			{ "SmokeShell", "", 250, "", "" },
			{ "CUP_HandGrenade_RGD5", "", 5000, "call life_opflevel >= 2", "" },
			{ "SmokeShellYellow", "Recommended to be used with a gas mask.", 7500, "call life_opflevel >= 2", "Teargas Grenade" }
		};
		attachments[] = {
			{ "CUP_optic_1p63", "", 200, "true", "" },
			{ "CUP_optic_ekp_8_02", "", 200, "true", "" },
			{ "hlc_optic_kobra", "", 200, "true", "" },
			{ "CUP_optic_Kobra", "", 200, "true", "" },
			{ "HLC_Optic_1p29", "", 200, "true", "" },
			{ "HLC_Optic_PSO1", "", 200, "true", "" },
			{ "CUP_optic_OKP_7", "", 200, "true", "" },
			{ "CUP_optic_PechenegScope", "", 200, "true", "" },
			{ "CUP_optic_PSO_1_1", "", 200, "true", "" },
			{ "CUP_optic_PSO_1", "", 200, "true", "" },
			{ "CUP_optic_PSO_3", "", 200, "true", "" },
			{ "CUP_optic_1P87_RIS", "", 200, "true", "" },
			{ "CUP_optic_1P87_1P90_BLK", "", 200, "true", "" },
			{ "CUP_optic_CompM2_low", "", 200, "true", "" },
			{ "CUP_optic_AIMM_COMPM2_BLK", "", 200, "true", "" },
			{ "CUP_optic_OKP_7_rail", "", 200, "true", "" },
			{ "CUP_optic_ACOG_TA01B_RMR_Black", "", 200, "true", "" },
			{ "CUP_optic_LeupoldMk4", "", 200, "true", "" },
			{ "CUP_optic_LeupoldM3LR", "", 200, "true", "" },
			{ "CUP_optic_LeupoldMk4_20x40_LRT", "", 200, "true", "" },
			{ "CUP_optic_PEM", "", 200, "true", "" },
			{ "CUP_optic_PSO_3,HLC_Optic_1p29", "", 200, "true", "" },
			{ "CUP_optic_PGO7V3", "", 200, "true", "" },
			{ "CUP_muzzle_snds_socom762rc", "", 2000, "true", "" },
			{ "CUP_muzzle_snds_KZRZP_AK762", "", 2000, "true", "" },
			{ "CUP_muzzle_snds_KZRZP_AK545", "", 2000, "true", "" }
		};
	};

	class gangWeapons {
		name = "Gang Weapons";
		conditions = "";
		side = "civ";
		weapons[] = {
			{ "CUP_hgun_UZI", "", 20000, "", "" },
			{ "hlc_smg_mp5k", "", 32000, "", "" },
			{ "CUP_hgun_Mac10", "", 30000, "", "" },
			{ "CUP_hgun_SA61", "", 25000, "", "" },
			{ "CUP_hgun_TEC9_FA", "", 26000, "", "" },
			{ "CUP_hgun_Deagle", "", 40000, "", "" },
			{ "hlc_rifle_ak74_dirty", "", 60000, "", "" },
			{ "CUP_smg_EVO", "", 38000, "", "" },
			{ "CUP_smg_M3A1_snd", "", 35000, "", "" },
			{ "CUP_arifle_TYPE_56_2_Early", "", 57000, "", "" },
			{ "CUP_smg_UZI", "", 26000, "", "" }
		};

		magazines[] = {

			{ "CUP_32Rnd_9x19_UZI_M", "", 500, "", "" },
			{ "hlc_30Rnd_9x19_B_MP5", "", 500, "", "" },
			{ "CUP_30Rnd_45ACP_MAC10_M", "", 600, "", "" },
			{ "CUP_20Rnd_B_765x17_Ball_M", "", 600, "", "" },
			{ "CUP_32Rnd_9x19_TEC9", "", 550, "", "" },
			{ "CUP_7Rnd_50AE_Deagle", "", 1000, "", "" },
			{ "hlc_30Rnd_762x39_b_ak", "", 1000, "", "" },
			{ "30Rnd_9x21_Mag_SMG_02", "", 650, "", "" },
			{ "CUP_30Rnd_45ACP_M3A1_M", "", 650, "", "" },
			{ "CUP_30Rnd_762x39_AK47_bakelite_M", "", 1100, "", "" },
			{ "CUP_32Rnd_9x19_UZI_M", "", 500, "", "" }
		};

		attachments[] = {};

		items[] = {
			{ "TFAR_anprc152", "Use this to communicate from distance", 150, "true", "" },
		};
	};

	class rebelNormal {
		name = "rebelNormal";
		conditions = "";
		side = "civ";
		armsDealer = 1;
		weapons[] = {
			{ "CUP_arifle_Sa58_Klec", "", 45000, "true", ""},
			{ "hlc_rifle_rpk", "", 60000, "true", "" },
			{ "CUP_arifle_AS_VAL", "", 60000, "true", "" },
			{ "CUP_smg_vityaz_vfg", "", 30000, "true", "" },
			{ "CUP_arifle_OTS14_GROZA", "", 34000, "true", "" },
			{ "CUP_smg_bizon", "", 35000, "true", "" },
			{ "CUP_arifle_AK107", "", 70000, "true", "" },
			{ "CUP_arifle_AK109", "", 75000, "true", "" },
			{ "CUP_lmg_PKM_B50_vfg", "", 90000, "true", "" },
			{ "CUP_srifle_SVD", "", 110000, "true", "" },
			{ "CUP_srifle_VSSVintorez", "", 85000, "true", "" },
			{ "hlc_rifle_ak74", "", 30000, "true", "" },
			{ "hlc_rifle_aks74u", "", 26000, "true", "" },
			{ "CUP_launch_RPG7V", "", 20000, "true", "" }
		};

		magazines[] = {
			{ "CUP_45Rnd_Sa58_M", "", 750, "true", "" },
			{ "hlc_40Rnd_762x39_b_rpk", "", 750, "true", "" },
			{ "hlc_45Rnd_762x39_m_rpk", "", 800, "true", "" },
			{ "hlc_45Rnd_762x39_t_rpk", "", 800, "true", "" },
			{ "CUP_20Rnd_9x39_SP5_VSS_M", "", 500, "true", "" },
			{ "CUP_30Rnd_9x19AP_Vityaz", "", 500, "true", "" },
			{ "CUP_20Rnd_9x39_SP5_GROZA_M", "", 500, "true", "" },
			{ "CUP_64Rnd_9x19_Bizon_M", "", 500, "true", "" },
			{ "CUP_64Rnd_Green_Tracer_9x19_Bizon_M", "", 500, "true", "" },
			{ "hlc_30Rnd_545x39_B_AK", "", 600, "true", "" },
			{ "hlc_30Rnd_545x39_t_ak", "", 600, "true", "" },
			{ "hlc_30Rnd_762x39_b_ak", "", 750, "true", "" },
			{ "hlc_30Rnd_762x39_t_ak", "", 750, "true", "" },
			{ "CUP_100Rnd_TE4_LRT4_762x54_PK_Tracer_Green_M", "", 5000, "true", "" },
			{ "CUP_10Rnd_762x54_SVD_M", "", 1200, "true", "" },
			{ "CUP_10Rnd_9x39_SP5_VSS_M", "", 500, "true", "" },
			{ "CUP_20Rnd_9x39_SP5_VSS_M", "", 500, "true", "" },
			{ "hlc_30Rnd_545x39_B_AK", "", 600, "true", "" },
			{ "hlc_30Rnd_545x39_t_ak", "", 600, "true", "" },
			{ "hlc_30Rnd_545x39_EP_ak", "", 600, "true", "" },
			{ "hlc_30Rnd_545x39_S_AK", "", 600, "true", "" },
			{ "CUP_PG7V_M", "", 40000, "true", "" }
		};

		attachments[] = {
			{ "CUP_optic_1P87_RIS", "", 100, "true", "" },
			{ "CUP_optic_1P87_1P90_BLK", "", 1000, "true", "" },
			{ "CUP_optic_CompM2_low", "", 1000, "true", "" },
			{ "CUP_optic_AIMM_COMPM2_BLK", "", 1000, "true", "" },
			{ "CUP_optic_OKP_7_rail", "", 1000, "true", "" },
			{ "CUP_optic_ACOG_TA01B_RMR_Black", "", 1000, "true", "" },
			{ "CUP_optic_LeupoldMk4", "", 5000, "", "" },
			{ "CUP_optic_LeupoldM3LR", "", 5000, "true", "" },
			{ "CUP_optic_LeupoldMk4_20x40_LRT", "", 5000, "true", "" },
			{ "CUP_muzzle_mfsup_Flashhider_762x39_Tan", "", 2500, "", "" },
			{ "CUP_acc_ANPEQ_15_Black", "", 2500, "", "" },
			{ "CUP_bipod_Harris_1A2_L_BLK", "", 3500, "", "" },
			{ "CUP_acc_ANPEQ_15_Black_Top", "", 3500, "", "" },
			{ "CUP_acc_ANPEQ_15_Flashlight_Black_L", "", 3500, "", "" }
		};

		items[] = {
			{ "CUP_NVG_1PN138", "Night Vision", 5000, "true", "" },
			{ "TFAR_anprc152", "Use this to communicate from distance", 150, "true", "" },
			{ "Binocular", "Use these to see stuff at furthur distances", 250, "true", "" },
			{ "ItemGPS", "Use this to not get lost", 500, "true", "" },
			{ "ItemMap", "Use this to find the local shops", 10, "true", "" },
			{ "ItemCompass", "Use this to find directions", 10, "true", "" },
			{ "CUP_HandGrenade_RGD5", "Pull pin and throw", 5000, "true", "" }
		};
	};

	class rebelAdvanced {
		name = "rebelAdvanced";
		conditions = "";
		side = "civ";
		armsDealer = 1;
		weapons[] = {
			{ "CUP_arifle_ACR_tan_556", "", 50000, "true", "" },
			{ "CUP_arifle_M4A3_camo", "", 45000, "true", "" },
			{ "CUP_arifle_HK_M27", "", 60000, "true", "" },
			{ "CUP_arifle_G3A3_ris_black", "", 65000, "true", "" },
			{ "CUP_arifle_CZ805_A2_blk", "", 45000, "true", "" },
			{ "hlc_rifle_g3sg1ris", "", 63000, "true", "" },
			{ "hlc_rifle_G36V", "", 55000, "true", "" },
			{ "hlc_rifle_SG551SB_RIS", "", 50000, "true", "" },
			{ "hlc_rifle_auga2carb_t", "", 60000, "true", "" },
			{ "CUP_arifle_FNFAL5060_desert", "", 70000, "true", "" },
			{ "CUP_srifle_M24_des", "", 90000, "true", "" },
			{ "CUP_srifle_M2010_dsrt", "", 100000, "true", "" },
			{ "hlc_rifle_FN3011Lynx", "", 75000, "true", "" },
			{ "CUP_launch_Igla_Loaded", "", 150000, "true", "" }
		};

		magazines[] = {
			{ "hlc_30rnd_556x45_EPR", "", 600, "true", "" },
			{ "hlc_30rnd_556x45_SOST", "", 600, "true", "" },
			{ "hlc_30rnd_556x45_SPR", "", 600, "true", "" },
			{ "CUP_20Rnd_762x51_G3", "", 1200, "true", "" },
			{ "CUP_30Rnd_556x45_CZ805", "", 600, "true", "" },
			{ "hlc_20rnd_762x51_b_G3", "", 1200, "true", "" },
			{ "hlc_20rnd_762x51_Mk316_G3", "", 1200, "true", "" },
			{ "hlc_20rnd_762x51_barrier_G3", "", 1200, "true", "" },
			{ "hlc_30Rnd_556x45_EPR_sg550", "", 600, "true", "" },
			{ "hlc_30Rnd_556x45_SOST_sg550", "", 600, "true", "" },
			{ "hlc_30Rnd_556x45_B_AUG", "", 600, "true", "" },
			{ "hlc_30Rnd_556x45_SOST_AUG", "", 600, "true", "" },
			{ "CUP_20Rnd_762x51_FNFAL_Desert_M", "", 1200, "true", "" },
			{ "CUP_20Rnd_TE1_Yellow_Tracer_762x51_FNFAL_Desert_M", "", 1200, "true", "" },
			{ "CUP_5Rnd_762x51_M24", "", 1200, "true", "" },
			{ "CUP_5Rnd_762x67_M2010_M", "", 1500, "true", "" },
			{ "hlc_10Rnd_762x51_B_fal", "", 1200, "true", "" },
			{ "hlc_10Rnd_762x51_mk316_fal", "", 1200, "true", "" },
			{ "hlc_10Rnd_762x51_barrier_fal", "", 1200, "true", "" },
			{ "CUP_Igla_M", "", 150, "true", "" },
			{ "CUP_OG7_M", "", 50000, "true", "" },
			{ "CUP_PG7VL_M", "", 70000, "true", "" }
		};

		attachments[] = {
			{ "CUP_optic_1P87_RIS_desert", "", 1000, "", "" },
			{ "CUP_optic_MicroT1_low_coyote", "", 1000, "", "" },
			{ "CUP_optic_AIMM_MICROT1_TAN", "", 1000, "", "" },
			{ "CUP_optic_AC11704_Coyote", "", 1000, "", "" },
			{ "CUP_optic_HoloDesert", "", 1000, "", "" },
			{ "CUP_optic_Eotech553_Coyote", "", 1000, "", "" },
			{ "CUP_optic_G33_HWS_COYOTE", "", 1000, "", "" },
			{ "CUP_optic_CompM2_low_coyote", "", 1000, "", "" },
			{ "CUP_optic_AIMM_M68_TAN", "", 1000, "", "" },
			{ "CUP_optic_OKP_7_d_rail", "", 1000, "", "" },
			{ "CUP_optic_Elcan_SpecterDR_coyote", "", 1000, "", "" },
			{ "CUP_optic_HensoldtZO_low_RDS_coyote", "", 1000, "", "" },
			{ "CUP_optic_ACOG_TA01B_Coyote", "", 1000, "", "" },
			{ "CUP_optic_SB_11_4x20_PM_tan", "", 1000, "", "" },
			{ "CUP_optic_LeupoldMk4_10x40_LRT_Desert", "", 1000, "", "" },
			{ "CUP_optic_LeupoldMk4_25x50_LRT_DESERT", "", 1000, "", "" },
			{ "hlc_muzzle_Gunfighter_comp", "", 1000, "", "" },
			{ "CUP_muzzle_mfsup_Flashhider_556x45_Tan", "", 1000, "", "" },
			{ "hlc_muzzle_snds_ROTEX3P", "", 1000, "", "" },
			{ "CUP_bipod_VLTOR_Modpod", "", 1000, "", "" },
			{ "CUP_acc_ANPEQ_15", "", 1000, "", "" },
			{ "CUP_acc_ANPEQ_15_Flashlight_Tan_L", "", 1000, "", "" },
			{ "CUP_acc_ANPEQ_15_Top_Flashlight_Tan_L", "", 1000, "", "" },
			{ "CUP_acc_Flashlight_desert", "", 1000, "", "" },
			{ "CUP_acc_LLM01_coyote_L", "", 1000, "", "" }
		};

		items[] = {
			{ "CUP_NVG_GPNVG_black", "Night Vision Goggles", 10000, "true", "" },
			{ "TFAR_anprc152", "Use this to communicate from distance", 150, "true", "" },
			{ "Rangefinder", "Use these to see stuff at furthur distances", 15, "", "" },
			{ "Binocular", "Use these to see stuff at furthur distances", 250, "true", "" },
			{ "ItemGPS", "Use this to not get lost", 500, "true", "" },
			{ "ItemMap", "Use this to find the local shops", 10, "true", "" },
			{ "ItemCompass", "Use this to find directions", 10, "true", "" },
			{ "CUP_IED_V3_M", "Use this to send your enemies to Allah", 95000, "true", "" },
			{ "CUP_IED_V1_M", "Use this to send your enemies to Allah", 95000, "true", "" },
			{ "CUP_IED_V2_M", "Use this to send your enemies to Allah", 150000, "true", "" },
			{ "CUP_IED_V4_M", "Use this to send your enemies to Allah", 150000, "true", "" },
		};
	};

	class warpoint {
		name = "warpoint";
		warpoints = 1;
		conditions = "";
		side = "civ";
		weapons[] = {
			{ "CUP_sgun_AA12", "", 10, "true", "" },
			{ "CUP_srifle_AS50", "", 30, "true", "" },
			{ "hlc_lmg_minimipara", "", 15, "true", "" },
			{ "hlc_rifle_BAB", "", 10, "true", "" },
			{ "CUP_srifle_ksvk", "", 25, "true", "" },
			{ "arifle_SDAR_F", "", 10, "true", "" },
			{ "CUP_arifle_AKS_Gold", "", 50, "true", "" },
			{ "CUP_arifle_M4_MOE_BW", "", 20, "true", "" },
			{ "hlc_lmg_m60", "", 18, "true", "" },
			{ "CUP_glaunch_M79", "", 30, "true", "" },
			{ "srifle_DMR_05_blk_F", "", 25, "true", "" },
			{ "CUP_launch_BF3_Loaded", "", 15, "true", "" }
		};

		magazines[] = {
			{ "CUP_20Rnd_B_AA12_Buck_00", "", 1000, "true", "" },
			{ "CUP_5Rnd_127x99_as50_M", "", 8000, "true", "" },
			{ "hlc_200rnd_556x45_M_SAW", "", 2000, "true", "" },
			{ "hlc_30rnd_556x45_EPR", "", 600, "true", "" },
			{ "CUP_5Rnd_127x108_KSVK_M", "", 4500, "true", "" },
			{ "hlc_30rnd_556x45_t", "", 650, "true", "" },
			{ "CUP_30Rnd_762x39_AK47_M", "", 750, "true", "" },
			{ "CUP_10Rnd_50BW_Mag_M4_M", "", 1500, "true", "" },
			{ "hlc_100Rnd_762x51_M_M60E4", "", 2000, "true", "" },
			{ "CUP_1Rnd_HE_M203", "", 5000, "true", "" },
			{ "10Rnd_93x64_DMR_05_Mag", "", 3500, "true", "" }
		};

		attachments[] = {};

		items[] = {
			{ "TFAR_anprc152", "Use this to communicate from distance", 150, "true", "" },
		};
	};

	class gun {
		name = "Firearms Store";
		conditions = "license_civ_gun";
		side = "civ";
		weapons[] = {
        	{ "CUP_hgun_FlareGun", "", 500, "", "" },
			{ "CUP_hgun_PMM", "", 5000, "", "" },
			{ "CUP_hgun_Glock17_tan", "", 5000, "", "" },
			{ "CUP_hgun_M9A1", "", 5000, "", "" },
			{ "CUP_hgun_Makarov", "", 5000, "", "" },
            { "CUP_hgun_Duty", "", 6000, "", "" }, // CZ75 DUTY
            { "CUP_hgun_Browning_HP", "", 5000, "", "" },
            { "CUP_hgun_TaurusTracker455", "Revolver", 8000, "", "" },
            { "hlc_pistol_C96_Wartime_Worn", "Mauser C96", 8000, "", "" },
            { "hlc_Pistol_M11", "", 5000, "", "" },
            { "CUP_hgun_Colt1911", "", 5000, "", "" },
			{ "CUP_hgun_TT", "", 6000, "", "" },
			{ "hgun_Pistol_heavy_02_F", "", 10000, "", "" }
		};

		magazines[] = {
            { "CUP_FlareWhite_265_M", "", 25, "", "" },
			{ "CUP_FlareRed_265_M", "", 25, "", "" },
			{ "CUP_FlareGreen_265_M", "", 25, "", "" },
			{ "CUP_FlareYellow_265_M", "", 25, "", "" },
			{ "CUP_IllumFlareWhite_265_M", "", 50, "", "" },
			{ "CUP_IllumFlareRed_265_M", "", 50, "", "" },
			{ "CUP_IllumFlareGreen_265_M", "", 50, "", "" },
			{ "CUP_IllumFlareYellow_265_M", "", 50, "", "" },
			{ "CUP_StarClusterWhite_265_M", "", 50, "", "" },
			{ "CUP_StarClusterRed_265_M", "", 50, "", "" },
			{ "CUP_StarClusterGreen_265_M", "", 50, "", "" },
            { "CUP_StarClusterYellow_265_M", "", 50, "", "" },
            { "CUP_12Rnd_9x18_PMM_M", "", 300, "", "" },
            { "CUP_17Rnd_9x19_glock17", "", 350, "", "" },
            { "CUP_15Rnd_9x19_M9 ", "", 350, "", "" },
            { "CUP_8Rnd_9x18_Makarov_M", "", 300, "", "" },
            { "16Rnd_9x21_Mag", "", 400, "", "" },
            { "CUP_13Rnd_9x19_Browning_HP", "", 300, "", "" },
            { "hlc_10Rnd_763x25_B_C96", "", 400, "", "" },
            { "hlc_13Rnd_9x19_B_P228 ", "", 350, "", "" },
			{ "hlc_13Rnd_9x19_JHP_P228", "", 350, "", "" },
			{ "9Rnd_45ACP_Mag", "", 500, "", "" },
			{ "CUP_8Rnd_762x25_TT", "", 400, "", "" },
			{ "CUP_6Rnd_45ACP_M", "", 500, "", "" },
			{ "6Rnd_45ACP_Cylinder", "", 800, "", "" }
		};

		attachments[] = {};

		items[] = {
			{ "TFAR_anprc152", "Use this to communicate from distance", 150, "true", "" },
			{ "Binocular", "Use these to see stuff at furthur distances", 250, "true", "" },
			{ "ItemGPS", "Use this to not get lost", 500, "true", "" },
			{ "ItemMap", "Use this to find the local shops", 10, "true", "" },
			{ "ItemCompass", "Use this to find directions", 10, "true", "" }
		};
	};

	class rifle {
		name = "Rifle Store";
		conditions = "license_civ_rifle";
		side = "civ";
		weapons[] = {
			{ "CUP_sgun_M1014_solidstock", "", 15000, "true", "" },
			{ "CUP_sgun_slamfire", "", 5000, "true", "" },
			{ "CUP_sgun_CZ584", "", 15000, "true", "" },
			{ "hlc_rifle_FN3011", "", 18000, "true", "" },
			{ "CUP_srifle_CZ550", "", 16000, "true", "" },
			{ "CUP_srifle_Mosin_Nagant", "", 11000, "true", "" },
			{ "CUP_srifle_LeeEnfield", "", 12000, "true", "" },
			{ "CUP_arifle_IMI_Romat", "", 35000, "true", "" },
			{ "CUP_SKS", "", 32000, "true", "" },
			{ "CUP_srifle_M21", "", 38000, "true", "" }
		};

		magazines[] = {
			{ "CUP_6Rnd_12Gauge_Pellets_No00_Buck", "", 500, "true", "" },
			{ "CUP_1Rnd_12Gauge_Slug", "", 200, "true", "" },
			{ "CUP_1Rnd_12Gauge_Pellets_No00_Buck", "", 200, "true", "" },
			{ "hlc_10Rnd_762x51_B_fal", "", 1200, "true", "" },
			{ "hlc_10Rnd_762x51_mk316_fal", "", 1200, "true", "" },
			{ "CUP_5x_22_LR_17_HMR_M", "", 350, "true", "" },
			{ "CUP_5Rnd_762x54_Mosin_M", "Mosin Nagant", 1200, "true", "" },
			{ "CUP_10x_303_M", "", 1200, "true", "" },
			{ "CUP_10Rnd_762x51_FNFAL_M", "", 1200, "true", "" },
			{ "CUP_10Rnd_762x39_SKS_M", "", 900, "true", "" },
			{ "10Rnd_Mk14_762x51_Mag", "", 1200, "true", "" },
			{ "CUP_10x_303_M", "", 1200, "true", "" }
		};

		attachments[] = {
			{ "hlc_optic_ANGSCHUTZ", "", 1500, "true", "" },
			{ "CUP_optic_no23mk2", "", 1500, "true", "" },
			{ "CUP_optic_PEM", "", 1500, "true", "" }
		};

		items[] = {
			{ "TFAR_anprc152", "Use this to communicate from distance", 150, "true", "" },
			{ "Binocular", "Use these to see stuff at furthur distances", 250, "true", "" },
			{ "ItemGPS", "Use this to not get lost", 500, "true", "" },
			{ "ItemMap", "Use this to find the local shops", 10, "true", "" },
			{ "ItemCompass", "Use this to find directions", 10, "true", "" }
		};
	};

	class WongsGuns {
		name = "Wong's Weapon Store";
		conditions = "";
		side = "civ";
		weapons[] = {};

		magazines[] = {};

		items[] = {};
	};

	class mafia {
		name = "Mafia Firearms";
		conditions = "";
		side = "civ";
		weapons[] = {};

		magazines[] = {};

		attachments[] = {};

		items[] = {
			{ "TFAR_anprc152", "Use this to communicate from distance", 150, "true", "" },
			{ "Binocular", "Use these to see stuff at furthur distances", 250, "true", "" },
			{ "ItemGPS", "Use this to not get lost", 500, "true", "" },
			{ "ItemMap", "Use this to find the local shops", 10, "true", "" },
			{ "ItemCompass", "Use this to find directions", 10, "true", "" }
		};
	};

	class jail {
		name = "Jail Firearms";
		conditions = "life_is_arrested";
		side = "civ";
		weapons[] = {};

		magazines[] = {};

		attachments[] = {};

		items[] = {
			{ "TFAR_anprc152", "Use this to communicate from distance", 150, "true", "" },
			{ "Binocular", "Use these to see cops at furthur distances", 250, "true", "" },
			{ "ItemGPS", "Let others find you if you are in a gang", 750, "true", "" },
			{ "ItemMap", "Use this to find your way out", 100, "true", "" }
		};
	};

	class genstore {
		name = "General Store";
		conditions = "";
		side = "civ";
		weapons[] = {};

		magazines[] = {};

		items[] = {
			{ "TFAR_anprc152", "Use this to communicate from distance", 150, "true", "" },
			{ "Binocular", "Use these to see stuff at furthur distances", 250, "true", "" },
			{ "ItemGPS", "Use this to not get lost", 500, "true", "" },
			{ "ItemMap", "Use this to find the local shops", 10, "true", "" },
			{ "ItemCompass", "Use this to find directions", 10, "true", "" }
		};
	};

	class jailworkshop {
		name = "Tyrone's Jail Workshop"; // lol
		conditions = "";
		side = "civ";
		weapons[] = {};

		magazines[] = {};

		items[] = {};
	};

	class f_station_store {
		name = "Gas Station";
		conditions = "";
		side = "civ";
		weapons[] = {};

		items[] = {
			{ "TFAR_anprc152", "Use this to communicate from distance", 150, "true", "" },
			{ "Binocular", "Use these to see stuff at furthur distances", 250, "true", "" },
			{ "ItemGPS", "Use this to not get lost", 500, "true", "" },
			{ "ItemMap", "Use this to find the local shops", 10, "true", "" },
			{ "ItemCompass", "Use this to find directions", 10, "true", "" }
		};

		magazines[] = {};
	};

	class med_basic {
		name = "Medic Shop";
		conditions = "";
		side = "med";
		weapons[] = {};

		items[] = {
			{ "TFAR_anprc152", "Use this to communicate from distance", 50, "true", "" },
			{ "Medikit", "Use this to heal to full health", 50, "true", "" },
			{ "FirstAidKit", "Use this to heal players", 50, "true", "" },
			{ "Binocular", "Use this to communicate from distance", 50, "true", "" },
			{ "ItemGPS", "Use this to not get lost", 50, "true", "" },
			{ "ItemMap", "Use this to find the local shops", 10, "true", "" },
			{ "ItemCompass", "Use this to find directions", 10, "true", "" }
		};

		magazines[] = {};
	};
};
