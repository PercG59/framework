class DynMarket {

	drugs[] = { "cocaine", "crack", "MDMA", "molly", "marijuana", "acid", "DMT","ogkush", "purplehaze", "hindukush", "sourdiesel", "bluedream", "pineappleexpress" };
	houseRobbery[] = { "rubyJewelery", "diamondJewelery", "sapphireJewelery", "amethystJewelery", "antiqueCoin", "boxers", "bra", "cards", "gnome", "iphonex", "noose", "painting", "panties", "remote", "samsungs9", "trash" };

	minerals[] = {"coal", "iron", "copper", "silver", "gold", "diamond", "ruby","emerald", "sapphire", "iron_final", "copper_final", "coal_final", "iron_final", "diamond_final", "ruby_final", "sapphire_final", "gold_final","emerald_final","silver_final" };
	farming[] = { "bean", "cotton", "sunflower", "pumpkin", "wheat", "corn" };
};