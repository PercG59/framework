class CfgFactions {
	class Civilian {
		displayName = "Civilians";
		side = 3;
		icon = "#(argb,8,8,3)color(1,1,1,1)";
		color[] = { 0.4, 0, 0.5, 1 };
	};
	class West {
		displayName = "NATO";
		side = 1;
		icon = "#(argb,8,8,3)color(1,1,1,1)";
		color[] = { 0, 0.3, 0.72, 1 };
	};
	class Independent {
		displayName = "UN";
		side = 2;
		icon = "#(argb,8,8,3)color(1,1,1,1)";
		color[] = { 0, 0.5, 0, 1 };
	};

	class East {
		displayName = "TLA";
		side = 0;
		icon = "#(argb,8,8,3)color(1,1,1,1)";
		color[] = { 0.5, 0, 0, 1 };
	};
};