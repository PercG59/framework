#define true 1
#define false 0
class CfgTitleCiv {
	class Newbie {
		title = "Newbie";
		desc = "Kill 10 people.";
		value = 10;
		valueType = "kills";
		perk = "";
	};
	class Thug {
		title = "Thug";
		desc = "Kill 25 people.";
		value = 25;
		valueType = "kills";
		perk = "";
	};
	class Capo {
		title = "Capo";
		desc = "Kill 50 people.";
		value = 50;
		valueType = "kills";
		perk = "";
	};
	class Psychopath {
		title = "Psychopath";
		desc = "Kill 75 people.";
		value = 75;
		valueType = "kills";
		perk = "";
	};
	class ColdBloodedKiller {
		title = "Cold Blooded Killer";
		desc = "Kill 100 people.";
		value = 100;
		valueType = "kills";
		perk = "2.5% discount at rebel gun store (rifles only) and rebel vehicle shop";
	};
	class Hitman {
		title = "Hitman";
		desc = "Kill 250 people.";
		value = 250;
		valueType = "kills";
		perk = "5% discount at rebel gun store (rifles only) and rebel vehicle shop";
	};
	class Homicidal {
		title = "Homicidal";
		desc = "Kill 500 people.";
		value = 500;
		valueType = "kills";
		perk = "5% discount at rebel gun store (rifles only) and rebel vehicle shop";
	};
	class Terminator {
		title = "Terminator";
		desc = "Kill 1,000 people.";
		value = 1000;
		valueType = "kills";
		perk = "5% discount at rebel gun store (rifles only) and rebel vehicle shop";
	};
	class John_Wick {
		title = "John Wick";
		desc = "Kill 1,500 people.";
		value = 1500;
		valueType = "kills";
		perk = "5% discount at rebel gun store (rifles only) and rebel vehicle shop";
	};
	class Thanos {
		title = "Thanos";
		desc = "Kill 2,500 people.";
		value = 2500;
		valueType = "kills";
		perk = "5% discount at rebel gun store (rifles only) and rebel vehicle shop";
	};
	class NewBlood {
		title = "New Blood";
		desc = "Kill 10 enemy gang members.";
		value = 10;
		valueType = "gangKills";
		perk = "";
	};
	class OG {
		title = "OG";
		desc = "Kill 25 enemy gang members.";
		value = 25;
		valueType = "gangKills";
		perk = "";
	};
	class Feared {
		title = "Feared";
		desc = "Kill 50 enemy gang members.";
		value = 50;
		valueType = "gangKills";
		perk = "";
	};
	class Genocidal {
		title = "Genocidal";
		desc = "Kill 75 enemy gang members.";
		value = 75;
		valueType = "gangKills";
		perk = "";
	};
	class WarChief {
		title = "War Chief";
		desc = "Kill 100 enemy gang members.";
		value = 100;
		valueType = "gangKills";
		perk = "2.5% discount at rebel gun store (rifles only) and rebel vehicle shop";
	};
	class WarMonger {
		title = "Warmonger";
		desc = "Kill 250 enemy gang members.";
		value = 250;
		valueType = "gangKills";
		perk = "5% discount at rebel gun store (rifles only) and rebel vehicle shop";
	};
	class Warlord {
		title = "Warlord";
		desc = "Kill 500 enemy gang members.";
		value = 500;
		valueType = "gangKills";
		perk = "10% discount at rebel gun store (rifles only) and rebel vehicle shop";
	};
	class Titan {
		title = "Titan";
		desc = "Kill 1,000 enemy gang members.";
		value = 1000;
		valueType = "gangKills";
		perk = "15% discount at rebel gun store (rifles only) and rebel vehicle shop";
	};
	class Cop_Killer {
		title = "Cop Killer";
		desc = "Kill 10 cops.";
		value = 10;
		valueType = "copKills";
		perk = "";
	};
	class Danger_to_Society {
		title = "On The Run";
		desc = "Kill 25 cops.";
		value = 25;
		valueType = "copKills";
		perk = "Pay 5% less when sent to jail";
	};
	class Bandit {
		title = "Bandit";
		desc = "Kill 50 Cops";
		value = 50;
		valueType = "copKills";
		perk = "Pay 10% less when sent to jail";
	};
	class Outlaw {
		title = "Outlaw";
		desc = "Kill 75 cops.";
		value = 75;
		valueType = "copKills";
		perk = "Pay 15% less when sent to jail";
	};
	class Most_Wanted {
		title = "Most Wanted";
		desc = "Kill 100 cops.";
		value = 100;
		valueType = "copKills";
		perk = "Pay 20% less when sent to jail";
	};
	class Blacklisted {
		title = "Blacklisted";
		desc = "Kill 250 cops.";
		value = 250;
		valueType = "copKills";
		perk = "Pay 25% less when sent to jail";
	};
	class Good_Samaritan {
		title = "Good Samaritan";
		desc = "Use 5 CPR Kits";
		value = 5;
		valueType = "revives";
		perk = "";
	};
	class Medicine_Man {
		title = "Basically a Doctor";
		desc = "Use 15 CPR Kits.";
		value = 15;
		valueType = "revives";
		perk = "";
	};
	class CPR_Certified {
		title = "CPR Certified";
		desc = "Use 30 CPR Kits.";
		value = 30;
		valueType = "revives";
		perk = "";
	};
	class Hijacker {
		title = "Carjacker";
		desc = "Lockpick 5 vehicles.";
		value = 5;
		valueType = "lockpicks";
		perk = "";
	};
	class Joyrider {
		title = "Joyrider";
		desc = "Lockpick 25 vehicles.";
		value = 25;
		valueType = "lockpicks";
		perk = "Chances to get keys are increased by 5%";
	};
	class Kleptomaniac {
		title = "Kleptomaniac";
		desc = "Lockpick 50 vehicles.";
		value = 50;
		valueType = "lockpicks";
		perk = "Chances to get keys are increased by 10%, 30% chance of no car alarms tripping";
	};
	class Pickpocket {
		title = "Pickpocket";
		desc = "Rob 10 other civilians of their gear.";
		value = 10;
		valueType = "robbedAmount";
		perk = "";
	};
	class Mugger {
		title = "Mugger";
		desc = "Rob 25 other civilians of their gear.";
		value = 25;
		valueType = "robbedAmount";
		perk = "";
	};
	class Crook {
		title = "Crook";
		desc = "Rob 50 other civilians of their gear.";
		value = 50;
		valueType = "robbedAmount";
		perk = "";
	};
	class Master_Thief {
		title = "Master Thief";
		desc = "Rob 75 other civilians of their gear.";
		value = 75;
		valueType = "robbedAmount";
		perk = "";
	};
	class Prisoner {
		title = "Prisoner";
		desc = "Spend 5 hours in prison.";
		value = 5;
		valueType = "hoursServed";
		perk = "5% less jail time when sent";
	};
	class Felon {
		title = "Felon";
		desc = "Spend 25 hours in prison.";
		value = 25;
		valueType = "hoursServed";
		perk = "10%% less jail time when sent";
	};
	class Death_Row {
		title = "Death Row";
		desc = "Spend 150 hours in prison.";
		value = 150;
		valueType = "hoursServed";
		perk = "15% less jail time when sent";
	};
	class Addict {
		title = "Addict";
		desc = "Sell 250 drugs to a drug dealer.";
		value = 250;
		valueType = "drugsSold";
		perk = "";
	};
	class Dealer {
		title = "Dealer";
		desc = "Sell 500 drugs to a drug dealer.";
		value = 500;
		valueType = "drugsSold";
		perk = "";
	};
	class Distributor {
		title = "Distributor";
		desc = "Sell 750 drugs to a drug dealer.";
		value = 750;
		valueType = "drugsSold";
		perk = "";
	};
	class Gus_Fring {
		title = "Gus Fring";
		desc = "Sell 1,000 drugs to a drug dealer.";
		value = 1000;
		valueType = "drugsSold";
		perk = "";
	};
	class Narco {
		title = "Pablo Escobar";
		desc = "Sell 2,500 drugs to a drug dealer.";
		value = 2500;
		valueType = "drugsSold";
		perk = "";
	};
	class Firestarter {
		title = "Firestarter";
		desc = "Plant 5 blasting charges.";
		value = 5;
		valueType = "chargesPlanted";
		perk = "5% faster boltcutting at the Federal Reserve";
	};
	class Demo_Man {
		title = "Demolitions Expert";
		desc = "Plant 25 blasting charges.";
		value = 25;
		valueType = "chargesPlanted";
		perk = "10% faster boltcutting at the Federal Reserve";
	};
	class Bomber_Man {
		title = "Professional";
		desc = "Plant 50 blasting charges.";
		value = 50;
		valueType = "chargesPlanted";
		perk = "25% faster boltcutting at the Federal Reserve";
	};
	class Noob {
		title = "Noob";
		desc = "Record 60 minutes on civilian.";
		value = 60;
		valueType = "minutesPlayed";
		perk = "";
	};
	class Invested {
		title = "Invested";
		desc = "Record 600 minutes on civilian.";
		value = 600;
		valueType = "minutesPlayed";
		perk = "";
	};
	class Dedicated {
		title = "Dedicated";
		desc = "Record 3,000 minutes on civilian.";
		value = 3000;
		valueType = "minutesPlayed";
		perk = "$500 increase in paychecks";
	};
	class Committed {
		title = "Committed";
		desc = "Record 6,000 minutes on civilian.";
		value = 6000;
		valueType = "minutesPlayed";
		perk = "$1,000 increase in paychecks";
	};
	class Addicted {
		title = "Addicted";
		desc = "Record 12,000 minutes on civilian.";
		value = 12000;
		valueType = "minutesPlayed";
		perk = "$1,500 increase in paychecks";
	};
	class Obsessed {
		title = "Obsessed";
		desc = "Record 30,000 minutes on civilian.";
		value = 30000;
		valueType = "minutesPlayed";
		perk = "$2,500 increase in paychecks";
	};
	class Explorer {
		title = "Explorer";
		desc = "Travel 1km on foot.";
		value = 1;
		valueType = "kmTraveled";
		perk = "";
	};
	class Hiker {
		title = "Hiker";
		desc = "Travel 10km on foot.";
		value = 10;
		valueType = "kmTraveled";
		perk = "";
	};
	class Journeyor {
		title = "Journeyor";
		desc = "Travel 50km on foot.";
		value = 50;
		valueType = "kmTraveled";
		perk = "Redgull lasts 10% longer";
	};
	class World_Travellor {
		title = "World Traveler";
		desc = "Travel 100km on foot.";
		value = 100;
		valueType = "kmTraveled";
		perk = "Redgull lasts 25% longer";
	};
	class Bot {
		title = "Bot";
		desc = "Accumulate a sum of 1 death.";
		value = 1;
		valueType = "deaths";
		perk = "";
	};
	class Death_Finds_Me_Often {
		title = "Death Finds Me Often";
		desc = "Accumulate a sum of 25 deaths.";
		value = 25;
		valueType = "deaths";
		perk = "";
	};
	class Crippling_Depression {
		title = "Crippling Depression";
		desc = "Accumulate a sum of 50 deaths.";
		value = 50;
		valueType = "deaths";
		perk = "";
	};
	class Masochist {
		title = "Masochist";
		desc = "Accumulate a sum of 75 deaths.";
		value = 75;
		valueType = "deaths";
		perk = "";
	};
	class Aims_With_Steering_Wheel {
		title = "Aims With A Steering Wheel";
		desc = "Accumulate a sum of 100 deaths.";
		value = 100;
		valueType = "deaths";
		perk = "";
	};
	class Suicide_Artist {
		title = "Suicide Artist";
		desc = "Accumulate a sum of 250 deaths.";
		value = 250;
		valueType = "deaths";
		perk = "";
	};
	class Lucky {
		title = "Lucky";
		desc = "Win 5 bets.";
		value = 5;
		valueType = "betsWon";
		perk = "";
	};
	class High_roller {
		title = "High Roller";
		desc = "Win 10 bets.";
		value = 10;
		valueType = "betsWon";
		perk = "";
	};
	class On_the_Heater {
		title = "On the Heater";
		desc = " Win 25 bets.";
		value = 25;
		valueType = "betsWon";
		perk = "";
	};
	class What_are_runs {
		title = "What are Runs";
		desc = "Win 50 bets.";
		value = 50;
		valueType = "betsWon";
		perk = "";
	};
	class Iam_Casino {
		title = "I am the Casino";
		desc = "Win 100 bets.";
		value = 100;
		valueType = "betsWon";
		perk = "";
	};
	class Card_Counter {
		title = "Card Counter";
		desc = "Win 150 bets.";
		value = 150;
		valueType = "betsWon";
		perk = "";
	};
	class poker_Champ {
		title = "World Poker Champ";
		desc = "Win 250 bets.";
		value = 250;
		valueType = "betsWon";
		perk = "";
	};
	class Rip_Money {
		title = "Rip My Money";
		desc = "Lose 1 bet.";
		value = 1;
		valueType = "betsLost";
		perk = "";
	};
	class Lets_go_again {
		title = "Lets Go Again";
		desc = "Lose 5 bets.";
		value = 5;
		valueType = "betsLost";
		perk = "";
	};
	class My_money {
		title = "Can I Have My Money Back";
		desc = "Lose 10 bets.";
		valueType = "betsLost";
		value = 10;
		perk = "";
	};
	class Get_loan {
		title = "Need a 2nd Loan";
		desc = "Lose 25 bets.";
		valueType = "betsLost";
		value = 25;
		perk = "";
	};
	class Cant_count {
		title = "I Cant Count Cards";
		desc = "Lose 50 bets.";
		valueType = "betsLost";
		value = 50;
		perk = "";
	};
	class Gambling_Addict {
		title = "Gambling Addict";
		desc = "Lose 100 Bets.";
		valueType = "betsLost";
		value = 100;
		perk = "";
	};
	class Need_help {
		title = "I Need Help";
		desc = "Lose 150 bets.";
		valueType = "betsLost";
		value = 150;
		perk = "";
	};
	class Better_Anonymous {
		title = "Better Anonymous";
		desc = "Lose 250 bets.";
		valueType = "betsLost";
		value = 250;
		perk = "";
	};
};
class CfgTitleCop {
	class Deputy {
		title = "Deputy";
		desc = "Earn the rank of Deputy.";
		value = 1;
		valueType = "copLevel";
		perk = "$300 paycheck increase";
	};
	class SrDep {
		title = "Senior Deputy";
		desc = "Earn the rank of Senior Deputy.";
		value = 2;
		valueType = "copLevel";
		perk = "$600 paycheck increase";
	};
	class Corporal {
		title = "Corporal";
		desc = "Earn the rank of Corporal.";
		value = 3;
		valueType = "copLevel";
		perk = "$900 paycheck increase";
	};
	class Sergeant {
		title = "Sergeant";
		desc = "Earn the rank of Sergeant.";
		value = 4;
		valueType = "copLevel";
		perk = "$1,200 paycheck increase";
	};
	class Lieutenant {
		title = "Lieutenant";
		desc = "Earn the rank of Lieutenant.";
		value = 5;
		valueType = "copLevel";
		perk = "$1,500 paycheck increase";
	};
	class Captain {
		title = "Captain";
		desc = "Earn the rank of Captain.";
		value = 6;
		valueType = "copLevel";
		perk = "$1,500 paycheck increase";
	};
	class Major {
		title = "Major";
		desc = "Earn the rank of Major.";
		value = 7;
		valueType = "copLevel";
		perk = "$1,500 paycheck increase";
	};
	class UnderSheriff {
		title = "Undersheriff";
		desc = "Earn the rank of Undersheriff.";
		value = 8;
		valueType = "copLevel";
		perk = "$1,800 paycheck increase";
	};
	class Sheriff {
		title = "Sheriff";
		desc = "Earn the rank of Sheriff.";
		value = 8;
		valueType = "copLevel";
		perk = "$1,800 paycheck increase";
	};
	class Doorkicker {
		title = "Doorkicker";
		desc = "Earn a spot on the SERT Team";
		value = 4;
		valueType = "copDept";
		perk = "";
	};
	class Narc {
		title = "Narc";
		desc = "Become an FBI Agent.";
		value = 5;
		valueType = "copDept";
		perk = "";
	};
	class Fed {
		title = "Fed";
		desc = "Become an FBI Agent.";
		value = 5;
		valueType = "copDept";
		perk = "";
	};
	class HRT {
		title = "Federal Badass";
		desc = "Earn a spot on FBI's HRT";
		value = 6;
		valueType = "copDept";
		perk = "";
	};
	class Mall_Cop {
        title = "Mall Cop";
        desc = "Seize $25,000 in drugs.";
        value = 25000;
		valueType = "drugMoney";
        perk = "";
    };
    class Drug_Dog {
        title = "Drug Dog";
        desc = "Seize $50,000 in drugs.";
        value = 50000;
		valueType = "drugMoney";
        perk = "2% increase in profits of drug seizures";
    };
    class DEA_Agent {
        title = "DEA Agent";
        desc = "Seize $100,000 in drugs.";
        value = 100000;
		valueType = "drugMoney";
        perk = "5% increase in profits of drug seizures";
    };
    class Narcotics_Ninja {
        title = "Narcotics Ninja";
        desc = "Seize $150,000 in drugs.";
        value = 150000;
		valueType = "drugMoney";
        perk = "8% increase in profits of drug seizures";
    };
    class The_Epitome_of_Escobar {
        title = "The Epitome of Escobar";
        desc = "Seize $500,000 in drugs.";
        value = 500000;
		valueType = "drugMoney";
        perk = "10% increase in profits of drug seizures";
    };
    class Defender {
        title = "Defender";
        desc = "Kill 10 Criminals"; // Cop kills gang member
        value = 25;
		valueType = "gangsKilled";
        perk = "";
    };
    class Enforcer {
        title = "Enforcer";
        desc = "Kill 10 Criminals.";
        value = 50;
		valueType = "gangsKilled";
        perk = "";
    };
    class Justicar {
        title = "Justicar";
        desc = "Kill 10 Criminals.";
        value = 75;
		valueType = "gangsKilled";
        perk = "";
    };
    class Sheriff_of_Slaying {
        title = "Sheriff of Slaying";
        desc = "Kill 100 Criminals.";
        value = 100;
		valueType = "gangsKilled";
        perk = "";
    };
    class The_Bandit_in_Blue {
        title = "The Bandit in Blue";
        desc = "Kill 250 Criminals.";
        value = 250;
		valueType = "gangsKilled";
        perk = "";
    };
    class The_Executioner {
        title = "The Executioner";
        desc = "Kill 500 Criminals.";
        value = 500;
		valueType = "gangsKilled";
        perk = "";
    };
	class Rookie {
        title = "Rookie";
        desc = "Arrest 5 civilians.";
        value = 5;
		valueType = "arrests";
        perk = "";
    };
    class Experienced_Officer {
        title = "Experienced Officer";
        desc = "Arrest 25 civilians.";
        value = 25;
		valueType = "arrests";
        perk = "";
    };
    class Veteran_Officer {
        title = "Veteran Officer";
        desc = "Arrest 50 civilians.";
        value = 50;
		valueType = "arrests";
        perk = "";
    };
    class Peacekeeper {
        title = "Peacekeeper";
        desc = "Arrest 75 civilians.";
        value = 75;
		valueType = "arrests";
        perk = "";
    };
    class DCSO_Finest {
        title = "DCSO's Finest";
        desc = "Arrest 100 civilians.";
        value = 100;
		valueType = "arrests";
        perk = "";
    };
    class Robocop {
        title = "Robocop";
        desc = "Arrest 250 civilians.";
        value = 250;
		valueType = "arrests";
        perk = "";
    };
	class Cadet {
        title = "Cadet";
        desc = "Record 60 minutes on cop.";
        value = 60;
		valueType = "copMinutes";
        perk = "";
    };
    class Qualified {
        title = "Qualified";
        desc = "Record 600 minutes on cop.";
        value = 600;
		valueType = "copMinutes";
        perk = "";
    };
    class Seasoned_Veteran {
        title = "Seasoned Veteran";
        desc = "Record 1,500 minutes on cop.";
        value = 1500;
		valueType = "copMinutes";
        perk = "";
    };
    class Legendary_Tenure {
        title = "Legendary Tenure";
        desc = "Record 3,000 minutes on cop.";
        value = 3000;
		valueType = "copMinutes";
        perk = "";
    };
    class Career_Cop {
        title = "Career Cop";
        desc = "Record 6,000 minutes on cop.";
        value = 6000;
		valueType = "copMinutes";
        perk = "";
    };
    class Should_Be_Retired {
        title = "Should Be Retired";
        desc = "Record 15,000 minutes on cop.";
        value = 15000;
		valueType = "copMinutes";
        perk = "";
    };
	class Pig {
        title = "Pig";
        desc = "Eat 1 donut.";
        value = 1;
		valueType = "donutsEaten";
        perk = "";
    };
    class Paul_Blart {
        title = "Paul Blart";
        desc = "Eat 50 donuts.";
        value = 50;
		valueType = "donutsEaten";
        perk = "";
    };
    class Precious {
        title = "Precious";
        desc = "Eat 500 donuts.";
        value = 500;
		valueType = "donutsEaten";
        perk = "";
    };
};
class CfgTitleMedic {
	class Intern {
        title = "Resident";
        desc = "Record 60 minutes on EMS.";
        value = 60;
		valueType = "EMSMinutes";
        perk = "";
    };
    class Walking_MedKit {
        title = "Walking Medkit";
        desc = "Record 600 minutes on EMS.";
        value = 600;
		valueType = "EMSMinutes";
        perk = "";
    };
    class Corpsman {
        title = "Corpsman";
        desc = "Record 1,500 minutes on EMS.";
        value = 1500;
		valueType = "EMSMinutes";
        perk = "";
    };
    class Aviator {
        title = "Air Responder";
        desc = "Record 3,000 minutes on EMS.";
        value = 3000;
		valueType = "EMSMinutes";
        perk = "";
    };
    class Greasemonkey {
        title = "Medic Extraordinaire";
        desc = "Record 6,000 minutes on EMS.";
        value = 6000;
		valueType = "EMSMinutes";
        perk = "";
    };
    class Surgeon {
        title = "Dr. Feelgood";
        desc = "Record 15,000 minutes on EMS.";
        value = 15000;
		valueType = "EMSMinutes";
        perk = "";
    };
	class Probie {
		title = "Probie";
		desc = "Revive 10 Patients";
		value = 10;
		valueType = "medicRevives";
		perk = "";
	};
	class Paramedic {
		title = "Paramedic";
		desc = "Revive 50 Patients";
		value = 50;
		valueType = "medicRevives";
		perk = "";
	};
	class Resident {
		title = "Resident";
		desc = "Revive 100 Patients";
		value = 100;
		valueType = "medicRevives";
		perk = "";
	};
	class Doctor {
		title = "Doctor";
		desc = "Revive 250 Patients";
		value = 250;
		valueType = "medicRevives";
		perk = "";
	};
	class Neuro {
		title = "Neuro Surgeon";
		desc = "Revive 500 Patients";
		value = 500;
		valueType = "medicRevives";
		perk = "";
	};
	class DrHouse {
		title = "Dr. House";
		desc = "Revive 1,000 Patients";
		value = 1000;
		valueType = "medicRevives";
		perk = "";
	};
};
class CfgTitleSpecial {
	class NitroDonators {
		title = "Discord Nitro Booster";
		desc = "Boosted the discord server.";
		value = 0;
		perk = "";
	};
	class Supporter {
		title = "Takistan Shareholder";
		desc = "Donated $15 to the server.";
		value = 0;
		perk = "Donation Rewards can be found at WEBSITE HERE";
	};
	class MVP {
		title = "Most Valuable Piggybank";
		desc = "Donated $30 to the server.";
		value = 0;
		perk = "Donation Rewards can be found at WEBSITE HERE";
	};
	class VIP {
		title = "Very Important Pockets";
		desc = "Donated $50 to the server.";
		value = 0;
		perk = "Donation Rewards can be found at WEBSITE HERE";
	};
	class Elite {
		title = "Rich Bitch";
		desc = "Donated $100 to the server.";
		value = 0;
		perk = "Donation Rewards can be found at WEBSITE HERE";
	};
	class Champion {
		title = "Sugar Daddy";
		desc = "Donated $250 to the server.";
		value = 0;
		perk = "Donation Rewards can be found at WEBSITE HERE";
	};
	class Legendary {
		title = "Dishwasher Donator";
		desc = "Donated $500 to the server.";
		value = 0;
		perk = "Donation Rewards can be found at WEBSITE HERE";
	};
	class MostEXP {
		title = "Farmer Extraordinaire";
		desc = "Obtain the most XP on the server.";
		value = 0;
		perk = "";
	};
	class WarPoints {
		title = "God of War";
		desc = "Most warpoints on the server";
		value = 0;
		perk = "";
	};
	class Homicidal_Maniac {
		title = "Homicidal Maniac";
		desc = "Most kills on the server";
		value = 0;
		perk = "";
	};
	class Merciless_Anarchist {
		title = "Merciless Anarchist"; // Cop Only
		desc = "Most cop kills on the server.";
		value = 0;
		perk = "";
	};
};