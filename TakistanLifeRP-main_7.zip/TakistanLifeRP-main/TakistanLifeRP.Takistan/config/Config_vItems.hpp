/*
*    FORMAT:
*        STRING (Conditions) - Must return boolean :
*            String can contain any amount of conditions, aslong as the entire
*            string returns a boolean. This allows you to check any levels, licenses etc,
*            in any combination. For example:
*                "call life_coplevel && license_civ_someLicense"
*            This will also let you call any other function.
*/

class VirtualShops {
	class farming {
		name = "STR_LegalSeed_Market";
		side = "";
		conditions = "";
		items[] = { "lambSteak","sunflowerseed", "wheatseed", "beanseed", "cottonseed", "pumpkinseed", "cornseed", "bean", "cotton", "sunflower", "pumpkin", "wheat", "corn" };
	};

	class market {
		name = "STR_Shops_Market";
		side = "";
		conditions = "";
		items[] = { "debitCard", "cprKit", "bandage", "stabilizer", "hardenedpickaxe", "toolkit", "fuelEmpty", "scratchOff", "peach", "cloth", "storagesmall", "storagebig", "waterBottle", "apple", "pepsi", "monsterEnergy", "doritos", "kfc", "redgull", "tbacon" };
	};

	class med_market {
		name = "STR_Shops_Market";
		side = "med";
		conditions = "";
		items[] = { "debitCard", "narcan", "alcoholwipe", "bandage", "morphine", "bloodbag", "splint", "defib", "stabilizer", "drugtestkit", "waterBottle", "apple", "redgull", "tbacon", "toolkit", "fuelEmpty" };
	};

	class gang {
		name = "STR_Shops_Gang";
		side = "";
		conditions = "";
		items[] = { "bandage", "waterBottle", "apple", "redgull", "tbacon", "toolkit", "fuelEmpty", "peach" };
	};

	class wongs {
		name = "STR_Shops_Wongs";
		side = "civ";
		conditions = "";
		items[] = { "turtle_soup", "turtle_raw" };
	};

	class coffee {
		name = "STR_Shops_Coffee";
		side = "";
		conditions = "";
		items[] = { "coffee", "donuts" };
	};

	class f_station_coffee {
		name = "STR_Shop_Station_Coffee";
		side = "";
		conditions = "";
		items[] = { "debitCard", "coffee", "donuts", "redgull", "bandage", "toolkit", "fuelEmpty" };
	};

	class drugdealer {
		name = "STR_Shops_DrugDealer";
		side = "";
		conditions = "";
		items[] = { "hindukush", "hash", "cocaine", "crack", "heroin", "heroinPure", "acid", "DMT" };
	};

	class blackmarket {
		name = "STR_Shops_BlackMarket";
		side = "civ";
		conditions = "";
		items[] = {"doorc4", "markedMoney","casinoChip", "goldBar", "codeCracker", "injectionHack", "decryptedIntel", "encryptedIntel", "fineArt", "plutonium", "poweroverrider", "blastingcharge", "vaultDrill", "generator","humanLiver","humanKidney","humanLung","humanHeart","humanBrain","humanCock"};
	};

	class oil {
		name = "STR_Shops_Oil";
		side = "civ";
		conditions = "";
		items[] = { "rubber", "oil_processed", "fuelEmpty", "hardenedpickaxe" };
	};

	class fishmarket {
		name = "STR_Shops_FishMarket";
		side = "civ";
		conditions = "";
		items[] = { "salema_raw", "ornate_raw", "mackerel_raw", "tuna_raw", "mullet_raw", "catshark_raw" };
	};

	class ingots {
		name = "STR_Shops_Ingots";
		side = "civ";
		conditions = "";
		items[] = {  "copper", "copper_final", "iron", "iron_final", "silver", "silver_final", "gold", "gold_final" };
	};

	class minerals {
		name = "STR_Shops_Minerals";
		side = "civ";
		conditions = "";
		items[] = { "coal", "coal_final", "diamond", "diamond_final", "sapphire", "sapphire_final" };
	};

	class cement {
		name = "STR_Shops_Cement";
		side = "civ";
		conditions = "";
		items[] = { "cement" };
	};

	class cop {
		name = "STR_Shops_Cop";
		side = "cop";
		conditions = "";
		items[] = { "debitCard","narcan","drugtestkit","gsrTest", "panicbutton", "keyCard", "gpstracker", "lockpick", "stabilizer", "cprKit", "bandage", "donuts", "coffee", "spikeStrip", "waterBottle", "apple", "redgull", "toolkit", "fuelEmpty", "defusekit", "enginedisable", "doorc4" };
	};

	class opf {
		name = "STR_Shops_Opf";
		side = "opf";
		conditions = "";
		items[] = { "debitCard","narcan","drugtestkit","gsrTest", "panicbutton", "keyCard", "gpstracker", "lockpick", "stabilizer", "cprKit", "bandage", "donuts", "coffee", "spikeStrip", "waterBottle", "apple", "redgull", "toolkit", "fuelEmpty", "defusekit", "enginedisable", "doorc4" };
	};

	class uranium {
		name = "STR_Shops_uranium";
		side = "";
		conditions = "";
		items[] = { "uranium" };
	};

	class archeologist {
		name = "STR_Shops_archeologist";
		side = "";
		conditions = "(player getVariable ['mav_ttm_var_relicReward2',false]) isEqualTo true";
		items[] = { "excavator" };
	};

	class unknown {
		name = "STR_Shops_unknown";
		side = "";
		conditions = "";
		items[] = { "unknown" };
	};

	class burglary {
		name = "STR_Shops_burglary";
		side = "";
		conditions = "";
		items[] = { "boltcutter","oilSupplies","lockpick", "crowbar", "gloves", "rubyJewelery", "diamondJewelery", "sapphireJewelery", "amethystJewelery", "antiqueCoin", "boxers", "bra", "cards", "gnome", "noose", "monaLisa", "panties", "remote", "samsungs9", "iphonex", "trash" };
	};

	class jail {
		name = "STR_Shops_Jail";
		side = "";
		conditions = "";
		items[] = { "shank", "zipties", "lockpick", "keyCard", "trash", "bandage" };
	};

	class jaillegal {
		name = "STR_Shops_JailLegal";
		side = "";
		conditions = "";
		items[] = { "coalOre", "ironOre", "diamondOre", "rubyOre", "emeraldOre", "sapphireOre", "silverOre", "goldOre", "tbacon", "waterBottle", "bandage" };
	};

	class goldcoin {
		name = "STR_Shops_goldcoin";
		side = "civ";
		conditions = "";
		items[] = { "goldcoin" };
	};

	class rebel {
		name = "STR_Shops_Illegal";
		side = "";
		conditions = "license_civ_reb";
		items[] = { "debitCard", "doorc4", "bandage", "cprKit", "scalpel", "stabilizer", "boltcutter", "lockpick", "zipties", "blindfold", "waterBottle", "apple", "redgull", "tbacon", "toolkit", "fuelEmpty", "peach", "boltLocker", "speedBomb", "seatEjector" };
	};

	class illegal {
		name = "Illegal Market";
		side = "";
		conditions = "";
		items[] = { "doorc4", "bandage", "cprKit", "stabilizer", "boltcutter", "moneyBagEmpty", "lockpick", "zipties", "blindfold", "waterBottle", "apple", "redgull", "tbacon", "toolkit", "fuelEmpty", "peach", "boltLocker", "seatEjector" };
	};

	
	class fortBluforShop {
        name = "STR_Shops_Fort"; 
        side = "cop";
        conditions = "";
        items[] = { "roadCone", "plasticRoadBarrier", "pRoadBarrier", "sRoadBarrier", "roadBarrierStriped", "barGate", "hBarrierC", "hBarrierS", "razorWire", "bunkerS", "camoNetNATOD", "camoNetNATODO", "sandBagL", "sandBagS", "sandBagC", "sandBagR" };
    };

	class fortOpforShop {
        name = "STR_Shops_Fort";
        side = "opf";
        conditions = "";
        items[] = { "roadCone", "plasticRoadBarrier", "pRoadBarrier", "sRoadBarrier", "roadBarrierStriped", "barGate", "hBarrierC", "hBarrierS", "razorWire", "bunkerS", "camoNetEASTD", "camoNetEASTDO", "sandBagL", "sandBagS", "sandBagC", "sandBagR" };
    };
};

/*
*    CLASS:
*        variable = Variable Name
*        displayName = Item Name
*        weight = Item Weight
*        buyPrice = Item Buy Price
*        sellPrice = Item Sell Price
*        illegal = Illegal Item
*        edible = Item Edible (-1 = Disabled)
*        icon = Item Icon
*        processedItem = Processed Item
*        marketIndex = If item is to be displayed on the market index (1 - Display, 0 - Don't display)
*/

class VirtualItems {

	class Default {
		weight = 1;
		buyPrice = -1;
		sellPrice = -1;
		illegal = 0;
		edible = -1;
		displayName = "";
		icon = "";
		marketIndex = 0;
		toolTip = "";
	};

	/* Farming */
	class pumpkinseed : Default {
		variable = "pumpkinseed";
		displayName = "STR_Item_pumpkinseed";
		weight = 2;
		buyPrice = 10;
		sellPrice = 10;
		icon = "SG_Core\images\icons\seed.paa";
	};

	class lambSteak : Default {
		variable = "lambSteak";
		displayName = "STR_Item_lambSteak";
		weight = 8;
		buyPrice = 3000;
		sellPrice = 2000;
		edible = 60;
		icon = "SG_Core\images\icons\steak.paa";
	};

	class humanCock : Default {
		variable = "humanCock";
		displayName = "STR_Item_humanCock";
		weight = 3;
		buyPrice = -1;
		sellPrice = 40250;
		icon = "SG_Core\images\icons\penis.paa";
	};

	class humanBrain : Default {
		variable = "humanBrain";
		displayName = "STR_Item_humanBrain";
		weight = 3;
		buyPrice = -1;
		sellPrice = 27500;
		icon = "SG_Core\images\icons\brain.paa";
	};

	class humanHeart : Default {
		variable = "humanHeart";
		displayName = "STR_Item_humanHeart";
		weight = 3;
		buyPrice = -1;
		sellPrice = 19500;
		icon = "SG_Core\images\icons\heart.paa";
	};

	class humanLung : Default {
		variable = "humanLung";
		displayName = "STR_Item_humanLung";
		weight = 3;
		buyPrice = -1;
		sellPrice = 8750;
		icon = "SG_Core\images\icons\lung.paa";
	};

	class humanLiver : Default {
		variable = "humanLiver";
		displayName = "STR_Item_humanLiver";
		weight = 3;
		buyPrice = -1;
		sellPrice = 12500;
		icon = "SG_Core\images\icons\liver.paa";
	};

	class humanKidney : Default {
		variable = "humanKidney";
		displayName = "STR_Item_humanKidney";
		weight = 3;
		buyPrice = -1;
		sellPrice = 6250;
		icon = "SG_Core\images\icons\kidney.paa";
	};

	class pumpkin : Default {
		variable = "pumpkin";
		displayName = "STR_Item_pumpkin";
		weight = 7;
		sellPrice = 1100;
		edible = 60;
		icon = "SG_Core\images\icons\pumpkin.paa";
	};

	class beanseed : Default {
		variable = "beanseed";
		displayName = "STR_Item_beanseed";
		weight = 2;
		buyPrice = 10;
		sellPrice = 10;
		icon = "SG_Core\images\icons\seed.paa";
	};

	class bean : Default {
		variable = "bean";
		displayName = "STR_Item_bean";
		weight = 4;
		sellPrice = 955;
		edible = 15;
		icon = "SG_Core\images\icons\bean.paa";
	};

	class cottonseed : Default {
		variable = "cottonseed";
		displayName = "STR_Item_cottonseed";
		weight = 2;
		buyPrice = 10;
		sellPrice = 10;
		icon = "SG_Core\images\icons\seed.paa";
	};

	class cotton : Default {
		variable = "cotton";
		displayName = "STR_Item_cotton";
		weight = 4;
		sellPrice = 977;
		marketIndex = 1;
		icon = "SG_Core\images\icons\cotton.paa";
	};

	class wheatseed : Default {
		variable = "wheatseed";
		displayName = "STR_Item_wheatseed";
		weight = 2;
		buyPrice = 10;
		sellPrice = 10;
		icon = "SG_Core\images\icons\seed.paa";
	};

	class wheat : Default {
		variable = "wheat";
		displayName = "STR_Item_wheat";
		weight = 4;
		sellPrice = 785;
		marketIndex = 1;
		icon = "SG_Core\images\icons\wheat.paa";
	};

	class cornseed : Default {
		variable = "cornseed";
		displayName = "STR_Item_cornseed";
		weight = 2;
		buyPrice = 10;
		sellPrice = 10;
		icon = "SG_Core\images\icons\seed.paa";
	};

	class corn : Default {
		variable = "corn";
		displayName = "STR_Item_corn";
		weight = 4;
		sellPrice = 1050;
		edible = 30;
		icon = "SG_Core\images\icons\corn.paa";
	};

	class sunflowerseed : Default {
		variable = "sunflowerSeed";
		displayName = "STR_Item_sunflowerseed";
		weight = 2;
		buyPrice = 10;
		sellPrice = 10;
		icon = "SG_Core\images\icons\seed.paa";
	};

	class sunflower : Default {
		variable = "sunflower";
		displayName = "STR_Item_sunflower";
		weight = 4;
		sellPrice = 985;
		marketIndex = 1;
		icon = "SG_Core\images\icons\sunflower.paa";
	};

	class pot : Default {
		variable = "pot";
		displayName = "STR_Item_pot";
		weight = 10;
		buyPrice = 1200;
		sellPrice = 10;
		icon = "SG_Core\images\icons\seed.paa";
	};

	class sassafrasSeed : Default {
		variable = "sassafrasSeed";
		displayName = "STR_Item_sassafrasSeed";
		weight = 2;
		buyPrice = 300;
		sellPrice = 10;
		illegal = true;
		icon = "SG_Core\images\icons\seed.paa";
	};

	class sassafras : Default {
		variable = "sassafras";
		displayName = "STR_Item_sassafras";
		weight = 5;
		illegal = true;
		icon = "SG_Core\images\icons\sassafras.paa";
		processedItem = "MDMA";
	};

	class MDMA : Default {
		variable = "MDMA";
		displayName = "STR_Item_MDMA";
		weight = 4;
		buyPrice = 2490;
		sellPrice = 1950;
		illegal = true;
		icon = "SG_Core\images\icons\dmt.paa";
	};

	class molly : Default {
		variable = "molly";
		displayName = "STR_Item_molly";
		weight = 4;
		buyPrice = 2990;
		sellPrice = 2702;
		illegal = true;
		icon = "SG_Core\images\icons\molly.paa";
	};

	class opium : Default {
		variable = "opium";
		displayName = "STR_Item_opium";
		weight = 4;
		buyPrice = -1;
		sellPrice = -1;
		illegal = true;
		icon = "SG_Core\images\icons\coca.paa";
	};

	class heroin : Default {
		variable = "heroin";
		displayName = "STR_Item_heroin";
		weight = 3;
		buyPrice = -1;
		sellPrice = 2555;
		illegal = true;
		marketIndex = 1;
		icon = "SG_Core\images\icons\alcoholwipe_ca.paa";
	};

	class heroinPure : Default {
		variable = "heroinPure";
		displayName = "STR_Item_heroinPure";
		weight = 3;
		buyPrice = -1;
		sellPrice = 3155;
		illegal = true;
		marketIndex = 1;
		icon = "SG_Core\images\icons\heroin.paa";
	};

	// Base Weed Strains
	class OGKushSeed : Default {
		variable = "OGKushSeed";
		displayName = "STR_Item_OGKushSeed";
		weight = 2;
		buyPrice = 340;
		sellPrice = 10;
		illegal = true;
		icon = "SG_Core\images\icons\seed.paa";
	};
	class PurpleHazeSeed : Default {
		variable = "PurpleHazeSeed";
		displayName = "STR_Item_PurpleHazeSeed";
		weight = 2;
		buyPrice = 340;
		sellPrice = 10;
		illegal = true;
		icon = "SG_Core\images\icons\seed.paa";
	};
	class hawaiianKushSeed : Default {
		variable = "hawaiianKushSeed";
		displayName = "STR_Item_hawaiianKushSeed";
		weight = 2;
		buyPrice = 340;
		sellPrice = 10;
		illegal = true;
		icon = "SG_Core\images\icons\seed.paa";
	};
	class ogkush : Default {
		variable = "ogkush";
		displayName = "STR_Item_ogkush";
		weight = 5;
		buyPrice = 3550;
		sellPrice = 1250;
		illegal = true;
		icon = "SG_Core\images\icons\weed.paa";
	};
	class purplehaze : Default {
		variable = "purplehaze";
		displayName = "STR_Item_purplehaze";
		weight = 5;
		buyPrice = 3775;
		sellPrice = 1250;
		illegal = true;
		icon = "SG_Core\images\icons\weed.paa";
	};
	class hinduBud : Default {
		variable = "hinduBud";
		displayName = "STR_Item_hinduBud";
		weight = 4;
		buyPrice = -1;
		sellPrice = 807;
		illegal = true;
		icon = "SG_Core\images\icons\weed.paa";
	};
	class hindukush : Default {
		variable = "hindukush";
		displayName = "STR_Item_hindukush";
		weight = 3;
		buyPrice = -1;
		sellPrice = 1553;
		illegal = true;
		icon = "SG_Core\images\icons\weed.paa";
		marketIndex = 1;
	};
	class hash : Default {
		variable = "hash";
		displayName = "STR_Item_hash";
		weight = 3;
		buyPrice = -1;
		sellPrice = 2149;
		illegal = true;
		icon = "SG_Core\images\icons\weed.paa";
		marketIndex = 1;
	};
	
	// Hybrid Weed Strains
	class pineappleExpressSeed : Default {
		variable = "pineappleExpressSeed";
		displayName = "STR_Item_pineappleExpressSeed";
		weight = 2;
		buyPrice = -1;
		sellPrice = 1575;
		illegal = true;
		icon = "SG_Core\images\icons\seed.paa";
	};
	class BlueDreamSeed : Default {
		variable = "BlueDreamSeed";
		displayName = "STR_Item_BlueDreamSeed";
		weight = 2;
		buyPrice = -1;
		sellPrice = 1500;
		illegal = true;
		icon = "SG_Core\images\icons\seed.paa";
	};

	class SourDieselSeed : Default {
		variable = "SourDieselSeed";
		displayName = "STR_Item_SourDieselSeed";
		weight = 2;
		buyPrice = -1;
		sellPrice = 1450;
		illegal = true;
		icon = "SG_Core\images\icons\seed.paa";
	};
	class sourdiesel : Default {
		variable = "sourdiesel";
		displayName = "STR_Item_sourdiesel";
		weight = 5;
		buyPrice = -1;
		sellPrice = 1775;
		illegal = true;
		icon = "SG_Core\images\icons\weed.paa";
	};
	class bluedream : Default {
		variable = "bluedream";
		displayName = "STR_Item_bluedream";
		weight = 5;
		buyPrice = -1;
		sellPrice = 1750;
		illegal = true;
		icon = "SG_Core\images\icons\weed.paa";
	};
	class pineappleexpress : Default {
		variable = "pineappleexpress";
		displayName = "STR_Item_pineappleexpress";
		weight = 5;
		buyPrice = -1;
		sellPrice = 3795;
		illegal = true;
		icon = "SG_Core\images\icons\weed.paa";
	};

	class cocoseed : Default {
		variable = "cocoseed";
		displayName = "STR_Item_cocoseed";
		weight = 2;
		buyPrice = 200;
		sellPrice = 150;
		illegal = true;
		icon = "SG_Core\images\icons\seed.paa";
	};

	class cocoleaf : Default {
		variable = "cocoleaf";
		displayName = "STR_Item_CocaineU";
		weight = 4;
		illegal = true;
		icon = "SG_Core\images\icons\coca.paa";
		processedItem = "cocaine";
	};

	class cocaine : Default {
		variable = "cocaine";
		displayName = "STR_Item_CocaineP";
		weight = 3;
		buyPrice = -1;
		sellPrice = 2757;
		illegal = true;
		icon = "SG_Core\images\icons\cocaine.paa";
		marketIndex = 1;
	};

	class crack : Default {
		variable = "crack";
		displayName = "STR_Item_Crack";
		weight = 3;
		buyPrice = -1;
		sellPrice = 3391;
		illegal = true;
		icon = "SG_Core\images\icons\crack.paa";
		marketIndex = 1;
	};

	/* Mining */
	class plutonium : Default {
		variable = "plutonium";
		displayName = "STR_Item_plutonium";
		weight = 3;
		sellPrice = 150000;
		illegal = true;
		icon = "SG_Core\images\icons\uraniumU_ca.paa";
		marketIndex = 1;
	};

	class rubberU : Default {
		variable = "rubberU";
		displayName = "STR_Item_rubberu";
		weight = 5;
		buyPrice = 225;
		sellPrice = 50;
		icon = "SG_Core\images\icons\rubberU_ca.paa";
	};

	class rubber : Default {
		variable = "rubber";
		displayName = "STR_Item_rubber";
		weight = 3;
		buyPrice = 325;
		sellPrice = 310;
		icon = "SG_Core\images\icons\rubber_ca.paa";
	};

	class goldcoin : Default {
		variable = "goldcoin";
		displayName = "STR_Item_goldcoin";
		weight = 2;
		sellPrice = 180;
		icon = "SG_Core\images\icons\goldcoin_ca.paa";
	};

	class wool : Default {
		variable = "wool";
		displayName = "STR_Item_wool";
		weight = 3;
		buyPrice = 225;
		sellPrice = 80;
		icon = "SG_Core\images\icons\wool_ca.paa";
	};

	class cloth : Default {
		variable = "cloth";
		displayName = "STR_Item_cloth";
		weight = 2;
		buyPrice = 625;
		sellPrice = 170;
		icon = "SG_Core\images\icons\cloth_ca.paa";
	};

	class sulfur : Default {
		variable = "sulfur";
		displayName = "STR_Item_sulfur";
		weight = 2;
		buyPrice = 425;
		sellPrice = 380;
		illegal = true;
		icon = "SG_Core\images\icons\rock_ca.paa";
	};

	class oil_unprocessed : Default {
		variable = "oil_unprocessed";
		displayName = "STR_Item_OilU";
		weight = 5;
		icon = "SG_Core\images\icons\oil_unprocessed_ca.paa";
	};

	class oil_processed : Default {
		variable = "oil_processed";
		displayName = "STR_Item_OilP";
		weight = 4;
		sellPrice = 2751;
		icon = "SG_Core\images\icons\oil_processed_ca.paa";
		marketIndex = 1;
	};

	class rubyOre : Default {
		variable = "rubyOre";
		displayName = "STR_Item_rubyore";
		weight = 3;
		sellPrice = 280;
		icon = "SG_Core\images\icons\rubyOre_ca.paa";
	};

	class ruby : Default {
		variable = "ruby";
		displayName = "STR_Item_ruby";
		weight = 2;
		sellPrice = 1200;
		icon = "SG_Core\images\icons\ruby_ca.paa";
		marketIndex = 1;
	};

	class ruby_final : Default {
		variable = "ruby_final";
		displayName = "STR_Item_rubyFinal";
		weight = 2;
		sellPrice = 2250;
		icon = "SG_Core\images\icons\ruby_ca.paa";
		marketIndex = 1;
	};

	class diamondOre : Default {
		variable = "diamondOre";
		displayName = "STR_Item_DiamondU";
		weight = 3;
		sellPrice = 300;
		icon = "SG_Core\images\icons\diamondOre_ca.paa";
	};

	class diamond : Default {
		variable = "diamond";
		displayName = "STR_Item_DiamondC";
		weight = 2;
		sellPrice = 2500;
		icon = "SG_Core\images\icons\diamond_ca.paa";
		marketIndex = 1;
	};

	class diamond_final : Default {
		variable = "diamond_final";
		displayName = "STR_Item_DiamondCFinal";
		weight = 2;
		sellPrice = 2975;
		icon = "SG_Core\images\icons\diamond_ca.paa";
		marketIndex = 1;
	};

	class sapphireOre : Default {
		variable = "sapphireOre";
		displayName = "STR_Item_SapphireU";
		weight = 3;
		sellPrice = 150;
		icon = "SG_Core\images\icons\diamondOre_ca.paa";
	};

	class sapphire : Default {
		variable = "sapphire";
		displayName = "STR_Item_SapphireC";
		weight = 2;
		sellPrice = 1250;
		icon = "SG_Core\images\icons\diamond_ca.paa";
		marketIndex = 1;
	};

	class sapphire_final : Default {
		variable = "sapphire_final";
		displayName = "STR_Item_SapphireCFinal";
		weight = 2;
		sellPrice = 1850;
		icon = "SG_Core\images\icons\diamond_ca.paa";
		marketIndex = 1;
	};

	class emeraldOre : Default {
		variable = "emeraldOre";
		displayName = "STR_Item_EmeraldU";
		weight = 3;
		sellPrice = 150;
		icon = "SG_Core\images\icons\diamondOre_ca.paa";
	};

	class emerald : Default {
		variable = "emerald";
		displayName = "STR_Item_EmeraldC";
		weight = 2;
		sellPrice = 1250;
		icon = "SG_Core\images\icons\diamond_ca.paa";
		marketIndex = 1;
	};

	class emerald_final : Default {
		variable = "emerald_final";
		displayName = "STR_Item_EmeraldCFinal";
		weight = 2;
		sellPrice = 1475;
		icon = "SG_Core\images\icons\diamond_ca.paa";
		marketIndex = 1;
	};

	class goldOre : Default {
		variable = "goldOre";
		displayName = "STR_Item_goldU";
		weight = 4;
		sellPrice = 300;
		icon = "SG_Core\images\icons\diamondOre_ca.paa";
	};

	class gold : Default {
		variable = "gold";
		displayName = "STR_Item_GoldC";
		weight = 3;
		sellPrice = 1850;
		icon = "SG_Core\images\icons\diamond_ca.paa";
		marketIndex = 1;
	};

	class gold_final : Default {
		variable = "gold_final";
		displayName = "STR_Item_GoldCFinal";
		weight = 3;
		sellPrice = 2715;
		icon = "SG_Core\images\icons\diamond_ca.paa";
		marketIndex = 1;
	};

	class silverOre : Default {
		variable = "silverOre";
		displayName = "STR_Item_SilverU";
		weight = 3;
		sellPrice = 200;
		icon = "SG_Core\images\icons\coalOre_ca.paa";
	};

	class silver : Default {
		variable = "silver";
		displayName = "STR_Item_SilverC";
		weight = 2;
		sellPrice = 1245;
		icon = "SG_Core\images\icons\coal_ca.paa";
		marketIndex = 1;
	};

	class silver_final : Default {
		variable = "silver_final";
		displayName = "STR_Item_SilverCFinal";
		weight = 2;
		sellPrice = 1850;
		icon = "SG_Core\images\icons\coal_ca.paa";
		marketIndex = 1;
	};

	class ironOre : Default {
		variable = "ironOre";
		displayName = "STR_Item_IronOre";
		weight = 3;
		sellPrice = 200;
		icon = "SG_Core\images\icons\coalOre_ca.paa";
	};

	class iron : Default {
		variable = "iron";
		displayName = "STR_Item_IronIngot";
		weight = 2;
		sellPrice = 1250;
		icon = "SG_Core\images\icons\coal_ca.paa";
		marketIndex = 1;
	};

	class iron_final : Default {
		variable = "iron_final";
		displayName = "STR_Item_IronIngotFinal";
		weight = 2;
		sellPrice = 1485;
		icon = "SG_Core\images\icons\coal_ca.paa";
		marketIndex = 1;
	};

	class copperOre : Default {
		variable = "copperOre";
		displayName = "STR_Item_CopperOre";
		weight = 3;
		sellPrice = 125;
		icon = "SG_Core\images\icons\coalOre_ca.paa";
	};

	class copper : Default {
		variable = "copper";
		displayName = "STR_Item_CopperIngot";
		weight = 2;
		sellPrice = 650;
		icon = "SG_Core\images\icons\coal_ca.paa";
		marketIndex = 1;
	};

	class copper_final : Default {
		variable = "copper_final";
		displayName = "STR_Item_CopperIngotFinal";
		weight = 2;
		sellPrice = 1025;
		icon = "SG_Core\images\icons\coal_ca.paa";
		marketIndex = 1;
	};

	class coalOre : Default {
		variable = "coalOre";
		displayName = "STR_Item_CoalOre";
		weight = 3;
		sellPrice = 200;
		icon = "SG_Core\images\icons\coalOre_ca.paa";
	};

	class coal : Default {
		variable = "coal";
		displayName = "STR_Item_Coal";
		weight = 2;
		sellPrice = 700;
		icon = "SG_Core\images\icons\coal_ca.paa";
		marketIndex = 1;
	};

	class coal_final : Default {
		variable = "coal_final";
		displayName = "STR_Item_CoalFinal";
		weight = 2;
		sellPrice = 900;
		icon = "SG_Core\images\icons\coal_ca.paa";
		marketIndex = 1;
	};

	class rock : Default {
		variable = "rock";
		displayName = "STR_Item_Rock";
		weight = 6;
		icon = "SG_Core\images\icons\rock_ca.paa";
	};

	class cement : Default {
		variable = "cement";
		displayName = "STR_Item_CementBag";
		weight = 5;
		sellPrice = 945;
		icon = "SG_Core\images\icons\cement_ca.paa";
	};

	//ILLEGAL
	class uraniumU : Default {
		variable = "uraniumU";
		displayName = "STR_Item_uraniumU";
		weight = 7;
		illegal = true;
		icon = "SG_Core\images\icons\uraniumU_ca.paa";
	};

	class uranium : Default {
		variable = "uranium";
		displayName = "STR_Item_uranium";
		weight = 6;
		sellPrice = 6954;
		illegal = true;
		icon = "SG_Core\images\icons\uranium_ca.paa";
		marketIndex = 1;
	};

	class toad : Default {
		variable = "toad";
		displayName = "STR_Item_Toad";
		weight = 5;
		illegal = true;
		icon = "SG_Core\images\icons\toad.paa";
	};

	class acid : Default {
		variable = "acid";
		displayName = "STR_Item_acid";
		weight = 4;
		buyPrice = -1;
		sellPrice = 2991;
		illegal = true;
		icon = "SG_Core\images\icons\lsd_ca.paa";
		marketIndex = 1;
	};

	class DMT : Default {
		variable = "DMT";
		displayName = "STR_Item_DMT";
		weight = 4;
		buyPrice = -1;
		sellPrice = 3578;
		illegal = true;
		icon = "SG_Core\images\icons\dmt.paa";
		marketIndex = 1;
	};

	/* Fish */
	class salema_raw : Default {
		variable = "salemaRaw";
		displayName = "STR_Item_SalemaRaw";
		weight = 2;
		sellPrice = 450;
		icon = "SG_Core\images\icons\fish.paa";
	};

	class salema : Default {
		variable = "salema";
		displayName = "STR_Item_Salema";
		buyPrice = 7;
		sellPrice = 5;
		edible = 30;
		icon = "SG_Core\images\icons\fish_cooked.paa";
	};

	class ornate_raw : Default {
		variable = "ornateRaw";
		displayName = "STR_Item_OrnateRaw";
		weight = 2;
		sellPrice = 550;
		icon = "SG_Core\images\icons\fish.paa";
	};

	class ornate : Default {
		variable = "ornate";
		displayName = "STR_Item_Ornate";
		buyPrice = 15;
		sellPrice = 10;
		edible = 25;
		icon = "SG_Core\images\icons\fish_cooked.paa";
	};

	class mackerel_raw : Default {
		variable = "mackerelRaw";
		displayName = "STR_Item_MackerelRaw";
		weight = 4;
		sellPrice = 750;
		icon = "SG_Core\images\icons\fish.paa";
	};

	class mackerel : Default {
		variable = "mackerel";
		displayName = "STR_Item_Mackerel";
		weight = 2;
		buyPrice = 25;
		sellPrice = 20;
		edible = 30;
		icon = "SG_Core\images\icons\fish_cooked.paa";
	};

	class tuna_raw : Default {
		variable = "tunaRaw";
		displayName = "STR_Item_TunaRaw";
		weight = 6;
		sellPrice = 975;
		icon = "SG_Core\images\icons\fish.paa";
	};

	class tuna : Default {
		variable = "tuna";
		displayName = "STR_Item_Tuna";
		weight = 3;
		buyPrice = 120;
		sellPrice = 100;
		edible = 100;
		icon = "SG_Core\images\icons\fish_cooked.paa";
	};

	class mullet_raw : Default {
		variable = "mulletRaw";
		displayName = "STR_Item_MulletRaw";
		weight = 4;
		sellPrice = 1000;
		icon = "SG_Core\images\icons\fish.paa";
	};

	class mullet : Default {
		variable = "mullet";
		displayName = "STR_Item_Mullet";
		weight = 2;
		buyPrice = 60;
		sellPrice = 40;
		edible = 80;
		icon = "SG_Core\images\icons\fish_cooked.paa";
	};

	class catshark_raw : Default {
		variable = "catsharkRaw";
		displayName = "STR_Item_CatSharkRaw";
		weight = 6;
		sellPrice = 1100;
		icon = "SG_Core\images\icons\fish.paa";
	};

	class catshark : Default {
		variable = "catshark";
		displayName = "STR_Item_CatShark";
		weight = 3;
		buyPrice = 75;
		sellPrice = 50;
		edible = 100;
		icon = "SG_Core\images\icons\fish_cooked.paa";
	};

	class turtle_raw : Default {
		variable = "turtleRaw";
		displayName = "STR_Item_TurtleRaw";
		weight = 10;
		sellPrice = 5300;
		illegal = true;
		icon = "SG_Core\images\icons\turtle.paa";
	};

	class turtle_soup : Default {
		variable = "turtleSoup";
		displayName = "STR_Item_TurtleSoup";
		weight = 2;
		buyPrice = 100;
		sellPrice = 75;
		illegal = true;
		edible = 100;
		icon = "SG_Core\images\icons\soup.paa";
	};

	/* Burglary */
	class lockpick : Default {
		variable = "lockpick";
		displayName = "STR_Item_Lockpick";
		weight = 4;
		buyPrice = 700;
		sellPrice = 200;
		illegal = false;
		icon = "SG_Core\images\icons\lockpick_ca.paa";
	};
	class crowbar : Default {
		variable = "crowbar";
		displayName = "STR_Item_crowbar";
		weight = 5;
		buyPrice = 2600;
		sellPrice = 450;
		illegal = false;
		icon = "SG_Core\images\icons\crowbar_ca.paa";
	};
	class gloves : Default {
		variable = "gloves";
		displayName = "STR_Item_gloves";
		buyPrice = 80;
		sellPrice = 40;
		icon = "SG_Core\images\icons\gloves.paa";
	};

	/* Burglary Loot */
	class rubyJewelery : Default {
		variable = "rubyJewelery";
		displayName = "STR_Item_rubyJewelery";
		weight = 2;
		sellPrice = 11500;
		illegal = true;
		icon = "SG_Core\images\icons\rubyJewelery_ca.paa";
	};
	class diamondJewelery : Default {
		variable = "diamondJewelery";
		displayName = "STR_Item_diamondJewelery";
		weight = 2;
		sellPrice = 16000;
		illegal = true;
		icon = "SG_Core\images\icons\diamondJewelery_ca.paa";
	};
	class sapphireJewelery : Default {
		variable = "sapphireJewelery";
		displayName = "STR_Item_sapphireJewelery";
		weight = 2;
		sellPrice = 8000;
		illegal = true;
		icon = "SG_Core\images\icons\sapphireJewelery_ca.paa";
	};
	class amethystJewelery : Default {
		variable = "amethystJewelery";
		displayName = "STR_Item_amethystJewelery";
		weight = 2;
		sellPrice = 9000;
		illegal = true;
		icon = "SG_Core\images\icons\amethystJewelery_ca.paa";
	};
	class antiqueCoin : Default {
		variable = "antiqueCoin";
		displayName = "STR_Item_antiqueCoin";
		weight = 3;
		sellPrice = 7500;
		illegal = true;
		icon = "SG_Core\images\icons\antiqueCoin_ca.paa";
	};
	class boxers : Default {
		variable = "boxers";
		displayName = "STR_Item_boxers";
		weight = 2;
		sellPrice = 20;
		illegal = true;
		icon = "SG_Core\images\icons\boxers_ca.paa";
	};
	class bra : Default {
		variable = "bra";
		displayName = "STR_Item_bra";
		sellPrice = 80;
		illegal = true;
		icon = "SG_Core\images\icons\bra_ca.paa";
	};
	class cards : Default {
		variable = "cards";
		displayName = "STR_Item_cards";
		weight = 2;
		sellPrice = 30;
		illegal = true;
		icon = "SG_Core\images\icons\cards_ca.paa";
	};
	class gnome : Default {
		variable = "gnome";
		displayName = "STR_Item_gnome";
		weight = 3;
		sellPrice = 5;
		illegal = true;
		icon = "SG_Core\images\icons\gnome_ca.paa";
	};
	class iphonex : Default {
		variable = "iphonex";
		displayName = "STR_Item_iphonex";
		weight = 2;
		sellPrice = 1449;
		illegal = true;
		icon = "SG_Core\images\icons\iphonex_ca.paa";
	};
	class noose : Default {
		variable = "noose";
		displayName = "STR_Item_noose";
		weight = 3;
		sellPrice = 50;
		illegal = true;
		icon = "SG_Core\images\icons\noose_ca.paa";
	};
	class monaLisa : Default {
		variable = "monaLisa";
		displayName = "STR_Item_monaLisa";
		weight = 5;
		sellPrice = 100000;
		illegal = true;
		icon = "SG_Core\images\icons\painting_ca.paa";
	};
	class fineArt : Default {
		variable = "fineArt";
		displayName = "STR_Item_fineArt";
		weight = 5;
		sellPrice = 300000;
		illegal = true;
		marketIndex = 1;
		icon = "SG_Core\images\icons\painting_ca.paa";
	};
	class panties : Default {
		variable = "panties";
		displayName = "STR_Item_panties";
		sellPrice = 100;
		illegal = true;
		icon = "SG_Core\images\icons\panties_ca.paa";
	};
	class remote : Default {
		variable = "remote";
		displayName = "STR_Item_remote";
		weight = 2;
		sellPrice = 20;
		illegal = true;
		icon = "SG_Core\images\icons\remote_ca.paa";
	};
	class samsungs9 : Default {
		variable = "samsungs9";
		displayName = "STR_Item_samsungs9";
		weight = 2;
		sellPrice = 1000;
		illegal = true;
		icon = "SG_Core\images\icons\samsung_ca.paa";
	};
	class trash : Default {
		variable = "trash";
		displayName = "STR_Item_trash";
		weight = 3;
		sellPrice = 50;
		illegal = true;
		icon = "SG_Core\images\icons\samsung_ca.paa";
	};

	//MISC
	class gpstracker : Default {
		variable = "gpstracker";
		displayName = "STR_Item_gpstracker";
		weight = 2;
		buyPrice = 400;
		sellPrice = 20;
		icon = "SG_Core\images\icons\gpstracker_ca.paa";
	};

	class enginedisable : Default {
		variable = "enginedisable";
		displayName = "STR_Item_enginedisable";
		weight = 10;
		buyPrice = 5000;
		sellPrice = 500;
		illegal = true;
		icon = "SG_Core\images\icons\enginedisable_ca.paa";
	};

	class keyCard : Default {
		variable = "keyCard";
		displayName = "STR_Item_keyCard";
		weight = 3;
		buyPrice = 1200;
		sellPrice = 500;
		icon = "SG_Core\images\icons\keyCard_ca.paa";
	};

	class boofCart : Default {
		variable = "boofCart";
		displayName = "STR_Item_BoofCart";
		buyPrice = 150;
		illegal = true;
		icon = "";
	};

	class pdrill : Default {
		variable = "pdrill";
		displayName = "STR_Item_drill";
		weight = 6;
		buyPrice = 900;
		icon = "SG_Core\images\icons\pdrill_ca.paa";
	};

	class redgull : Default {
		variable = "redgull";
		displayName = "STR_Item_RedGull";
		buyPrice = 500;
		sellPrice = 5;
		edible = 65;
		icon = "SG_Core\images\icons\redgull_ca.paa";
	};

	class coffee : Default {
		variable = "coffee";
		displayName = "STR_Item_Coffee";
		buyPrice = 10;
		sellPrice = 5;
		edible = 100;
		icon = "SG_Core\images\icons\coffee_ca.paa";
	};

	class waterBottle : Default {
		variable = "waterBottle";
		displayName = "STR_Item_WaterBottle";
		buyPrice = 10;
		sellPrice = 5;
		edible = 65;
		icon = "SG_Core\images\icons\waterBottle_ca.paa";
	};
	class apple : Default {
		variable = "apple";
		displayName = "STR_Item_Apple";
		buyPrice = 6;
		sellPrice = 5;
		edible = 10;
		icon = "SG_Core\images\icons\apple_ca.paa";
	};

	class peach : Default {
		variable = "peach";
		displayName = "STR_Item_Peach";
		buyPrice = 15;
		sellPrice = 5;
		edible = 10;
		icon = "SG_Core\images\icons\peach_ca.paa";
	};

	class tbacon : Default {
		variable = "tbacon";
		displayName = "STR_Item_TBacon";
		buyPrice = 7;
		sellPrice = 2;
		edible = 40;
		icon = "SG_Core\images\icons\tbacon_ca.paa";
	};

	class donuts : Default {
		variable = "donuts";
		displayName = "STR_Item_Donuts";
		buyPrice = 12;
		sellPrice = 6;
		edible = 30;
		icon = "SG_Core\images\icons\donuts_ca.paa";
	};

	class doritos : Default {
		variable = "doritos";
		displayName = "STR_Doritos";
		buyPrice = 10;
		sellPrice = 4;
		edible = 30;
		icon = "SG_Core\images\icons\doritos_ca.paa";
	};

	class pepsi : Default {
		variable = "pepsi";
		displayName = "STR_Pepsi";
		buyPrice = 5;
		sellPrice = 3;
		edible = 50;
		icon = "SG_Core\images\icons\pepsi_ca.paa";
	};

	class monsterEnergy : Default {
		variable = "monsterEnergy";
		displayName = "STR_MonsterEnergy";
		buyPrice = 10;
		sellPrice = 5;
		edible = 60;
		icon = "SG_Core\images\icons\monsterEnergy_ca.paa";
	};

	class kfc : Default {
		variable = "kfc";
		displayName = "STR_KFC";
		buyPrice = 7;
		sellPrice = 3;
		edible = 70;
		icon = "SG_Core\images\icons\kfc_ca.paa";
	};

	class zipties : Default {
		variable = "zipties";
		displayName = "STR_Item_ZipTies";
		weight = 5;
		buyPrice = 600;
		sellPrice = 100;
		illegal = true;
		icon = "SG_Core\images\icons\zipties_ca.paa";
	};

	class shank : Default {
		variable = "shank";
		displayName = "STR_Item_Shank";
		weight = 10;
		buyPrice = 6000;
		sellPrice = 1000;
		illegal = true;
		icon = "SG_Core\images\icons\shank_ca.paa";
	};

	class scalpel : Default {
		variable = "scalpel";
		displayName = "STR_Item_Scalpel";
		weight = 5;
		buyPrice = 4000;
		sellPrice = 450;
		illegal = false;
		icon = "SG_Core\images\icons\shank_ca.paa";
	};

	class blindfold : Default {
		variable = "blindfold";
		displayName = "STR_Item_Blindfold";
		weight = 0;
		buyPrice = 60;
		sellPrice = 20;
		illegal = true;
		icon = "SG_Core\images\icons\blindfold_ca.paa";
	};

	class panicbutton : Default {
		variable = "panicbutton";
		displayName = "STR_Item_panicbutton";
		weight = 2;
		buyPrice = 50;
		sellPrice = 5;
		icon = "SG_Core\images\icons\panicbutton_ca.paa";
	};

	class cprKit : Default {
		variable = "cprKit";
		displayName = "STR_Item_CPRMediKit";
		weight = 5;
		buyPrice = 5000;
		sellPrice = 250;
		icon = "SG_Core\images\icons\cprKit_ca.paa";
	};

	//Medical Things
	class bandage : Default {
		variable = "bandage";
		displayName = "STR_Item_Bandage";
		weight = 2;
		buyPrice = 150;
		sellPrice = 25;
		icon = "SG_Core\images\icons\bandage_ca.paa";
	};

	class alcoholwipe : Default {
		variable = "alcoholwipe";
		displayName = "STR_Item_AlcoholWipe";
		weight = 1;
		buyPrice = 10;
		sellPrice = 2;
		icon = "SG_Core\images\icons\alcoholwipe_ca.paa";
	};

	class bloodbag : Default {
		variable = "bloodbag";
		displayName = "STR_Item_Bloodbag";
		weight = 1;
		buyPrice = 50;
		sellPrice = 5;
		icon = "SG_Core\images\icons\bloodbag_ca.paa";
	};

	class splint : Default {
		variable = "splint";
		displayName = "STR_Item_Splint";
		weight = 1;
		buyPrice = 25;
		sellPrice = 5;
		icon = "SG_Core\images\icons\splint_ca.paa";
	};

	class morphine : Default {
		variable = "morphine";
		displayName = "STR_Item_Morphine";
		weight = 1;
		buyPrice = 25;
		sellPrice = 5;
		icon = "SG_Core\images\icons\morphine_ca.paa";
	};

	class defib : Default {
		variable = "defib";
		displayName = "STR_Item_Defib";
		weight = 5;
		buyPrice = 2500;
		sellPrice = 50;
		icon = "SG_Core\images\icons\defib_ca.paa";
	};

	class stabilizer : Default {
		variable = "stabilizer";
		displayName = "STR_Item_Stabilizer";
		weight = 3;
		buyPrice = 1500;
		sellPrice = 50;
		icon = "SG_Core\images\icons\bloodbag_ca.paa";
	};

	//Misc Items
	class hardenedpickaxe : Default {
		variable = "hardenedpickaxe";
		displayName = "STR_Item_Pickaxe";
		weight = 2;
		buyPrice = 250;
		sellPrice = 55;
		icon = "SG_Core\images\icons\pickaxe_ca.paa";
	};

	class toolkit : Default {
		variable = "toolkit";
		displayName = "STR_Item_Toolkit";
		weight = 4;
		buyPrice = 35;
		sellPrice = 10;
		icon = "SG_Core\images\icons\toolkit_ca.paa";
	};

	class fuelEmpty : Default {
		variable = "fuelEmpty";
		displayName = "STR_Item_FuelE";
		weight = 2;
		buyPrice = 500;
		sellPrice = 10;
		icon = "SG_Core\images\icons\fuelcan_ca.paa";
	};
	class fuelFull : Default {
		variable = "fuelFull";
		displayName = "STR_Item_FuelF";
		weight = 10;
		icon = "SG_Core\images\icons\fuelcan_ca.paa";
	};

	class spikeStrip : Default {
		variable = "spikeStrip";
		displayName = "STR_Item_SpikeStrip";
		weight = 15;
		buyPrice = 250;
		sellPrice = 100;
		icon = "SG_Core\images\icons\spikeStrip_ca.paa";
	};

	class blastingcharge : Default {
		variable = "blastingCharge";
		displayName = "STR_Item_BCharge";
		weight = 15;
		buyPrice = 86000;
		illegal = true;
		icon = "SG_Core\images\icons\c4_ca.paa";
	};

	class borderCharge : Default {
		variable = "borderCharge";
		displayName = "STR_Item_borderCharge";
		weight = 10;
		buyPrice = 45000;
		illegal = true;
		icon = "SG_Core\images\icons\c4_ca.paa";
	};

	class poweroverrider : Default {
		variable = "poweroverrider";
		displayName = "STR_Item_poweroverrider";
		weight = 15;
		buyPrice = 45000;
		illegal = true;
		icon = "SG_Core\images\icons\poweroverrider_ca.paa";
	};

	class boltcutter : Default {
		variable = "boltCutter";
		displayName = "STR_Item_BCutter";
		weight = 5;
		buyPrice = 4500;
		sellPrice = 100;
		illegal = true;
		icon = "SG_Core\images\icons\boltcutter_ca.paa";
	};

	class defusekit : Default {
		variable = "defuseKit";
		displayName = "STR_Item_DefuseKit";
		weight = 2;
		buyPrice = 250;
		sellPrice = 200;
		illegal = true;
		icon = "SG_Core\images\icons\defusekit_ca.paa";
	};

	class storagesmall : Default {
		variable = "storageSmall";
		displayName = "STR_Item_StorageBS";
		weight = 5;
		buyPrice = 15250;
		sellPrice = 550;
		varPrice = 1;
		maxPrice = 15500;
		minPrice = 15500;
		factor = 0;
		icon = "SG_Core\images\icons\storagesmall_ca.paa";
	};

	class storagebig : Default {
		variable = "storageBig";
		displayName = "STR_Item_StorageBL";
		weight = 10;
		buyPrice = 46500;
		sellPrice = 1370;
		varPrice = 1;
		maxPrice = 13700;
		minPrice = 13705;
		factor = 0;
		icon = "SG_Core\images\icons\storagebig_ca.paa";
	};

	// Fortifications
	
	class roadBarrierStriped : Default {
        variable = "roadBarrierStriped";
        displayName = "STR_Item_CNCBARS";
        weight = 5;
        buyPrice = 142;
        sellPrice = 70;
        illegal = false;
        icon = "";
    };

    class barGate : Default {
        variable = "barGate";
        displayName = "STR_Item_BARGATE";
        weight = 10;
        buyPrice = 2840;
        sellPrice = 142;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class plasticRoadBarrier : Default {
        variable = "plasticRoadBarrier";
        displayName = "STR_Item_PRBARRIER";
        weight = 2;
        buyPrice = 84;
        sellPrice = 42;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class roadCone : Default {
        variable = "roadCone";
        displayName = "STR_Item_RCONE";
        weight = 1;
        buyPrice = 28;
        sellPrice = 14;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class hBarrierC : Default { //Land_HBarrier_1_F
        variable = "hBarrierC";
        displayName = "STR_Item_HBARRIER1";
        weight = 5;
        buyPrice = 284;
        sellPrice = 142;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class hBarrierS : Default { //Land_HBarrier_3_F
        variable = "hBarrierS";
        displayName = "STR_Item_HBARRIER3";
        weight = 5;
        buyPrice = 428;
        sellPrice = 214;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class razorWire : Default { //Land_Razorwire_F
        variable = "razorWire";
        displayName = "STR_Item_RAZORWIRE";
        weight = 4;
        buyPrice = 342;
        sellPrice = 170;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class bunkerS : Default { //Land_fortified_nest_small_EP1
        variable = "bunkerS";
        displayName = "STR_Item_BUNKERS";
        weight = 20;
        buyPrice = 14560;
        sellPrice = 2280;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class camoNetEASTD : Default { //Land_CamoNet_EAST_EP1
        variable = "camoNetEASTD";
        displayName = "STR_Item_CAMMONET";
        weight = 10;
        buyPrice = 428;
        sellPrice = 214;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class camoNetEASTDO : Default { //Land_CamoNetVar_EAST_EP1
        variable = "camoNetEASTDO";
        displayName = "STR_Item_CAMMONETO";
        weight = 10;
        buyPrice = 428;
        sellPrice = 214;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class camoNetNATOD : Default { //Land_CamoNet_NATO_EP1
        variable = "camoNetNATOD";
        displayName = "STR_Item_CAMMONET";
        weight = 10;
        buyPrice = 428;
        sellPrice = 214;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class camoNetNATODO : Default { //Land_CamoNetVar_NATO_EP1
        variable = "camoNetNATODO";
        displayName = "STR_Item_CAMMONETO";
        weight = 10;
        buyPrice = 428;
        sellPrice = 214;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class sandBagL : Default { //Land_BagFence_Long_F
        variable = "sandBagL";
        displayName = "STR_Item_BUNKERL";
        weight = 5;
        buyPrice = 428;
        sellPrice = 214;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class sandBagS : Default { //Land_BagFence_Short_F
        variable = "sandBagS";
        displayName = "STR_Item_WALLBAGS";
        weight = 4;
        buyPrice = 228;
        sellPrice = 114;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class sandBagC : Default { //Land_BagFence_Corner_F
        variable = "sandBagC";
        displayName = "STR_Item_BUNKERC";
        weight = 2;
        buyPrice = 228;
        sellPrice = 114;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class sandBagR : Default { //Land_BagFence_Round_F
        variable = "sandBagR";
        displayName = "STR_Item_BUNKERR";
        weight = 5;
        buyPrice = 228;
        sellPrice = 114;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class pRoadBarrier : Default {
        variable = "pRoadBarrier";
        displayName = "STR_Item_WBARRIER";
        weight = 5;
        buyPrice = 84;
        sellPrice = 21;
        illegal = false;
        edible = -1;
        icon = "";
    };

    class sRoadBarrier : Default {
        variable = "sRoadBarrier";
        displayName = "STR_Item_SWBARRIER";
        weight = 2;
        buyPrice = 84;
        sellPrice = 44;
        illegal = false;
        edible = -1;
        icon = "";
    };

	// Quest Items

	class relic1 : Default {
		variable = "relic1";
		displayName = "STR_Item_relic1";
		weight = 3;
		icon = "SG_Core\images\icons\relic_ca.paa";
	};
	class relic2 : Default {
		variable = "relic2";
		displayName = "STR_Item_relic2";
		weight = 3;
		icon = "SG_Core\images\icons\relic_ca.paa";
	};
	class relic3 : Default {
		variable = "relic3";
		displayName = "STR_Item_relic3";
		weight = 3;
		icon = "SG_Core\images\icons\relic_ca.paa";
	};
	class relic4 : Default {
		variable = "relic4";
		displayName = "STR_Item_relic4";
		weight = 3;
		icon = "SG_Core\images\icons\relic_ca.paa";
	};

	class map1 : Default {
		variable = "map1";
		displayName = "STR_Item_map1";
		weight = 3;
		icon = "SG_Core\images\icons\cement_ca.paa";
	};

	class map2 : Default {
		variable = "map2";
		displayName = "STR_Item_map2";
		weight = 3;
		icon = "SG_Core\images\icons\cement_ca.paa";
	};

	class map3 : Default {
		variable = "map3";
		displayName = "STR_Item_map3";
		weight = 3;
		icon = "SG_Core\images\icons\cement_ca.paa";
	};

	class relicFed : Default {
		variable = "relicFed";
		displayName = "STR_Item_relicFed";
		weight = 3;
		illegal = true;
		icon = "SG_Core\images\icons\relicFed_ca.paa";
	};
	class relicBank : Default {
		variable = "relicBank";
		displayName = "STR_Item_relicBank";
		weight = 3;
		illegal = true;
		icon = "SG_Core\images\icons\relicFed_ca.paa";
	};
	class relicCasino : Default {
		variable = "relicCasino";
		displayName = "STR_Item_relicCasino";
		weight = 3;
		illegal = true;
		icon = "SG_Core\images\icons\relicFed_ca.paa";
	};
	class antiMatter : Default {
		variable = "antiMatter";
		displayName = "STR_Item_antiMatter";
		weight = 3;
		illegal = true;
		icon = "SG_Core\images\icons\satellite_ca.paa";
	};

	class unknown : Default {
		variable = "unknown";
		displayName = "STR_Item_unknown";
		weight = 7;
		sellPrice = 3000;
		illegal = true;
		icon = "SG_Core\images\icons\unknown_ca.paa";
	};

	class oilSupplies : Default {
		variable = "oilSupplies";
		displayName = "STR_Item_oilSupplies";
		weight = 20;
		sellPrice = 9500;
		illegal = true;
		icon = "SG_Core\images\icons\oil_processed_ca.paa";
	};

	class excavator : Default {
		variable = "excavator";
		displayName = "STR_Item_excavator";
		weight = 10;
		buyPrice = 1400;
		illegal = true;
		icon = "SG_Core\images\icons\excavator_ca.paa";
	};

	class doorc4 : Default {
		variable = "doorc4";
		displayName = "STR_Item_doorc4";
		weight = 10;
		buyPrice = 5000;
		icon = "SG_Core\images\icons\c4_ca.paa";
	};

	class speedBomb : Default {
		variable = "speedBomb";
		displayName = "STR_Item_speedBomb";
		weight = 10;
		buyPrice = 225000;
		icon = "SG_Core\images\icons\c4_ca.paa";
	};

	class boltLocker : Default {
		variable = "boltLocker";
		displayName = "STR_Item_boltLocker";
		weight = 10;
		buyPrice = 5000;
		icon = "SG_Core\images\icons\boltLocker_ca.paa";
	};

	class narcan : Default {
		variable = "narcan";
		displayName = "STR_Item_narcan";
		weight = 1;
		buyPrice = 75;
		icon = "SG_Core\images\icons\cprKit_ca.paa";
	};

	class drugtestkit : Default {
		variable = "drugtestkit";
		displayName = "STR_Item_drugtestkit";
		weight = 2;
		buyPrice = 75;
		icon = "SG_Core\images\icons\testKit.paa";
	};

	class gsrTest : Default {
		variable = "gsrTest";
		displayName = "STR_Item_GSR";
		weight = 2;
		buyPrice = 75;
		icon = "SG_Core\images\icons\testKit.paa";
	};

	class policeBarricade : Default {
		variable = "policeBarricade";
		displayName = "STR_Item_policeBarricade";
		weight = 20;
		buyPrice = 20000;
		icon = "SG_Core\images\icons\policeBarricade_ca.paa";
	};

	class civilianBarricade : Default {
		variable = "civilianBarricade";
		displayName = "STR_Item_civilianBarricade";
		weight = 20;
		buyPrice = 20000;
		illegal = true;
		icon = "SG_Core\images\icons\policeBarricade_ca.paa";
	};

	class seatEjector : Default {
		variable = "seatEjector";
		displayName = "STR_Item_seatEjector";
		weight = 10;
		buyPrice = 35000;
		icon = "SG_Core\images\icons\seatEjector_ca.paa";
	};

	class codeCracker : Default {
		variable = "codeCracker";
		displayName = "STR_Item_codeCracker";
		weight = 10;
		buyPrice = 27500;
		illegal = true;
		icon = "SG_Core\images\icons\codeCracker_ca.paa";
	};

	class c4Charge : Default {
		variable = "c4Charge";
		displayName = "STR_Item_c4Charge";
		weight = 10;
		buyPrice = 5500;
		illegal = true;
		icon = "SG_Core\images\icons\c4_ca.paa";
	};

	class injectionHack : Default {
		variable = "injectionHack";
		displayName = "STR_Item_injectionHack";
		weight = 5;
		buyPrice = 15000;
		illegal = true;
		icon = "SG_Core\images\icons\remote_ca.paa";
	};

	class encryptedIntel : Default {
		variable = "encryptedIntel";
		displayName = "STR_Item_encryptedIntel";
		weight = 5;
		sellPrice = 275000;
		illegal = true;
		marketIndex = 1;
		icon = "SG_Core\images\icons\injectionHack_ca.paa";
	};

	class decryptedIntel : Default {
		variable = "decryptedIntel";
		displayName = "STR_Item_decryptedIntel";
		weight = 5;
		sellPrice = 350000;
		illegal = true;
		marketIndex = 1;
		icon = "SG_Core\images\icons\injectionHack_ca.paa";
	};

	class moneyBagEmpty : Default {
		variable = "moneyBagEmpty";
		displayName = "STR_Item_moneyBagEmpty";
		weight = 10;
		buyPrice = 1500;
		icon = "SG_Core\images\icons\moneyBag_ca.paa";
	};

	class bankDrill : Default {
		variable = "bankDrill";
		displayName = "STR_Item_bankDrill";
		weight = 5;
		buyPrice = 45000;
		illegal = true;
		icon = "SG_Core\images\icons\bankDrill_ca.paa";
	};

	class debitCard : Default {
		variable = "debitCard";
		displayName = "STR_Item_debitCard";
		weight = 1;
		buyPrice = 1500;
		toolTip = "By having this item in your inventory if you cannot afford an item it will use your bank balance instead. This comes with a tax of 20% though.";
		icon = "SG_Core\images\icons\debit.paa";
	};

	class scratchOff : Default {
		variable = "scratchOff";
		displayName = "STR_Item_scratchOff";
		weight = 1;
		buyPrice = 7500;
		icon = "SG_Core\images\icons\scratchOff.paa";
	};

	class markedMoney : Default {
		variable = "markedMoney";
		displayName = "STR_Item_markedMoney";
		weight = 12;
		sellPrice = 95000;
		illegal = true;
		icon = "SG_Core\images\icons\markedmoney_ca.paa";
	};

	class casinoChip : Default {
		variable = "casinoChip";
		displayName = "STR_Item_casinoChip";
		weight = 3;
		sellPrice = 45000;
		illegal = true;
		marketIndex = 1;
		icon = "SG_Core\images\icons\pokerChip.paa";
	};

	class goldBar : Default {
		variable = "goldBar";
		displayName = "STR_Item_goldBar";
		weight = 8;
		sellPrice = 182000;
		illegal = true;
		marketIndex = 1;
		icon = "SG_Core\images\icons\ironOre_-ca.paa";
	};

	class vaultDrill : Default {
		variable = "vaultDrill";
		displayName = "STR_Item_vaultDrill";
		weight = 10;
		buyPrice = 95000;
		illegal = true;
		icon = "SG_Core\images\icons\pdrill_ca.paa";
	};

	class generator : Default {
		variable = "generator";
		displayName = "STR_Item_generator";
		weight = 8;
		buyPrice = 40000;
		icon = "SG_Core\images\icons\toolkit_ca.paa";
	};
};