class CfgWebsite {
	display = "SG_WebMaster";
	class travelntransport {
		domain = "com";
		title = "Travel'N Transport Dealers";
		control = "webpage_vehicleshop_travelntransport";
		function = "SG_Web_TravelnTransport";
	};
	class southmetroautos {
		domain = "com";
		title = "South Metro Autos";
		control = "webpage_vehicleshop";
		function = "SG_Web_VehicleShop_onLoad";
		shop = "civ_car";
		image = "";
		description = "This is the website description, you can write anything here!";
		class purchase {
			title = "South Metro Autos - Purchase";
			control = "webpage_vehicleshop_purchase";
			function = "SG_Web_VehicleShop_Purchase";
		};
	};
	class luxurymotorsports {
		domain = "com";
		title = "Luxury Motorsports";
		control = "webpage_vehicleshop";
		function = "SG_Web_VehicleShop_onLoad";
		shop = "civ_car_sports";
		image = "";
		description = "This is the website description, you can write anything here!";
		class purchase {
			title = "Luxury Motorsports - Purchase";
			control = "webpage_vehicleshop_purchase";
			function = "SG_Web_VehicleShop_Purchase";
		};
	};
	class newmetrotrucks {
		domain = "com";
		title = "New Metro Trucks";
		control = "webpage_vehicleshop";
		function = "SG_Web_VehicleShop_onLoad";
		shop = "civ_truck";
		image = "";
		description = "This is the website description, you can write anything here!";
		class purchase {
			title = "New Metro Trucks - Purchase";
			control = "webpage_vehicleshop_purchase";
			function = "SG_Web_VehicleShop_Purchase";
		};
	};
	class metrotravels {
		domain = "com";
		title = "Metro Travels";
		control = "webpage_vehicleshop";
		function = "SG_Web_VehicleShop_onLoad";
		shop = "civ_air";
		image = "";
		description = "This is the website description, you can write anything here!";
		class purchase {
			title = "Metro Travels - Purchase";
			control = "webpage_vehicleshop_purchase";
			function = "SG_Web_VehicleShop_Purchase";
		};
	};
	class domain {
		domain = "list";
		title = "Domain List";
		control = "webpage_directory";
		function = "SG_Web_Directory_onLoad";
	};
	class example {
		domain = "error";
		title = "example.error";
		icon = "\SG_Core\images\websites\error\SG_icon_error_200_ca.paa";
		control = "";
		condition = "true";
		redirect = "";
		force_error = "200";
	};
};