class DailyRewards {

	class Day_0 {
		daysNeeded = 0;
		expReward = "";
		moneyReward = 5000;
	};
	class Day_1 {
		daysNeeded = 1;
		expReward = "dailyRewardSmall";
		moneyReward = 5000;
	};
	class Day_2 {
		daysNeeded = 2;
		expReward = "dailyRewardSmall";
		moneyReward = 5000;
	};
	class Day_3 {
		daysNeeded = 3;
		expReward = "dailyRewardSmall";
		moneyReward = 5000;
	};
	class Day_4 {
		daysNeeded = 4;
		expReward = "dailyRewardSmall";
		moneyReward = 5000;
	};
	class Day_5 {
		daysNeeded = 5;
		expReward = "dailyRewardSmall";
		moneyReward = 5000;
	};
	class Day_6 {
		daysNeeded = 6;
		expReward = "dailyRewardSmall";
		moneyReward = 5000;
	};
	class Day_7 {
		daysNeeded = 7;
		expReward = "dailyRewardSmall";
		moneyReward = 5000;
	};
	class Day_8 {
		daysNeeded = 8;
		expReward = "dailyRewardSmall";
		moneyReward = 5000;
	};
	class Day_9 {
		daysNeeded = 9;
		expReward = "dailyRewardSmall";
		moneyReward = 5000;
	};
	class Day_10 {
		daysNeeded = 10;
		expReward = "dailyRewardMedium";
		moneyReward = 10000;
	};
	class Day_11 {
		daysNeeded = 11;
		expReward = "dailyRewardMedium";
		moneyReward = 10000;
	};
	class Day_12 {
		daysNeeded = 12;
		expReward = "dailyRewardMedium";
		moneyReward = 10000;
	};
	class Day_13 {
		daysNeeded = 13;
		expReward = "dailyRewardMedium";
		moneyReward = 10000;
	};
	class Day_14 {
		daysNeeded = 14;
		expReward = "dailyRewardMedium";
		moneyReward = 10000;
	};
	class Day_15 {
		daysNeeded = 15;
		expReward = "dailyRewardMedium";
		moneyReward = 10000;
	};
	class Day_16 {
		daysNeeded = 16;
		expReward = "dailyRewardMedium";
		moneyReward = 10000;
	};
	class Day_17 {
		daysNeeded = 17;
		expReward = "dailyRewardMedium";
		moneyReward = 10000;
	};
	class Day_18 {
		daysNeeded = 18;
		expReward = "dailyRewardMedium";
		moneyReward = 10000;
	};
	class Day_19 {
		daysNeeded = 19;
		expReward = "dailyRewardMedium";
		moneyReward = 10000;
	};
	class Day_20 {
		daysNeeded = 20;
		expReward = "dailyRewardMedium";
		moneyReward = 15000;
	};
	class Day_21 {
		daysNeeded = 21;
		expReward = "dailyRewardMedium";
		moneyReward = 15000;
	};
	class Day_22 {
		daysNeeded = 22;
		expReward = "dailyRewardMedium";
		moneyReward = 15000;
	};
	class Day_23 {
		daysNeeded = 23;
		expReward = "dailyRewardMedium";
		moneyReward = 15000;
	};
	class Day_24 {
		daysNeeded = 24;
		expReward = "dailyRewardMedium";
		moneyReward = 15000;
	};
	class Day_25 {
		daysNeeded = 25;
		expReward = "dailyRewardMedium";
		moneyReward = 15000;
	};
	class Day_26 {
		daysNeeded = 26;
		expReward = "dailyRewardMedium";
		moneyReward = 15000;
	};
	class Day_27 {
		daysNeeded = 27;
		expReward = "dailyRewardMedium";
		moneyReward = 15000;
	};
	class Day_28 {
		daysNeeded = 28;
		expReward = "dailyRewardMedium";
		moneyReward = 15000;
	};
	class Day_29 {
		daysNeeded = 29;
		expReward = "dailyRewardMedium";
		moneyReward = 15000;
	};
	class Day_30 {
		daysNeeded = 30;
		expReward = "dailyRewardLarge";
		moneyReward = 30000;
	};
}