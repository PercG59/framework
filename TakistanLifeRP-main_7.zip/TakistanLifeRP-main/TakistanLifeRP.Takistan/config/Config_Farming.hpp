class Farming {
	class sassafrasSeed {
		classname = "Land_BarrelSand_grey_F";
		item = "sassafras";
		time = 300;
	};
	class cocoseed {
		classname = "Land_BarrelSand_F";
		item = "cocoleaf";
		time = 300;
	};
	class sunflowerseed {
		classname = "A3L_Sunflower";
		item = "sunflower";
		time = 300;
	};
	class wheatseed {
		classname = "A3L_Wheat";
		item = "wheat";
		time = 300;
	};
	class beanseed {
		classname = "A3L_Beans";
		item = "bean";
		time = 300;
	};
	class cottonseed {
		classname = "A3L_Cotton";
		item = "cotton";
		time = 300;
	};
	class pumpkinseed {
		classname = "A3L_Pumpkin";
		item = "pumpkin";
		time = 300;
	};
	class cornseed {
		classname = "A3L_Corn";
		item = "corn";
		time = 300;
	};
};