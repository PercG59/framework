/*
*   class:
*       MaterialsReq (Needed to process) = Array - Format -> {{"ITEM CLASS",HOWMANY}}
*       MaterialGive (Returned items) = Array - Format -> {{"ITEM CLASS",HOWMANY}}
*       Text (Progess Bar Text) = Localised String
*       NoLicenseCost (Cost to process w/o license) = Scalar
*
*   Example for multiprocess:
*
*   class Example {
*       MaterialsReq[] = {{"cocaine",1},{"heroin",1}};
*       MaterialGive[] = {{"diamond_cut",1}};
*       Text = "STR_Process_Example";
*       NoLicenseCost = 4000;
*   };
*/

class ProcessAction {
	class oil {
		MaterialsReq[] = { { "oil_unprocessed", 1 } };
		MaterialGive[] = { { "oil_processed", 1 } };
		Text = "STR_Process_Oil";
		NoLicenseCost = 1000;
	};

	class sassafras {
		MaterialsReq[] = { { "sassafras", 1 } };
		MaterialGive[] = { { "MDMA", 1 } };
		Text = "STR_Process_Sassafras";
		NoLicenseCost = 4000;
	};

	class molly {
		MaterialsReq[] = { { "MDMA", 1 } };
		MaterialGive[] = { { "molly", 1 } };
		Text = "STR_Process_MDMA";
		NoLicenseCost = 2000;
	};

	class opium {
		MaterialsReq[] = { { "opium", 1 } };
		MaterialGive[] = { { "heroin", 1 } };
		Text = "STR_Process_opium";
		NoLicenseCost = 4000;
	};

	class heroin {
		MaterialsReq[] = { { "heroin", 1 } };
		MaterialGive[] = { { "heroinPure", 1 } };
		Text = "STR_Process_heroinPure";
		NoLicenseCost = 2000;
	};

	class coal {
		MaterialsReq[] = { { "coalOre", 1 } };
		MaterialGive[] = { { "coal", 1 } };
		Text = "STR_Process_Coal";
		NoLicenseCost = 1000;
	};

	class iron {
		MaterialsReq[] = { { "ironOre", 1 } };
		MaterialGive[] = { { "iron", 1 } };
		Text = "STR_Process_Iron";
		NoLicenseCost = 1000;
	};

	class copper {
		MaterialsReq[] = { { "copperOre", 1 } };
		MaterialGive[] = { { "copper", 1 } };
		Text = "STR_Process_Copper";
		NoLicenseCost = 800;
	};
	
	class diamond {
		MaterialsReq[] = { { "diamondOre", 1 } };
		MaterialGive[] = { { "diamond", 1 } };
		Text = "STR_Process_Diamond";
		NoLicenseCost = 1000;
	};

	class ruby {
		MaterialsReq[] = { { "rubyore", 1 } };
		MaterialGive[] = { { "ruby", 1 } };
		Text = "STR_Process_Ruby";
		NoLicenseCost = 1500;
	};

	class silver {
		MaterialsReq[] = { { "silverOre", 1 } };
		MaterialGive[] = { { "silver", 1 } };
		Text = "STR_Process_Silver";
		NoLicenseCost = 1500;
	};

	class gold {
		MaterialsReq[] = { { "goldOre", 1 } };
		MaterialGive[] = { { "gold", 1 } };
		Text = "STR_Process_Gold";
		NoLicenseCost = 1500;
	};

	class emerald {
		MaterialsReq[] = { { "emeraldOre", 1 } };
		MaterialGive[] = { { "emerald", 1 } };
		Text = "STR_Process_Emerald";
		NoLicenseCost = 1500;
	};

	class sapphire {
		MaterialsReq[] = { { "sapphireOre", 1 } };
		MaterialGive[] = { { "sapphire", 1 } };
		Text = "STR_Process_Emerald";
		NoLicenseCost = 1500;
	};

	class cocaine {
		MaterialsReq[] = { { "cocoleaf", 1 } };
		MaterialGive[] = { { "cocaine", 1 } };
		Text = "STR_Process_Cocaine";
		NoLicenseCost = 4000;
	};

	class crack {
		MaterialsReq[] = { { "cocaine", 1 } };
		MaterialGive[] = { { "crack", 1 } };
		Text = "STR_Process_Crack";
		NoLicenseCost = 2000;
	};

	class marijuana {
		MaterialsReq[] = { { "cannabis", 1 } };
		MaterialGive[] = { { "marijuana", 1 } };
		Text = "STR_Process_Marijuana";
		NoLicenseCost = 2500;
	};

	class rubber {
		MaterialsReq[] = { { "rubberU", 1 } };
		MaterialGive[] = { { "rubber", 1 } };
		Text = "STR_Process_rubber";
		NoLicenseCost = 1000;
	};

	class cloth {
		MaterialsReq[] = { { "wool", 1 } };
		MaterialGive[] = { { "cloth", 1 } };
		Text = "STR_Process_cloth";
		NoLicenseCost = 1000;
	};

	class acid {
		MaterialsReq[] = { { "toad", 1 } };
		MaterialGive[] = { { "acid", 1 } };
		Text = "STR_Process_acid";
		NoLicenseCost = 3000;
	};

	class DMT {
		MaterialsReq[] = { { "acid", 1 } };
		MaterialGive[] = { { "DMT", 1 } };
		Text = "STR_Process_DMT";
		NoLicenseCost = 2000;
	};

	class uranium {
		MaterialsReq[] = { { "uraniumU", 1 } };
		MaterialGive[] = { { "uranium", 1 } };
		Text = "STR_Process_uranium";
		NoLicenseCost = 3000;
	};

	class weed {
		MaterialsReq[] = { { "hinduBud", 1 } };
		MaterialGive[] = { { "hindukush", 1 } };
		Text = "STR_Process_weed";
		NoLicenseCost = 2000;
	};

	class hash {
		MaterialsReq[] = { { "hindukush", 1 } };
		MaterialGive[] = { { "hash", 1 } };
		Text = "STR_Process_hash";
		NoLicenseCost = 2000;
	};

	class intel {
		MaterialsReq[] = { { "encryptedIntel", 1 } };
		MaterialGive[] = { { "decryptedIntel", 1 } };
		Text = "STR_Process_Intel";
		NoLicenseCost = 0;
	};
};