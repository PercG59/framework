#define true 1
#define false 0

class Apartment {
	class Takistan {
		class Land_M_Apartment {
			class Apartment_1 {
				doors[] = { "door_1" };
				rentPrice = 10000;

				containerDir[] = { -0.00385973, -0.999993, 0 };
				containerPos[] = { -2.23633, 3.67871, -9.98201 };
				spawnPos[] = {-2.10352, 1.13428, -9.98201};
				spawnDir[] = {1, 0, 0};
			};

			class Apartment_2 : Apartment_1 {
				doors[] = { "door_2" };
				containerPos[] = { -2.2417, -3.52734, -9.98201 };
				spawnPos[] = {-2.84668,-0.930664, -9.98201};
			};

			class Apartment_3 : Apartment_1 {
				doors[] = { "door_3" };
				containerPos[] = { -2.23633, 3.67871, -6.61322 };
				spawnPos[] = {-2.10352, 1.13428, -6.61322};
			};

			class Apartment_4 : Apartment_1 {
				doors[] = { "door_4" };
				containerPos[] = { -2.1958, -3.52734, -6.61322 };
				spawnPos[] = {-2.84668,-0.930664, -6.61322};
			};

			class Apartment_5 : Apartment_1 {
				doors[] = { "door_5" };
				containerPos[] = { -2.23633, 3.67871, -3.37854 };
				spawnPos[] = {-2.10352, 1.13428, -3.37854};
			};

			class Apartment_6 : Apartment_1 {
				doors[] = { "door_6" };
				containerPos[] = { -2.26367, -3.52734, -3.37854 };
				spawnPos[] = {-2.84668,-0.930664, -3.37854};
			};

			class Apartment_7 : Apartment_1 {
				doors[] = { "door_7" };
				containerPos[] = { -2.23633, 3.67871, -0.15115 };
				spawnPos[] = {-2.10352, 1.13428, -0.15115};
			};

			class Apartment_8 : Apartment_1 {
				doors[] = { "door_8" };
				containerPos[] = { -2.17871, -3.52734, -0.15115 };
				spawnPos[] = {-2.84668,-0.930664, -0.15115};
			};

			class Apartment_9 : Apartment_1 {
				doors[] = { "door_9" };
				containerPos[] = { -2.23633, 3.67871, 3.08885 };
				spawnPos[] = {-2.10352, 1.13428, 3.08885};
			};

			class Apartment_10 : Apartment_1 {
				doors[] = { "door_12" };
				containerPos[] = { -2.23096, -3.52734, 3.08885 };
				spawnPos[] = {-2.84668,-0.930664, 3.08885};
			};

			class Apartment_11 : Apartment_1 {
				doors[] = { "door_13" };
				containerPos[] = { -2.23633, 3.67871, 6.32353 };
				spawnPos[] = {-2.10352, 1.13428, 6.32353};
			};

			class Apartment_12 : Apartment_1 {
				doors[] = { "door_14" };
				containerPos[] = { -2.24658, -3.52734, 6.32353 };
				spawnPos[] = {-2.84668,-0.930664, 6.32353};
			};
		};
	};
};