class CarShops {
	class civ_car {
		conditions = "playerside isEqualTo civilian || call(life_copdept) IN ['CIA']";
		vehicles[] = {

			{ "ivory_suburban", "" }, //cop variants exist
			{ "ivory_challenger", "" }, //cop variants exist
			{ "ivory_charger", "" }, //cop variants exist
			{ "ivory_cv", "" },
			{ "ivory_taurus", "" }, //cop variants exist
			{ "CUP_C_Volha_Limo_TKCIV", "" },
			{ "CUP_C_Golf4_CR_Civ", "" },
			{ "CUP_C_Golf4_Sport_CR_Civ", "" },
			{ "CUP_I_Hilux_unarmed_TK", "" },
		    { "CUP_B_M151_HIL", "" }, //willie jeep
			{ "ivory_190e", "" },
			{ "ivory_190e_taxi", "" },
			{ "CUP_C_Pickup_unarmed_CIV", "" },
			{ "C_Quadbike_01_F", "" },
			{ "ivory_gt500", "" },
			{ "CUP_C_Skoda_CR_CIV", "" },
			{ "CUP_C_Octavia_CIV", "" },
			{ "CUP_C_S1203_CIV", "" },
			{ "CUP_C_SUV_CIV", "" },
			{ "ivory_prius", "" }, //cop variants exist
			{ "CUP_C_UAZ_Unarmed_TK_CIV", "" },
			{ "C_Van_02_vehicle_F", "" }, // multiple variants, news, etc.
			{ "C_Van_02_transport_F", "" }, // multiple variants, cop variants
			{ "CUP_C_Lada_CIV", "" },
			{ "CUP_LADA_LM_CIV", "" },
			{ "ivory_gti", "" },
			{ "CUP_C_Datsun", "" },
			{ "ivory_e36", "" }
		};
	};

	class civ_car_luxury {
		conditions = "playerside isEqualTo civilian";
		vehicles[] = {
			{ "ivory_r8", ""},
			{ "ivory_r8_spyder", "" },
			{ "ivory_rs4", "" },
			{ "ivory_rs4_taxi", "" },
			{ "ivory_c", "" },
			{ "ivory_m3", "" },
			{ "ivory_veyron", "" },
			{ "ivory_ccx", "" },
			{ "ivory_lp560", "" },
			{ "ivory_rev", "" },
			{ "ivory_isf", "" },
			{ "ivory_lfa", "" },
			{ "ivory_elise", "" },
			{ "ivory_f1", "" },
			{ "ivory_r34", "" },
			{ "ivory_evox", "" },
			{ "ivory_supra", "" },
			{ "ivory_supra_topsecret", "" },
			{ "ivory_911", "" },
			{ "ivory_mp4", "" },
			{ "ivory_wrx", "" }
		};
	};

	class civ_car_sports {
		conditions = "playerside isEqualTo civilian";
		vehicles[] = {};
	};
	class civ_truck {
		conditions = "playerside isEqualTo civilian";
		vehicles[] = {
			{ "CUP_C_Ikarus_TKC", "" },
			{ "CUP_C_Bus_City_CIV", "" },
			{ "CUP_O_V3S_Open_TKC", "" },
			{ "CUP_C_V3S_Covered_TKC", "" },
			{ "CUP_B_T810_Unarmed_CZ_WDL", "" },
			{ "CUP_C_Ural_Civ_01", "" },
			{ "CUP_C_Ural_Open_Civ_03", "" },
			{ "CUP_O_Ural_Empty_SLA", "" }
		};
	};

	class civ_air {
		conditions = "playerside isEqualTo civilian && (missionNamespace getVariable ['SG_Aviation_Training',false])";
		vehicles[] = {
            { "CUP_C_AN2_AIRTAK_TK_CIV", "life_currentExpLevel >= 8"},
            { "CUP_I_C130J_RACS", "life_currentExpLevel >= 40"},
            { "CUP_I_C130J_Cargo_RACS", "life_currentExpLevel >= 42"},
            { "CUP_C_C47_CIV", "life_currentExpLevel >= 20"},
            { "CUP_C_CESSNA_CIV", "life_currentExpLevel >= 30"},
            { "CUP_C_DC3_ChernAvia_CIV", "life_currentExpLevel >= 20"},
            { "CUP_C_412", "life_currentExpLevel >= 25"},
            { "CUP_C_412_Luxury", "life_currentExpLevel >= 30"},
            { "CUP_C_Merlin_HC3_CIV_Lux", "life_currentExpLevel >= 35"},
            { "C_Heli_Light_01_civil_F", ""},
            { "CUP_B_MI6A_CDF", "life_currentExpLevel >= 40"},
            { "CUP_C_Mi17_Civilian_RU", "life_currentExpLevel >= 51"},
			{ "C_Plane_Civil_01_racing_F", ""}
		};
	};

	class reb_air {
		conditions = "license_civ_reb || call(life_copdept) IN ['CIA']";
		vehicles[] = {
			{ "CUP_O_UH1H_TKA", "" },
			{ "CUP_O_UH1H_slick_TKA", "" },
			{ "CUP_I_412_Mil_Transport_AAF", "" }
		};
	};

	class reb_car {
		conditions = "license_civ_reb || call(life_copdept) IN ['CIA']";
		vehicles[] = {
			{ "CUP_I_BTR40_TKG", "" },
			{ "CUP_I_BTR40_MG_TKG", "" },
			{ "CUP_O_Datsun_PK_Random", "" },
			{ "CUP_O_Hilux_AGS30_TK_INS", "" },
			{ "CUP_O_Hilux_DSHKM_TK_INS", "" },
			{ "CUP_O_Hilux_armored_unarmed_TK_INS", "" },
			{ "CUP_O_Hilux_armored_DSHKM_TK_INS", "" }
		};
	};

	class adv_reb_car {
		conditions = "license_civ_AdvReb";
		vehicles[] = {
			{ "CUP_O_Hilux_zu23_TK_INS", "" },
			{ "CUP_O_Hilux_SPG9_TK_INS", "" },
			{ "CUP_O_Hilux_BMP1_TK_INS", "" },
			{ "CUP_O_Hilux_btr60_TK_INS", "" },
			{ "CUP_O_Hilux_igla_TK_INS", "" },
			{ "CUP_O_Hilux_armored_BMP1_TK_INS", "" },
			{ "CUP_I_BMP1_TK_GUE", "" },
			{ "CUP_O_BMP2_ZU_TKA", "" },
			{ "CUP_I_T34_TK_GUE", "" },
			{ "CUP_I_MTLB_pk_NAPA", "" }
		};
	};

	class adv_reb_air {
		conditions = "license_civ_AdvReb";
		vehicles[] = {
			{ "CUP_B_AC47_Spooky_USA", "" }
		};
	};

	class civ_ship {
		conditions = "playerside isEqualTo civilian";
		vehicles[] = {
			{ "C_Boat_Civil_01_F", "" },
			{ "C_Boat_Transport_02_F", "" },
			{ "C_Rubberboat", "" },
			{ "C_Scooter_Transport_01_F", "" }
		};
	};

	class med_shop {
		conditions = "playerside isEqualTo independent";
		vehicles[] = {
			{ "C_Van_02_medevac_F", "true" },
			{ "CUP_B_LR_Ambulance_CZ_W", "true" },
			{ "ivory_suburban_ems", "true" },
			{ "CUP_C_S1203_Ambulance_CIV", "call life_mediclevel >= 1" },
			{ "CUP_O_GAZ_Vodnik_MedEvac_RU", "call life_mediclevel >= 1" },
			{ "CUP_I_BMP2_AMB_UN", "call life_mediclevel >= 1" }

		};
	};

	class ems_boat {
		conditions = "playerside isEqualTo independent && call life_mediclevel >= 1";
		vehicles[] = {
			{ "B_Lifeboat", "call life_mediclevel >= 1" },
			{ "C_Boat_Civil_01_rescue_F", "call life_mediclevel >= 1" }
		};
	};

	class med_air_hs {
		conditions = "playerside isEqualTo independent && call life_mediclevel >= 1";
		vehicles[] = {
			{ "v_rc_UH60", "call life_mediclevel >= 1" },
			{ "CUP_C_412_Medic", "call life_mediclevel >= 1" },
			{ "v_rc_bird", "call life_mediclevel >= 1" }
		};
	};

	class cop_car {
		conditions = "playerside isEqualTo west";
		vehicles[] = {
			//Marked
			{ "ivory_cv_marked_classic", "call life_coplevel >= 1" },
			{ "ivory_suburban_marked_classic", "call life_coplevel >= 2" },
			{ "ivory_rs4_marked_classic", "call life_coplevel >= 3" },
			{ "ivory_m3_marked_classic", "call life_coplevel >= 3" },
			{ "ivory_charger_marked_classic", "call life_coplevel >= 3" },
			{ "CUP_B_nM1038_4s_USA_DES", "call life_coplevel >= 1" },
			{ "CUP_B_MTVR_Refuel_USA", "call life_coplevel >= 1" },
			{ "CUP_B_MTVR_Repair_USA", "call life_coplevel >= 2" },
			{ "CUP_B_MTVR_Ammo_USA", "call life_coplevel >= 3" },
			{ "CUP_B_MTVR_USA", "call life_coplevel >= 3" },
			{ "CUP_B_M1151_USA", "call life_coplevel >= 3" },
			{ "CUP_B_nM1025_M2_USA_DES", "call life_coplevel >= 3" },
			{ "CUP_B_nM1025_M240_USA_DES", "call life_coplevel >= 3" },
			{ "CUP_B_nM1025_SOV_M2_USA_DES", "call life_coplevel >= 3" },
			{ "CUP_B_M1151_M2_USA", "call life_coplevel >= 5" },
			{ "CUP_B_M1151_Deploy_USA", "call life_coplevel >= 3" },
			{ "CUP_B_HMMWV_DSHKM_GPK_ACR", "call life_coplevel >= 3" },
			{ "CUP_B_nM1097_AVENGER_USA_DES", "call life_coplevel >= 3" }, // No Missiles
			{ "CUP_B_HMMWV_Crows_M2_USA", "call life_coplevel >= 3" },
			{ "CUP_B_RG31E_M2_USMC", "call life_coplevel >= 3" },
			{ "CUP_B_AAV_Unarmed_USMC", "call life_coplevel >= 3" },
			{ "CUP_B_LAV25_HQ_USMC", "call life_coplevel >= 3" },
			{ "CUP_B_LAV25M240_USMC", "call life_coplevel >= 3" },
			{ "CUP_B_MCV80_GB_D", "call life_coplevel >= 3" }
		};
	};

	class uc_car {
		conditions = "call life_copdept in ['CIA']";
		vehicles[] = {
			//Marked
			{ "d3s_suburban_08_unm", "" },
			{ "d3s_tahoe_15_unm", "" },
			{ "d3s_escalade_16_unm", "" },
			{ "d3s_explorer_UNM_13", "" },
			{ "B_LSV_01_unarmed_F", "" },
			{ "CUP_I_LSV_02_unarmed_ION", "" },
			{ "C_Offroad_02_unarmed_F", "" },
			{ "d3s_evo_12_FQ", "" },
			{ "d3s_h2_02_Black", "" },
			{ "d3s_savana_VAN", "" }
		};
	};

	class cop_air {
		conditions = "playerside isEqualTo west && call life_coplevel >= 1";
		vehicles[] = {

			{ "CUP_B_MH6J_USA", "call life_coplevel >= 2" },

			// Aviation License
			{ "CUP_B_Merlin_HC3A_GB", "license_cop_aviation" },
			{ "CUP_B_MH60S_USMC", "license_cop_aviation" },
			{ "CUP_B_UH60M_US", "license_cop_aviation" },
			{ "CUP_B_CH47F_USA", "license_cop_aviation" },
			{ "CUP_B_CH53E_USMC", "license_cop_aviation" },
			{ "CUP_B_UH1Y_Gunship_Dynamic_USMC", "license_cop_aviation" },
			{ "CUP_B_AH6J_USA", "license_cop_aviation" }
		};
	};

	class cop_war {
		conditions = "playerSide isEqualTo west && call life_coplevel >= 3 && (missionNamespace getVariable 'SG_ThreatLevel' == 4)";
		vehicles[] = {

			{ "CUP_B_M163_Vulcan_USA", "" },
			{ "CUP_B_M2Bradley_USA_D", "" },
			{ "CUP_I_M60A3_RACS", "" },
			{ "CUP_B_M1A1SA_Desert_US_Army", "" }
		};
	};

	class cop_war_air {
		conditions = "playerSide isEqualTo west && call life_coplevel >= 3 && (missionNamespace getVariable 'SG_ThreatLevel' == 4)";
		vehicles[] = {

			{ "CUP_B_MH60L_DAP_4x_US", "license_cop_aviation" },
			{ "CUP_B_A10_DYN_USA", "license_cop_aviation" }		//	CUSTOM PYLON LOADOUT -- Maybe remove (replace with A-10)
		};
	};

	class opf_car {
		conditions = "playerSide isEqualTo east && call life_opflevel >= 1";
		vehicles[] = {

			{ "CUP_C_SUV_TK", "call life_opflevel >= 1" },
            { "CUP_O_UAZ_Unarmed_RU", "call life_opflevel >= 1" },
            { "CUP_O_LR_Transport_TKA", "call life_opflevel >= 1" },
			{ "CUP_O_UAZ_Open_RU", "call life_opflevel >= 1" },
			{ "CUP_O_UAZ_MG_RU", "call life_opflevel >= 2" },
			{ "CUP_O_UAZ_AGS30_RU", "call life_opflevel >= 3" },
			{ "CUP_O_LR_Transport_TKM", "call life_opflevel >= 1" },
			{ "CUP_O_LR_MG_TKM", "call life_opflevel >= 2" },
			{ "CUP_O_V3S_Open_TKA", "call life_opflevel >= 1" },
			{ "CUP_O_Ural_RU", "call life_opflevel >= 1" },
			{ "CUP_O_Ural_ZU23_RU", "call life_opflevel >= 2" },
			{ "CUP_O_Kamaz_RU", "call life_opflevel >= 2" },
			{ "CUP_O_Kamaz_Open_RU", "call life_opflevel >= 2" },
			{ "CUP_O_Kamaz_Reammo_RU", "call life_opflevel >= 2" },
			{ "CUP_O_Kamaz_Refuel_RU", "call life_opflevel >= 2" },
			{ "CUP_O_Kamaz_Repair_RU", "call life_opflevel >= 2" },
			{ "CUP_O_GAZ_Vodnik_Unarmed_RU", "call life_opflevel >= 2" },
			{ "CUP_O_GAZ_Vodnik_PK_RU", "call life_opflevel >= 2" },
			{ "CUP_O_GAZ_Vodnik_KPVT_RU", "call life_opflevel >= 2" },
			{ "CUP_I_BRDM2_HQ_TKA", "call life_opflevel >= 2" },
            { "CUP_O_BRDM2_RUS", "call life_opflevel >= 2" },
			{ "CUP_O_BTR90_HQ_RU", "call life_opflevel >= 2" },
			{ "CUP_O_BMP_HQ_RU", "call life_opflevel >= 2" },
			{ "CUP_O_BTR80_DESERT_RU", "call life_opflevel >= 2" },
			{ "CUP_O_BTR80A_DESERT_RU", "call life_opflevel >= 2" },
			{ "CUP_O_BMP2_RU", "call life_opflevel >= 3" }
		};
	};

	class opf_air {
		conditions = "playerSide isEqualTo east && call life_opflevel >= 1";
		vehicles[] = {

			{ "CUP_O_UH1H_TKA", "license_opf_opfAviation" },
			{ "CUP_O_Mi8AMT_RU", "license_opf_opfAviation" },
			{ "CUP_O_MI6T_RU", "license_opf_opfAviation" },
            { "CUP_O_MI6A_CHDKZ", "license_opf_opfAviation" },
            { "O_Heli_Light_02_dynamicLoadout_F", "license_opf_opfAviation"},
            { "CUP_B_Mi24_D_MEV_Dynamic_CDF", "license_opf_opfAviation"},
			{ "CUP_I_AH6J_RACS", "license_opf_opfAviation"}
		};
	};

	class opf_war {
		conditions = "playerSide isEqualTo east && (call life_opflevel >= 3 || call life_opfDept in ['AFRF','FIS','Command']) && (missionNamespace getVariable 'SG_ThreatLevel' == 4)";
		vehicles[] = {

			{ "CUP_O_ZSU23_SLA", "" },
			{ "CUP_O_BMP3_RU", "" },
			{ "CUP_O_T55_SLA", "" },
			{ "CUP_O_T72_SLA", "" }
		};
	};

	class opf_war_air {
		conditions = "playerSide isEqualTo east && (call life_opflevel >= 3 || call life_opfDept in ['AFRF','FIS','Command']) && (missionNamespace getVariable 'SG_ThreatLevel' == 4)";
		vehicles[] = {
			
			{ "CUP_O_Mi8_RU", "license_opf_opfAviation" },
			{ "CUP_O_Su25_Dyn_RU", "license_opf_opfAviation" },		//	CUSTOM PYLON LOADOUT
		};
	};
};

class LifeCfgVehicles {
	class Default {
		vItemSpace = 70;
		conditions = "";
		price = -1;
		noinsure = 0;
	};

	// Crates and Shit for Majors/Housing
	class B_supplyCrate_F : Default {vItemSpace = 700; };
	class CargoNet_01_box_F : Default {vItemSpace = 700; };
	class B_CargoNet_01_ammo_F : Default {vItemSpace = 1000; };
	class Box_IND_Grenades_F : Default {vItemSpace = 350; };
	class Land_CargoBox_V1_F : Default {vItemSpace = 500; };
	class C_IDAP_CargoNet_01_supplies_F : Default {vItemSpace = 500; };
	class I_E_CargoNet_01_ammo_F : Default {vItemSpace = 500; };
	class plp_ctm_RuggedCrateGrey : Default {vItemSpace = 500; };
	class plp_cts_WeathCrateBigBrown : Default {vItemSpace = 1000;};

	// Normal Car Shop
	class ivory_suburban : Default {vItemSpace = 55; price = 45000;};
	class ivory_challenger : Default {vItemSpace = 40; price = 50000;};
	class ivory_charger : Default {vItemSpace = 40; price = 40000;};
	class ivory_cv : Default {vItemSpace = 40; price = 26000;};
	class ivory_taurus : Default {vItemSpace = 40; price = 31000;};
	class CUP_C_Volha_Limo_TKCIV : Default {vItemSpace = 40; price = 14000;};
	class CUP_C_Golf4_CR_Civ : Default {vItemSpace = 40; price = 35000;};
	class CUP_C_Golf4_Sport_CR_Civ : Default {vItemSpace = 40; price = 48000;};
	class CUP_I_Hilux_unarmed_TK : Default {vItemSpace = 60; price = 37500;};
	class CUP_B_M151_HIL : Default {vItemSpace = 45; price = 33000;};
	class ivory_190e : Default {vItemSpace = 40; price = 28000;};
	class ivory_190e_taxi : Default {vItemSpace = 40; price = 28500;};
	class CUP_C_Pickup_unarmed_CIV : Default {vItemSpace = 60; price = 43000;};
	class C_Quadbike_01_F : Default {vItemSpace = 5; price = 8000;};
	class ivory_gt500 : Default {vItemSpace = 40; price = 65000;};
	class CUP_C_Skoda_CR_CIV : Default {vItemSpace = 40; price = 22000; nomod = 1;};
	class CUP_C_Octavia_CIV : Default {vItemSpace = 40; price = 28000; nomod = 1;};
	class CUP_C_S1203_CIV : Default {vItemSpace = 50; price = 14500; nomod = 1;};
	class CUP_C_SUV_CIV : Default {vItemSpace = 55; price = 48000; nomod = 1;};
	class ivory_prius : Default {vItemSpace = 40; price = 21500; nomod = 1;};
	class CUP_C_Tractor_CIV : Default {vItemSpace = 40; price = 9000; nomod = 1;};
	class CUP_C_Tractor_Old_CIV : Default {vItemSpace = 40; price = 4500; nomod = 1;};
	class CUP_C_UAZ_Unarmed_TK_CIV : Default {vItemSpace = 55; price = 31000;};
	class C_Van_02_vehicle_F : Default {vItemSpace = 80; price = 75000;};
	class C_Van_02_transport_F : Default {vItemSpace = 45; price = 42000;};
	class CUP_C_Lada_CIV : Default {vItemSpace = 40; price = 14500;};
	class CUP_LADA_LM_CIV : Default {vItemSpace = 40; price = 18500;};
	class ivory_gti : Default {vItemSpace = 40; price = 48750;};
	class CUP_C_TowingTractor_CIV : Default {vItemSpace = 5; price = 20000;};
	class CUP_C_Datsun : Default {vItemSpace = 60; price = 42000;};
	class ivory_e36 : Default {vItemSpace = 40; price = 34000;};

	// Luxury Car Shop
	class ivory_r8 : Default {vItemSpace = 15; price = 160000;};
	class ivory_r8_spyder : Default {vItemSpace = 15; price = 210000;};
	class ivory_rs4 : Default {vItemSpace = 15; price = 150000;};
	class ivory_rs4_taxi : Default {vItemSpace = 15; price = 170000;};
	class ivory_c : Default {vItemSpace = 15; price = 450000;};
	class ivory_m3 : Default {vItemSpace = 15; price = 165000;};
	class ivory_veyron : Default {vItemSpace = 15; price = 650000;};
	class ivory_ccx : Default {vItemSpace = 15; price = 575000;};
	class ivory_lp560 : Default {vItemSpace = 15; price = 350000;};
	class ivory_rev : Default {vItemSpace = 15; price = 500000;};
	class ivory_isf : Default {vItemSpace = 15; price = 360000;};
	class ivory_lfa : Default {vItemSpace = 15; price = 365000;};
	class ivory_elise : Default {vItemSpace = 15; price = 390000;};
	class ivory_r34 : Default {vItemSpace = 15; price = 250000;};
	class ivory_evox : Default {vItemSpace = 15; price = 185000;};
	class ivory_supra : Default {vItemSpace = 15; price = 190000;};
	class ivory_supra_topsecret : Default {vItemSpace = 15; price = 265000;};
	class ivory_911 : Default {vItemSpace = 15; price = 300000;};
	class ivory_mp4 : Default {vItemSpace = 15; price = 440000;};
	class ivory_wrx : Default {vItemSpace = 15; price = 155000;};

	// High-End Car Shop
	class d3s_r8v10_19 : Default {vItemSpace = 20; price = 135750;};
	class AlessioGTR : Default {vItemSpace = 20; price = 192810;};
	class d3s_urus_18 : Default {vItemSpace = 20; price = 285990;};
	class d3s_mclaren_18 : Default {vItemSpace = 20; price = 305760;};
	class d3s_huracan_18 : Default {vItemSpace = 20; price = 320750;};
	class Alessio458 : Default {vItemSpace = 20; price = 345870;};
	class AlessioGallardo : Default {vItemSpace = 20; price = 397500;};
	class AlessioGTB : Default {vItemSpace = 20; price = 421840;};
	class d3s_novus_phantom_18 : Default {vItemSpace = 40; price = 450750;};
	class AlessioAventador : Default {vItemSpace = 20; price = 572850;};
	class AlessioSuperfast : Default {vItemSpace = 20; price = 875900;};
	class d3s_senna_18_M : Default {vItemSpace = 20; price = 965345;};
	class d3s_veyron_12_SS : Default {vItemSpace = 20; price = 1285750;};
	class AlessioAgera : Default {vItemSpace = 20; price = 1957550;};
	class AlessioLaFerrari : Default {vItemSpace = 20; price = 2155295;};
	class AlessioHuayra : Default {vItemSpace = 20; price = 2300750;};
	class d3s_chiron_18_S : Default {vItemSpace = 20; price = 3005750;};

	// Big trucks
	class CUP_C_Ikarus_TKC : Default {vItemSpace = 40; price = 86570;};
	class CUP_C_Bus_City_CIV : Default {vItemSpace = 40; price = 86570;};
	class CUP_C_Bus_City_TKCIV : Default {vItemSpace = 40; price = 88650;};
	class CUP_C_Ikarus_Chernarus : Default {vItemSpace = 40; price = 93650;};
	class CUP_O_V3S_Open_TKC : Default {vItemSpace = 225; price = 185000;};
	class CUP_C_V3S_Covered_TKC : Default {vItemSpace = 225; price = 185000;};
	class CUP_B_T810_Unarmed_CZ_WDL : Default {vItemSpace = 350; price = 300000;};
	class CUP_C_Ural_Civ_01 : Default {vItemSpace = 265; price = 225000;};
	class CUP_C_Ural_Open_Civ_03 : Default {vItemSpace = 265; price = 225000;};
	class CUP_O_Ural_Empty_SLA : Default {vItemSpace = 120; price = 150000;};

	// EMS Cars
	class CUP_O_GAZ_Vodnik_MedEvac_RU : Default {vItemSpace = 40; price = 90000; nomod = 1;};
	class CUP_B_LR_Ambulance_CZ_W : Default {vItemSpace = 40; price = 30000; nomod = 1;};
	class CUP_C_S1203_Ambulance_CIV : Default {vItemSpace = 40; price = 15000; nomod = 1;};
	class C_Van_02_medevac_F : Default {vItemSpace = 40; price = 60000; nomod = 1;};
	class CUP_I_BMP2_AMB_UN : Default {vItemSpace = 40; price = 150000; nomod = 1;};
	class v_rc_strider : Default {vItemSpace = 40; price = 60000; nomod = 1;};
	class v_rc_hunter : Default {vItemSpace = 40; price = 60000; nomod = 1;};
	class v_rc_suv : Default {vItemSpace = 40; price = 60000; nomod = 1;};
	class ivory_suburban_ems : Default {vItemSpace = 40; price = 90000; nomod = 1;};
	
	// EMS Air
	class v_rc_UH60 : Default {vItemSpace = 10; price = 200000;};
	class CUP_C_412_Medic : Default {vItemSpace = 10; price = 180000;};
	class v_rc_bird : Default {vItemSpace = 10; price = 120000;};

	// Civ Helicopters
	class O_Heli_Light_02_unarmed_F : Default {vItemSpace = 0; price = 8500;}; // Orca
	class B_Heli_Transport_03_unarmed_F : Default {vItemSpace = 0; price = 18500;}; // Huron

	// Civ Air
	class CUP_C_AN2_AIRTAK_TK_CIV : Default {vItemSpace = 100; price = 165000;};
	class CUP_I_C130J_RACS : Default {vItemSpace = 180; price = 650000;};
	class CUP_I_C130J_Cargo_RACS : Default {vItemSpace = 240; price = 800000;};
	class CUP_C_CESSNA_CIV : Default {vItemSpace = 100; price = 315000;};
	class CUP_C_C47_CIV : Default {vItemSpace = 100; price = 350000;};
	class CUP_B_CH53E_USMC : Default {vItemSpace = 60; price = 185000;};
	class CUP_C_DC3_ChernAvia_CIV : Default {vItemSpace = 100; price = 450000;};
	class CUP_C_412 : Default {vItemSpace = 70; price = 210000;};
	class CUP_C_412_Luxury : Default {vItemSpace = 50; price = 300000;};
	class CUP_C_Merlin_HC3_CIV_Lux : Default {vItemSpace = 80; price = 320000;};
	class C_Heli_Light_01_civil_F : Default {vItemSpace = 20; price = 90000;}; //m900
	class CUP_B_MI6A_CDF : Default {vItemSpace = 125; price = 575000;};
	class CUP_C_Mi17_Civilian_RU : Default {vItemSpace = 80; price = 330000;};
	class C_Plane_Civil_01_racing_F : Default {vItemSpace = 10; price = 200000;};

	// Rebel Air
	class CUP_O_UH1H_slick_TKA : Default {vItemSpace = 20; price = 165000;};
	class CUP_I_412_Mil_Transport_AAF : Default {vItemSpace = 30; price = 165000;};
	class CUP_B_AC47_Spooky_USA : Default {vItemSpace = 60; price = 300000;};

	// Blufor
	class ivory_cv_marked_classic : Default {vItemSpace = 20; price = 20000; nomod = 1;};
	class ivory_rs4_marked_classic : Default {vItemSpace = 20; price = 60000; nomod = 1;};
	class ivory_m3_marked_classic : Default {vItemSpace = 20; price = 55000; nomod = 1;};
	class ivory_charger_marked_classic : Default {vItemSpace = 20; price = 70000; nomod = 1;};
	class ivory_suburban_marked_classic : Default {vItemSpace = 40; price = 60000; nomod = 1;};
	class CUP_B_nM1038_4s_USA_DES : Default {vItemSpace = 30; price = 30000; nomod = 1;};
	class CUP_B_MTVR_Refuel_USA : Default {vItemSpace = 50; price = 60000; nomod = 1;};
	class CUP_B_MTVR_Repair_USA : Default {vItemSpace = 50; price = 60000; nomod = 1;};
	class CUP_B_MTVR_Ammo_USA  : Default {vItemSpace = 50; price = 80000; nomod = 1;};
	class CUP_B_MTVR_USA : Default {vItemSpace = 50; price = 50000; nomod = 1;};
	class CUP_B_M1151_USA : Default {vItemSpace = 30; price = 60000; nomod = 1;};
	class CUP_B_nM1025_M2_USA_DES : Default {vItemSpace = 30; price = 80000; nomod = 1;};
	class CUP_B_nM1025_M240_USA_DES : Default {vItemSpace = 30; price = 75000; nomod = 1;};
	class CUP_B_nM1025_SOV_M2_USA_DES : Default {vItemSpace = 30; price = 60000; nomod = 1;};
	class CUP_B_HMMWV_DSHKM_GPK_ACR : Default {vItemSpace = 30; price = 70000; nomod = 1;};
	class CUP_B_M1151_M2_USA : Default {vItemSpace = 30; price = 85000; nomod = 1;};
	class CUP_B_M1151_Deploy_USA : Default {vItemSpace = 30; price = 90000; nomod = 1;};
	class CUP_B_nM1097_AVENGER_USA_DES : Default {vItemSpace = 20; price = 150000; nomod = 1;};
	class CUP_B_HMMWV_Crows_M2_USA : Default {vItemSpace = 20; price = 115000; nomod = 1;};
	class CUP_B_RG31E_M2_USMC : Default {vItemSpace = 30; price = 100000; nomod = 1;};
	class CUP_B_LAV25_HQ_USMC : Default {vItemSpace = 50; price = 130000; nomod = 1;};
	class CUP_B_LAV25M240_USMC : Default {vItemSpace = 50; price = 200000; nomod = 1; noinsure=1;};
	class CUP_B_AAV_Unarmed_USMC : Default {vItemSpace = 50; price = 140000; nomod = 1; noinsure=1;};
	class CUP_B_MCV80_GB_D : Default {vItemSpace = 40; price = 285000; nomod = 1; noinsure=1;};
	
	// CIA
	class CUP_B_Jackal2_L2A1_GB_D : Default {vItemSpace = 0; price = 75000; nomod = 1; noinsure=1;};
	class B_LSV_01_unarmed_F : Default {vItemSpace = 0; price = 7500; nomod = 1;};
	class CUP_I_LSV_02_unarmed_ION : Default {vItemSpace = 0; price = 7500; nomod = 1;};
	class I_C_Offroad_02_LMG_F : Default {vItemSpace = 0; price = 7500; nomod = 1; noinsure=1;};

	// BLUFOR Air Vehicles
	class CUP_B_MH6J_USA : Default {vItemSpace = 20; price = 80000;};
	class CUP_B_Merlin_HC3A_GB : Default {vItemSpace = 50; price = 110000;};
	class CUP_B_CH47F_USA : Default {vItemSpace = 0; price = 120000;};
	class CUP_B_MH60S_USMC : Default {vItemSpace = 0; price = 140000;};
	class CUP_B_Merlin_HC3_Armed_GB : Default {vItemSpace = 0; price = 130000;};
	class CUP_B_CH47F_VIV_USA : Default {vItemSpace = 0; price = 140000;};
	class CUP_B_UH60M_US : Default {vItemSpace = 0; price = 150000;};
	class CUP_B_UH1Y_Gunship_Dynamic_USMC : Default {vItemSpace = 0; price = 305000; noinsure=1;};
	class CUP_B_AH6J_USA : Default {vItemSpace = 0; price = 325000; noinsure=1;};

	// BLUFOR War Vehicles
	class CUP_B_M163_Vulcan_USA : Default {vItemSpace = 0; price = 285000; noinsure = 1; nomod = 1; wartime = 1;};
	class CUP_B_M2Bradley_USA_D : Default {vItemSpace = 0; price = 300000; noinsure = 1; nomod = 1; wartime = 1;};
	class CUP_I_M60A3_RACS : Default {vItemSpace = 0; price = 375000; noinsure = 1; nomod = 1; wartime = 1;};
	class CUP_B_M1A1SA_Desert_US_Army : Default {vItemSpace = 0; price = 435000; noinsure = 1; nomod = 1; wartime = 1;};

	// BLUFOR Air War Vehicles
	class CUP_B_MH60L_DAP_4x_US : Default {vItemSpace = 0; price = 285000; noinsure = 1; nomod = 1; wartime = 1;};
	class CUP_B_A10_DYN_USA : Default {vItemSpace = 0; price = 415000; noinsure = 1; nomod = 1; wartime = 1;};

	//Special
	class CUP_B_MH47E_USA : Default {vItemSpace = 0; price = 15000; noinsure=1;};
	class CUP_MH60S_Unarmed_USN : Default {vItemSpace = 0; price = 15000; noinsure=1;};
	class B_CTRG_Heli_Transport_01_sand_F : Default {vItemSpace = 0; price = 35000; noinsure=1;};

	// Rebel Vics
	class CUP_I_BTR40_TKG : Default {vItemSpace = 40; price = 60000; nomod = 1; noinsure=1;};
	class CUP_I_BTR40_MG_TKG : Default {vItemSpace = 40; price = 85000; nomod = 1; noinsure=1;};
	class CUP_O_Datsun_PK_Random : Default {vItemSpace = 40; price = 65000; nomod = 1; noinsure=1;};
	class CUP_O_Hilux_AGS30_TK_INS : Default {vItemSpace = 40; price = 150000; nomod = 1; noinsure=1;};
	class CUP_O_Hilux_DSHKM_TK_INS : Default {vItemSpace = 40; price = 80000; nomod = 1; noinsure=1;};
	class CUP_O_Hilux_armored_DSHKM_TK_INS : Default {vItemSpace = 40; price = 130000; nomod = 1; noinsure=1;};
	class CUP_O_Hilux_armored_unarmed_TK_INS : Default {vItemSpace = 40; price = 75000; nomod = 1; noinsure=1;};
	class CUP_O_Hilux_zu23_TK_INS : Default {vItemSpace = 40; price = 120000; nomod = 1; noinsure=1;};
	class CUP_O_Hilux_SPG9_TK_INS : Default {vItemSpace = 40; price = 185000; nomod = 1; noinsure=1;};
	class CUP_O_Hilux_BMP1_TK_INS : Default {vItemSpace = 40; price = 200000; nomod = 1; noinsure=1;};
	class CUP_O_Hilux_btr60_TK_INS : Default {vItemSpace = 40; price = 140000; nomod = 1; noinsure=1;};
	class CUP_O_Hilux_igla_TK_INS : Default {vItemSpace = 40; price = 120000; nomod = 1; noinsure=1;};
	class CUP_O_Hilux_armored_BMP1_TK_INS : Default {vItemSpace = 40; price = 330000; nomod = 1; noinsure=1;};
	class CUP_I_BMP1_TK_GUE : Default {vItemSpace = 40; price = 350000; nomod = 1; noinsure=1;};
	class CUP_O_BMP2_ZU_TKA : Default {vItemSpace = 40; price = 260000; nomod = 1; noinsure=1;};
	class CUP_I_T34_TK_GUE : Default {vItemSpace = 40; price = 400000; nomod = 1; noinsure=1;};
	class CUP_I_MTLB_pk_NAPA : Default {vItemSpace = 40; price = 185000; nomod = 1; noinsure=1;};

	// Marked Vehicles
	class SG_NATO_CTS : Default {vItemSpace = 0; price = 5000; nomod = 1;};
	class SG_NATO_Focus : Default {vItemSpace = 0; price = 5000; nomod = 1;};
	class SG_NATO_Tesla : Default {vItemSpace = 0; price = 5000; nomod = 1;};
	class SG_NATO_Taurus : Default {vItemSpace = 0; price = 5000; nomod = 1;};
	class SG_NATO_Tahoe15 : Default {vItemSpace = 0; price = 5000; nomod = 1;};
	class SG_NATO_Evo : Default {vItemSpace = 0; price = 5000; nomod = 1;};
	class SG_NATO_Charger_Interceptor : Default {vItemSpace = 0; price = 5000; nomod = 1;};
	class SG_NATO_Durango : Default {vItemSpace = 0; price = 5000; nomod = 1;};
	class SG_NATO_Explorer : Default {vItemSpace = 0; price = 5000; nomod = 1;};

	// Gang Cars
	class Qilin_Primal : Default {vItemSpace = 75; price = 135000; nomod = 1;};
	class Ifrit_Primal : Default {vItemSpace = 75; price = 450000; nomod = 1;};
	class MCLAREN_Primal : Default {vItemSpace = 40; price = 305760; nomod = 1;};
	class URUS_PRIMAL : Default {vItemSpace = 40; price = 285990; nomod = 1;};
	class R8_Hamburglar : Default {vItemSpace = 40; price = 135750; nomod = 1;};
	class Ifrit_Hamburglar : Default {vItemSpace = 75; price = 450000; nomod = 1;};
	class SRT_Hamburglar : Default {vItemSpace = 40; price = 83500; nomod = 1;};
	class URUS_Hamburglar : Default {vItemSpace = 40; price = 285990; nomod = 1;};

	// CIA Cars
	class d3s_suburban_08_unm : Default {vItemSpace = 0; price = 4000; UC = 1;};
	class d3s_h2_02_Black : Default {vItemSpace = 0; price = 4000; UC = 1;};
	class d3s_tahoe_15_unm : Default {vItemSpace = 0; price = 4000; UC = 1;};
	class d3s_escalade_16_unm : Default {vItemSpace = 0; price = 4000; UC = 1;};
	class d3s_explorer_UNM_13 : Default {vItemSpace = 0; price = 4000; UC = 1;};
	class C_Offroad_02_unarmed_F : Default {vItemSpace = 0; price = 4000;};
	class d3s_savana_VAN : Default {vItemSpace = 0; price = 4000;};

	//Opfor land vehicles
	class CUP_C_SUV_TK : Default {vItemSpace = 50; price = 30000; nomod = 1;};
	class CUP_O_UAZ_Unarmed_RU : Default {vItemSpace = 40; price = 18000; nomod = 1;};
	class CUP_O_LR_Transport_TKA : Default {vItemSpace = 40; price = 22000; nomod = 1;};
	class CUP_O_UAZ_Open_RU : Default {vItemSpace = 40; price = 18000; nomod = 1;};
	class CUP_O_UAZ_MG_RU : Default {vItemSpace = 40; price = 40000; nomod = 1;};
	class CUP_O_UAZ_AGS30_RU : Default {vItemSpace = 40; price = 60000; nomod = 1;};
	class CUP_O_LR_Transport_TKM : Default {vItemSpace = 40; price = 22500; nomod = 1;};
	class CUP_O_LR_MG_TKM : Default {vItemSpace = 40; price = 47500; nomod = 1;};
	class CUP_O_V3S_Open_TKA : Default {vItemSpace = 80; price = 40000; nomod = 1;};
	class CUP_O_Ural_RU : Default {vItemSpace = 80; price = 40000; nomod = 1;};
	class CUP_O_Ural_ZU23_RU : Default {vItemSpace = 50; price = 85000; nomod = 1;};
	class CUP_O_Kamaz_RU : Default {vItemSpace = 100; price = 50000; nomod = 1;};
	class CUP_O_Kamaz_Open_RU : Default {vItemSpace = 100; price = 50000; nomod = 1;};
	class CUP_O_Kamaz_Reammo_RU : Default {vItemSpace = 20; price = 80000; nomod = 1;};
	class CUP_O_Kamaz_Refuel_RU : Default {vItemSpace = 20; price = 60000; nomod = 1;};
	class CUP_O_Kamaz_Repair_RU : Default {vItemSpace = 20; price = 60000; nomod = 1;};
	class CUP_O_GAZ_Vodnik_Unarmed_RU : Default {vItemSpace = 40; price = 50000; nomod = 1;};
	class CUP_O_GAZ_Vodnik_PK_RU : Default {vItemSpace = 20; price = 75000; nomod = 1;};
	class CUP_O_GAZ_Vodnik_KPVT_RU : Default {vItemSpace = 20; price = 85000; nomod = 1;};
	class CUP_I_BRDM2_HQ_TKA : Default {vItemSpace = 30; price = 80000; nomod = 1;};
	class CUP_O_BRDM2_RUS : Default {vItemSpace = 20; price = 100000; noinsure = 1; nomod = 1;};
	class CUP_O_BTR90_HQ_RU : Default {vItemSpace = 40; price = 100000; nomod = 1;};
	class CUP_O_BMP_HQ_RU : Default {vItemSpace = 40; price = 70000; nomod = 1;};
	class CUP_O_BTR80_DESERT_RU : Default {vItemSpace = 20; price = 110000; noinsure = 1; nomod = 1;};
	class CUP_O_BTR80A_DESERT_RU : Default {vItemSpace = 20; price = 150000; noinsure = 1; nomod = 1;};
	class CUP_O_ZSU23_Afghan_SLA : Default {vItemSpace = 20; price = 285000; noinsure = 1; nomod = 1;};
	class CUP_O_BMP2_RU : Default {vItemSpace = 20; price = 295000; noinsure = 1; nomod = 1;};

	//Opfor Air Vehicles
	class CUP_O_UH1H_TKA : Default {vItemSpace = 20; price = 75000; nomod = 1;};
	class CUP_O_Mi8AMT_RU : Default {vItemSpace = 0; price = 90000; nomod = 1;};
	class CUP_O_MI6T_RU : Default {vItemSpace = 0; price = 120000; nomod = 1;};
	class CUP_O_MI6A_CHDKZ : Default {vItemSpace = 0; price = 150000; nomod = 1;};
	class CUP_B_Mi24_D_MEV_Dynamic_CDF : Default {vItemSpace = 0; price = 270000; noinsure = 1; nomod = 1;};
	class O_Heli_Light_02_dynamicLoadout_F : Default {vItemSpace = 0; price = 285000; noinsure = 1; nomod = 1;};
	class CUP_I_AH6J_RACS : Default {vItemSpace = 0; price = 325000; noinsure = 1; nomod = 1;};
	
	// OPFOR War Vehicles
	class CUP_O_ZSU23_SLA : Default {vItemSpace = 0; price = 280000; noinsure = 1; nomod = 1; wartime = 1;};
	class CUP_O_BMP3_RU : Default {vItemSpace = 0; price = 295000; noinsure = 1; nomod = 1; wartime = 1;};
	class CUP_O_T55_SLA : Default {vItemSpace = 0; price = 335000; noinsure = 1; nomod = 1; wartime = 1;};
	class CUP_O_T72_SLA : Default {vItemSpace = 0; price = 385000; noinsure = 1; nomod = 1; wartime = 1;};

	// OPFOR Air War Vehicles
	class CUP_O_Mi8_RU : Default {vItemSpace = 0; price = 295000; noinsure = 1; nomod = 1; wartime = 1;};
	class CUP_O_Su25_Dyn_RU : Default {vItemSpace = 0; price = 400000; noinsure = 1; nomod = 1; wartime = 1;};
};