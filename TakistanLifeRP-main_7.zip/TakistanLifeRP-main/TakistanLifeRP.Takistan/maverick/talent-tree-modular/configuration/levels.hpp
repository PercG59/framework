class Level_0 {
	displayName = "Rank 0";
	expRequired = 0;
	perkPointsOnUnlock = 2;
};

class Level_1 {
	displayName = "Rank 1";
	expRequired = 85;
	perkPointsOnUnlock = 2;
};

class Level_2 {
	displayName = "Rank 2";
	expRequired = 340;
	perkPointsOnUnlock = 2;
};

class Level_3 {
	displayName = "Rank 3";
	expRequired = 765;
	perkPointsOnUnlock = 2;
};

class Level_4 {
	displayName = "Rank 4";
	expRequired = 1360;
	perkPointsOnUnlock = 2;
};

class Level_5 {
	displayName = "Rank 5";
	expRequired = 2125;
	perkPointsOnUnlock = 5;
};

class Level_6 {
	displayName = "Rank 6";
	expRequired = 3060;
	perkPointsOnUnlock = 2;
};

class Level_7 {
	displayName = "Rank 7";
	expRequired = 4165;
	perkPointsOnUnlock = 2;
};

class Level_8 {
	displayName = "Rank 8";
	expRequired = 5440;
	perkPointsOnUnlock = 2;
};

class Level_9 {
	displayName = "Rank 9";
	expRequired = 6885;
	perkPointsOnUnlock = 2;
};

class Level_10 {
	displayName = "Rank 10";
	expRequired = 8500;
	perkPointsOnUnlock = 5;
};

class Level_11 {
	displayName = "Rank 11";
	expRequired = 10285;
	perkPointsOnUnlock = 2;
};

class Level_12 {
	displayName = "Rank 12";
	expRequired = 12240;
	perkPointsOnUnlock = 2;
};

class Level_13 {
	displayName = "Rank 13";
	expRequired = 14365;
	perkPointsOnUnlock = 2;
};

class Level_14 {
	displayName = "Rank 14";
	expRequired = 16660;
	perkPointsOnUnlock = 2;
};

class Level_15 {
	displayName = "Rank 15";
	expRequired = 19125;
	perkPointsOnUnlock = 5;
};

class Level_16 {
	displayName = "Rank 16";
	expRequired = 21760;
	perkPointsOnUnlock = 2;
};

class Level_17 {
	displayName = "Rank 17";
	expRequired = 24565;
	perkPointsOnUnlock = 2;
};

class Level_18 {
	displayName = "Rank 18";
	expRequired = 27540;
	perkPointsOnUnlock = 2;
};

class Level_19 {
	displayName = "Rank 19";
	expRequired = 30685;
	perkPointsOnUnlock = 2;
};

class Level_20 {
	displayName = "Rank 20";
	expRequired = 34000;
	perkPointsOnUnlock = 5;
};

class Level_21 {
	displayName = "Rank 21";
	expRequired = 37485;
	perkPointsOnUnlock = 2;
};

class Level_22 {
	displayName = "Rank 22";
	expRequired = 41140;
	perkPointsOnUnlock = 2;
};

class Level_23 {
	displayName = "Rank 23";
	expRequired = 44965;
	perkPointsOnUnlock = 2;
};

class Level_24 {
	displayName = "Rank 24";
	expRequired = 48960;
	perkPointsOnUnlock = 2;
};

class Level_25 {
	displayName = "Rank 25";
	expRequired = 53125;
	perkPointsOnUnlock = 5;
};

class Level_26 {
	displayName = "Rank 26";
	expRequired = 57460;
	perkPointsOnUnlock = 2;
};

class Level_27 {
	displayName = "Rank 27";
	expRequired = 61965;
	perkPointsOnUnlock = 2;
};

class Level_28 {
	displayName = "Rank 28";
	expRequired = 66640;
	perkPointsOnUnlock = 2;
};

class Level_29 {
	displayName = "Rank 29";
	expRequired = 71485;
	perkPointsOnUnlock = 2;
};

class Level_30 {
	displayName = "Rank 30";
	expRequired = 76500;
	perkPointsOnUnlock = 5;
};

class Level_31 {
	displayName = "Rank 31";
	expRequired = 81685;
	perkPointsOnUnlock = 3;
};

class Level_32 {
	displayName = "Rank 32";
	expRequired = 87040;
	perkPointsOnUnlock = 3;
};

class Level_33 {
	displayName = "Rank 33";
	expRequired = 92565;
	perkPointsOnUnlock = 3;
};

class Level_34 {
	displayName = "Rank 34";
	expRequired = 98260;
	perkPointsOnUnlock = 3;
};

class Level_35 {
	displayName = "Rank 35";
	expRequired = 104125;
	perkPointsOnUnlock = 5;
};

class Level_36 {
	displayName = "Rank 36";
	expRequired = 110160;
	perkPointsOnUnlock = 3;
};

class Level_37 {
	displayName = "Rank 37";
	expRequired = 116365;
	perkPointsOnUnlock = 3;
};

class Level_38 {
	displayName = "Rank 38";
	expRequired = 122740;
	perkPointsOnUnlock = 3;
};

class Level_39 {
	displayName = "Rank 39";
	expRequired = 129285;
	perkPointsOnUnlock = 3;
};

class Level_40 {
	displayName = "Rank 40";
	expRequired = 136000;
	perkPointsOnUnlock = 5;
};

class Level_41 {
	displayName = "Rank 41";
	expRequired = 142885;
	perkPointsOnUnlock = 4;
};

class Level_42 {
	displayName = "Rank 42";
	expRequired = 149940;
	perkPointsOnUnlock = 4;
};

class Level_43 {
	displayName = "Rank 43";
	expRequired = 157165;
	perkPointsOnUnlock = 4;
};

class Level_44 {
	displayName = "Rank 44";
	expRequired = 164560;
	perkPointsOnUnlock = 4;
};

class Level_45 {
	displayName = "Rank 45";
	expRequired = 172125;
	perkPointsOnUnlock = 5;
};

class Level_46 {
	displayName = "Rank 46";
	expRequired = 179860;
	perkPointsOnUnlock = 4;
};

class Level_47 {
	displayName = "Rank 47";
	expRequired = 187765;
	perkPointsOnUnlock = 4;
};

class Level_48 {
	displayName = "Rank 48";
	expRequired = 195840;
	perkPointsOnUnlock = 4;
};

class Level_49 {
	displayName = "Rank 49";
	expRequired = 204085;
	perkPointsOnUnlock = 4;
};

class Level_50 {
	displayName = "Rank 50";
	expRequired = 212500;
	perkPointsOnUnlock = 5;
};

class Level_51 {
	displayName = "Rank 51";
	expRequired = 221085;
	perkPointsOnUnlock = 4;
};

class Level_52 {
	displayName = "Rank 52";
	expRequired = 229840;
	perkPointsOnUnlock = 4;
};

class Level_53 {
	displayName = "Rank 53";
	expRequired = 238765;
	perkPointsOnUnlock = 4;
};

class Level_54 {
	displayName = "Rank 54";
	expRequired = 247860;
	perkPointsOnUnlock = 4;
};

class Level_55 {
	displayName = "Rank 55";
	expRequired = 257125;
	perkPointsOnUnlock = 5;
};

class Level_56 {
	displayName = "Rank 56";
	expRequired = 266560;
	perkPointsOnUnlock = 4;
};

class Level_57 {
	displayName = "Rank 57";
	expRequired = 276165;
	perkPointsOnUnlock = 4;
};

class Level_58 {
	displayName = "Rank 58";
	expRequired = 285940;
	perkPointsOnUnlock = 4;
};

class Level_59 {
	displayName = "Rank 59";
	expRequired = 295885;
	perkPointsOnUnlock = 4;
};

class Level_60 {
	displayName = "Rank 60";
	expRequired = 306000;
	perkPointsOnUnlock = 5;
};

class Level_61 {
	displayName = "Rank 61";
	expRequired = 316285;
	perkPointsOnUnlock = 4;
};

class Level_62 {
	displayName = "Rank 62";
	expRequired = 326740;
	perkPointsOnUnlock = 4;
};

class Level_63 {
	displayName = "Rank 63";
	expRequired = 337365;
	perkPointsOnUnlock = 4;
};

class Level_64 {
	displayName = "Rank 64";
	expRequired = 348160;
	perkPointsOnUnlock = 4;
};

class Level_65 {
	displayName = "Rank 65";
	expRequired = 359125;
	perkPointsOnUnlock = 5;
};

class Level_66 {
	displayName = "Rank 66";
	expRequired = 370260;
	perkPointsOnUnlock = 4;
};

class Level_67 {
	displayName = "Rank 67";
	expRequired = 381565;
	perkPointsOnUnlock = 4;
};

class Level_68 {
	displayName = "Rank 68";
	expRequired = 393040;
	perkPointsOnUnlock = 4;
};

class Level_69 {
	displayName = "Rank 69";
	expRequired = 404685;
	perkPointsOnUnlock = 4;
};

class Level_70 {
	displayName = "Rank 70";
	expRequired = 416500;
	perkPointsOnUnlock = 5;
};

class Level_71 {
	displayName = "Rank 71";
	expRequired = 428485;
	perkPointsOnUnlock = 4;
};

class Level_72 {
	displayName = "Rank 72";
	expRequired = 440640;
	perkPointsOnUnlock = 4;
};

class Level_73 {
	displayName = "Rank 73";
	expRequired = 452965;
	perkPointsOnUnlock = 4;
};

class Level_74 {
	displayName = "Rank 74";
	expRequired = 465460;
	perkPointsOnUnlock = 4;
};

class Level_75 {
	displayName = "Rank 75";
	expRequired = 478125;
	perkPointsOnUnlock = 5;
};

class Level_76 {
	displayName = "Rank 76";
	expRequired = 490960;
	perkPointsOnUnlock = 4;
};

class Level_77 {
	displayName = "Rank 77";
	expRequired = 503965;
	perkPointsOnUnlock = 4;
};

class Level_78 {
	displayName = "Rank 78";
	expRequired = 517140;
	perkPointsOnUnlock = 4;
};

class Level_79 {
	displayName = "Rank 79";
	expRequired = 530485;
	perkPointsOnUnlock = 4;
};

class Level_80 {
	displayName = "Rank 80";
	expRequired = 544000;
	perkPointsOnUnlock = 5;
};

class Level_81 {
	displayName = "Rank 81";
	expRequired = 557685;
	perkPointsOnUnlock = 4;
};

class Level_82 {
	displayName = "Rank 82";
	expRequired = 571540;
	perkPointsOnUnlock = 4;
};

class Level_83 {
	displayName = "Rank 83";
	expRequired = 585565;
	perkPointsOnUnlock = 4;
};

class Level_84 {
	displayName = "Rank 84";
	expRequired = 599760;
	perkPointsOnUnlock = 4;
};

class Level_85 {
	displayName = "Rank 85";
	expRequired = 614125;
	perkPointsOnUnlock = 5;
};

class Level_86 {
	displayName = "Rank 86";
	expRequired = 628660;
	perkPointsOnUnlock = 4;
};

class Level_87 {
	displayName = "Rank 87";
	expRequired = 643365;
	perkPointsOnUnlock = 4;
};

class Level_88 {
	displayName = "Rank 88";
	expRequired = 658240;
	perkPointsOnUnlock = 4;
};

class Level_89 {
	displayName = "Rank 89";
	expRequired = 673285;
	perkPointsOnUnlock = 4;
};

class Level_90 {
	displayName = "Rank 90";
	expRequired = 688500;
	perkPointsOnUnlock = 5;
};

class Level_91 {
	displayName = "Rank 91";
	expRequired = 703885;
	perkPointsOnUnlock = 4;
};

class Level_92 {
	displayName = "Rank 92";
	expRequired = 719440;
	perkPointsOnUnlock = 4;
};

class Level_93 {
	displayName = "Rank 93";
	expRequired = 735165;
	perkPointsOnUnlock = 4;
};

class Level_94 {
	displayName = "Rank 94";
	expRequired = 751060;
	perkPointsOnUnlock = 4;
};

class Level_95 {
	displayName = "Rank 95";
	expRequired = 767125;
	perkPointsOnUnlock = 5;
};

class Level_96 {
	displayName = "Rank 96";
	expRequired = 783360;
	perkPointsOnUnlock = 4;
};

class Level_97 {
	displayName = "Rank 97";
	expRequired = 799765;
	perkPointsOnUnlock = 4;
};

class Level_98 {
	displayName = "Rank 98";
	expRequired = 816340;
	perkPointsOnUnlock = 4;
};

class Level_99 {
	displayName = "Rank 99";
	expRequired = 833085;
	perkPointsOnUnlock = 4;
};

class Level_100 {
	displayName = "Rank 100";
	expRequired = 850000;
	perkPointsOnUnlock = 5;
};

class Level_101 {
	displayName = "Rank 101";
	expRequired = 867085;
	perkPointsOnUnlock = 4;
};

class Level_102 {
	displayName = "Rank 102";
	expRequired = 884340;
	perkPointsOnUnlock = 4;
};

class Level_103 {
	displayName = "Rank 103";
	expRequired = 901765;
	perkPointsOnUnlock = 4;
};

class Level_104 {
	displayName = "Rank 104";
	expRequired = 919360;
	perkPointsOnUnlock = 4;
};

class Level_105 {
	displayName = "Rank 105";
	expRequired = 937125;
	perkPointsOnUnlock = 5;
};

class Level_106 {
	displayName = "Rank 106";
	expRequired = 955060;
	perkPointsOnUnlock = 4;
};

class Level_107 {
	displayName = "Rank 107";
	expRequired = 973165;
	perkPointsOnUnlock = 4;
};

class Level_108 {
	displayName = "Rank 108";
	expRequired = 991440;
	perkPointsOnUnlock = 4;
};

class Level_109 {
	displayName = "Rank 109";
	expRequired = 1009885;
	perkPointsOnUnlock = 4;
};

class Level_110 {
	displayName = "Rank 110";
	expRequired = 1028500;
	perkPointsOnUnlock = 5;
};

class Level_111 {
	displayName = "Rank 111";
	expRequired = 1047285;
	perkPointsOnUnlock = 4;
};

class Level_112 {
	displayName = "Rank 112";
	expRequired = 1066240;
	perkPointsOnUnlock = 4;
};

class Level_113 {
	displayName = "Rank 113";
	expRequired = 1085365;
	perkPointsOnUnlock = 4;
};

class Level_114 {
	displayName = "Rank 114";
	expRequired = 1104660;
	perkPointsOnUnlock = 4;
};

class Level_115 {
	displayName = "Rank 115";
	expRequired = 1124125;
	perkPointsOnUnlock = 5;
};

class Level_116 {
	displayName = "Rank 116";
	expRequired = 1143760;
	perkPointsOnUnlock = 4;
};

class Level_117 {
	displayName = "Rank 117";
	expRequired = 1163565;
	perkPointsOnUnlock = 4;
};

class Level_118 {
	displayName = "Rank 118";
	expRequired = 1183540;
	perkPointsOnUnlock = 4;
};

class Level_119 {
	displayName = "Rank 119";
	expRequired = 1203685;
	perkPointsOnUnlock = 4;
};

class Level_120 {
	displayName = "Rank 120";
	expRequired = 1224000;
	perkPointsOnUnlock = 5;
};

class Level_121 {
	displayName = "Rank 121";
	expRequired = 1244485;
	perkPointsOnUnlock = 4;
};

class Level_122 {
	displayName = "Rank 122";
	expRequired = 1265140;
	perkPointsOnUnlock = 4;
};

class Level_123 {
	displayName = "Rank 123";
	expRequired = 1285965;
	perkPointsOnUnlock = 4;
};

class Level_124 {
	displayName = "Rank 124";
	expRequired = 1306960;
	perkPointsOnUnlock = 4;
};

class Level_125 {
	displayName = "Rank 125";
	expRequired = 1328125;
	perkPointsOnUnlock = 5;
};

class Level_126 {
	displayName = "Rank 126";
	expRequired = 1349460;
	perkPointsOnUnlock = 4;
};

class Level_127 {
	displayName = "Rank 127";
	expRequired = 1370965;
	perkPointsOnUnlock = 4;
};

class Level_128 {
	displayName = "Rank 128";
	expRequired = 1392640;
	perkPointsOnUnlock = 4;
};

class Level_129 {
	displayName = "Rank 129";
	expRequired = 1414485;
	perkPointsOnUnlock = 4;
};

class Level_130 {
	displayName = "Rank 130";
	expRequired = 1436500;
	perkPointsOnUnlock = 5;
};

class Level_131 {
	displayName = "Rank 131";
	expRequired = 1458685;
	perkPointsOnUnlock = 4;
};

class Level_132 {
	displayName = "Rank 132";
	expRequired = 1481040;
	perkPointsOnUnlock = 4;
};

class Level_133 {
	displayName = "Rank 133";
	expRequired = 1503565;
	perkPointsOnUnlock = 4;
};

class Level_134 {
	displayName = "Rank 134";
	expRequired = 1526260;
	perkPointsOnUnlock = 4;
};

class Level_135 {
	displayName = "Rank 135";
	expRequired = 1549125;
	perkPointsOnUnlock = 5;
};

class Level_136 {
	displayName = "Rank 136";
	expRequired = 1572160;
	perkPointsOnUnlock = 4;
};

class Level_137 {
	displayName = "Rank 137";
	expRequired = 1595365;
	perkPointsOnUnlock = 4;
};

class Level_138 {
	displayName = "Rank 138";
	expRequired = 1618740;
	perkPointsOnUnlock = 4;
};

class Level_139 {
	displayName = "Rank 139";
	expRequired = 1642285;
	perkPointsOnUnlock = 4;
};

class Level_140 {
	displayName = "Rank 140";
	expRequired = 1666000;
	perkPointsOnUnlock = 5;
};

class Level_141 {
	displayName = "Rank 141";
	expRequired = 1689885;
	perkPointsOnUnlock = 4;
};

class Level_142 {
	displayName = "Rank 142";
	expRequired = 1713940;
	perkPointsOnUnlock = 4;
};

class Level_143 {
	displayName = "Rank 143";
	expRequired = 1738165;
	perkPointsOnUnlock = 4;
};

class Level_144 {
	displayName = "Rank 144";
	expRequired = 1762560;
	perkPointsOnUnlock = 4;
};

class Level_145 {
	displayName = "Rank 145";
	expRequired = 1787125;
	perkPointsOnUnlock = 5;
};

class Level_146 {
	displayName = "Rank 146";
	expRequired = 1811860;
	perkPointsOnUnlock = 4;
};

class Level_147 {
	displayName = "Rank 147";
	expRequired = 1836765;
	perkPointsOnUnlock = 4;
};

class Level_148 {
	displayName = "Rank 148";
	expRequired = 1861840;
	perkPointsOnUnlock = 4;
};

class Level_149 {
	displayName = "Rank 149";
	expRequired = 1887085;
	perkPointsOnUnlock = 4;
};

class Level_150 {
	displayName = "Rank 150";
	expRequired = 1912500;
	perkPointsOnUnlock = 5;
};