class TTM_GUI_RscTitleExperienceAdded
{
	idd = -1;
	movingEnable = 0;
	enableSimulation = 1;
	fadeout = 0.2;
	fadein = 0.2;
	duration = 6;
	enableDisplay = 1;
	onLoad = "uiNamespace setVariable ['TTM_GUI_RscTitleExperienceAdded',_this select 0];";

	class controls
	{
    class ProgressGroup: SG_ctrlControlsGroupNoScrollbars {
        idc = -1;
        x   = (((getResolution select 2) * 0.5 * pixelW) - (140 * 0.5) * (pixelW * pixelGrid * 0.50));
        y   = ((safezoneY + safezoneH) - (17 * (pixelH * pixelGrid * 0.50)) - (7 * (pixelH * pixelGrid * 0.50)) - (2 * (pixelH * pixelGrid * 0.50)));
        w   = 140 * (pixelW * pixelGrid * 0.50);
        h   = 7 * (pixelH * pixelGrid * 0.50);
        class controls {
            class TextBackground: SG_ctrlStatic {
                idc               = -1;
                x                 = 0;
                y                 = 0;
                w                 = 140 * (pixelW * pixelGrid * 0.50);
                h                 = (7 * (pixelH * pixelGrid * 0.50)) - (2 * (pixelH * pixelGrid * 0.50));
                colorBackground[] = {0.15, 0.15, 0.15, 1};
            };
            class Text: SG_ctrlStructuredText {
                idc               = 3;
                x                 = 0;
                y                 = 0.5 * (pixelH * pixelGrid * 0.50);
                w                 = 140 * (pixelW * pixelGrid * 0.50);
                h                 = (7 * (pixelH * pixelGrid * 0.50)) - (2 * (pixelH * pixelGrid * 0.50));
                class Attributes {
                    size = 1 * (pixelH * pixelGrid * 0.50);
                };
            };
            class ProgressBackground: SG_ctrlStatic {
                idc               = -1;
                x                 = 0;
                y                 = (7 * (pixelH * pixelGrid * 0.50)) - (2 * (pixelH * pixelGrid * 0.50));
                w                 = 140 * (pixelW * pixelGrid * 0.50);
                h                 = 2 * (pixelH * pixelGrid * 0.50);
                colorBackground[] = {0.2, 0.2, 0.2, 0.9};
            };
            class ProgressBackgroundStriped: SG_ctrlStaticBackgroundDisableTiles {
                idc               = -1;
                x                 = 0;
                y                 = (7 * (pixelH * pixelGrid * 0.50)) - (2 * (pixelH * pixelGrid * 0.50));
                w                 = 140 * (pixelW * pixelGrid * 0.50);
                h                 = 2 * (pixelH * pixelGrid * 0.50);
            };
            class Progress: SG_ctrlProgress {
                idc               = 5;
                x                 = 0;
                y                 = (7 * (pixelH * pixelGrid * 0.50)) - (2 * (pixelH * pixelGrid * 0.50));
                w                 = 140 * (pixelW * pixelGrid * 0.50);
                h                 = 2 * (pixelH * pixelGrid * 0.50);
                colorBar[]        = {"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.3843])","(profilenamespace getvariable ['GUI_BCG_RGB_G',0.7019])","(profilenamespace getvariable ['GUI_BCG_RGB_B',0.8862])","1"};
                colorFrame[]      = {0, 0, 0, 0};
                onLoad            = "(_this select 0) progressSetPosition 0.7";
            };
        };
    };
	};
};