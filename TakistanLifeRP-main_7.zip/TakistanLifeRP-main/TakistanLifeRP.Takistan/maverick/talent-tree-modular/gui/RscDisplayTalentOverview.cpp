class TTM_GUI_RscDisplayTalentOverview {
  idd = 6600;
  movingEnable = 0;
  enableSimulation = 1;
  scriptPath = "maverick\talent-tree-modular\gui\RscDisplayTalentOverview.sqf";
  onLoad = "[_this, 'onLoad'] spawn TTM_GUI_master_script;";

  class controlsBackground {
		class Title: SG_ctrlStaticHeader {
			idc  = -1;
			text = "Perk System";
			x = 0.33332 * safezoneW + safezoneX;
			y = 0.2866 * safezoneH + safezoneY;
			w = 0.333413 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
		class Background: SG_ctrlStaticBackground {
			x = 0.33332 * safezoneW + safezoneX;
			y = 0.30508 * safezoneH + safezoneY;
			w = 0.333413 * safezoneW;
			h = 0.351853 * safezoneH;
		};
	};
	class controls {
		class Footer: SG_ctrlControlsGroupNoScrollbars {
			idc = -1;
			x = 0.33332 * safezoneW + safezoneX;
			y = 0.65686 * safezoneH + safezoneY;
			w = 0.333413 * safezoneW;
			h = 0.0259259 * safezoneH;
			class controls {
					class Background: SG_ctrlStaticFooter {
							x = 0;
							y = 0;
							w = "safezoneW";
							h = "safezoneH";
					};
			};
		};
		class ButtonBuy: SG_ctrlDefaultButton {
			idc = 10;
			text = "INSUFFICIENT POINTS";
			onButtonClick = "[_this, 'onButtonPurchaseClick'] spawn TTM_GUI_master_script;";
			x = 0.582311 * safezoneW + safezoneX;
			y = 0.661 * safezoneH + safezoneY;
			w = 0.0827403 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
		class Listbox_Back: SG_ctrlStaticContent {
			idc = -1;
			x = 0.33332 * safezoneW + safezoneX;
			y = 0.3564 * safezoneH + safezoneY;
			w = 0.187644 * safezoneW;
			h = 0.301853 * safezoneH;
		};
		class Listbox: SG_RscTree {
			idc = 7;
			text = "";
			x = 0.33332 * safezoneW + safezoneX;
			y = 0.3564 * safezoneH + safezoneY;
			w = 0.187544 * safezoneW;
			h = 0.301853 * safezoneH;
			onTreeSelChanged = "[_this, 'onTreeSelectionChanged'] spawn TTM_GUI_master_script;";
			type = 12;
			default = 0;
			style = 2;
			blinkingPeriod = 0;
			colorBackground[] = {0,0,0,0};
			sizeEx = 0.035;

			picture = "";
			colorPicture[] = {1,1,1,1};
			colorPictureSelected[] = {1,1,1,1};
			colorPictureDisabled[] = {1,1,1,1};
			colorPictureRight[] = {1,1,1,1};
			colorPictureRightSelected[] = {1,1,1,1};
			colorPictureRightDisabled[] = {1,1,1,1};
			colorPictureLeft[] = {1,1,1,1};
			colorPictureLeftSelected[] = {1,1,1,1};
			colorPictureLeftDisabled[] = {1,1,1,1};

			font = "PuristaSemiBold";

			rowHeight = 0.0439091;
				color[] = {1, 1, 1, 1};
				colorSelect[] = {0.7, 0.7, 0.7, 1};
				colorSelectBackground[] = {0, 0, 0, 1};
				colorBorder[] = {0, 0, 0, 0};
				borderSize = 0;

			colorMarked[] = {1,0.5,0,0.5};  
			colorMarkedSelected[] = {1,0.5,0,1};  

			colorText[] = {1,1,1,1};  
			colorSelectText[] = {1,1,1,1};  
			colorMarkedText[] = {1,1,1,1};  

			tooltip = "CT_TREE";  
			tooltipColorShade[] = {0,0,0,1};  
			tooltipColorText[] = {1,1,1,1}; 
			tooltipColorBox[] = {1,1,1,1};  

			multiselectEnabled = 0; 
			expandOnDoubleclick = 1;  
			hiddenTexture = "\A3\ui_f\data\gui\rsccommon\rsctree\hiddenTexture_ca.paa"; 
			expandedTexture = "\A3\ui_f\data\gui\rsccommon\rsctree\expandedTexture_ca.paa"; 
			maxHistoryDelay = 1;    
			class ScrollBar
			{
				width = 0;  
				height = 0; 
				scrollSpeed = 0.01; 

				arrowEmpty = "\A3\ui_f\data\gui\cfg\scrollbar\arrowEmpty_ca.paa"; 
				arrowFull = "\A3\ui_f\data\gui\cfg\scrollbar\arrowFull_ca.paa"; 
				border = "\A3\ui_f\data\gui\cfg\scrollbar\border_ca.paa"; 
				thumb = "\A3\ui_f\data\gui\cfg\scrollbar\thumb_ca.paa"; 

				color[] = {1,1,1,1};  
			};

			colorDisabled[] = {0,0,0,0};  
			colorArrow[] = {0,0,0,0}; 
		};
		class textCurrentRank_Back: SG_ctrlStaticContent {
			idc = -1;
			x = 0.333335 * safezoneW + safezoneX;
			y = 0.3042 * safezoneH + safezoneY;
			w = 0.05 * safezoneW;
			h = 0.052 * safezoneH;
		};
		class textRankInfo_Back: SG_ctrlStaticContent {
			idc = -1;
			x = 0.3835 * safezoneW + safezoneX;
			y = 0.3042 * safezoneH + safezoneY;
			w = 0.138 * safezoneW;
			h = 0.052 * safezoneH;
		};
		class textCurrentRank: SG_ctrlStructuredText
		{
			idc = 3;
			text = "<t font='PuristaSemiBold' size='2.9' shadow='0' align='center'>50</t>";
			x = 0.333335 * safezoneW + safezoneX;
			y = 0.3042 * safezoneH + safezoneY;
			w = 0.05 * safezoneW;
			h = 0.052 * safezoneH;
			sizeEx = 2.7 * 0.04;
			colorText[] = {1,1,1,1};
			colorBackground[] = {0,0,0,0};
		};
		class textRankInfo: SG_ctrlStructuredText
		{
			idc = 4;
			text = "<t font='PuristaSemiBold' align='left' size='1.2' shadow='0'>Rank 50</t><br/><t font='PuristaMedium' align='left' size='1' shadow='0'>XP: %1, Maximum Level, Perk Points Available: %2</t><br/><t font='PuristaMedium' align='left' size='1' shadow='0'>%3</t>";
			x = 0.3835 * safezoneW + safezoneX;
			y = 0.3042 * safezoneH + safezoneY;
			w = 0.138 * safezoneW;
			h = 0.052 * safezoneH;
			colorText[] = {1,1,1,1};
			colorBackground[] = {0.2,0.2,0.2,0.5};
			sizeEx = 4.32 * (1 / (getResolution select 3)) * pixelGrid * 0.5 * GUI_GRID_H;
		};
		class textPerkName: SG_ctrlStructuredText
		{
			idc = 8;
			text = "<t font='PuristaSemiBold' align='left' size='1.2' shadow='0'>Civilian Perks</t><br/><t font='PuristaMedium' align='left' size='1' shadow='0'>Level 4 Required, 3 Perk Points</t><br/><t font='PuristaMedium' align='left' size='1' shadow='0'>Learn to process materials more efficiently<br/><br/><t color='#10FF45'>+10% faster processing</t></t>";
			x = 0.521 * safezoneW + safezoneX;
			y = 0.3042 * safezoneH + safezoneY;
			w = 0.1455 * safezoneW;
			h = 0.354 * safezoneH;
			colorText[] = {1,1,1,1};
			colorBackground[] = {0.2,0.2,0.2,0.8};
			sizeEx = 4.32 * (1 / (getResolution select 3)) * pixelGrid * 0.5 * GUI_GRID_H;
		};
		class ProgressBackground: SG_ctrlStatic {
			idc               = -1;
			x = 0.33332 * safezoneW + safezoneX;
			y = 0.6826 * safezoneH + safezoneY;
			w = 0.333413 * safezoneW;
			h = 0.0074074 * safezoneH;
			colorBackground[] = {0.2, 0.2, 0.2, 0.9};
		};
		class ProgressBackgroundStriped: SG_ctrlStaticBackgroundDisableTiles {
			idc               = -1;
			x = 0.33332 * safezoneW + safezoneX;
			y = 0.6826 * safezoneH + safezoneY;
			w = 0.333413 * safezoneW;
			h = 0.0074074 * safezoneH;
		};
		class Progress: SG_ctrlProgress {
			idc               = 6;
			x = 0.33332 * safezoneW + safezoneX;
			y = 0.6826 * safezoneH + safezoneY;
			w = 0.333413 * safezoneW;
			h = 0.0074074 * safezoneH;
			colorBar[]        = {"(profilenamespace getvariable ['GUI_BCG_RGB_R',0.3843])","(profilenamespace getvariable ['GUI_BCG_RGB_G',0.7019])","(profilenamespace getvariable ['GUI_BCG_RGB_B',0.8862])","1"};
			colorFrame[]      = {0, 0, 0, 0};
			onLoad            = "(_this select 0) progressSetPosition 0.7";
		};
		class ButtonClose: SG_ctrlButtonClose {
			x = 0.656288 * safezoneW + safezoneX;
			y = 0.2866 * safezoneH + safezoneY;
			w = 0.0104192 * safezoneW;
			h = 0.0185185 * safezoneH;
		};
	};
};