class perk_civilian_master {
	displayName = "Civilian Perks";
	requiredPerkPoints = 1;
	requiredLevel = 1;
	requiredPerk = "";
	subtitle = "1 point required to unlock this tree";
	description = "Learn and improve on civilian specific perks";
	initScript = "";
	limitToSides[] = {"CIV"};
	color[] = {0,0.6,0,1};
};

class perk_processing_1 {
	displayName = "Processing Speed";
	requiredPerkPoints = 3;
	requiredLevel = 4;
	requiredPerk = "perk_civilian_master";
	subtitle = "Level 4 Required, 3 Perk Points";
	description = "Learn to process materials more efficiently<br/><br/><t color='#10FF45'>+10% faster processing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_processSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_processing_2 {
	displayName = "Processing Speed 2";
	requiredPerkPoints = 3;
	requiredLevel = 8;
	requiredPerk = "perk_processing_1";
	subtitle = "Level 8 Required, 3 Perk Points";
	description = "Learn to process materials more efficiently<br/><br/><t color='#10FF45'>+20% faster processing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_processSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_processing_3 {
	displayName = "Processing Speed 3";
	requiredPerkPoints = 6;
	requiredLevel = 16;
	requiredPerk = "perk_processing_2";
	subtitle = "Level 16 Required, 6 Perk Points";
	description = "Learn to process materials more efficiently<br/><br/><t color='#10FF45'>+30% faster processing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_processSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_processing_4 {
	displayName = "Processing Speed 4";
	requiredPerkPoints = 9;
	requiredLevel = 24;
	requiredPerk = "perk_processing_3";
	subtitle = "Level 24 Required, 9 Perk Points";
	description = "Learn to process materials more efficiently<br/><br/><t color='#10FF45'>+40% faster processing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_processSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_processing_5 {
	displayName = "Processing Speed 5";
	requiredPerkPoints = 11;
	requiredLevel = 30;
	requiredPerk = "perk_processing_4";
	subtitle = "Level 30 Required, 11 Perk Points";
	description = "Learn to process materials more efficiently<br/><br/><t color='#10FF45'>+50% faster processing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_processSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_processing_6 {
	displayName = "Processing Speed 6";
	requiredPerkPoints = 14;
	requiredLevel = 45;
	requiredPerk = "perk_processing_5";
	subtitle = "Level 45 Required, 14 Perk Points";
	description = "Learn to process materials more efficiently<br/><br/><t color='#10FF45'>+65% faster processing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_processSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_gathering_1 {
	displayName = "Gathering Speed";
	requiredPerkPoints = 3;
	requiredLevel = 4;
	requiredPerk = "perk_civilian_master";
	subtitle = "Level 4 Required, 3 Perk Points";
	description = "Learn to move your hands a bit faster while gathering<br/><br/><t color='#10FF45'>+10% faster gathering</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_gatherSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_gathering_2 {
	displayName = "Gathering Speed 2";
	requiredPerkPoints = 3;
	requiredLevel = 7;
	requiredPerk = "perk_gathering_1";
	subtitle = "Level 7 Required, 3 Perk Points";
	description = "Learn to move your hands a bit faster while gathering<br/><br/><t color='#10FF45'>+15% faster gathering</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_gatherSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_gathering_3 {
	displayName = "Gathering Speed 3";
	requiredPerkPoints = 4;
	requiredLevel = 13;
	requiredPerk = "perk_gathering_2";
	subtitle = "Level 13 Required, 4 Perk Points";
	description = "Learn to move your hands a bit faster while gathering<br/><br/><t color='#10FF45'>+25% faster gathering</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_gatherSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_farmingMultiplier_1 {
	displayName = "Harvesting Multiplier";
	requiredPerkPoints = 3;
	requiredLevel = 7;
	requiredPerk = "perk_civilian_master";
	subtitle = "Level 7 Required, 3 Perk Points";
	description = "Learn to harvest more efficiently<br/><br/><t color='#10FF45'>+25% more product when harvesting</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_farmingMultiplier.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_farmingMultiplier_2 {
	displayName = "Harvesting Multiplier 2";
	requiredPerkPoints = 6;
	requiredLevel = 14;
	requiredPerk = "perk_farmingMultiplier_1";
	subtitle = "Level 14 Required, 6 Perk Points";
	description = "Learn to harvest more efficiently<br/><br/><t color='#10FF45'>+50% more product when harvesting</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_farmingMultiplier.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_farmingMultiplier_3 {
	displayName = "Harvesting Multiplier 3";
	requiredPerkPoints = 8;
	requiredLevel = 21;
	requiredPerk = "perk_farmingMultiplier_2";
	subtitle = "Level 21 Required, 8 Perk Points";
	description = "Learn to harvest more efficiently<br/><br/><t color='#10FF45'>+75% more product when harvesting</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_farmingMultiplier.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class functions_air {
	displayName = "Aviation Training";
	requiredPerkPoints = 5;
	requiredLevel = 11;
	requiredPerk = "perk_civilian_master";
	subtitle = "Level 11 Required, 5 Perk Points";
	description = "Gain access to the air shops to buy aircraft";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_air.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class functions_home {
	displayName = "Home Ownership";
	requiredPerkPoints = 8;
	requiredLevel = 16;
	requiredPerk = "perk_civilian_master";
	subtitle = "Level 16 Required, 8 Perk Points";
	description = "Gain the ability to own your own house";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_home.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_police_master {
	displayName = "Police Perks";
	requiredPerkPoints = 1;
	requiredLevel = 1;
	requiredPerk = "";
	subtitle = "1 point required to unlock this tree";
	description = "Learn and improve on police specific perks";
	initScript = "";
	limitToSides[] = {"WEST","EAST"};
	color[] = {0,0,0.6,1};
};

class functions_impoundSpeed_1 {
	displayName = "Impounding";
	requiredPerkPoints = 3;
	requiredLevel = 5;
	requiredPerk = "perk_police_master";
	subtitle = "Level 5 Required, 3 Perk Points";
	description = "You can impound vehicles more efficiently<br/><br/><t color='#10FF45'>100% faster impounding</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_impoundSpeed.sqf";
	limitToSides[] = {"WEST","EAST"};
	color[] = {1,1,1,1};
};

class functions_impoundSpeed_2 {
	displayName = "Impounding 2";
	requiredPerkPoints = 5;
	requiredLevel = 12;
	requiredPerk = "functions_impoundSpeed_1";
	subtitle = "Level 12 Required, 5 Perk Points";
	description = "You can impound vehicles more efficiently<br/><br/><t color='#10FF45'>200% faster impounding</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_impoundSpeed.sqf";
	limitToSides[] = {"WEST","EAST"};
	color[] = {1,1,1,1};
};

class perk_global_master {
	displayName = "Global Perks";
	requiredPerkPoints = 1;
	requiredLevel = 1;
	requiredPerk = "";
	subtitle = "1 point required to unlock this tree";
	description = "General perks for everyone to level up";
	initScript = "";
	limitToSides[] = {};
	color[] = {0.2,0.5,0.3,1};
};

class perk_carryweight_1 {
	displayName = "Carry Weight Increase 1";
	requiredPerkPoints = 3;
	requiredLevel = 5;
	requiredPerk = "perk_global_master";
	subtitle = "Level 5 Required, 3 Perk Points";
	description = "Earn the ability to carry <br/><br/><t color='#10FF45'>25% more items!</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_carryweight.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_carryweight_2 {
	displayName = "Carry Weight Increase 2";
	requiredPerkPoints = 6;
	requiredLevel = 15;
	requiredPerk = "perk_carryweight_1";
	subtitle = "Level 15 Required, 6 Perk Points";
	description = "Earn the ability to carry <br/><br/><t color='#10FF45'>50% more items!</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_carryweight.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_carryweight_3 {
	displayName = "Carry Weight Increase 3";
	requiredPerkPoints = 10;
	requiredLevel = 30;
	requiredPerk = "perk_carryweight_2";
	subtitle = "Level 30 Required, 10 Perk Points";
	description = "Earn the ability to carry <br/><br/><t color='#10FF45'>75% more items!</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_carryweight.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_evidence_1 {
	displayName = "Evidence 25% Faster";
	color[] = {1,1,1,1};
	requiredPerkPoints = 5;
	requiredLevel = 10;
	requiredPerk = "perk_global_master";
	subtitle = "Level 10 Required, 5 Perk Points";
	description = "You will be able to pickup/destroy evidence 25% faster.";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_evidence.sqf";
};

class perk_evidence_2 {
	displayName = "Evidence 50% Faster";
	color[] = {1,1,1,1};
	requiredPerkPoints = 7;
	requiredLevel = 13;
	requiredPerk = "perk_evidence_1";
	subtitle = "Level 13 Required, 7 Perk Points";
	description = "You will be able to pickup/destroy evidence 50% faster.";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_evidence.sqf";
};

class perk_paycheck_1 {
	displayName = "Paycheck";
	requiredPerkPoints = 2;
	requiredLevel = 2;
	requiredPerk = "perk_global_master";
	subtitle = "Level 2 Required, 2 Perk Points";
	description = "Receive more money on a paycheck<br/><br/><t color='#10FF45'>+20% more money per paycheck</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_paycheckIncrease.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_paycheck_2 {
	displayName = "Paycheck 2";
	requiredPerkPoints = 3;
	requiredLevel = 8;
	requiredPerk = "perk_paycheck_1";
	subtitle = "Level 8 Required, 3 Perk Points";
	description = "Receive more money on a paycheck<br/><br/><t color='#10FF45'>+35% more money per paycheck</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_paycheckIncrease.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_paycheck_3 {
	displayName = "Paycheck 3";
	requiredPerkPoints = 7;
	requiredLevel = 21;
	requiredPerk = "perk_paycheck_2";
	subtitle = "Level 21 Required, 7 Perk Points";
	description = "Receive more money on a paycheck<br/><br/><t color='#10FF45'>+75% more money per paycheck</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_paycheckIncrease.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_paycheck_4 {
	displayName = "Paycheck 4";
	requiredPerkPoints = 15;
	requiredLevel = 33;
	requiredPerk = "perk_paycheck_3";
	subtitle = "Level 33 Required, 15 Perk Points";
	description = "Receive more money on a paycheck<br/><br/><t color='#10FF45'>+100% more money per paycheck</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_paycheckIncrease.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_paycheck_5 {
	displayName = "Direct Deposit";
	requiredPerkPoints = 8;
	requiredLevel = 42;
	requiredPerk = "perk_paycheck_4";
	subtitle = "Level 42 Required, 8 Perk Points";
	description = "Your paycheck is directly deposited into your bank account.";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_directDeposit.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class functions_repairSpeed_1 {
	displayName = "Repairing Speed";
	requiredPerkPoints = 2;
	requiredLevel = 6;
	requiredPerk = "perk_global_master";
	subtitle = "Level 6 Required, 2 Perk Points";
	description = "You can repair vehicles more efficiently<br/><br/><t color='#10FF45'>35% faster repairing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_repairSpeed.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class functions_repairSpeed_2 {
	displayName = "Repairing Speed 2";
	requiredPerkPoints = 4;
	requiredLevel = 12;
	requiredPerk = "functions_repairSpeed_1";
	subtitle = "Level 12 Required, 4 Perk Points";
	description = "You can repair vehicles more efficiently<br/><br/><t color='#10FF45'>45% faster repairing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_repairSpeed.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class functions_repairSpeed_3 {
	displayName = "Repairing Speed 3";
	requiredPerkPoints = 6;
	requiredLevel = 24;
	requiredPerk = "functions_repairSpeed_2";
	subtitle = "Level 24 Required, 6 Perk Points";
	description = "You can repair vehicles more efficiently<br/><br/><t color='#10FF45'>55% faster repairing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_repairSpeed.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class functions_repairSpeed_4 {
	displayName = "Repairing Speed 4";
	requiredPerkPoints = 10;
	requiredLevel = 32;
	requiredPerk = "functions_repairSpeed_3";
	subtitle = "Level 32 Required, 10 Perk Points";
	description = "You can repair vehicles more efficiently<br/><br/><t color='#10FF45'>65% faster repairing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_repairSpeed.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class functions_repairSpeed_5 {
	displayName = "Repairing Speed 5";
	requiredPerkPoints = 14;
	requiredLevel = 45;
	requiredPerk = "functions_repairSpeed_4";
	subtitle = "Level 45 Required, 14 Perk Points";
	description = "You can repair vehicles more efficiently<br/><br/><t color='#10FF45'>75% faster repairing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_repairSpeed.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class functions_NoToolKit {
	displayName = "No Toolkit Repair";
	requiredPerkPoints = 18;
	requiredLevel = 60;
	requiredPerk = "functions_repairSpeed_5";
	subtitle = "Level 60 Required, 18 Perk Points";
	description = "You can now repair vehicles at max speed without a toolkit!</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_noToolkit.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class functions_LowGearMode {
	displayName = "Manual Drive Training";
	requiredPerkPoints = 10;
	requiredLevel = 12;
	requiredPerk = "perk_global_master";
	subtitle = "Level 12 Required, 10 Perk Points";
	description = "Allows you to use Low Gear Mode when driving a vehicle.</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_lowGearInit.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

/*class perk_killfeed {
	displayName = "Killfeed";
	requiredPerkPoints = 3;
	requiredLevel = 7;
	requiredPerk = "perk_global_master";
	subtitle = "Level 7 Required, 3 Perk Points";
	description = "Get access to see the conventional killfeed.";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_killfeed.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};*/

/*class functions_stamina {
	displayName = "Unlimited Stamina";
	requiredPerkPoints = 3;
	requiredLevel = 7;
	requiredPerk = "perk_global_master";
	subtitle = "Level 7 Required, 3 Perk Points";
	description = "Stamina<br/><br/><t color='#10FF45'>No longer run out of stamina, ever. If purchased, relog to see effect take place.</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_stamina.sqf";
	limitToSides[] = {};
	respawn = 1;
	color[] = {1,1,1,1};
};*/

class perk_medical {
	displayName = "Medical Perks";
	color[] = {0.75,0.04,0.19,1};
	requiredPerkPoints = 1;
	requiredLevel = 1;
	requiredPerk = "";
	limitToSides[] = {};
	subtitle = "1 point required to unlock this tree";
	description = "Learn and improve on medical specific perks";
};

class perk_insurance {
	displayName = "Health Insurance";
	color[] = {1,1,1,1};
	requiredPerkPoints = 5;
	requiredLevel = 9;
	requiredPerk = "perk_medical";
	subtitle = "Level 9 Required, 5 Perk Points";
	description = "You only pay 50% of the medical fees when you are revived by medics!";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_insurance.sqf";
};

class perk_insurance2 {
	displayName = "Full Coverage Health Insurance";
	color[] = {1,1,1,1};
	requiredPerkPoints = 12;
	requiredLevel = 22;
	requiredPerk = "perk_insurance";
	subtitle = "Level 22 Required, 12 Perk Points";
	description = "Your medical insurance covers all of your medical fees when revived by medics!";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_insurance.sqf";
};

class perk_cpr_1 {
	displayName = "25% CPR Chance";
	color[] = {1,1,1,1};
	requiredPerkPoints = 7;
	requiredLevel = 5;
	requiredPerk = "perk_medical";
	subtitle = "Level 5 Required, 7 Perk Points";
	description = "Increase your CPR chance from 20% to 25%";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_cpr.sqf";
};

class perk_cpr_2 {
	displayName = "50% CPR Chance";
	color[] = {1,1,1,1};
	requiredPerkPoints = 7;
	requiredLevel = 15;
	requiredPerk = "perk_cpr_1";
	subtitle = "Level 15 Required, 7 Perk Points";
	description = "Increase your CPR chance from 25% to 50%";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_cpr.sqf";
};

class perk_cpr_3 {
	displayName = "75% CPR Chance";
	color[] = {1,1,1,1};
	requiredPerkPoints = 10;
	requiredLevel = 20;
	requiredPerk = "perk_cpr_2";
	subtitle = "Level 20 Required, 10 Perk Points";
	description = "Increase your CPR chance from 50% to 75%";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_cpr.sqf";
};

class perk_cpr_4 {
	displayName = "100% CPR Chance";
	color[] = {1,1,1,1};
	requiredPerkPoints = 14;
	requiredLevel = 25;
	requiredPerk = "perk_cpr_3";
	subtitle = "Level 25 Required, 14 Perk Points";
	description = "Increase your CPR chance from 75% to 100%";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_cpr.sqf";
};

class perk_cpr_full {
	displayName = "Full CPR HP";
	color[] = {1,1,1,1};
	requiredPerkPoints = 7;
	requiredLevel = 21;
	requiredPerk = "perk_cpr_4";
	subtitle = "Level 21 Required, 7 Perk Points";
	description = "Reviving a player will fully heal them.";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_cpr_full.sqf";
};

class perk_stabalizeLength_1 {
	displayName = "Stabalize Length 1";
	color[] = {1,1,1,1};
	requiredPerkPoints = 3;
	requiredLevel = 9;
	requiredPerk = "perk_medical";
	subtitle = "Level 9 Required, 3 Perk Points";
	description = "Increase your stabalize length from 1 minute to 2 minutes";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_stabalizeLength.sqf";
};

class perk_stabalizeLength_2 {
	displayName = "Stabalize Length 2";
	color[] = {1,1,1,1};
	requiredPerkPoints = 5;
	requiredLevel = 11;
	requiredPerk = "perk_stabalizeLength_1";
	subtitle = "Level 11 Required, 5 Perk Points";
	description = "Increase your stabalize length from 2 minute to 3 minutes";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_stabalizeLength.sqf";
};

class perk_bandage_1 {
	displayName = "Bandage Heal 90";
	color[] = {1,1,1,1};
	requiredPerkPoints = 2;
	requiredLevel = 2;
	requiredPerk = "perk_medical";
	subtitle = "Level 2 Required, 2 Perk Points";
	description = "Increase your bandage heals from 80 to 90";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_bandage.sqf";
};

class perk_bandage_2 {
	displayName = "Bandage Heal 100";
	color[] = {1,1,1,1};
	requiredPerkPoints = 3;
	requiredLevel = 5;
	requiredPerk = "perk_bandage_1";
	subtitle = "Level 5 Required, 3 Perk Points";
	description = "Increase your bandage heals from 90 to 100";	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_bandage.sqf";
};

class perk_medicalSpeed_1 {
	displayName = "Combat Medic";
	color[] = {1,1,1,1};
	requiredPerkPoints = 3;
	requiredLevel = 8;
	requiredPerk = "perk_medical";
	subtitle = "Level 8 Required, 3 Perk Points";
	description = "Provide medical treatment more efficiently<br/><br/><t color='#10FF45'>25% faster at providing medical treatment</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_medicalSpeed.sqf";
};

class perk_medicalSpeed_2 {
	displayName = "Medical Technician";
	color[] = {1,1,1,1};
	requiredPerkPoints = 4;
	requiredLevel = 16;
	requiredPerk = "perk_medicalSpeed_1";
	subtitle = "Level 16 Required, 4 Perk Points";
	description = "Provide medical treatment more efficiently<br/><br/><t color='#10FF45'>50% faster at providing medical treatment</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_medicalSpeed.sqf";
};

class perk_gunsspecialist_master {
	displayName = "Weapon Perks";
	requiredPerkPoints = 1;
	requiredLevel = 1;
	requiredPerk = "";
	subtitle = "1 point required to unlock this tree";
	description = "Learn and improve on your weapon skills";
	initScript = "";
	limitToSides[] = {"CIV","WEST","EAST"};
	color[] = {0.85,0.7,0,1};
};

class perk_gunsspecialist_lessRecoil_1 {
	displayName = "Less Recoil";
	requiredPerkPoints = 5;
	requiredLevel = 5;
	requiredPerk = "perk_gunsspecialist_master";
	subtitle = "Level 5 Required, 5 Perk Points";
	description = "Learn to control weapons better and lower the noticable recoil<br/><br/><t color='#10FF45'>-5% less recoil</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_recoilCompensation.sqf";
	limitToSides[] = {};
	respawn = 1;
	color[] = {1,1,1,1};
};

class perk_gunsspecialist_lessRecoil_2 {
	displayName = "Less Recoil 2";
	requiredPerkPoints = 6;
	requiredLevel = 10;
	requiredPerk = "perk_gunsspecialist_lessRecoil_1";
	subtitle = "Level 10 Required, 6 Perk Points";
	description = "Learn to control weapons better and lower the noticable recoil<br/><br/><t color='#10FF45'>-10% less recoil</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_recoilCompensation.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_gunsspecialist_lessRecoil_3 {
	displayName = "Less Recoil 3";
	requiredPerkPoints = 7;
	requiredLevel = 15;
	requiredPerk = "perk_gunsspecialist_lessRecoil_2";
	subtitle = "Level 15 Required, 7 Perk Points";
	description = "Learn to control weapons better and lower the noticable recoil<br/><br/><t color='#10FF45'>-15% less recoil</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_recoilCompensation.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_gunsspecialist_lessRecoil_4 {
	displayName = "Less Recoil 4";
	requiredPerkPoints = 9;
	requiredLevel = 25;
	requiredPerk = "perk_gunsspecialist_lessRecoil_3";
	subtitle = "Level 25 Required, 9 Perk Points";
	description = "Learn to control weapons better and lower the noticable recoil<br/><br/><t color='#10FF45'>-20% less recoil</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_recoilCompensation.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_gunsspecialist_lessRecoil_5 {
	displayName = "Less Recoil 5";
	requiredPerkPoints = 12;
	requiredLevel = 35;
	requiredPerk = "perk_gunsspecialist_lessRecoil_4";
	subtitle = "Level 35 Required, 12 Perk Points";
	description = "Learn to control weapons better and lower the noticable recoil<br/><br/><t color='#10FF45'>-25% less recoil</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_recoilCompensation.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_gunsspecialist_lessRecoil_6 {
	displayName = "Less Recoil 6";
	requiredPerkPoints = 12;
	requiredLevel = 50;
	requiredPerk = "perk_gunsspecialist_lessRecoil_5";
	subtitle = "Level 50 Required, 12 Perk Points";
	description = "Learn to control weapons better and lower the noticable recoil<br/><br/><t color='#10FF45'>-30% less recoil</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_recoilCompensation.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_gunsspecialist_lessRecoil_7 {
	displayName = "Less Recoil 7";
	requiredPerkPoints = 14;
	requiredLevel = 60;
	requiredPerk = "perk_gunsspecialist_lessRecoil_6";
	subtitle = "Level 60 Required, 14 Perk Points";
	description = "Learn to control weapons better and lower the noticable recoil<br/><br/><t color='#10FF45'>-35% less recoil</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_recoilCompensation.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_gunsspecialist_lessRecoil_8 {
	displayName = "Less Recoil 8";
	requiredPerkPoints = 16;
	requiredLevel = 70;
	requiredPerk = "perk_gunsspecialist_lessRecoil_7";
	subtitle = "Level 70 Required, 16 Perk Points";
	description = "Learn to control weapons better and lower the noticable recoil<br/><br/><t color='#10FF45'>-40% less recoil</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_recoilCompensation.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_gunsspecialist_lessRecoil_9 {
	displayName = "Less Recoil 9";
	requiredPerkPoints = 18;
	requiredLevel = 80;
	requiredPerk = "perk_gunsspecialist_lessRecoil_8";
	subtitle = "Level 80 Required, 18 Perk Points";
	description = "Learn to control weapons better and lower the noticable recoil<br/><br/><t color='#10FF45'>-45% less recoil</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_recoilCompensation.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_gunsspecialist_lessRecoil_10 {
	displayName = "Less Recoil 10";
	requiredPerkPoints = 20;
	requiredLevel = 100;
	requiredPerk = "perk_gunsspecialist_lessRecoil_9";
	subtitle = "Level 100 Required, 20 Perk Points";
	description = "Learn to control weapons better and lower the noticable recoil<br/><br/><t color='#10FF45'>-50% less recoil</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_recoilCompensation.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_weaponSway_1 {
	displayName = "Weapon Sway Control";
	requiredPerkPoints = 3;
	requiredLevel = 6;
	requiredPerk = "perk_gunsspecialist_master";
	subtitle = "Level 6 Required, 3 Perk Points";
	description = "Learn to control weapons better with lower overall weapon sway<br/><br/><t color='#10FF45'>-5% less weapon sway</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_weaponSway.sqf";
	limitToSides[] = {};
	respawn = 1;
	color[] = {1,1,1,1};
};

class perk_weaponSway_2 {
	displayName = "Weapon Sway Control 2";
	requiredPerkPoints = 6;
	requiredLevel = 18;
	requiredPerk = "perk_weaponSway_1";
	subtitle = "Level 18 Required, 6 Perk Points";
	description = "Learn to control weapons better with lower overall weapon sway<br/><br/><t color='#10FF45'>-10% less weapon sway</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_weaponSway.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_weaponSway_3 {
	displayName = "Weapon Sway Control 3";
	requiredPerkPoints = 8;
	requiredLevel = 35;
	requiredPerk = "perk_weaponSway_2";
	subtitle = "Level 35 Required, 8 Perk Points";
	description = "Learn to control weapons better with lower overall weapon sway<br/><br/><t color='#10FF45'>-20% less weapon sway</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_weaponSway.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_weaponSway_4 {
	displayName = "Weapon Sway Control 4";
	requiredPerkPoints = 19;
	requiredLevel = 58;
	requiredPerk = "perk_weaponSway_3";
	subtitle = "Level 58 Required, 19 Perk Points";
	description = "Learn to control weapons better with lower overall weapon sway<br/><br/><t color='#10FF45'>-35% less weapon sway</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_weaponSway.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_weaponSway_5 {
	displayName = "Weapon Sway Control 5";
	requiredPerkPoints = 24;
	requiredLevel = 75;
	requiredPerk = "perk_weaponSway_4";
	subtitle = "Level 75 Required, 24 Perk Points";
	description = "Learn to control weapons better with lower overall weapon sway<br/><br/><t color='#10FF45'>-50% less weapon sway</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_weaponSway.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class perk_illegal_master {
	displayName = "Illegal Perks";
	requiredPerkPoints = 1;
	requiredLevel = 3;
	requiredPerk = "";
	subtitle = "Level 3 / 1 point required to unlock this tree";
	description = "Learn and improve on perks focused around illegal activities";
	initScript = "";
	limitToSides[] = {"CIV"};
	color[] = {0.6,0,0,1};
};

class perk_DMT {
	displayName = "Toad Gathering";
	requiredPerkPoints = 5;
	requiredLevel = 15;
	requiredPerk = "perk_illegal_master";
	subtitle = "Level 15 Required, 5 Perk Points";
	description = "Learn to gather magic toads to make DMT<br/>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_dmt.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_doubleProcess {
	displayName = "Double Processing";
	requiredPerkPoints = 19;
	requiredLevel = 32;
	requiredPerk = "perk_illegal_master";
	subtitle = "Level 32 Required, 19 Perk Points";
	description = "Gain the ability to process drugs into a refined form.<br/><br/><t color='#10FF45'>Refined drugs sell for significantly more money at the drug dealer.</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_doubleProcess.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

// class perk_processing_cost_1 {
// 	displayName = "Processing Cost";
// 	requiredPerkPoints = 3;
// 	requiredLevel = 6;
// 	requiredPerk = "perk_illegal_master";
// 	subtitle = "Level 6 Required, 3 Perk Points";
// 	description = "Reduces the cost for processing drugs<br/><br/><t color='#10FF45'>-20% processing cost</t>";
// 	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_processCost.sqf";
// 	limitToSides[] = {"CIV"};
// 	color[] = {1,1,1,1};
// };

// class perk_processing_cost_2 {
// 	displayName = "Processing Cost 2";
// 	requiredPerkPoints = 8;
// 	requiredLevel = 17;
// 	requiredPerk = "perk_processing_cost_2";
// 	subtitle = "Level 17 Required, 9 Perk Points";
// 	description = "Further reduces the cost for processing drugs<br/><br/><t color='#10FF45'>-50% processing cost</t>";
// 	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_processCost.sqf";
// 	limitToSides[] = {"CIV"};
// 	color[] = {1,1,1,1};
// };

// class perk_processing_cost_3 {
// 	displayName = "Processing Cost 3";
// 	requiredPerkPoints = 11;
// 	requiredLevel = 35;
// 	requiredPerk = "perk_processing_cost_3";
// 	subtitle = "Level 35 Required, 11 Perk Points";
// 	description = "Completely removes the cost for processing drugs<br/><br/><t color='#10FF45'>-100% processing cost</t>";
// 	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_processCost.sqf";
// 	limitToSides[] = {"CIV"};
// 	color[] = {1,1,1,1};
// };

// class functions_uranium {
// 	displayName = "Uranium Gathering";
// 	requiredPerkPoints = 8;
// 	requiredLevel = 20;
// 	requiredPerk = "perk_lsd_1";
// 	subtitle = "Level 20 Required, 8 Perk Points";
// 	description = "Learn to gather uranium to process and sell for major profit<br/><br/><t color='#10FF45'>Estimated at 45% more profit than cocaine</t>";
// 	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_uranium.sqf";
// 	limitToSides[] = {"CIV"};
// 	color[] = {1,1,1,1};
// };

class perk_locksmith_1 {
	displayName = "Locksmith";
	requiredPerkPoints = 3;
	requiredLevel = 7;
	requiredPerk = "perk_illegal_master";
	subtitle = "Level 7 Required, 3 Perk Points";
	description = "Learn to pick locks more efficiently and reduce lockpicking times on vehicles<br/><br/><t color='#10FF45'>+10% faster lockpicking</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_lockpickSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_locksmith_2 {
	displayName = "Locksmith 2";
	requiredPerkPoints = 5;
	requiredLevel = 16;
	requiredPerk = "perk_locksmith_1";
	subtitle = "Level 16 Required, 5 Perk Points";
	description = "Learn to pick locks more efficiently and reduce lockpicking times on vehicles<br/><br/><t color='#10FF45'>+15% faster lockpicking</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_lockpickSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_locksmith_3 {
	displayName = "Locksmith 3";
	requiredPerkPoints = 7;
	requiredLevel = 23;
	requiredPerk = "perk_locksmith_2";
	subtitle = "Level 23 Required, 7 Perk Points";
	description = "Learn to pick locks more efficiently and reduce lockpicking times on vehicles<br/><br/><t color='#10FF45'>+25% faster lockpicking</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_lockpickSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_locksmith_4 {
	displayName = "Locksmith 4";
	requiredPerkPoints = 9;
	requiredLevel = 29;
	requiredPerk = "perk_locksmith_3";
	subtitle = "Level 28 Required, 9 Perk Points";
	description = "Learn to pick locks more efficiently and reduce lockpicking times on vehicles<br/><br/><t color='#10FF45'>+45% faster lockpicking</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_lockpickSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_locksmith_5 {
	displayName = "Locksmith 5";
	requiredPerkPoints = 12;
	requiredLevel = 36;
	requiredPerk = "perk_locksmith_4";
	subtitle = "Level 36 Required, 12 Perk Points";
	description = "Learn to pick locks more efficiently and reduce lockpicking times on vehicles<br/><br/><t color='#10FF45'>+75% faster lockpicking</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_lockpickSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_boltspeed_1 {
	displayName = "Bolt Speed";
	requiredPerkPoints = 3;
	requiredLevel = 15;
	requiredPerk = "perk_illegal_master";
	subtitle = "Level 15 Required, 3 Perk Points";
	description = "Learn to bolt doors more efficiently!<br/><br/><t color='#10FF45'>+10% faster bolting</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_boltSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

class perk_boltspeed_2 {
	displayName = "Bolt Speed";
	requiredPerkPoints = 5;
	requiredLevel = 20;
	requiredPerk = "perk_boltspeed_1";
	subtitle = "Level 20 Required, 5 Perk Points";
	description = "Learn to bolt doors more efficiently!<br/><br/><t color='#10FF45'>+20% faster bolting</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_boltSpeed.sqf";
	limitToSides[] = {"CIV"};
	color[] = {1,1,1,1};
};

// class perk_rebel {
// 	displayName = "Become a Rebel";
// 	requiredPerkPoints = 3;
// 	requiredLevel = 10;
// 	requiredPerk = "perk_illegal_master";
// 	subtitle = "Level 10 Required, 3 Perk Points";
// 	description = "Get access to a weapon shop and illegal items to make sure you are one step ahead of your enemies.";
// 	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_rebel.sqf";
// 	limitToSides[] = {"CIV","EAST"};
// 	color[] = {1,1,1,1};
// };

class perk_gasrobbery {
	displayName = "Armed Robbery";
	requiredPerkPoints = 6;
	requiredLevel = 17;
	requiredPerk = "perk_illegal_master";
	subtitle = "Level 17 Required, 6 Perk Points";
	description = "Learn to intimidate gas station clerks and banks more efficiently<br/><br/><t color='#10FF45'>+50% faster robbing</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_gasrobbery.sqf";
	limitToSides[] = {"CIV","EAST"};
	color[] = {1,1,1,1};
};

// class perk_policecheck_1 {
// 	displayName = "Checkpoint Detection";
// 	requiredPerkPoints = 6;
// 	requiredLevel = 35;
// 	requiredPerk = "perk_illegal_master";
// 	subtitle = "Level 35 Required, 6 Perk Points";
// 	description = "Get a notification and a mark on your map when police set up a checkpoint, be one step ahead of them with this perk.";
// 	initScript = "";
// 	limitToSides[] = {"CIV","EAST"};
// 	color[] = {1,1,1,1};
// };

class functions_quests {
	displayName = "Quests";
	requiredPerkPoints = 2;
	requiredLevel = 5;
	requiredPerk = "";
	subtitle = "Level 5 Required, 2 Perk Points";
	description = "Begin your journey with questing, quests give good xp and allow you to do things others cant!";
	initScript = "";
	limitToSides[] = {};
	color[] = {0,0.46,0.76,1};
};

class functions_relicReward {
	displayName = "Quest: Collecting Relics - Part 1";
	requiredPerkPoints = 9999;
	requiredLevel = 1;
	requiredPerk = "functions_quests";
	subtitle = "Collecting Hidden Relics";
	description = "Bring all the hidden relics around the map (4) to the archeologist <br/><br/><t color='#10FF45'>Reward: 12,500 XP</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_relicReward.sqf";
	limitToSides[] = {};
	color[] = {0.024,0.337,0.145,1.0};
};

class functions_relicReward2 {
	displayName = "Quest: Collecting Relics - Part 2";
	requiredPerkPoints = 9999;
	requiredLevel = 1;
	requiredPerk = "functions_relicReward";
	subtitle = "Major Crime Relics";
	description = "Collect all three Relics from each of the Major Crimes, this one could be tricky to do as you need to turn in all three at once. I suggest putting them in your house until you have all three.<br/><br/><t color='#10FF45'>Reward: 20,000 XP</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_relicReward2.sqf";
	limitToSides[] = {};
	color[] = {0.992,0.514,0.071,1.0};
};
/*
class functions_relicReward3 {
	displayName = "Quest: Collecting The Lost Flight Plan";
	requiredPerkPoints = 9999;
	requiredLevel = 1;
	requiredPerk = "functions_relicReward2";
	subtitle = "Lost Flight Plan";
	description = "Scavenge the three shipwrecks on the map to find pieces of the flight plan of the plane that was rumored to be carrying an alien artifact.<br/><br/><t color='#10FF45'>Reward: 7,500 XP</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_relicReward3.sqf";
	limitToSides[] = {};
	color[] = {0.463,0.118,0.118,1.0};
};

class functions_antiMatter {
	displayName = "Quest: The Lost Aircraft";
	requiredPerkPoints = 9999;
	requiredLevel = 1;
	requiredPerk = "functions_relicReward3";
	subtitle = "Find the Missing Plane";
	description = "0xxx5xxx7xx9x3xxx4Grid.xyzxsaHD*CooRDxx234s.csdf.resdf<br/><br/><t color='#10FF45'>Reward: 10,000 XP</t>";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_antiMatter.sqf";
	limitToSides[] = {};
	color[] = {0.122,0.122,0.122,1.0};
};*/

class functions_bleedoutTime1 {
	displayName = "Bleedout Time 1";
	requiredPerkPoints = 8;
	requiredLevel = 12;
	requiredPerk = "perk_medical";
	subtitle = "Extends bleedout time";
	description = "You take 50% longer to bleedout! You are still able to respawn in same amount of time!";
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_bleedout.sqf";
	limitToSides[] = {};
	color[] = {1,1,1,1};
};

class functions_organHarvest {
	displayName = "Organ Harvesting";
	requiredPerkPoints = 1;
	requiredLevel = 31;
	requiredPerk = "perk_illegal_master";
	subtitle = "Level 31 Required, 1 Perk Point";
	description = "Why not?";
	initScript = "";
	limitToSides[] = {"CIV"};
	color[] = {0,0.46,0.76,1};
};
class organHarvestLungs {
	displayName = "Harvest Lungs";
	requiredPerkPoints = 3;
	requiredLevel = 31;
	requiredPerk = "functions_organHarvest";
	subtitle = "Level 31 Required, 3 Perk Points";
	description = "You will be able to harvest Lungs.";	
	limitToSides[] = {"CIV"};
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_organHarvest.sqf";
};
class organHarvestLiver {
	displayName = "Harvest Liver";
	requiredPerkPoints = 3;
	requiredLevel = 36;
	requiredPerk = "functions_organHarvest";
	subtitle = "Level 36 Required, 3 Perk Points";
	description = "You will be able to harvest Livers.";
	limitToSides[] = {"CIV"};	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_organHarvest.sqf";
};
class organHarvestKidney {
	displayName = "Harvest Kidney";
	requiredPerkPoints = 5;
	requiredLevel = 41;
	requiredPerk = "functions_organHarvest";
	subtitle = "Level 41 Required, 5 Perk Points";
	description = "You will be able to harvest Kidneys.";
	limitToSides[] = {"CIV"};	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_organHarvest.sqf";
};
class organHarvestHeart {
	displayName = "Harvest Heart";
	requiredPerkPoints = 5;
	requiredLevel = 46;
	requiredPerk = "functions_organHarvest";
	subtitle = "Level 46 Required, 5 Perk Points";
	description = "You will be able to harvest Hearts.";
	limitToSides[] = {"CIV"};	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_organHarvest.sqf";
};
class organHarvestBrain {
	displayName = "Harvest Brain";
	requiredPerkPoints = 5;
	requiredLevel = 51;
	requiredPerk = "functions_organHarvest";
	subtitle = "Level 51 Required, 5 Perk Points";
	description = "You will be able to harvest Brains.";
	limitToSides[] = {"CIV"};	
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_organHarvest.sqf";
};

class organHarvestDingus {
	displayName = "Harvest Dingus";
	requiredPerkPoints = 5;
	requiredLevel = 56;
	requiredPerk = "functions_organHarvest";
	subtitle = "Level 56 Required, 5 Perk Points";
	description = "You will be able to harvest a literal cock. Recommend gloves.";	
	limitToSides[] = {"CIV"};
	initScript = "maverick\talent-tree-modular\modules\maverick_perkset_1\functions\functions_organHarvest.sqf";
};