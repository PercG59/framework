class VehiclePurchased {
	expToAdd = 100;
	message = "Vehicle Purchased";
	name = "Vehicle Purchased";
};

class ItemProcessed {
	expToAdd = 40;
	message = "Items Processed (40xp per item you processed)";
	name = "Item Processed";
};

class ItemSmelted {
	expToAdd = 20;
	message = "Items Processed (20xp per item)";
	name = "Item Smelted";
};

class ItemRefined {
	expToAdd = 30;
	message = "Items Processed (30xp per item)";
	name = "Item Refined";
};

class VehicleLockpicked {
	expToAdd = 100;
	message = "Vehicle Lockpicked";
	name = "Vehicle Lockpicked";
};

class PatrolMissionPoint {
	expToAdd = 75;
	message = "Patrol Point Completed";
	name = "Patrol Point";
};

class PatrolMissionComplete {
	expToAdd = 800;
	message = "Patrol Mission Completed";
	name = "Patrol Mission";
};

class VehicleImpounded {
	expToAdd = 500;
	message = "Impounded Vehicle";
	name = "Vehicle Impounded";
};

class VehicleCrushed {
	expToAdd = 800;
	message = "Crushed Vehicle";
	name = "Vehicle Crushed";
};

class Suicide {
	expToAdd = 450;
	message = "For our brothers";
	name = "Suicide";
};

class buyHouse {
	expToAdd = 700;
	message = "Property Purchasing";
	name = "Buy House";
};

class playerJailed {
	expToAdd = 800;
	message = "Cleaning the streets";
	name = "Jailed Player";
};

class robshop {
	expToAdd = 350;
	message = "Armed Robbery";
	name = "Robbed Shop";
};

class robbank {
	expToAdd = 2000;
	message = "Armed Bank Robbery";
	name = "Robbed Bank";
};

class robevidence {
	expToAdd = 2500;
	message = "Evidence Locker Robbery";
	name = "Raided Evidence Locker";
};

class FixSafe {
	expToAdd = 1300;
	message = "Fixed the Safe!";
	name = "Fixed Safe";
};

class DMV {
	expToAdd = 300;
	message = "Drivers Test Passed";
	name = "Passed Drivers Test";
};

class santa {
	expToAdd = 300;
	message = "Merry Christmas!";
	name = "Merry Christmas";
};

class PickupEvidence {
	expToAdd = 150;
	message = "Picked up Evidence";
	name = "Picked Up Evidence";
};

class CPR {
	expToAdd = 150;
	message = "Picked up a Player!";
	name = "CPR Player";
};

class Stabalize {
	expToAdd = 200;
	message = "Extended lifetime for someone!";
	name = "Stablized Player";
};

class Revive {
	expToAdd = 250;
	message = "Helped out the injured!";
	name = "Revived Player";
};

class burglary {
	expToAdd = 350;
	message = "Burglary";
	name = "Robbed House";
};

class playtime {
	expToAdd = 350;
	message = "Taking a slot!";
	name = "Playing On the Server";
};

class playtime_servername {
	expToAdd = 500;
	message = "Taking a slot!";
	name = "Playing On the Server";
};

class kill {
	expToAdd = 250;
	message = "You killed a player!";
	name = "Killed A Player";
};

class dailyRewardSmall {
	expToAdd = 500;
	message = "Small reward for logging in Daily!";
	name = "Small Daily Reward";
};

class dailyRewardMedium {
	expToAdd = 1000;
	message = "Medium reward for logging in Daily!";
	name = "Medium Daily Reward";
};

class dailyRewardLarge {
	expToAdd = 3000;
	message = "Large reward for logging in Daily!";
	name = "Large Daily Reward";
};

class Kill200 {
	expToAdd = 50;
	message = "You got XP for that kill (100-200 Meters)";
	name = "Kill someone from 100-200 Meters";
};

class Kill300 {
	expToAdd = 100;
	message = "You got XP for that kill (200-300 Meters)";
	name = "Kill someone from 200-300 Meters";
};

class Kill400 {
	expToAdd = 200;
	message = "You got XP for that kill (300-400 Meters)";
	name = "Kill someone from 300-400 Meters";
};

class Kill500 {
	expToAdd = 300;
	message = "You got XP for that kill (400-500 Meters)";
	name = "Kill someone from 400-500 Meters";
};

class KillFar {
	expToAdd = 500;
	message = "You got XP for that kill (500+ Meters)";
	name = "Kill someone from 500+ Meters";
};

class RobATM {
	expToAdd = 350;
	message = "ATM Robbery";
	name = "Rob an ATM";
};

class ticket_signed {
	expToAdd = 75;
	message = "Ticket Signed";
	name = "Have a player sign a ticket";
};

class gather {
	expToAdd = 75;
	message = "Gathered a crop";
	name = "Harvest a crop";
};

class repairshit {
	expToAdd = 75;
	message = "Repair Object";
	name = "Repair an Object";
};

class weed_grow {
	expToAdd = 75;
	message = "Growing Weed";
	name = "Grow some Weed";
};

class seizeWeed {
	expToAdd = 350;
	message = "Seized some Weed";
	name = "Seize some of that Chronic";
};

class skinAnimal {
	expToAdd = 150;
	message = "Skinned an Animal";
	name = "Skin an Animal";
};

class gutTurtle {
	expToAdd = 300;
	message = "Gutted a Turtle";
	name = "Gut a Turtle";
};

class CapBase {
	expToAdd = 1000;
	message = "Captured an enemy base";
	name = "Capture an Enemy Base";
};

class DecapBase {
	expToAdd = 1500;
	message = "Decaptured an enemy base";
	name = "Decapture an Enemy Base";
};

class relic {
	expToAdd = 12500;
	message = "Completed Quest: Collecting Relics - Part 1";
	name = "Complete the Collecting Relics - Part 1 Quest";
};

class relic2 {
	expToAdd = 20000;
	message = "Completed Quest: Collecting Relics - Part 2";
	name = "Complete the Collecting Relics - Part 2 Quest";
};

class relic3 {
	expToAdd = 15000;
	message = "Completed Quest: Collecting The Lost Flight Plan";
	name = "Complete the Lost Flight Plan Quest";
};

class relic4 {
	expToAdd = 20000;
	message = "Completed Quest: The Lost Aircraft";
	name = "Complete The Lost Aircraft Quest";
};

class repairWall {
	expToAdd = 750;
	message = "Repaired a damaged part of the border!";
	name = "Repair a damaged part of the border.";
};

class organHarvest {
	expToAdd = 1000;
	message = "It was a joke! You are sick!";
	name = "Harvest an organ. I DARE YOU!";

}