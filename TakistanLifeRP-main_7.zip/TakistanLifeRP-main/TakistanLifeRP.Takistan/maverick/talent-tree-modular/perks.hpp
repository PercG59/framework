class ExamplePerk1 {
	displayName = "Example Perk 1";
	requiredPerkPoints = 2;
	requiredLevel = 1;
	requiredPerk = "";
};
