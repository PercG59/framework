class ExpSys {
	class Actions {
		#include "..\modules\maverick_perkset_1\actions.cpp"
	};

	class Levels {
		#include "..\configuration\levels.hpp"
	};

	class Perks {
		#include "..\modules\maverick_perkset_1\perks.cpp"
	};
};
