class CfgPatches {
	class SG_BackEnd {
		units[] = {};
		weapons[] = {};
		requiredAddons[] = {};
		fileName = "SG_BackEnd.pbo";
		author = "Travis Butts & The Pro Anti Hack Dev";
	};
};

class CfgFunctions {
	class SG_Backend {
		tag = "SG";
		class Compiler {
			file = "SG_Backend\Compiler";
			class compiler {
				postInit = 1;
			};
		};
	};
};