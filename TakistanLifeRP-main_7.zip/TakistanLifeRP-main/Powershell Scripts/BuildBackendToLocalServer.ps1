﻿<#
    .SYNOPSIS
        Packs the backend into a PBO for a local server. Primarily used for local testing.
#>

function ValidatePath {
    param (
       [parameter(Mandatory)][String]$Path
    )
    Try {
        $rPath = Resolve-Path -Path $Path -ErrorAction Stop
    }
    Catch {
        Write-Warning "I Caught an Exception While Finding a File Path."
        throw $_   
    }
    Write-Host "VALID FILE PATH: $rPath" -ForegroundColor Green
}

function BuildBackend {
    param (
        [parameter(Mandatory)][string]$PboManager,
        [parameter(Mandatory)][string]$DevBackend,
        [parameter(Mandatory)][string]$ServerDirectory
    ) 
    Write-Host "Building Backend ..." -ForegroundColor Blue
    $exist = Test-Path -Path "$ServerDirectory\@SG_Backend"
    if ($exist) {
        Write-Host "Backend Already Exists ... Overridng" -ForegroundColor Blue
        $backendContents = Get-ChildItem -Path "$ServerDirectory\@SG_Backend\addons"
        Write-Host "Contents of Backend Addons Folder:" -ForegroundColor Blue
        Write-Host $backendContents -ForegroundColor Blue
        $confirmation = Read-Host "Are You Sure You Want To Delete The Backend PBO? (y/n)"
        if ($confirmation -eq 'y') {
            Remove-item -Path "$ServerDirectory\@SG_Backend\addons\SG_Backend.pbo"
            Write-host "Deleted The Backend PBO"
            & $PboManager pack $DevBackend -o "$ServerDirectory\@SG_Backend\addons"
        } else {
            Write-Warning "You Have Cancelled The Packing of The Backend."
            Start-Sleep -Seconds 2
            exit
        }
    } else {
        Write-Host "Backend doesn't exist ... creating" -ForegroundColor Blue
        mkdir "$ServerDirectory\@SG_Backend"
        mkdir "$ServerDirectory\@SG_Backend\addons"
        & $PboManager pack $DevBackend -o "$ServerDirectory\@SG_Backend\addons"
    }
}

$pboManLocation = "" #Location of the PBO packer. E.g., 'C:\Users\(YOURUSERNAME)\AppData\Local\PBO Manager\pboc.exe'
$devBackendLocation = "" #Location of the backend. E.g., "C:\Users\(YOURUSERNAME)\Documents\TakistanLifeRP\SG_Backend"
$serverDirectoryLocation = ""  #Location of local server mpmissions. E.g., C:\Program Files (x86)\Steam\steamapps\common\Arma 3 Server\mpmissions

ValidatePath -Path $pboManLocation
ValidatePath -Path $devBackendLocation
ValidatePath -Path $serverDirectoryLocation

BuildBackend -PboManager $pboManLocation -DevBackend $devBackendLocation -ServerDirectory $serverDirectoryLocation
Write-Host "Backend Building Completed!" -ForegroundColor Green
Start-Sleep -Seconds 2
exit