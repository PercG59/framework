﻿function ValidatePath {
    param (
       [parameter(Mandatory)][String]$Path
    )
    Try {
        $rPath = Resolve-Path -Path $Path -ErrorAction Stop
    }
    Catch {
        Write-Warning "I Caught an Exception While Finding a File Path."
        throw $_   
    }
    Write-Host "VALID FILE PATH: $rPath" -ForegroundColor Green
}

$devMissionFileLocation = "" #Where the mission is actually stored. E.g., C:\Users\(YOURUSERNAME)\Documents\TakistanLifeRP\SperoGaming.Takistan
$profileMissionFileLocation = "" #Where you want to send the mission. E.g., C:\Users\(YOURUSERNAME)\Documents\Arma 3 - Other Profiles\(ARMA3PROFILENAME)\missions

ValidatePath -Path $devMissionFileLocation
ValidatePath -Path $profileMissionFileLocation

Copy-Item -Path "$devMissionFileLocation" -Destination "$profileMissionFileLocation" -Recurse -Force