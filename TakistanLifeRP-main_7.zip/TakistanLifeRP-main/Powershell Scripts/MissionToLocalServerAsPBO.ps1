﻿function ValidatePath {
    param (
       [parameter(Mandatory)][String]$Path
    )
    Try {
        $rPath = Resolve-Path -Path $Path -ErrorAction Stop
    }
    Catch {
        Write-Warning "I Caught an Exception While Finding a File Path."
        throw $_   
    }
    Write-Host "VALID FILE PATH: $rPath" -ForegroundColor Green
}

$pboManLocation = '' #Location of the PBO packer. E.g., C:\Users\(YOURUSERNAME)\AppData\Local\PBO Manager\pboc.exe
$devMissionFileLocation = "" #Location of where the misison is. E.g., C:\Users\(YOURUSERNAME)\Documents\TakistanLifeRP\SperoGaming.Takistan
$serverMissionFileLocation = "" #Location of local server mpmissions. E.g., C:\Program Files (x86)\Steam\steamapps\common\Arma 3 Server\mpmissions

ValidatePath -Path $pboManLocation
ValidatePath -Path $devMissionFileLocation
ValidatePath -Path $serverMissionFileLocation

Remove-Item "$serverMissionFileLocation\TakistanLifeRP.Takistan.pbo" 
& $pboManLocation pack $devMissionFileLocation -o $serverMissionFileLocation
Rename-Item -Path "$serverMissionFileLocation\SperoGaming.Takistan.pbo" -NewName "TakistanLifeRP.Takistan.pbo"