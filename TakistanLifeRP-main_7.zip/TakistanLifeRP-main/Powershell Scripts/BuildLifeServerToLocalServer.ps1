﻿<#
    .SYNOPSIS
        Packs the life_server into a PBO for a local server. Primarily used for local testing.
#>

function ValidatePath {
    param (
       [parameter(Mandatory)][String]$Path
    )
    Try {
        $rPath = Resolve-Path -Path $Path -ErrorAction Stop
    }
    Catch {
        Write-Warning "I Caught an Exception While Finding a File Path."
        throw $_   
    }
    Write-Host "VALID FILE PATH: $rPath" -ForegroundColor Green
}

function BuildLifeServer {
    param (
        [parameter(Mandatory)][string]$PboManager,
        [parameter(Mandatory)][string]$Devlife_server,
        [parameter(Mandatory)][string]$ServerDirectory
    ) 
    Write-Host "Building life_server ..." -ForegroundColor Blue
    $exist = Test-Path -Path "$ServerDirectory\@SG_life_server"
    if ($exist) {
        Write-Host "life_server Already Exists ... Overridng" -ForegroundColor Blue
        $life_serverContents = Get-ChildItem -Path "$ServerDirectory\@SG_life_server\addons"
        Write-Host "Contents of life_server Addons Folder:" -ForegroundColor Blue
        Write-Host $life_serverContents -ForegroundColor Blue
        $confirmation = Read-Host "Are You Sure You Want To Delete The life_server PBO? (y/n)"
        if ($confirmation -eq 'y') {
            Remove-item -Path "$ServerDirectory\@SG_life_server\addons\life_server.pbo"
            Write-host "Deleted The life_server PBO"
            & $PboManager pack $Devlife_server -o "$ServerDirectory\@SG_life_server\addons"
        } else {
            Write-Warning "You Have Cancelled The Packing of The life_server."
            Start-Sleep -Seconds 2
            exit
        }
    } else {
        Write-Host "life_server doesn't exist ... creating" -ForegroundColor Blue
        mkdir "$ServerDirectory\@SG_life_server"
        mkdir "$ServerDirectory\@SG_life_server\addons"
        & $PboManager pack $Devlife_server -o "$ServerDirectory\@SG_life_server\addons"
    }
}

$pboManLocation = "" #Location of the PBO packer. E.g., 'C:\Users\(YOURUSERNAME)\AppData\Local\PBO Manager\pboc.exe'
$devLifeServerLocation = "" #Location of the life_server. E.g., "C:\Users\(YOURUSERNAME)\Documents\TakistanLifeRP\SG_life_server"
$serverDirectoryLocation = ""  #Location of local server mpmissions. E.g., C:\Program Files (x86)\Steam\steamapps\common\Arma 3 Server\mpmissions

ValidatePath -Path $pboManLocation
ValidatePath -Path $devLifeServerLocation
ValidatePath -Path $serverDirectoryLocation

BuildLifeServer -PboManager $pboManLocation -Devlife_server $devLifeServerLocation -ServerDirectory $serverDirectoryLocation
Write-Host "life_server Building Completed!" -ForegroundColor Green
Start-Sleep -Seconds 2
exit