---
name: Bug Report
about: Create a bug report
title: "[BUG]"
labels: bug
assignees: ''

---

**Describe the bug**
- A clear and concise description of what the bug is:
<br></br>

**To Reproduce**
- Steps to reproduce the behaviour:
1. 

<br></br>
**Expected behaviour**
- A clear and concise description of what you expected to happen:

<br></br>
**Screenshots**
- If applicable, add screenshots to help explain your problem:

<br></br>
**RPT log file:**
- Add a link ([gist](https://gist.github.com) or [pastebin](http://pastebin.com)) to the client and/or server RPT file. An instruction to find your RPT files can be found [here](https://community.bistudio.com/wiki/Crash_Files#Arma_3):
