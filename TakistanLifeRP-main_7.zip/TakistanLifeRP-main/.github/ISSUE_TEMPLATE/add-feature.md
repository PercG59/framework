---
name: Add Feature
about: Add this feature
title: "[ADD]"
labels: add
assignees: ''

---

**Describe what feature that needs to be added:**
