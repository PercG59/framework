---
name: Feature Request
about: Suggest an idea for this project
title: "[SUGGESTION]"
labels: suggestion
assignees: ''

---

**Is the suggestion related to a problem? Please describe.**
- A clear and concise description of what the problem is. 

<br></br>
**Describe the suggestion**
- A clear and concise description of what the suggestion is.

<br></br>
**Additional context**
- Add any other context or documentation about the suggestion here.
